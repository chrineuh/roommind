(function(){var e={en:{"room.climate_control_toggle":`Climate control`,"override.label":`Temporary Override`,"override.comfort":`Comfort`,"override.eco":`Eco`,"override.custom":`Custom`,"override.target":`Target:`,"override.heat_to":`Heat to:`,"override.cool_above":`Cool above:`,"override.invalid_band":`Cooling target must be at or above the heating target`,"override.activate_for":`Activate for:`,"override.error_set":`Failed to set override`,"override.error_clear":`Failed to clear override`,"hero.target":`Target`,"hero.override":`Override`,"hero.remaining":`{time} remaining`,"hero.humidity":`{value}% humidity`,"hero.device_setpoint":`Device set to {value}{unit}`,"hero.heat_source_primary":`Heating: TRV`,"hero.heat_source_secondary":`Heating: AC`,"hero.heat_source_both":`Heating: TRV + AC`,"hero.permanent":`Permanent`,"hero.waiting":`Waiting for sensor data...`,"hero.not_configured":`Not configured yet`,"hero.mpc_learning_paused":`MPC learning paused`,"hero.mpc_learning_paused.outdoor_unavailable":`RoomMind needs an outdoor temperature to learn this room's thermal model. The configured outdoor sensor is unavailable and no weather entity is set as a fallback. Configure either in Settings.`,"hero.compressor_protection_min_off":`Compressor protection: waiting for min-off`,"hero.compressor_protection_min_off_left":`Compressor protection: waiting for min-off, {minutes} min left`,"hero.compressor_protection_min_run":`Compressor protection: min-run active`,"hero.compressor_protection_min_run_left":`Compressor protection: min-run, {minutes} min left`,"hero.compressor_protection_info":`This room shares an outdoor compressor with other rooms. To prevent short-cycling, the shared compressor group enforces a minimum run time and a minimum off time before this device is allowed to switch again.`,"hero.coil_dry":`Drying ({minutes} min)`,"hero.coil_dry_drain":`Draining ({minutes} min)`,"hero.coil_dry_info":`The AC is running its evaporator drying cycle and switches off afterwards. Cooling demand cancels it immediately.`,"card.target":`Target`,"card.waiting":`Waiting for data...`,"card.humidity":`{value}% humidity`,"card.thermostat":`Thermostat`,"card.thermostats":`Thermostats`,"card.ac":`AC`,"card.acs":`ACs`,"card.climate_device":`climate device`,"card.climate_devices":`climate devices`,"card.temp_sensor":`temp sensor`,"card.temp_sensors":`temp sensors`,"card.no_climate":`No climate devices`,"card.outdoor":`Outdoor`,"card.tap_configure":`Tap to configure`,"card.mpc_active":`MPC active`,"card.mpc_learning":`MPC learning`,"card.compressor_min_run":`Min run {minutes} min`,"card.compressor_min_off":`Min off {minutes} min`,"card.not_controlled":`Not controlled by RoomMind`,"mode.auto":`Auto`,"mode.auto_desc":`Heats & cools automatically based on target temperature`,"mode.heat_only":`Heat Only`,"mode.heat_only_desc":`Heats only. With thermostats in the room, ACs stay off unless smart source selection is on`,"mode.cool_only":`Cool Only`,"mode.cool_only_desc":`Only uses ACs, thermostats stay off`,"mode.heating":`Heating`,"mode.cooling":`Cooling`,"mode.idle":`Standby`,"hero.window_open":`Window open – paused`,"card.window_open":`Window open`,"card.presence_away":`Away`,"card.mold_warning":`Mold risk`,"card.mold_critical":`Mold danger!`,"card.mold_prevention":`Mold prevention +{delta}{unit}`,"roomcard.name":`RoomMind room`,"roomcard.description":`Room status with temporary override, mode and comfort/eco temperatures.`,"roomcard.no_area":`Choose a room in the card settings.`,"roomcard.loading":`Loading…`,"roomcard.unknown_room":`This room is not set up in RoomMind yet.`,"roomcard.open_room":`Open in RoomMind`,"roomcard.mode":`Mode`,"roomcard.temperatures":`Temperatures`,"roomcard.lower":`Lower {name}`,"roomcard.raise":`Raise {name}`,"roomcard.error_save":`Saving failed`,"roomcard.editor.area":`Room`,"roomcard.editor.hide_override":`Hide temporary override`,"roomcard.editor.hide_mode":`Hide mode (auto, heat only, cool only)`,"roomcard.editor.hide_climate_control":`Hide climate control switch`,"roomcard.editor.hide_temperatures":`Hide comfort and eco temperatures`,"roomcard.paused":`paused`,"roomcard.editor.compact":`Compact layout`},de:{"room.climate_control_toggle":`Klimasteuerung`,"override.label":`Temporärer Override`,"override.comfort":`Komfort`,"override.eco":`Eco`,"override.custom":`Individuell`,"override.target":`Ziel:`,"override.heat_to":`Heizen bis:`,"override.cool_above":`Kühlen ab:`,"override.invalid_band":`Das Kühlziel muss mindestens so hoch wie das Heizziel sein`,"override.activate_for":`Aktivieren für:`,"override.error_set":`Override konnte nicht gesetzt werden`,"override.error_clear":`Override konnte nicht aufgehoben werden`,"hero.target":`Ziel`,"hero.override":`Override`,"hero.remaining":`noch {time}`,"hero.humidity":`{value}% Luftfeuchtigkeit`,"hero.device_setpoint":`Gerät auf {value}{unit}`,"hero.heat_source_primary":`Heizung: TRV`,"hero.heat_source_secondary":`Heizung: AC`,"hero.heat_source_both":`Heizung: TRV + AC`,"hero.permanent":`Dauerhaft`,"hero.waiting":`Warte auf Sensordaten...`,"hero.not_configured":`Noch nicht konfiguriert`,"hero.mpc_learning_paused":`MPC-Lernen pausiert`,"hero.mpc_learning_paused.outdoor_unavailable":`RoomMind benötigt eine Außentemperatur, um das thermische Modell dieses Raums zu lernen. Der konfigurierte Außensensor ist nicht verfügbar und es ist keine Wetter-Entity als Fallback gesetzt. Konfiguriere eine der beiden in den Einstellungen.`,"hero.compressor_protection_min_off":`Kompressorschutz: wartet auf Mindestpause`,"hero.compressor_protection_min_off_left":`Kompressorschutz: Mindestpause, noch {minutes} Min`,"hero.compressor_protection_min_run":`Kompressorschutz: Mindestlaufzeit aktiv`,"hero.compressor_protection_min_run_left":`Kompressorschutz: Mindestlaufzeit, noch {minutes} Min`,"hero.compressor_protection_info":`Dieser Raum teilt sich eine Außeneinheit (Kompressor) mit anderen Räumen. Um Kurzzyklen zu vermeiden, erzwingt die Kompressorgruppe eine Mindestlaufzeit und eine Mindestpause, bevor dieses Gerät wieder umschalten darf.`,"hero.coil_dry":`Trocknet ({minutes} Min)`,"hero.coil_dry_drain":`Kondensat läuft ab ({minutes} Min)`,"hero.coil_dry_info":`Das Klimagerät führt seinen Verdampfer-Trocknungslauf aus und schaltet danach ab. Kühlbedarf bricht ihn sofort ab.`,"card.target":`Ziel`,"card.waiting":`Warte auf Daten...`,"card.humidity":`{value}% Luftfeuchtigkeit`,"card.thermostat":`Thermostat`,"card.thermostats":`Thermostate`,"card.ac":`Klimaanlage`,"card.acs":`Klimaanlagen`,"card.climate_device":`Klimagerät`,"card.climate_devices":`Klimageräte`,"card.temp_sensor":`Temperatursensor`,"card.temp_sensors":`Temperatursensoren`,"card.no_climate":`Keine Klimageräte`,"card.outdoor":`Außen`,"card.tap_configure":`Tippen zum Konfigurieren`,"card.mpc_active":`MPC aktiv`,"card.mpc_learning":`MPC lernt`,"card.compressor_min_run":`Mindestlauf {minutes} Min`,"card.compressor_min_off":`Mindestpause {minutes} Min`,"card.not_controlled":`Nicht von RoomMind gesteuert`,"mode.auto":`Automatisch`,"mode.auto_desc":`Heizt und kühlt automatisch basierend auf der Zieltemperatur`,"mode.heat_only":`Nur Heizen`,"mode.heat_only_desc":`Nur Heizen. Mit Thermostaten im Raum bleiben Klimaanlagen aus, außer die intelligente Quellenauswahl ist an`,"mode.cool_only":`Nur Kühlen`,"mode.cool_only_desc":`Nutzt nur Klimaanlagen, Thermostate bleiben aus`,"mode.heating":`Heizen`,"mode.cooling":`Kühlen`,"mode.idle":`Standby`,"hero.window_open":`Fenster offen – pausiert`,"card.window_open":`Fenster offen`,"card.presence_away":`Abwesend`,"card.mold_warning":`Schimmelrisiko`,"card.mold_critical":`Schimmelgefahr!`,"card.mold_prevention":`Schimmelschutz +{delta}{unit}`,"roomcard.name":`RoomMind-Raum`,"roomcard.description":`Raumstatus mit temporärem Override, Modus und Komfort-/Eco-Temperaturen.`,"roomcard.no_area":`Wähle in den Karteneinstellungen einen Raum.`,"roomcard.loading":`Lädt…`,"roomcard.unknown_room":`Dieser Raum ist in RoomMind noch nicht eingerichtet.`,"roomcard.open_room":`In RoomMind öffnen`,"roomcard.mode":`Modus`,"roomcard.temperatures":`Temperaturen`,"roomcard.lower":`{name} senken`,"roomcard.raise":`{name} erhöhen`,"roomcard.error_save":`Speichern fehlgeschlagen`,"roomcard.editor.area":`Raum`,"roomcard.editor.hide_override":`Temporären Override ausblenden`,"roomcard.editor.hide_mode":`Modus ausblenden (Automatisch, Nur Heizen, Nur Kühlen)`,"roomcard.editor.hide_climate_control":`Schalter für die Klimasteuerung ausblenden`,"roomcard.editor.hide_temperatures":`Komfort- und Eco-Temperaturen ausblenden`,"roomcard.paused":`pausiert`,"roomcard.editor.compact":`Kompakte Darstellung`},fr:{"room.climate_control_toggle":`Contrôle climatique`,"override.label":`Dérogation temporaire`,"override.comfort":`Confort`,"override.eco":`Éco`,"override.custom":`Personnalisé`,"override.target":`Cible:`,"override.heat_to":`Chauffer jusqu'à:`,"override.cool_above":`Refroidir au-dessus de:`,"override.invalid_band":`La cible de refroidissement doit être supérieure ou égale à la cible de chauffage`,"override.activate_for":`Activer pendant:`,"override.error_set":`Échec lors de la configuration de la dérogation`,"override.error_clear":`Échec lors de la suppression de la dérogation`,"hero.target":`Cible`,"hero.override":`Dérogation`,"hero.remaining":`{time} restant`,"hero.humidity":`{value}% humidité`,"hero.device_setpoint":`Appareil réglé sur {value}{unit}`,"hero.heat_source_primary":`Chauffage: vannes thermostatiques`,"hero.heat_source_secondary":`Chauffage: Climatisation`,"hero.heat_source_both":`Chauffage: Vannes thermostatiques + Climatisation`,"hero.permanent":`Permanent`,"hero.waiting":`En attente des données du capteur...`,"hero.not_configured":`Pas encore configuré`,"hero.mpc_learning_paused":`Apprentissage du MPC en pause`,"hero.mpc_learning_paused.outdoor_unavailable":`RoomMind a besoin d'une température extérieure pour apprendre le modèle thermique de cette pièce. Le capteur extérieur configuré n'est pas disponible et aucune entité météo n'est définie comme solution de secours. Configurez l'un ou l'autre dans les Paramètres.`,"hero.compressor_protection_min_off":`Protection du compresseur : attente du délai minimal d'arrêt`,"hero.compressor_protection_min_off_left":`Protection du compresseur : délai minimal d'arrêt, encore {minutes} min`,"hero.compressor_protection_min_run":`Protection du compresseur : durée minimale de fonctionnement active`,"hero.compressor_protection_min_run_left":`Protection du compresseur : durée minimale de fonctionnement, encore {minutes} min`,"hero.compressor_protection_info":`Cette pièce partage une unité extérieure (compresseur) avec d'autres pièces. Pour éviter les cycles courts, le groupe de compresseurs impose une durée minimale de fonctionnement et un délai minimal d'arrêt avant que cet appareil ne puisse à nouveau changer d'état.`,"hero.coil_dry":`Séchage ({minutes} min)`,"hero.coil_dry_drain":`Écoulement ({minutes} min)`,"hero.coil_dry_info":`Le climatiseur effectue son cycle de séchage de l'évaporateur puis s'arrête. Une demande de refroidissement l'interrompt immédiatement.`,"card.target":`Cible`,"card.waiting":`En attente de données...`,"card.humidity":`{value}% humidité`,"card.thermostat":`Thermostat`,"card.thermostats":`Thermostats`,"card.ac":`Climatisation`,"card.acs":`Climatisations`,"card.climate_device":`appareil de climatisation`,"card.climate_devices":`appareils de climatisation`,"card.temp_sensor":`capteur temp.`,"card.temp_sensors":`capteurs temp.`,"card.no_climate":`Aucun appareil de climatisation`,"card.outdoor":`Extérieur`,"card.tap_configure":`Appuyez pour configurer`,"card.mpc_active":`MPC actif`,"card.mpc_learning":`MPC en apprentissage`,"card.compressor_min_run":`Marche min. {minutes} min`,"card.compressor_min_off":`Arrêt min. {minutes} min`,"card.not_controlled":`Pas contrôlé par RoomMind`,"mode.auto":`Auto`,"mode.auto_desc":`Chauffe et refroidit automatiquement en fonction de la température cible`,"mode.heat_only":`Chauffer seulement`,"mode.heat_only_desc":`Chauffe uniquement. Avec des thermostats dans la pièce, la climatisation reste éteinte, sauf si la sélection intelligente de la source est active`,"mode.cool_only":`Refroidir seulement`,"mode.cool_only_desc":`Utilise seulement la climatisation, les thermostats restent éteints`,"mode.heating":`Chauffage`,"mode.cooling":`Refroidissement`,"mode.idle":`En veille`,"hero.window_open":`Fenêtre ouverte - en pause`,"card.window_open":`Fenêtre ouverte`,"card.presence_away":`Absent`,"card.mold_warning":`Risque de moisissure`,"card.mold_critical":`Danger de moisissure !`,"card.mold_prevention":`Prévention de la moisissure +{delta}{unit}`,"roomcard.name":`Pièce RoomMind`,"roomcard.description":`État de la pièce avec dérogation temporaire, mode et températures confort/éco.`,"roomcard.no_area":`Choisissez une pièce dans les paramètres de la carte.`,"roomcard.loading":`Chargement…`,"roomcard.unknown_room":`Cette pièce n'est pas encore configurée dans RoomMind.`,"roomcard.open_room":`Ouvrir dans RoomMind`,"roomcard.mode":`Mode`,"roomcard.temperatures":`Températures`,"roomcard.lower":`Baisser {name}`,"roomcard.raise":`Augmenter {name}`,"roomcard.error_save":`Échec de l'enregistrement`,"roomcard.editor.area":`Pièce`,"roomcard.editor.hide_override":`Masquer la dérogation temporaire`,"roomcard.editor.hide_mode":`Masquer le mode (auto, chauffer seulement, refroidir seulement)`,"roomcard.editor.hide_climate_control":`Masquer l'interrupteur du contrôle climatique`,"roomcard.editor.hide_temperatures":`Masquer les températures confort et éco`,"roomcard.paused":`en pause`,"roomcard.editor.compact":`Affichage compact`},it:{"room.climate_control_toggle":`Controllo climatizzazione`,"override.label":`Forzatura temporanea`,"override.comfort":`Comfort`,"override.eco":`Eco`,"override.custom":`Personalizzata`,"override.target":`Obiettivo:`,"override.heat_to":`Riscalda fino a:`,"override.cool_above":`Raffresca sopra:`,"override.invalid_band":`L'obiettivo di raffrescamento deve essere uguale o superiore a quello di riscaldamento`,"override.activate_for":`Attiva per:`,"override.error_set":`Impostazione della forzatura non riuscita`,"override.error_clear":`Annullamento della forzatura non riuscito`,"hero.target":`Obiettivo`,"hero.override":`Forzatura`,"hero.remaining":`{time} rimanenti`,"hero.humidity":`{value}% di umidità`,"hero.device_setpoint":`Dispositivo impostato a {value}{unit}`,"hero.heat_source_primary":`Riscaldamento: TRV`,"hero.heat_source_secondary":`Riscaldamento: AC`,"hero.heat_source_both":`Riscaldamento: TRV + AC`,"hero.permanent":`Permanente`,"hero.waiting":`In attesa dei dati dai sensori...`,"hero.not_configured":`Non ancora configurata`,"hero.mpc_learning_paused":`Apprendimento MPC in pausa`,"hero.mpc_learning_paused.outdoor_unavailable":`RoomMind ha bisogno di una temperatura esterna per apprendere il modello termico di questa stanza. Il sensore esterno configurato non è disponibile e non è impostata alcuna entità meteo come alternativa. Configurane una nelle Impostazioni.`,"hero.compressor_protection_min_off":`Protezione compressore: attesa tempo minimo di spegnimento`,"hero.compressor_protection_min_off_left":`Protezione compressore: tempo minimo di spegnimento, ancora {minutes} min`,"hero.compressor_protection_min_run":`Protezione compressore: tempo minimo di funzionamento attivo`,"hero.compressor_protection_min_run_left":`Protezione compressore: tempo minimo di funzionamento, ancora {minutes} min`,"hero.compressor_protection_info":`Questa stanza condivide un compressore esterno con altre stanze. Per evitare cicli troppo brevi, il gruppo compressore condiviso impone un tempo minimo di funzionamento e un tempo minimo di spegnimento prima che questo dispositivo possa commutare di nuovo.`,"hero.coil_dry":`Asciugatura ({minutes} min)`,"hero.coil_dry_drain":`Scarico ({minutes} min)`,"hero.coil_dry_info":`Il condizionatore sta eseguendo il ciclo di asciugatura dell'evaporatore e poi si spegne. Una richiesta di raffreddamento lo annulla subito.`,"card.target":`Obiettivo`,"card.waiting":`In attesa di dati...`,"card.humidity":`{value}% di umidità`,"card.thermostat":`termostato`,"card.thermostats":`termostati`,"card.ac":`AC`,"card.acs":`AC`,"card.climate_device":`dispositivo di climatizzazione`,"card.climate_devices":`dispositivi di climatizzazione`,"card.temp_sensor":`sensore temp.`,"card.temp_sensors":`sensori temp.`,"card.no_climate":`Nessun dispositivo di climatizzazione`,"card.outdoor":`Esterno`,"card.tap_configure":`Tocca per configurare`,"card.mpc_active":`MPC attivo`,"card.mpc_learning":`MPC in apprendimento`,"card.compressor_min_run":`Funz. minimo {minutes} min`,"card.compressor_min_off":`Pausa minima {minutes} min`,"card.not_controlled":`Non controllata da RoomMind`,"mode.auto":`Auto`,"mode.auto_desc":`Riscalda e raffresca automaticamente in base alla temperatura obiettivo`,"mode.heat_only":`Solo riscaldamento`,"mode.heat_only_desc":`Solo riscaldamento. Con termostati nella stanza, gli AC restano spenti, salvo con la scelta intelligente della fonte attiva`,"mode.cool_only":`Solo raffrescamento`,"mode.cool_only_desc":`Usa solo gli AC, i termostati restano spenti`,"mode.heating":`Riscaldamento`,"mode.cooling":`Raffrescamento`,"mode.idle":`Standby`,"hero.window_open":`Finestra aperta – in pausa`,"card.window_open":`Finestra aperta`,"card.presence_away":`Fuori casa`,"card.mold_warning":`Rischio muffa`,"card.mold_critical":`Pericolo muffa!`,"card.mold_prevention":`Prevenzione muffa +{delta}{unit}`,"roomcard.name":`Stanza RoomMind`,"roomcard.description":`Stato della stanza con forzatura temporanea, modalità e temperature comfort/eco.`,"roomcard.no_area":`Scegli una stanza nelle impostazioni della scheda.`,"roomcard.loading":`Caricamento…`,"roomcard.unknown_room":`Questa stanza non è ancora configurata in RoomMind.`,"roomcard.open_room":`Apri in RoomMind`,"roomcard.mode":`Modalità`,"roomcard.temperatures":`Temperature`,"roomcard.lower":`Abbassa {name}`,"roomcard.raise":`Alza {name}`,"roomcard.error_save":`Salvataggio non riuscito`,"roomcard.editor.area":`Stanza`,"roomcard.editor.hide_override":`Nascondi forzatura temporanea`,"roomcard.editor.hide_mode":`Nascondi modalità (auto, solo riscaldamento, solo raffrescamento)`,"roomcard.editor.hide_climate_control":`Nascondi interruttore del controllo climatizzazione`,"roomcard.editor.hide_temperatures":`Nascondi temperature comfort ed eco`,"roomcard.paused":`in pausa`,"roomcard.editor.compact":`Visualizzazione compatta`}};function t(t,n,r){let i=(e[n]??e[n.split(`-`)[0]]??e.en)[t]??e.en[t]??t;if(r)for(let[e,t]of Object.entries(r))i=i.replaceAll(`{${e}}`,String(t));return i}var n=globalThis,r=n.ShadowRoot&&(n.ShadyCSS===void 0||n.ShadyCSS.nativeShadow)&&`adoptedStyleSheets`in Document.prototype&&`replace`in CSSStyleSheet.prototype,i=Symbol(),a=new WeakMap,o=class{constructor(e,t,n){if(this._$cssResult$=!0,n!==i)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=e,this.t=t}get styleSheet(){let e=this.o,t=this.t;if(r&&e===void 0){let n=t!==void 0&&t.length===1;n&&(e=a.get(t)),e===void 0&&((this.o=e=new CSSStyleSheet).replaceSync(this.cssText),n&&a.set(t,e))}return e}toString(){return this.cssText}},s=e=>new o(typeof e==`string`?e:e+``,void 0,i),c=(e,...t)=>new o(e.length===1?e[0]:t.reduce((t,n,r)=>t+(e=>{if(!0===e._$cssResult$)return e.cssText;if(typeof e==`number`)return e;throw Error(`Value passed to 'css' function must be a 'css' function result: `+e+`. Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.`)})(n)+e[r+1],e[0]),e,i),l=(e,t)=>{if(r)e.adoptedStyleSheets=t.map(e=>e instanceof CSSStyleSheet?e:e.styleSheet);else for(let r of t){let t=document.createElement(`style`),i=n.litNonce;i!==void 0&&t.setAttribute(`nonce`,i),t.textContent=r.cssText,e.appendChild(t)}},u=r?e=>e:e=>e instanceof CSSStyleSheet?(e=>{let t=``;for(let n of e.cssRules)t+=n.cssText;return s(t)})(e):e,{is:d,defineProperty:ee,getOwnPropertyDescriptor:te,getOwnPropertyNames:ne,getOwnPropertySymbols:re,getPrototypeOf:ie}=Object,f=globalThis,ae=f.trustedTypes,oe=ae?ae.emptyScript:``,se=f.reactiveElementPolyfillSupport,p=(e,t)=>e,m={toAttribute(e,t){switch(t){case Boolean:e=e?oe:null;break;case Object:case Array:e=e==null?e:JSON.stringify(e)}return e},fromAttribute(e,t){let n=e;switch(t){case Boolean:n=e!==null;break;case Number:n=e===null?null:Number(e);break;case Object:case Array:try{n=JSON.parse(e)}catch{n=null}}return n}},h=(e,t)=>!d(e,t),ce={attribute:!0,type:String,converter:m,reflect:!1,useDefault:!1,hasChanged:h};Symbol.metadata??=Symbol(`metadata`),f.litPropertyMetadata??=new WeakMap;var g=class extends HTMLElement{static addInitializer(e){this._$Ei(),(this.l??=[]).push(e)}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(e,t=ce){if(t.state&&(t.attribute=!1),this._$Ei(),this.prototype.hasOwnProperty(e)&&((t=Object.create(t)).wrapped=!0),this.elementProperties.set(e,t),!t.noAccessor){let n=Symbol(),r=this.getPropertyDescriptor(e,n,t);r!==void 0&&ee(this.prototype,e,r)}}static getPropertyDescriptor(e,t,n){let{get:r,set:i}=te(this.prototype,e)??{get(){return this[t]},set(e){this[t]=e}};return{get:r,set(t){let a=r?.call(this);i?.call(this,t),this.requestUpdate(e,a,n)},configurable:!0,enumerable:!0}}static getPropertyOptions(e){return this.elementProperties.get(e)??ce}static _$Ei(){if(this.hasOwnProperty(p(`elementProperties`)))return;let e=ie(this);e.finalize(),e.l!==void 0&&(this.l=[...e.l]),this.elementProperties=new Map(e.elementProperties)}static finalize(){if(this.hasOwnProperty(p(`finalized`)))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty(p(`properties`))){let e=this.properties,t=[...ne(e),...re(e)];for(let n of t)this.createProperty(n,e[n])}let e=this[Symbol.metadata];if(e!==null){let t=litPropertyMetadata.get(e);if(t!==void 0)for(let[e,n]of t)this.elementProperties.set(e,n)}this._$Eh=new Map;for(let[e,t]of this.elementProperties){let n=this._$Eu(e,t);n!==void 0&&this._$Eh.set(n,e)}this.elementStyles=this.finalizeStyles(this.styles)}static finalizeStyles(e){let t=[];if(Array.isArray(e)){let n=new Set(e.flat(1/0).reverse());for(let e of n)t.unshift(u(e))}else e!==void 0&&t.push(u(e));return t}static _$Eu(e,t){let n=t.attribute;return!1===n?void 0:typeof n==`string`?n:typeof e==`string`?e.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev()}_$Ev(){this._$ES=new Promise(e=>this.enableUpdating=e),this._$AL=new Map,this._$E_(),this.requestUpdate(),this.constructor.l?.forEach(e=>e(this))}addController(e){(this._$EO??=new Set).add(e),this.renderRoot!==void 0&&this.isConnected&&e.hostConnected?.()}removeController(e){this._$EO?.delete(e)}_$E_(){let e=new Map,t=this.constructor.elementProperties;for(let n of t.keys())this.hasOwnProperty(n)&&(e.set(n,this[n]),delete this[n]);e.size>0&&(this._$Ep=e)}createRenderRoot(){let e=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return l(e,this.constructor.elementStyles),e}connectedCallback(){this.renderRoot??=this.createRenderRoot(),this.enableUpdating(!0),this._$EO?.forEach(e=>e.hostConnected?.())}enableUpdating(e){}disconnectedCallback(){this._$EO?.forEach(e=>e.hostDisconnected?.())}attributeChangedCallback(e,t,n){this._$AK(e,n)}_$ET(e,t){let n=this.constructor.elementProperties.get(e),r=this.constructor._$Eu(e,n);if(r!==void 0&&!0===n.reflect){let i=(n.converter?.toAttribute===void 0?m:n.converter).toAttribute(t,n.type);this._$Em=e,i==null?this.removeAttribute(r):this.setAttribute(r,i),this._$Em=null}}_$AK(e,t){let n=this.constructor,r=n._$Eh.get(e);if(r!==void 0&&this._$Em!==r){let e=n.getPropertyOptions(r),i=typeof e.converter==`function`?{fromAttribute:e.converter}:e.converter?.fromAttribute===void 0?m:e.converter;this._$Em=r;let a=i.fromAttribute(t,e.type);this[r]=a??this._$Ej?.get(r)??a,this._$Em=null}}requestUpdate(e,t,n,r=!1,i){if(e!==void 0){let a=this.constructor;if(!1===r&&(i=this[e]),n??=a.getPropertyOptions(e),!((n.hasChanged??h)(i,t)||n.useDefault&&n.reflect&&i===this._$Ej?.get(e)&&!this.hasAttribute(a._$Eu(e,n))))return;this.C(e,t,n)}!1===this.isUpdatePending&&(this._$ES=this._$EP())}C(e,t,{useDefault:n,reflect:r,wrapped:i},a){n&&!(this._$Ej??=new Map).has(e)&&(this._$Ej.set(e,a??t??this[e]),!0!==i||a!==void 0)||(this._$AL.has(e)||(this.hasUpdated||n||(t=void 0),this._$AL.set(e,t)),!0===r&&this._$Em!==e&&(this._$Eq??=new Set).add(e))}async _$EP(){this.isUpdatePending=!0;try{await this._$ES}catch(e){Promise.reject(e)}let e=this.scheduleUpdate();return e!=null&&await e,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this.renderRoot??=this.createRenderRoot(),this._$Ep){for(let[e,t]of this._$Ep)this[e]=t;this._$Ep=void 0}let e=this.constructor.elementProperties;if(e.size>0)for(let[t,n]of e){let{wrapped:e}=n,r=this[t];!0!==e||this._$AL.has(t)||r===void 0||this.C(t,void 0,n,r)}}let e=!1,t=this._$AL;try{e=this.shouldUpdate(t),e?(this.willUpdate(t),this._$EO?.forEach(e=>e.hostUpdate?.()),this.update(t)):this._$EM()}catch(t){throw e=!1,this._$EM(),t}e&&this._$AE(t)}willUpdate(e){}_$AE(e){this._$EO?.forEach(e=>e.hostUpdated?.()),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(e)),this.updated(e)}_$EM(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$ES}shouldUpdate(e){return!0}update(e){this._$Eq&&=this._$Eq.forEach(e=>this._$ET(e,this[e])),this._$EM()}updated(e){}firstUpdated(e){}};g.elementStyles=[],g.shadowRootOptions={mode:`open`},g[p(`elementProperties`)]=new Map,g[p(`finalized`)]=new Map,se?.({ReactiveElement:g}),(f.reactiveElementVersions??=[]).push(`2.1.2`);var _=globalThis,le=e=>e,v=_.trustedTypes,ue=v?v.createPolicy(`lit-html`,{createHTML:e=>e}):void 0,de=`$lit$`,y=`lit$${Math.random().toFixed(9).slice(2)}$`,fe=`?`+y,pe=`<${fe}>`,b=document,x=()=>b.createComment(``),S=e=>e===null||typeof e!=`object`&&typeof e!=`function`,C=Array.isArray,me=e=>C(e)||typeof e?.[Symbol.iterator]==`function`,w=`[ 	
\f\r]`,T=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,E=/-->/g,D=/>/g,O=RegExp(`>|${w}(?:([^\\s"'>=/]+)(${w}*=${w}*(?:[^ \t\n\f\r"'\`<>=]|("|')|))|$)`,`g`),he=/'/g,ge=/"/g,_e=/^(?:script|style|textarea|title)$/i,k=(e=>(t,...n)=>({_$litType$:e,strings:t,values:n}))(1),A=Symbol.for(`lit-noChange`),j=Symbol.for(`lit-nothing`),ve=new WeakMap,M=b.createTreeWalker(b,129);function ye(e,t){if(!C(e)||!e.hasOwnProperty(`raw`))throw Error(`invalid template strings array`);return ue===void 0?t:ue.createHTML(t)}var be=(e,t)=>{let n=e.length-1,r=[],i,a=t===2?`<svg>`:t===3?`<math>`:``,o=T;for(let t=0;t<n;t++){let n=e[t],s,c,l=-1,u=0;for(;u<n.length&&(o.lastIndex=u,c=o.exec(n),c!==null);)u=o.lastIndex,o===T?c[1]===`!--`?o=E:c[1]===void 0?c[2]===void 0?c[3]!==void 0&&(o=O):(_e.test(c[2])&&(i=RegExp(`</`+c[2],`g`)),o=O):o=D:o===O?c[0]===`>`?(o=i??T,l=-1):c[1]===void 0?l=-2:(l=o.lastIndex-c[2].length,s=c[1],o=c[3]===void 0?O:c[3]===`"`?ge:he):o===ge||o===he?o=O:o===E||o===D?o=T:(o=O,i=void 0);let d=o===O&&e[t+1].startsWith(`/>`)?` `:``;a+=o===T?n+pe:l>=0?(r.push(s),n.slice(0,l)+de+n.slice(l)+y+d):n+y+(l===-2?t:d)}return[ye(e,a+(e[n]||`<?>`)+(t===2?`</svg>`:t===3?`</math>`:``)),r]},N=class e{constructor({strings:t,_$litType$:n},r){let i;this.parts=[];let a=0,o=0,s=t.length-1,c=this.parts,[l,u]=be(t,n);if(this.el=e.createElement(l,r),M.currentNode=this.el.content,n===2||n===3){let e=this.el.content.firstChild;e.replaceWith(...e.childNodes)}for(;(i=M.nextNode())!==null&&c.length<s;){if(i.nodeType===1){if(i.hasAttributes())for(let e of i.getAttributeNames())if(e.endsWith(de)){let t=u[o++],n=i.getAttribute(e).split(y),r=/([.?@])?(.*)/.exec(t);c.push({type:1,index:a,name:r[2],strings:n,ctor:r[1]===`.`?Se:r[1]===`?`?Ce:r[1]===`@`?we:I}),i.removeAttribute(e)}else e.startsWith(y)&&(c.push({type:6,index:a}),i.removeAttribute(e));if(_e.test(i.tagName)){let e=i.textContent.split(y),t=e.length-1;if(t>0){i.textContent=v?v.emptyScript:``;for(let n=0;n<t;n++)i.append(e[n],x()),M.nextNode(),c.push({type:2,index:++a});i.append(e[t],x())}}}else if(i.nodeType===8){if(i.data===fe)c.push({type:2,index:a});else{let e=-1;for(;(e=i.data.indexOf(y,e+1))!==-1;)c.push({type:7,index:a}),e+=y.length-1}}a++}}static createElement(e,t){let n=b.createElement(`template`);return n.innerHTML=e,n}};function P(e,t,n=e,r){if(t===A)return t;let i=r===void 0?n._$Cl:n._$Co?.[r],a=S(t)?void 0:t._$litDirective$;return i?.constructor!==a&&(i?._$AO?.(!1),a===void 0?i=void 0:(i=new a(e),i._$AT(e,n,r)),r===void 0?n._$Cl=i:(n._$Co??=[])[r]=i),i!==void 0&&(t=P(e,i._$AS(e,t.values),i,r)),t}var xe=class{constructor(e,t){this._$AV=[],this._$AN=void 0,this._$AD=e,this._$AM=t}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(e){let{el:{content:t},parts:n}=this._$AD,r=(e?.creationScope??b).importNode(t,!0);M.currentNode=r;let i=M.nextNode(),a=0,o=0,s=n[0];for(;s!==void 0;){if(a===s.index){let t;s.type===2?t=new F(i,i.nextSibling,this,e):s.type===1?t=new s.ctor(i,s.name,s.strings,this,e):s.type===6&&(t=new Te(i,this,e)),this._$AV.push(t),s=n[++o]}a!==s?.index&&(i=M.nextNode(),a++)}return M.currentNode=b,r}p(e){let t=0;for(let n of this._$AV)n!==void 0&&(n.strings===void 0?n._$AI(e[t]):(n._$AI(e,n,t),t+=n.strings.length-2)),t++}},F=class e{get _$AU(){return this._$AM?._$AU??this._$Cv}constructor(e,t,n,r){this.type=2,this._$AH=j,this._$AN=void 0,this._$AA=e,this._$AB=t,this._$AM=n,this.options=r,this._$Cv=r?.isConnected??!0}get parentNode(){let e=this._$AA.parentNode,t=this._$AM;return t!==void 0&&e?.nodeType===11&&(e=t.parentNode),e}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(e,t=this){e=P(this,e,t),S(e)?e===j||e==null||e===``?(this._$AH!==j&&this._$AR(),this._$AH=j):e!==this._$AH&&e!==A&&this._(e):e._$litType$===void 0?e.nodeType===void 0?me(e)?this.k(e):this._(e):this.T(e):this.$(e)}O(e){return this._$AA.parentNode.insertBefore(e,this._$AB)}T(e){this._$AH!==e&&(this._$AR(),this._$AH=this.O(e))}_(e){this._$AH!==j&&S(this._$AH)?this._$AA.nextSibling.data=e:this.T(b.createTextNode(e)),this._$AH=e}$(e){let{values:t,_$litType$:n}=e,r=typeof n==`number`?this._$AC(e):(n.el===void 0&&(n.el=N.createElement(ye(n.h,n.h[0]),this.options)),n);if(this._$AH?._$AD===r)this._$AH.p(t);else{let e=new xe(r,this),n=e.u(this.options);e.p(t),this.T(n),this._$AH=e}}_$AC(e){let t=ve.get(e.strings);return t===void 0&&ve.set(e.strings,t=new N(e)),t}k(t){C(this._$AH)||(this._$AH=[],this._$AR());let n=this._$AH,r,i=0;for(let a of t)i===n.length?n.push(r=new e(this.O(x()),this.O(x()),this,this.options)):r=n[i],r._$AI(a),i++;i<n.length&&(this._$AR(r&&r._$AB.nextSibling,i),n.length=i)}_$AR(e=this._$AA.nextSibling,t){for(this._$AP?.(!1,!0,t);e!==this._$AB;){let t=le(e).nextSibling;le(e).remove(),e=t}}setConnected(e){this._$AM===void 0&&(this._$Cv=e,this._$AP?.(e))}},I=class{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(e,t,n,r,i){this.type=1,this._$AH=j,this._$AN=void 0,this.element=e,this.name=t,this._$AM=r,this.options=i,n.length>2||n[0]!==``||n[1]!==``?(this._$AH=Array(n.length-1).fill(new String),this.strings=n):this._$AH=j}_$AI(e,t=this,n,r){let i=this.strings,a=!1;if(i===void 0)e=P(this,e,t,0),a=!S(e)||e!==this._$AH&&e!==A,a&&(this._$AH=e);else{let r=e,o,s;for(e=i[0],o=0;o<i.length-1;o++)s=P(this,r[n+o],t,o),s===A&&(s=this._$AH[o]),a||=!S(s)||s!==this._$AH[o],s===j?e=j:e!==j&&(e+=(s??``)+i[o+1]),this._$AH[o]=s}a&&!r&&this.j(e)}j(e){e===j?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,e??``)}},Se=class extends I{constructor(){super(...arguments),this.type=3}j(e){this.element[this.name]=e===j?void 0:e}},Ce=class extends I{constructor(){super(...arguments),this.type=4}j(e){this.element.toggleAttribute(this.name,!!e&&e!==j)}},we=class extends I{constructor(e,t,n,r,i){super(e,t,n,r,i),this.type=5}_$AI(e,t=this){if((e=P(this,e,t,0)??j)===A)return;let n=this._$AH,r=e===j&&n!==j||e.capture!==n.capture||e.once!==n.once||e.passive!==n.passive,i=e!==j&&(n===j||r);r&&this.element.removeEventListener(this.name,this,n),i&&this.element.addEventListener(this.name,this,e),this._$AH=e}handleEvent(e){typeof this._$AH==`function`?this._$AH.call(this.options?.host??this.element,e):this._$AH.handleEvent(e)}},Te=class{constructor(e,t,n){this.element=e,this.type=6,this._$AN=void 0,this._$AM=t,this.options=n}get _$AU(){return this._$AM._$AU}_$AI(e){P(this,e)}},Ee=_.litHtmlPolyfillSupport;Ee?.(N,F),(_.litHtmlVersions??=[]).push(`3.3.2`);var De=(e,t,n)=>{let r=n?.renderBefore??t,i=r._$litPart$;if(i===void 0){let e=n?.renderBefore??null;r._$litPart$=i=new F(t.insertBefore(x(),e),e,void 0,n??{})}return i._$AI(e),i},L=globalThis,R=class extends g{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){let e=super.createRenderRoot();return this.renderOptions.renderBefore??=e.firstChild,e}update(e){let t=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(e),this._$Do=De(t,this.renderRoot,this.renderOptions)}connectedCallback(){super.connectedCallback(),this._$Do?.setConnected(!0)}disconnectedCallback(){super.disconnectedCallback(),this._$Do?.setConnected(!1)}render(){return A}};R._$litElement$=!0,R.finalized=!0,L.litElementHydrateSupport?.({LitElement:R});var Oe=L.litElementPolyfillSupport;Oe?.({LitElement:R}),(L.litElementVersions??=[]).push(`4.2.2`);var ke={attribute:!0,type:String,converter:m,reflect:!1,hasChanged:h},Ae=(e=ke,t,n)=>{let{kind:r,metadata:i}=n,a=globalThis.litPropertyMetadata.get(i);if(a===void 0&&globalThis.litPropertyMetadata.set(i,a=new Map),r===`setter`&&((e=Object.create(e)).wrapped=!0),a.set(n.name,e),r===`accessor`){let{name:r}=n;return{set(n){let i=t.get.call(this);t.set.call(this,n),this.requestUpdate(r,i,e,!0,n)},init(t){return t!==void 0&&this.C(r,void 0,e,t),t}}}if(r===`setter`){let{name:r}=n;return function(n){let i=this[r];t.call(this,n),this.requestUpdate(r,i,e,!0,n)}}throw Error(`Unsupported decorator location: `+r)};function je(e){return(t,n)=>typeof n==`object`?Ae(e,t,n):((e,t,n)=>{let r=t.hasOwnProperty(n);return t.constructor.createProperty(n,e),r?Object.getOwnPropertyDescriptor(t,n):void 0})(e,t,n)}function z(e){return je({...e,state:!0,attribute:!1})}function Me(e){switch(e){case`heating`:return`mode-heating`;case`cooling`:return`mode-cooling`;case`idle`:return`mode-idle`;default:return`mode-other`}}var Ne={heating:`mode.heating`,cooling:`mode.cooling`,idle:`mode.idle`};function Pe(e,n){return t(Ne[e],n)}var Fe=c`
  .mode-pill {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-size: 13px;
    font-weight: 500;
    padding: 4px 14px;
    border-radius: 16px;
  }

  .mode-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
  }

  .mode-heating {
    color: var(--warning-color, #ff9800);
    background: rgba(255, 152, 0, 0.12);
  }
  .mode-heating .mode-dot {
    background: var(--warning-color, #ff9800);
  }

  .mode-cooling {
    color: #2196f3;
    background: rgba(33, 150, 243, 0.12);
  }
  .mode-cooling .mode-dot {
    background: #2196f3;
  }

  .mode-idle {
    color: var(--secondary-text-color, #757575);
    background: rgba(0, 0, 0, 0.05);
  }
  .mode-idle .mode-dot {
    background: var(--disabled-text-color, #bdbdbd);
  }

  .mode-other {
    color: var(--secondary-text-color);
    background: rgba(0, 0, 0, 0.05);
  }
  .mode-other .mode-dot {
    background: var(--secondary-text-color);
  }
`;function B(e){return e.config?.unit_system?.temperature===`°F`}function V(e){return B(e)?`°F`:`°C`}function Ie(e,t){return B(t)?e*9/5+32:e}function Le(e,t){return B(t)?(e-32)*5/9:e}function H(e,t,n=1){return Ie(e,t).toFixed(n)}var Re=[1,2,4];function ze(e,t,n,r){let i,a;return e===`boost`?(i=n.comfortHeat,a=n.comfortCool):e===`eco`?(i=n.ecoHeat,a=n.ecoCool):(i=r.heat,a=r.cool),t===`heat_only`&&(a=null),t===`cool_only`&&(i=null),{heat:i,cool:a}}function Be(e,t){return e!=null&&t!=null&&t<e}function Ve(e,t,n,r,i){let a={type:`roommind/override/set`,area_id:e,override_type:t,duration:n};return t===`custom`&&(r!==`cool_only`&&(a.heat=i.heat),r!==`heat_only`&&(a.cool=i.cool)),a}function He(e,t=Date.now()/1e3){let n=e-t;if(n<=0)return``;let r=Math.floor(n/3600),i=Math.floor(n%3600/60);return r>0?`${r}h ${i}m`:`${i}m`}var Ue=1e4,U=new Set,W=null,G,K=null,q=null,J=``;function We(e){let t=!W;W=e,t&&U.size&&Y()}function Ge(e){return U.add(e),(q||J)&&e(q,J),U.size===1&&qe(),()=>{U.delete(e),U.size||Je()}}function Y(e=!1){return W?K?e?K.then(()=>Y(!0)):K:(K=W.callWS({type:`roommind/rooms/list`}).then(e=>{q={rooms:e.rooms??{},climate_control_active:e.climate_control_active??!0},J=``}).catch(e=>{J=e instanceof Error?e.message:String(e?.message??e)}).finally(()=>{K=null;for(let e of U)e(q,J)}),K):Promise.resolve()}function Ke(){document.hidden||Y()}function qe(){Y(),G=setInterval(()=>{document.hidden||Y()},Ue),document.addEventListener(`visibilitychange`,Ke)}function Je(){G&&clearInterval(G),G=void 0,document.removeEventListener(`visibilitychange`,Ke)}function X(e,t,n,r){var i=arguments.length,a=i<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,o;if(typeof Reflect==`object`&&typeof Reflect.decorate==`function`)a=Reflect.decorate(e,t,n,r);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(i<3?o(a):i>3?o(t,n,a):o(t,n))||a);return i>3&&a&&Object.defineProperty(t,n,a),a}var Ye=800,Xe=[{type:`boost`,icon:`mdi:sofa`,key:`override.comfort`},{type:`eco`,icon:`mdi:leaf`,key:`override.eco`},{type:`custom`,icon:`mdi:thermometer`,key:`override.custom`}],Ze=[{value:`auto`,icon:`mdi:autorenew`,key:`mode.auto`},{value:`heat_only`,icon:`mdi:fire`,key:`mode.heat_only`},{value:`cool_only`,icon:`mdi:snowflake`,key:`mode.cool_only`}];function Z(){return document.querySelector(`home-assistant`)?.hass?.language??navigator.language??`en`}var Q=class extends R{constructor(...e){super(...e),this._feed=null,this._feedError=``,this._now=Date.now()/1e3,this._pending=null,this._customHeat=21,this._customCool=24,this._optimisticOverride=null,this._modeDraft=null,this._controlDraft=null,this._tempsDraft=null,this._error=``,this._tempsEdit=0}static getConfigForm(){return{schema:[{name:`area`,required:!0,selector:{area:{}}},{name:`compact`,selector:{boolean:{}}},{name:`hide_override`,selector:{boolean:{}}},{name:`hide_mode`,selector:{boolean:{}}},{name:`hide_climate_control`,selector:{boolean:{}}},{name:`hide_temperatures`,selector:{boolean:{}}}],computeLabel:e=>t(`roomcard.editor.${e.name}`,Z())}}static getStubConfig(e){return{type:`custom:roommind-room-card`,area:Object.values(e?.entities??{}).find(e=>e.platform===`roommind`&&e.entity_id.startsWith(`climate.`)&&e.area_id)?.area_id??Object.keys(e?.areas??{})[0]??``}}setConfig(e){if(!e)throw Error(`Invalid configuration`);e.area!==this._config?.area&&(this._flushTemps(),this._resetDrafts()),this._config=e}getCardSize(){let e=this._config;return e?.compact?2+(this._shown(e.hide_override)||this._shown(e.hide_mode)||this._shown(e.hide_climate_control)?1:0)+(this._shown(e.hide_temperatures)?2:0):3+(this._shown(e?.hide_override)?2:0)+(this._shown(e?.hide_mode)?2:+!!this._shown(e?.hide_climate_control))+(this._shown(e?.hide_temperatures)?3:0)}getGridOptions(){return this._config?.compact?{columns:6,min_columns:6}:{columns:12,min_columns:9}}connectedCallback(){super.connectedCallback(),this.hass&&We(this.hass),this._unsubscribe=Ge((e,t)=>{this._feed=e,this._feedError=t}),this._clock=setInterval(()=>this._now=Date.now()/1e3,3e4)}disconnectedCallback(){super.disconnectedCallback(),this._unsubscribe?.(),this._unsubscribe=void 0,this._clock&&clearInterval(this._clock),this._clock=void 0,this._flushTemps()}willUpdate(e){e.has(`hass`)&&this.hass&&We(this.hass),this._pending&&this._room&&this._override(this._room).type&&(this._pending=null)}_shown(e){return e!==!0}get _lang(){return this.hass?.language??`en`}get _room(){let e=this._config?.area;return e?this._feed?.rooms[e]:void 0}_climateMode(e){return this._modeDraft??e.climate_mode??`auto`}_temps(e){return this._tempsDraft??{comfortHeat:e.comfort_heat??e.comfort_temp??21,comfortCool:e.comfort_cool??24,ecoHeat:e.eco_heat??e.eco_temp??17,ecoCool:e.eco_cool??27}}_override(e){if(this._optimisticOverride)return this._optimisticOverride;let t=e.live;return t?.override_active&&t.override_type?{type:t.override_type,until:t.override_until}:{type:null,until:null}}_resetDrafts(){this._pending=null,this._optimisticOverride=null,this._modeDraft=null,this._controlDraft=null,this._tempsDraft=null,this._error=``}render(){if(!this._config||!this.hass)return j;if(!this._config.area)return this._renderMessage(t(`roomcard.no_area`,this._lang));if(!this._feed)return this._renderMessage(this._feedError||t(`roomcard.loading`,this._lang),this._feedError?`error`:``);let e=this._room;if(e?.is_outdoor)return this._renderMonitorOnly(e);if(!e||(e.devices?.length??0)===0)return this._renderMessage(t(`roomcard.unknown_room`,this._lang),``,!0);let n=e.live,r=n?.mode,i=(this._controlDraft??e.climate_control_enabled!==!1)&&this._feed.climate_control_active;return k`
      <ha-card class=${this._config.compact?`compact`:``}>
        <div class="accent ${r?Me(r):`mode-other`}"></div>
        <div class="content">
          ${this._renderHeader(e)}
          ${n?this._renderStatus(e,i):k` <div class="hint">${t(`card.waiting`,this._lang)}</div> `}
          <div class="controls">
            ${this._shown(this._config.hide_override)?this._renderOverride(e):j}
            ${this._renderMode(e)}
          </div>
          ${this._shown(this._config.hide_temperatures)?this._renderTemps(e):j}
          <div class="error" role="status" aria-live="polite">${this._error}</div>
        </div>
      </ha-card>
    `}_renderMonitorOnly(e){let n=e.live,r=this._lang;return k`
      <ha-card class=${this._config?.compact?`compact`:``}>
        <div class="content">
          <div class="header">
            ${this._renderName(e.area_id,e)}
            <span class="mode-pill mode-other">${t(`card.outdoor`,r)}</span>
          </div>
          <div class="temps">
            <span class="current">
              ${n?.current_temp==null?`--`:H(n.current_temp,this.hass)}<span
                class="unit"
                >${V(this.hass)}</span
              >
            </span>
            ${n?.current_humidity==null?j:k`<div class="target-block">
                    ${t(`card.humidity`,r,{value:n.current_humidity.toFixed(0)})}
                  </div>`}
          </div>
        </div>
      </ha-card>
    `}_renderMessage(e,n=``,r=!1){return k`
      <ha-card class=${this._config?.compact?`compact`:``}>
        <div class="content">
          ${this._config?.area?k`<div class="header">${this._renderName(this._config.area,void 0)}</div>`:j}
          <div class="hint ${n}">${e}</div>
          ${r?k`<a class="open-link" href=${this._roomPath()} @click=${this._openRoom}
                  >${t(`roomcard.open_room`,this._lang)}</a
                >`:j}
        </div>
      </ha-card>
    `}_roomPath(){return`/roommind/room/${encodeURIComponent(this._config?.area??``)}`}_renderName(e,t){let n=t?.display_name||this.hass.areas?.[e]?.name||e;return k`<a class="name" href=${this._roomPath()} @click=${this._openRoom}>${n}</a>`}_renderHeader(e){let t=e.live;return k`
      <div class="header">
        ${this._renderName(e.area_id,e)}
        ${t?k`<span class="mode-pill ${Me(t.mode)}">
                <span class="mode-dot"></span>
                ${Pe(t.mode,this._lang)}${t.heating_power>0&&t.heating_power<100?k` ${t.heating_power}%`:j}
              </span>`:j}
      </div>
    `}_renderStatus(e,n){let r=e.live,i=this._lang,a=this._override(e),o=this._climateMode(e)===`auto`&&r.heat_target!=null&&r.cool_target!=null&&r.heat_target!==r.cool_target,s=r.target_temp??r.heat_target??r.cool_target,c=V(this.hass),l=!this._optimisticOverride&&!!r.override_suppressed,u=``;return l?u=t(`roomcard.paused`,i):a.type&&(u=a.until?t(`hero.remaining`,i,{time:He(a.until,this._now)||`0m`}):t(`hero.permanent`,i)),k`
      <div class="temps">
        <span class="current">
          ${r.current_temp==null?`--`:H(r.current_temp,this.hass)}<span
            class="unit"
            >${c}</span
          >
        </span>
        <div class="target-block">
          ${s!=null||o?k`<span class="target">
                  ${t(`card.target`,i)}
                  <strong
                    >${o?`${H(r.heat_target,this.hass)} – ${H(r.cool_target,this.hass)}`:H(s,this.hass)}${c}</strong
                  >
                </span>`:j}
          <span class="icons">
            ${r.window_open?k`<ha-icon
                    icon="mdi:window-open-variant"
                    role="img"
                    title=${t(`card.window_open`,i)}
                    aria-label=${t(`card.window_open`,i)}
                  ></ha-icon>`:j}
            ${r.presence_away?k`<ha-icon
                    icon="mdi:home-off-outline"
                    role="img"
                    title=${t(`card.presence_away`,i)}
                    aria-label=${t(`card.presence_away`,i)}
                  ></ha-icon>`:j}
            ${r.current_humidity==null?j:k`<span class="humidity"
                    >${t(`card.humidity`,i,{value:r.current_humidity.toFixed(0)})}</span
                  >`}
          </span>
        </div>
      </div>
      ${a.type?k`<div class="override-status ${l?`paused`:a.type}">
              <ha-icon
                icon=${l?`mdi:pause-circle-outline`:`mdi:timer-outline`}
                aria-hidden="true"
              ></ha-icon>
              <span
                >${t(Xe.find(e=>e.type===a.type).key,i)} ·
                ${u}</span
              >
            </div>`:j}
      ${n?j:k`<div class="hint">${t(`card.not_controlled`,i)}</div>`}
    `}_renderOverride(e){let n=this._lang,r=this._override(e).type,i=this._climateMode(e);return k`
      <section class="override-section ${!r&&this._pending?`expanded`:``}">
        <h4>${t(`override.label`,n)}</h4>
        <div class="segments">
          ${Xe.map(i=>k`
              <button
                class="segment ${i.type} ${r===i.type?`active`:``} ${!r&&this._pending===i.type?`pending`:``}"
                aria-pressed=${r===i.type||!r&&this._pending===i.type}
                aria-label=${t(i.key,n)}
                title=${t(i.key,n)}
                ?disabled=${r!==null&&r!==i.type}
                @click=${()=>this._onPreset(e,i.type,r)}
              >
                <ha-icon icon=${i.icon}></ha-icon>
                <span>${t(i.key,n)}</span>
              </button>
            `)}
        </div>
        ${!r&&this._pending?k`
                ${this._pending===`custom`?k`<div class="custom-row">
                        ${i===`cool_only`?j:this._customField(i===`auto`?`override.heat_to`:`override.target`,this._customHeat,e=>{this._customHeat=e,i===`auto`&&this._customCool<e&&(this._customCool=e)})}
                        ${i===`heat_only`?j:this._customField(i===`auto`?`override.cool_above`:`override.target`,this._customCool,e=>{this._customCool=e,i===`auto`&&this._customHeat>e&&(this._customHeat=e)})}
                      </div>`:j}
                <div class="duration">
                  <span>${t(`override.activate_for`,n)}</span>
                  ${Re.map(t=>k`<button class="chip" @click=${()=>this._activate(e,t)}>
                        ${t}h
                      </button>`)}
                </div>
              `:j}
      </section>
    `}_renderMode(e){let n=this._shown(this._config?.hide_mode),r=this._shown(this._config?.hide_climate_control);if(!n&&!r)return j;let i=this._lang,a=this._climateMode(e),o=this._controlDraft??e.climate_control_enabled!==!1,s=k`<div class="section-head">
      ${n?k`<h4>${t(`roomcard.mode`,i)}</h4>`:k`<span></span>`}
      ${r?k`<button
              class="switch"
              role="switch"
              aria-checked=${o?`true`:`false`}
              aria-label=${t(`room.climate_control_toggle`,i)}
              title=${t(`room.climate_control_toggle`,i)}
              @click=${()=>this._saveRoom({climate_control_enabled:!o},`control`)}
            >
              <ha-icon class="switch-icon" icon="mdi:power" aria-hidden="true"></ha-icon>
              <span class="switch-label">${t(`room.climate_control_toggle`,i)}</span>
              <span class="track"><span class="thumb"></span></span>
            </button>`:j}
    </div>`,c=n?k`<div class="segments">
          ${Ze.map(e=>k`
              <button
                class="segment ${a===e.value?`active`:``}"
                aria-pressed=${a===e.value}
                aria-label=${t(e.key,i)}
                title=${t(e.key,i)}
                @click=${()=>a!==e.value&&this._saveRoom({climate_mode:e.value},`mode`)}
              >
                <ha-icon icon=${e.icon}></ha-icon>
                <span>${t(e.key,i)}</span>
              </button>
            `)}
        </div>`:j;return k`
      <section class="mode-section">
        ${this._config?.compact?k`${c}${s}`:k`${s}${c}`}
      </section>
    `}_renderTemps(e){let n=this._lang,r=this._climateMode(e),i=this._temps(e),a=r===`auto`,o=t(`mode.heating`,n),s=t(`mode.cooling`,n),c=(c,l,u)=>{let d=t(c,n);return k`
        <span class="row-label">${d}</span>
        ${r===`cool_only`?j:this._stepper(a?`${d} ${o}`:d,i[l],t=>this._editTemps(e,l,t),a?`mdi:fire`:void 0)}
        ${r===`heat_only`?j:this._stepper(a?`${d} ${s}`:d,i[u],t=>this._editTemps(e,u,t),a?`mdi:snowflake`:void 0)}
      `};return k`
      <section class="temps-section">
        <h4>${t(`roomcard.temperatures`,n)}</h4>
        <div class="temp-grid ${a?`auto`:`single`}">
          ${a?k`
                  <span class="corner"></span>
                  <span class="col-head"><ha-icon icon="mdi:fire"></ha-icon>${o}</span>
                  <span class="col-head"><ha-icon icon="mdi:snowflake"></ha-icon>${s}</span>
                `:j}
          ${c(`override.comfort`,`comfortHeat`,`comfortCool`)}
          ${c(`override.eco`,`ecoHeat`,`ecoCool`)}
        </div>
      </section>
    `}_customField(e,n,r){let i=t(e,this._lang).replace(/:\s*$/,``);return k`
      <div class="custom-field">
        <span class="field-label">${i}</span>
        ${this._stepper(i,n,r)}
      </div>
    `}_stepper(e,n,r,i){let a=this._lang;return k`
      <div class="stepper" role="group" aria-label=${e}>
        <button
          class="step"
          aria-label=${t(`roomcard.lower`,a,{name:e})}
          ?disabled=${n<=5}
          @click=${()=>r(this._step(n,-1))}
        >
          <ha-icon icon="mdi:minus"></ha-icon>
        </button>
        <span class="value" aria-live="polite"
          >${i?k`<ha-icon class="side-icon" icon=${i} aria-hidden="true"></ha-icon>`:j}${H(n,this.hass)}${V(this.hass)}</span
        >
        <button
          class="step"
          aria-label=${t(`roomcard.raise`,a,{name:e})}
          ?disabled=${n>=35}
          @click=${()=>r(this._step(n,1))}
        >
          <ha-icon icon="mdi:plus"></ha-icon>
        </button>
      </div>
    `}_step(e,t){let n=B(this.hass)?1:.5,r=Ie(e,this.hass)/n,i=Le((t>0?Math.floor(r+1e-6)+1:Math.ceil(r-1e-6)-1)*n,this.hass);return Math.min(35,Math.max(5,i))}_openRoom(e){e.button!==0||e.ctrlKey||e.metaKey||e.shiftKey||e.altKey||(e.preventDefault(),history.pushState(null,``,this._roomPath()),window.dispatchEvent(new CustomEvent(`location-changed`,{detail:{replace:!1}})))}_onPreset(e,t,n){if(this._error=``,n===t)this._clearOverride(e);else if(this._pending===t)this._pending=null;else if(this._pending=t,t===`custom`){let t=this._temps(e);this._customHeat=t.comfortHeat,this._customCool=t.comfortCool}}async _activate(e,n){let r=this._pending;if(!r)return;let i=this._climateMode(e),a={heat:this._customHeat,cool:this._customCool},o=ze(r,i,this._temps(e),a);if(Be(o.heat,o.cool))this._error=t(`override.invalid_band`,this._lang);else{this._pending=null,this._error=``,this._optimisticOverride={type:r,until:Date.now()/1e3+n*3600},this._refocusPreset(r);try{this._tempsTimer&&(clearTimeout(this._tempsTimer),await this._saveTemps()),await this.hass.callWS(Ve(e.area_id,r,n,i,a)),await Y(!0)}catch(e){this._error=this._message(e,`override.error_set`)}this._optimisticOverride=null}}async _refocusPreset(e){let t=this.shadowRoot,n=!!t?.activeElement;await this.updateComplete,n&&!t?.activeElement&&t?.querySelector(`.override-section .segment.${e}`)?.focus()}async _clearOverride(e){this._optimisticOverride={type:null,until:null};try{await this.hass.callWS({type:`roommind/override/clear`,area_id:e.area_id}),await Y(!0)}catch(e){this._error=this._message(e,`override.error_clear`)}this._optimisticOverride=null}async _saveRoom(e,t){if(this._config?.area){this._error=``,t===`mode`?this._modeDraft=e.climate_mode:this._controlDraft=e.climate_control_enabled;try{await this.hass.callWS({type:`roommind/rooms/save`,area_id:this._config.area,...e}),await Y(!0)}catch(e){this._error=this._message(e,`roomcard.error_save`)}t===`mode`?this._modeDraft=null:this._controlDraft=null}}_editTemps(e,t,n){let r={...this._temps(e),[t]:n};t===`comfortHeat`&&r.comfortCool<n&&(r.comfortCool=n),t===`comfortCool`&&r.comfortHeat>n&&(r.comfortHeat=n),t===`ecoHeat`&&r.ecoCool<n&&(r.ecoCool=n),t===`ecoCool`&&r.ecoHeat>n&&(r.ecoHeat=n),this._tempsDraft=r,this._tempsEdit+=1,this._tempsTimer&&clearTimeout(this._tempsTimer),this._tempsTimer=setTimeout(()=>void this._saveTemps(),Ye)}_flushTemps(){this._tempsTimer&&(clearTimeout(this._tempsTimer),this._saveTemps())}async _saveTemps(){this._tempsTimer=void 0;let e=this._tempsDraft,t=this._config?.area;if(!e||!t)return;let n=this._tempsEdit;try{await this.hass.callWS({type:`roommind/rooms/save`,area_id:t,comfort_heat:e.comfortHeat,comfort_cool:e.comfortCool,eco_heat:e.ecoHeat,eco_cool:e.ecoCool}),await Y(!0)}catch(e){this._error=this._message(e,`roomcard.error_save`)}n===this._tempsEdit&&(this._tempsDraft=null)}_message(e,n){return e?.message||t(n,this._lang)}static{this.styles=[Fe,c`
      :host {
        display: block;
      }

      ha-card {
        position: relative;
        overflow: hidden;
        height: 100%;
        box-sizing: border-box;
        container-type: inline-size;
      }

      .accent {
        position: absolute;
        inset: 0 auto 0 0;
        width: 4px;
      }

      .accent.mode-heating {
        background: var(--warning-color, #ff9800);
      }

      .accent.mode-cooling {
        background: #2196f3;
      }

      .accent.mode-idle,
      .accent.mode-other {
        background: var(--disabled-text-color, #bdbdbd);
      }

      .content {
        padding: 16px 16px 12px 20px;
      }

      .header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        min-width: 0;
      }

      .name {
        font-size: 16px;
        font-weight: 500;
        color: var(--primary-text-color);
        text-decoration: none;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        min-width: 0;
        min-height: 44px;
        line-height: 44px;
      }

      .name:hover {
        text-decoration: underline;
      }

      .mode-pill {
        flex-shrink: 0;
        gap: 5px;
        font-size: 12px;
        padding: 3px 10px;
        border-radius: 12px;
      }

      .mode-dot {
        width: 7px;
        height: 7px;
      }

      .temps {
        display: flex;
        align-items: flex-end;
        gap: 12px;
        flex-wrap: wrap;
      }

      .current {
        font-size: 40px;
        font-weight: 300;
        line-height: 1;
        color: var(--primary-text-color);
        font-variant-numeric: tabular-nums;
      }

      .unit {
        font-size: 18px;
        color: var(--secondary-text-color);
        margin-left: 2px;
      }

      .target-block {
        display: flex;
        flex-direction: column;
        gap: 2px;
        font-size: 13px;
        color: var(--secondary-text-color);
        padding-bottom: 3px;
      }

      .target strong {
        font-weight: 500;
        color: var(--primary-text-color);
        font-variant-numeric: tabular-nums;
      }

      .icons {
        display: flex;
        align-items: center;
        gap: 6px;
      }

      .icons ha-icon {
        --mdc-icon-size: 16px;
      }

      .override-status {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        margin-top: 12px;
        padding: 4px 10px;
        border-radius: 12px;
        font-size: 13px;
        font-variant-numeric: tabular-nums;
      }

      .override-status ha-icon {
        --mdc-icon-size: 16px;
      }

      .override-status.paused {
        color: var(--secondary-text-color);
        background: rgba(var(--rgb-primary-text-color, 0, 0, 0), 0.06);
      }

      .override-status.boost {
        color: var(--warning-color, #ff9800);
        background: rgba(255, 152, 0, 0.12);
      }

      .override-status.eco {
        color: var(--success-color, #4caf50);
        background: rgba(76, 175, 80, 0.12);
      }

      .override-status.custom {
        color: var(--info-color, #2196f3);
        background: rgba(33, 150, 243, 0.12);
      }

      .hint {
        margin-top: 10px;
        font-size: 13px;
        color: var(--secondary-text-color);
      }

      .hint.error,
      .error {
        color: var(--error-color, #db4437);
        font-size: 13px;
      }

      .error:not(:empty) {
        margin-top: 10px;
      }

      .open-link {
        display: inline-flex;
        align-items: center;
        min-height: 44px;
        color: var(--primary-color);
        font-size: 14px;
      }

      section {
        margin-top: 16px;
        padding-top: 12px;
        border-top: 1px solid var(--divider-color, rgba(0, 0, 0, 0.12));
      }

      h4 {
        margin: 0 0 8px;
        font-size: 13px;
        font-weight: 500;
        color: var(--secondary-text-color);
      }

      .section-head {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        margin-bottom: 4px;
      }

      .section-head h4 {
        margin: 0;
      }

      button {
        font: inherit;
        color: inherit;
        touch-action: manipulation;
      }

      button:focus-visible {
        outline: 2px solid var(--primary-color);
        outline-offset: 2px;
      }

      .segments {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 8px;
      }

      .segment {
        min-height: 56px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: 2px;
        padding: 6px 4px;
        border: 1px solid var(--divider-color, rgba(0, 0, 0, 0.12));
        border-radius: 10px;
        background: transparent;
        color: var(--primary-text-color);
        font-size: 12px;
        line-height: 1.2;
        text-align: center;
        cursor: pointer;
        min-width: 0;
        overflow-wrap: break-word;
        hyphens: auto;
        transition:
          background-color 0.15s,
          border-color 0.15s;
      }

      .segment ha-icon {
        --mdc-icon-size: 18px;
        flex-shrink: 0;
      }

      .segment:hover:not(:disabled) {
        background: rgba(var(--rgb-primary-text-color, 0, 0, 0), 0.04);
      }

      .segment:disabled {
        opacity: 0.4;
        cursor: default;
      }

      .segment.active,
      .segment.pending {
        border-color: var(--primary-color);
        background: rgba(var(--rgb-primary-color, 3, 169, 244), 0.1);
        color: var(--primary-color);
      }

      /* Picked but not running yet: must not look like the active climate mode. */
      .segment.pending {
        border-style: dashed;
        background: transparent;
      }

      .segment.active.boost {
        border-color: var(--warning-color, #ff9800);
        background: rgba(255, 152, 0, 0.15);
        color: var(--warning-color, #ff9800);
      }

      .segment.active.eco {
        border-color: var(--success-color, #4caf50);
        background: rgba(76, 175, 80, 0.15);
        color: var(--success-color, #4caf50);
      }

      .segment.active.custom {
        border-color: var(--info-color, #2196f3);
        background: rgba(33, 150, 243, 0.15);
        color: var(--info-color, #2196f3);
      }

      .custom-row {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
        gap: 8px 12px;
        margin-top: 10px;
      }

      .custom-field {
        display: flex;
        flex-direction: column;
        gap: 4px;
      }

      .field-label {
        font-size: 12px;
        color: var(--secondary-text-color);
      }

      .duration {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 8px;
        margin-top: 10px;
        font-size: 13px;
        color: var(--secondary-text-color);
      }

      .chip {
        min-width: 56px;
        min-height: 44px;
        border-radius: 22px;
        border: 1px solid var(--primary-color);
        background: transparent;
        color: var(--primary-color);
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
      }

      .chip:hover {
        background: rgba(var(--rgb-primary-color, 3, 169, 244), 0.1);
      }

      .switch {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        min-height: 44px;
        padding: 0;
        border: none;
        background: transparent;
        cursor: pointer;
        font-size: 13px;
        color: var(--secondary-text-color);
      }

      .track {
        position: relative;
        width: 36px;
        height: 20px;
        border-radius: 10px;
        background: var(--disabled-text-color, #bdbdbd);
        transition: background-color 0.15s;
        flex-shrink: 0;
      }

      .thumb {
        position: absolute;
        top: 2px;
        left: 2px;
        width: 16px;
        height: 16px;
        border-radius: 50%;
        background: var(--card-background-color, #fff);
        box-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
        transition: transform 0.15s;
      }

      .switch[aria-checked="true"] .track {
        background: var(--primary-color);
      }

      .switch[aria-checked="true"] .thumb {
        transform: translateX(16px);
      }

      .temp-grid {
        display: grid;
        align-items: center;
        gap: 8px 12px;
      }

      .temp-grid.single {
        grid-template-columns: 1fr auto;
      }

      .temp-grid.auto {
        grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      }

      .temp-grid.auto .corner {
        display: none;
      }

      .temp-grid.auto .row-label {
        grid-column: 1 / -1;
        margin-bottom: -4px;
      }

      @container (max-width: 339px) {
        .temp-grid.auto {
          grid-template-columns: minmax(0, 1fr);
        }

        .temp-grid.auto .col-head {
          display: none;
        }

        .temp-grid.auto .side-icon {
          display: inline-block;
        }
      }

      @container (max-width: 259px) {
        .temp-grid.single {
          grid-template-columns: minmax(0, 1fr);
        }
      }

      .col-head {
        display: flex;
        align-items: center;
        gap: 4px;
        font-size: 12px;
        color: var(--secondary-text-color);
      }

      .col-head ha-icon {
        --mdc-icon-size: 14px;
      }

      @container (min-width: 440px) {
        .temp-grid.auto {
          grid-template-columns: auto 1fr 1fr;
        }

        .temp-grid.auto .corner {
          display: block;
        }

        .temp-grid.auto .row-label {
          grid-column: auto;
          margin-bottom: 0;
        }
      }

      .row-label {
        font-size: 14px;
        color: var(--primary-text-color);
      }

      .stepper {
        min-width: 0;
        display: flex;
        justify-content: space-between;
        align-items: center;
        border: 1px solid var(--divider-color, rgba(0, 0, 0, 0.12));
        border-radius: 22px;
      }

      .step {
        width: 44px;
        height: 44px;
        display: flex;
        align-items: center;
        justify-content: center;
        border: none;
        border-radius: 50%;
        background: transparent;
        color: var(--primary-text-color);
        cursor: pointer;
      }

      .step ha-icon {
        --mdc-icon-size: 18px;
      }

      .step:hover:not(:disabled) {
        background: rgba(var(--rgb-primary-text-color, 0, 0, 0), 0.06);
      }

      .step:disabled {
        opacity: 0.35;
        cursor: default;
      }

      .side-icon {
        display: none;
        --mdc-icon-size: 14px;
        margin-right: 2px;
        color: var(--secondary-text-color);
      }

      .value {
        flex: 1;
        min-width: 48px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        white-space: nowrap;
        text-align: center;
        font-size: 15px;
        font-variant-numeric: tabular-nums;
        color: var(--primary-text-color);
      }

      .switch-icon {
        display: none;
        --mdc-icon-size: 18px;
      }

      /* Compact: one status block, icon-only controls side by side. */
      .compact .content {
        padding: 10px 12px 8px 16px;
      }

      .compact .name {
        font-size: 15px;
        line-height: 1.25;
        white-space: normal;
        overflow-wrap: break-word;
        flex-shrink: 0;
        max-width: 100%;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        padding: 13px 0;
        min-height: 0;
      }

      .compact .header {
        flex-wrap: wrap;
        row-gap: 4px;
      }

      .compact .current {
        font-size: 28px;
      }

      .compact .unit {
        font-size: 14px;
      }

      .compact .override-status {
        margin-top: 6px;
      }

      .compact h4,
      .compact .switch-label,
      .compact .segment span {
        position: absolute;
        width: 1px;
        height: 1px;
        overflow: hidden;
        clip-path: inset(50%);
        white-space: nowrap;
      }

      .compact .switch-icon {
        display: inline-block;
      }

      .compact .controls {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 0 16px;
      }

      .compact .controls section {
        flex: 0 1 auto;
        margin-top: 8px;
        padding-top: 0;
        border-top: none;
      }

      .compact .controls section.expanded {
        flex-basis: 100%;
      }

      .compact .mode-section {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 6px 12px;
      }

      .compact .mode-section .section-head {
        margin: 0;
      }

      .compact .segments {
        grid-template-columns: repeat(3, 44px);
        gap: 6px;
      }

      .compact .segment {
        min-height: 44px;
        padding: 0;
      }

      .compact .chip {
        min-width: 44px;
      }

      .compact .temps-section {
        margin-top: 8px;
        padding-top: 8px;
      }

      @media (prefers-reduced-motion: reduce) {
        .segment,
        .track,
        .thumb {
          transition: none;
        }
      }
    `]}};X([je({attribute:!1})],Q.prototype,`hass`,void 0),X([z()],Q.prototype,`_config`,void 0),X([z()],Q.prototype,`_feed`,void 0),X([z()],Q.prototype,`_feedError`,void 0),X([z()],Q.prototype,`_now`,void 0),X([z()],Q.prototype,`_pending`,void 0),X([z()],Q.prototype,`_customHeat`,void 0),X([z()],Q.prototype,`_customCool`,void 0),X([z()],Q.prototype,`_optimisticOverride`,void 0),X([z()],Q.prototype,`_modeDraft`,void 0),X([z()],Q.prototype,`_controlDraft`,void 0),X([z()],Q.prototype,`_tempsDraft`,void 0),X([z()],Q.prototype,`_error`,void 0);var Qe=`roommind-room-card`;customElements.whenDefined(`home-assistant`).then(()=>{window.customElements.get(Qe)||window.customElements.define(Qe,Q)});var $=window;$.customCards=$.customCards??[],$.customCards.some(e=>e.type===`roommind-room-card`)||$.customCards.push({type:`roommind-room-card`,get name(){return t(`roomcard.name`,Z())},get description(){return t(`roomcard.description`,Z())},preview:!0,documentationURL:`https://github.com/snazzybean/roommind#dashboard-card`})})();