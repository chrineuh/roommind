(function(){var e=Object.defineProperty,t=(e,t,n)=>()=>{if(n)throw n[0];try{return e&&(t=e(e=0)),t}catch(e){throw n=[e],e}},n=(t,n)=>{let r={};for(var i in t)e(r,i,{get:t[i],enumerable:!0});return n||e(r,Symbol.toStringTag,{value:`Module`}),r},r,i,a,o,s,c,l,u,d,f=t((()=>{r=globalThis,i=r.ShadowRoot&&(r.ShadyCSS===void 0||r.ShadyCSS.nativeShadow)&&`adoptedStyleSheets`in Document.prototype&&`replace`in CSSStyleSheet.prototype,a=Symbol(),o=new WeakMap,s=class{constructor(e,t,n){if(this._$cssResult$=!0,n!==a)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=e,this.t=t}get styleSheet(){let e=this.o,t=this.t;if(i&&e===void 0){let n=t!==void 0&&t.length===1;n&&(e=o.get(t)),e===void 0&&((this.o=e=new CSSStyleSheet).replaceSync(this.cssText),n&&o.set(t,e))}return e}toString(){return this.cssText}},c=e=>new s(typeof e==`string`?e:e+``,void 0,a),l=(e,...t)=>{let n=e.length===1?e[0]:t.reduce((t,n,r)=>t+(e=>{if(!0===e._$cssResult$)return e.cssText;if(typeof e==`number`)return e;throw Error(`Value passed to 'css' function must be a 'css' function result: `+e+`. Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.`)})(n)+e[r+1],e[0]);return new s(n,e,a)},u=(e,t)=>{if(i)e.adoptedStyleSheets=t.map(e=>e instanceof CSSStyleSheet?e:e.styleSheet);else for(let n of t){let t=document.createElement(`style`),i=r.litNonce;i!==void 0&&t.setAttribute(`nonce`,i),t.textContent=n.cssText,e.appendChild(t)}},d=i?e=>e:e=>e instanceof CSSStyleSheet?(e=>{let t=``;for(let n of e.cssRules)t+=n.cssText;return c(t)})(e):e})),p,ee,te,ne,re,ie,ae,oe,se,ce,le,ue,de,fe,pe,me=t((()=>{f(),{is:p,defineProperty:ee,getOwnPropertyDescriptor:te,getOwnPropertyNames:ne,getOwnPropertySymbols:re,getPrototypeOf:ie}=Object,ae=globalThis,oe=ae.trustedTypes,se=oe?oe.emptyScript:``,ce=ae.reactiveElementPolyfillSupport,le=(e,t)=>e,ue={toAttribute(e,t){switch(t){case Boolean:e=e?se:null;break;case Object:case Array:e=e==null?e:JSON.stringify(e)}return e},fromAttribute(e,t){let n=e;switch(t){case Boolean:n=e!==null;break;case Number:n=e===null?null:Number(e);break;case Object:case Array:try{n=JSON.parse(e)}catch{n=null}}return n}},de=(e,t)=>!p(e,t),fe={attribute:!0,type:String,converter:ue,reflect:!1,useDefault:!1,hasChanged:de},Symbol.metadata??=Symbol(`metadata`),ae.litPropertyMetadata??=new WeakMap,pe=class extends HTMLElement{static addInitializer(e){this._$Ei(),(this.l??=[]).push(e)}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(e,t=fe){if(t.state&&(t.attribute=!1),this._$Ei(),this.prototype.hasOwnProperty(e)&&((t=Object.create(t)).wrapped=!0),this.elementProperties.set(e,t),!t.noAccessor){let n=Symbol(),r=this.getPropertyDescriptor(e,n,t);r!==void 0&&ee(this.prototype,e,r)}}static getPropertyDescriptor(e,t,n){let{get:r,set:i}=te(this.prototype,e)??{get(){return this[t]},set(e){this[t]=e}};return{get:r,set(t){let a=r?.call(this);i?.call(this,t),this.requestUpdate(e,a,n)},configurable:!0,enumerable:!0}}static getPropertyOptions(e){return this.elementProperties.get(e)??fe}static _$Ei(){if(this.hasOwnProperty(le(`elementProperties`)))return;let e=ie(this);e.finalize(),e.l!==void 0&&(this.l=[...e.l]),this.elementProperties=new Map(e.elementProperties)}static finalize(){if(this.hasOwnProperty(le(`finalized`)))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty(le(`properties`))){let e=this.properties,t=[...ne(e),...re(e)];for(let n of t)this.createProperty(n,e[n])}let e=this[Symbol.metadata];if(e!==null){let t=litPropertyMetadata.get(e);if(t!==void 0)for(let[e,n]of t)this.elementProperties.set(e,n)}this._$Eh=new Map;for(let[e,t]of this.elementProperties){let n=this._$Eu(e,t);n!==void 0&&this._$Eh.set(n,e)}this.elementStyles=this.finalizeStyles(this.styles)}static finalizeStyles(e){let t=[];if(Array.isArray(e)){let n=new Set(e.flat(1/0).reverse());for(let e of n)t.unshift(d(e))}else e!==void 0&&t.push(d(e));return t}static _$Eu(e,t){let n=t.attribute;return!1===n?void 0:typeof n==`string`?n:typeof e==`string`?e.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev()}_$Ev(){this._$ES=new Promise(e=>this.enableUpdating=e),this._$AL=new Map,this._$E_(),this.requestUpdate(),this.constructor.l?.forEach(e=>e(this))}addController(e){(this._$EO??=new Set).add(e),this.renderRoot!==void 0&&this.isConnected&&e.hostConnected?.()}removeController(e){this._$EO?.delete(e)}_$E_(){let e=new Map,t=this.constructor.elementProperties;for(let n of t.keys())this.hasOwnProperty(n)&&(e.set(n,this[n]),delete this[n]);e.size>0&&(this._$Ep=e)}createRenderRoot(){let e=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return u(e,this.constructor.elementStyles),e}connectedCallback(){this.renderRoot??=this.createRenderRoot(),this.enableUpdating(!0),this._$EO?.forEach(e=>e.hostConnected?.())}enableUpdating(e){}disconnectedCallback(){this._$EO?.forEach(e=>e.hostDisconnected?.())}attributeChangedCallback(e,t,n){this._$AK(e,n)}_$ET(e,t){let n=this.constructor.elementProperties.get(e),r=this.constructor._$Eu(e,n);if(r!==void 0&&!0===n.reflect){let i=(n.converter?.toAttribute===void 0?ue:n.converter).toAttribute(t,n.type);this._$Em=e,i==null?this.removeAttribute(r):this.setAttribute(r,i),this._$Em=null}}_$AK(e,t){let n=this.constructor,r=n._$Eh.get(e);if(r!==void 0&&this._$Em!==r){let e=n.getPropertyOptions(r),i=typeof e.converter==`function`?{fromAttribute:e.converter}:e.converter?.fromAttribute===void 0?ue:e.converter;this._$Em=r;let a=i.fromAttribute(t,e.type);this[r]=a??this._$Ej?.get(r)??a,this._$Em=null}}requestUpdate(e,t,n,r=!1,i){if(e!==void 0){let a=this.constructor;if(!1===r&&(i=this[e]),n??=a.getPropertyOptions(e),!((n.hasChanged??de)(i,t)||n.useDefault&&n.reflect&&i===this._$Ej?.get(e)&&!this.hasAttribute(a._$Eu(e,n))))return;this.C(e,t,n)}!1===this.isUpdatePending&&(this._$ES=this._$EP())}C(e,t,{useDefault:n,reflect:r,wrapped:i},a){n&&!(this._$Ej??=new Map).has(e)&&(this._$Ej.set(e,a??t??this[e]),!0!==i||a!==void 0)||(this._$AL.has(e)||(this.hasUpdated||n||(t=void 0),this._$AL.set(e,t)),!0===r&&this._$Em!==e&&(this._$Eq??=new Set).add(e))}async _$EP(){this.isUpdatePending=!0;try{await this._$ES}catch(e){Promise.reject(e)}let e=this.scheduleUpdate();return e!=null&&await e,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this.renderRoot??=this.createRenderRoot(),this._$Ep){for(let[e,t]of this._$Ep)this[e]=t;this._$Ep=void 0}let e=this.constructor.elementProperties;if(e.size>0)for(let[t,n]of e){let{wrapped:e}=n,r=this[t];!0!==e||this._$AL.has(t)||r===void 0||this.C(t,void 0,n,r)}}let e=!1,t=this._$AL;try{e=this.shouldUpdate(t),e?(this.willUpdate(t),this._$EO?.forEach(e=>e.hostUpdate?.()),this.update(t)):this._$EM()}catch(t){throw e=!1,this._$EM(),t}e&&this._$AE(t)}willUpdate(e){}_$AE(e){this._$EO?.forEach(e=>e.hostUpdated?.()),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(e)),this.updated(e)}_$EM(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$ES}shouldUpdate(e){return!0}update(e){this._$Eq&&=this._$Eq.forEach(e=>this._$ET(e,this[e])),this._$EM()}updated(e){}firstUpdated(e){}},pe.elementStyles=[],pe.shadowRootOptions={mode:`open`},pe[le(`elementProperties`)]=new Map,pe[le(`finalized`)]=new Map,ce?.({ReactiveElement:pe}),(ae.reactiveElementVersions??=[]).push(`2.1.2`)}));function he(e,t){if(!Oe(e)||!e.hasOwnProperty(`raw`))throw Error(`invalid template strings array`);return be===void 0?t:be.createHTML(t)}function ge(e,t,n=e,r){if(t===ze)return t;let i=r===void 0?n._$Cl:n._$Co?.[r],a=De(t)?void 0:t._$litDirective$;return i?.constructor!==a&&(i?._$AO?.(!1),a===void 0?i=void 0:(i=new a(e),i._$AT(e,n,r)),r===void 0?n._$Cl=i:(n._$Co??=[])[r]=i),i!==void 0&&(t=ge(e,i._$AS(e,t.values),i,r)),t}var _e,ve,ye,be,xe,Se,Ce,we,Te,Ee,De,Oe,ke,Ae,je,Me,Ne,Pe,Fe,Ie,Le,Re,m,ze,h,Be,Ve,He,Ue,We,Ge,Ke,qe,Je,Ye,Xe,Ze,Qe,$e=t((()=>{_e=globalThis,ve=e=>e,ye=_e.trustedTypes,be=ye?ye.createPolicy(`lit-html`,{createHTML:e=>e}):void 0,xe=`$lit$`,Se=`lit$${Math.random().toFixed(9).slice(2)}$`,Ce=`?`+Se,we=`<${Ce}>`,Te=document,Ee=()=>Te.createComment(``),De=e=>e===null||typeof e!=`object`&&typeof e!=`function`,Oe=Array.isArray,ke=e=>Oe(e)||typeof e?.[Symbol.iterator]==`function`,Ae=`[ 	
\f\r]`,je=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,Me=/-->/g,Ne=/>/g,Pe=RegExp(`>|${Ae}(?:([^\\s"'>=/]+)(${Ae}*=${Ae}*(?:[^ \t\n\f\r"'\`<>=]|("|')|))|$)`,`g`),Fe=/'/g,Ie=/"/g,Le=/^(?:script|style|textarea|title)$/i,Re=e=>(t,...n)=>({_$litType$:e,strings:t,values:n}),m=Re(1),Re(2),Re(3),ze=Symbol.for(`lit-noChange`),h=Symbol.for(`lit-nothing`),Be=new WeakMap,Ve=Te.createTreeWalker(Te,129),He=(e,t)=>{let n=e.length-1,r=[],i,a=t===2?`<svg>`:t===3?`<math>`:``,o=je;for(let t=0;t<n;t++){let n=e[t],s,c,l=-1,u=0;for(;u<n.length&&(o.lastIndex=u,c=o.exec(n),c!==null);)u=o.lastIndex,o===je?c[1]===`!--`?o=Me:c[1]===void 0?c[2]===void 0?c[3]!==void 0&&(o=Pe):(Le.test(c[2])&&(i=RegExp(`</`+c[2],`g`)),o=Pe):o=Ne:o===Pe?c[0]===`>`?(o=i??je,l=-1):c[1]===void 0?l=-2:(l=o.lastIndex-c[2].length,s=c[1],o=c[3]===void 0?Pe:c[3]===`"`?Ie:Fe):o===Ie||o===Fe?o=Pe:o===Me||o===Ne?o=je:(o=Pe,i=void 0);let d=o===Pe&&e[t+1].startsWith(`/>`)?` `:``;a+=o===je?n+we:l>=0?(r.push(s),n.slice(0,l)+xe+n.slice(l)+Se+d):n+Se+(l===-2?t:d)}return[he(e,a+(e[n]||`<?>`)+(t===2?`</svg>`:t===3?`</math>`:``)),r]},Ue=class e{constructor({strings:t,_$litType$:n},r){let i;this.parts=[];let a=0,o=0,s=t.length-1,c=this.parts,[l,u]=He(t,n);if(this.el=e.createElement(l,r),Ve.currentNode=this.el.content,n===2||n===3){let e=this.el.content.firstChild;e.replaceWith(...e.childNodes)}for(;(i=Ve.nextNode())!==null&&c.length<s;){if(i.nodeType===1){if(i.hasAttributes())for(let e of i.getAttributeNames())if(e.endsWith(xe)){let t=u[o++],n=i.getAttribute(e).split(Se),r=/([.?@])?(.*)/.exec(t);c.push({type:1,index:a,name:r[2],strings:n,ctor:r[1]===`.`?qe:r[1]===`?`?Je:r[1]===`@`?Ye:Ke}),i.removeAttribute(e)}else e.startsWith(Se)&&(c.push({type:6,index:a}),i.removeAttribute(e));if(Le.test(i.tagName)){let e=i.textContent.split(Se),t=e.length-1;if(t>0){i.textContent=ye?ye.emptyScript:``;for(let n=0;n<t;n++)i.append(e[n],Ee()),Ve.nextNode(),c.push({type:2,index:++a});i.append(e[t],Ee())}}}else if(i.nodeType===8){if(i.data===Ce)c.push({type:2,index:a});else{let e=-1;for(;(e=i.data.indexOf(Se,e+1))!==-1;)c.push({type:7,index:a}),e+=Se.length-1}}a++}}static createElement(e,t){let n=Te.createElement(`template`);return n.innerHTML=e,n}},We=class{constructor(e,t){this._$AV=[],this._$AN=void 0,this._$AD=e,this._$AM=t}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(e){let{el:{content:t},parts:n}=this._$AD,r=(e?.creationScope??Te).importNode(t,!0);Ve.currentNode=r;let i=Ve.nextNode(),a=0,o=0,s=n[0];for(;s!==void 0;){if(a===s.index){let t;s.type===2?t=new Ge(i,i.nextSibling,this,e):s.type===1?t=new s.ctor(i,s.name,s.strings,this,e):s.type===6&&(t=new Xe(i,this,e)),this._$AV.push(t),s=n[++o]}a!==s?.index&&(i=Ve.nextNode(),a++)}return Ve.currentNode=Te,r}p(e){let t=0;for(let n of this._$AV)n!==void 0&&(n.strings===void 0?n._$AI(e[t]):(n._$AI(e,n,t),t+=n.strings.length-2)),t++}},Ge=class e{get _$AU(){return this._$AM?._$AU??this._$Cv}constructor(e,t,n,r){this.type=2,this._$AH=h,this._$AN=void 0,this._$AA=e,this._$AB=t,this._$AM=n,this.options=r,this._$Cv=r?.isConnected??!0}get parentNode(){let e=this._$AA.parentNode,t=this._$AM;return t!==void 0&&e?.nodeType===11&&(e=t.parentNode),e}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(e,t=this){e=ge(this,e,t),De(e)?e===h||e==null||e===``?(this._$AH!==h&&this._$AR(),this._$AH=h):e!==this._$AH&&e!==ze&&this._(e):e._$litType$===void 0?e.nodeType===void 0?ke(e)?this.k(e):this._(e):this.T(e):this.$(e)}O(e){return this._$AA.parentNode.insertBefore(e,this._$AB)}T(e){this._$AH!==e&&(this._$AR(),this._$AH=this.O(e))}_(e){this._$AH!==h&&De(this._$AH)?this._$AA.nextSibling.data=e:this.T(Te.createTextNode(e)),this._$AH=e}$(e){let{values:t,_$litType$:n}=e,r=typeof n==`number`?this._$AC(e):(n.el===void 0&&(n.el=Ue.createElement(he(n.h,n.h[0]),this.options)),n);if(this._$AH?._$AD===r)this._$AH.p(t);else{let e=new We(r,this),n=e.u(this.options);e.p(t),this.T(n),this._$AH=e}}_$AC(e){let t=Be.get(e.strings);return t===void 0&&Be.set(e.strings,t=new Ue(e)),t}k(t){Oe(this._$AH)||(this._$AH=[],this._$AR());let n=this._$AH,r,i=0;for(let a of t)i===n.length?n.push(r=new e(this.O(Ee()),this.O(Ee()),this,this.options)):r=n[i],r._$AI(a),i++;i<n.length&&(this._$AR(r&&r._$AB.nextSibling,i),n.length=i)}_$AR(e=this._$AA.nextSibling,t){for(this._$AP?.(!1,!0,t);e!==this._$AB;){let t=ve(e).nextSibling;ve(e).remove(),e=t}}setConnected(e){this._$AM===void 0&&(this._$Cv=e,this._$AP?.(e))}},Ke=class{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(e,t,n,r,i){this.type=1,this._$AH=h,this._$AN=void 0,this.element=e,this.name=t,this._$AM=r,this.options=i,n.length>2||n[0]!==``||n[1]!==``?(this._$AH=Array(n.length-1).fill(new String),this.strings=n):this._$AH=h}_$AI(e,t=this,n,r){let i=this.strings,a=!1;if(i===void 0)e=ge(this,e,t,0),a=!De(e)||e!==this._$AH&&e!==ze,a&&(this._$AH=e);else{let r=e,o,s;for(e=i[0],o=0;o<i.length-1;o++)s=ge(this,r[n+o],t,o),s===ze&&(s=this._$AH[o]),a||=!De(s)||s!==this._$AH[o],s===h?e=h:e!==h&&(e+=(s??``)+i[o+1]),this._$AH[o]=s}a&&!r&&this.j(e)}j(e){e===h?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,e??``)}},qe=class extends Ke{constructor(){super(...arguments),this.type=3}j(e){this.element[this.name]=e===h?void 0:e}},Je=class extends Ke{constructor(){super(...arguments),this.type=4}j(e){this.element.toggleAttribute(this.name,!!e&&e!==h)}},Ye=class extends Ke{constructor(e,t,n,r,i){super(e,t,n,r,i),this.type=5}_$AI(e,t=this){if((e=ge(this,e,t,0)??h)===ze)return;let n=this._$AH,r=e===h&&n!==h||e.capture!==n.capture||e.once!==n.once||e.passive!==n.passive,i=e!==h&&(n===h||r);r&&this.element.removeEventListener(this.name,this,n),i&&this.element.addEventListener(this.name,this,e),this._$AH=e}handleEvent(e){typeof this._$AH==`function`?this._$AH.call(this.options?.host??this.element,e):this._$AH.handleEvent(e)}},Xe=class{constructor(e,t,n){this.element=e,this.type=6,this._$AN=void 0,this._$AM=t,this.options=n}get _$AU(){return this._$AM._$AU}_$AI(e){ge(this,e)}},Ze=_e.litHtmlPolyfillSupport,Ze?.(Ue,Ge),(_e.litHtmlVersions??=[]).push(`3.3.2`),Qe=(e,t,n)=>{let r=n?.renderBefore??t,i=r._$litPart$;if(i===void 0){let e=n?.renderBefore??null;r._$litPart$=i=new Ge(t.insertBefore(Ee(),e),e,void 0,n??{})}return i._$AI(e),i}})),et,g,tt,nt=t((()=>{me(),me(),$e(),$e(),et=globalThis,g=class extends pe{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){let e=super.createRenderRoot();return this.renderOptions.renderBefore??=e.firstChild,e}update(e){let t=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(e),this._$Do=Qe(t,this.renderRoot,this.renderOptions)}connectedCallback(){super.connectedCallback(),this._$Do?.setConnected(!0)}disconnectedCallback(){super.disconnectedCallback(),this._$Do?.setConnected(!1)}render(){return ze}},g._$litElement$=!0,g.finalized=!0,et.litElementHydrateSupport?.({LitElement:g}),tt=et.litElementPolyfillSupport,tt?.({LitElement:g}),(et.litElementVersions??=[]).push(`4.2.2`)})),rt=t((()=>{})),_=t((()=>{me(),$e(),nt(),rt()})),v,it=t((()=>{v=e=>(t,n)=>{n===void 0?customElements.define(e,t):n.addInitializer(()=>{customElements.define(e,t)})}}));function y(e){return(t,n)=>typeof n==`object`?ot(e,t,n):((e,t,n)=>{let r=t.hasOwnProperty(n);return t.constructor.createProperty(n,e),r?Object.getOwnPropertyDescriptor(t,n):void 0})(e,t,n)}var at,ot,st=t((()=>{me(),at={attribute:!0,type:String,converter:ue,reflect:!1,hasChanged:de},ot=(e=at,t,n)=>{let{kind:r,metadata:i}=n,a=globalThis.litPropertyMetadata.get(i);if(a===void 0&&globalThis.litPropertyMetadata.set(i,a=new Map),r===`setter`&&((e=Object.create(e)).wrapped=!0),a.set(n.name,e),r===`accessor`){let{name:r}=n;return{set(n){let i=t.get.call(this);t.set.call(this,n),this.requestUpdate(r,i,e,!0,n)},init(t){return t!==void 0&&this.C(r,void 0,e,t),t}}}if(r===`setter`){let{name:r}=n;return function(n){let i=this[r];t.call(this,n),this.requestUpdate(r,i,e,!0,n)}}throw Error(`Unsupported decorator location: `+r)}}));function b(e){return y({...e,state:!0,attribute:!1})}var ct=t((()=>{st()})),lt=t((()=>{})),ut,dt=t((()=>{ut=(e,t,n)=>(n.configurable=!0,n.enumerable=!0,Reflect.decorate&&typeof t!=`object`&&Object.defineProperty(e,t,n),n)}));function ft(e,t){return(n,r,i)=>{let a=t=>t.renderRoot?.querySelector(e)??null;if(t){let{get:e,set:t}=typeof r==`object`?n:i??(()=>{let e=Symbol();return{get(){return this[e]},set(t){this[e]=t}}})();return ut(n,r,{get(){let n=e.call(this);return n===void 0&&(n=a(this),(n!==null||this.hasUpdated)&&t.call(this,n)),n}})}return ut(n,r,{get(){return a(this)}})}}var pt=t((()=>{dt()})),mt=t((()=>{})),ht=t((()=>{})),gt=t((()=>{})),_t=t((()=>{})),x=t((()=>{it(),st(),ct(),lt(),pt(),mt(),ht(),gt(),_t()}));_(),x();var vt={en:{"panel.title":`RoomMind`,"panel.subtitle":`Climate management`,"panel.tab.rooms":`Rooms`,"panel.edit":`Edit room`,"panel.tab.settings":`Settings`,"panel.loading":`Loading...`,"panel.no_areas":`No areas configured in Home Assistant.`,"panel.no_areas_hint":`Add areas in HA settings to get started.`,"badge.beta":`Beta`,"badge.beta_hint":`This feature is in beta and may change or be restructured in future updates.`,"common.learn_more":`Learn more`,"panel.stat.rooms":`Rooms`,"panel.stat.heating":`Heating`,"panel.stat.cooling":`Cooling`,"panel.stat.vacation":`Vacation`,"panel.stat.away":`Away`,"panel.stat.mold":`Mold`,"panel.hide_room":`Hide`,"panel.unhide":`Show`,"panel.hidden_rooms":`Hidden rooms`,"panel.floor_other":`Other`,"panel.reorder":`Reorder rooms`,"panel.reorder_done":`Done`,"room.back":`Back to rooms`,"room.section.climate_mode":`Climate Mode`,"room.section.schedule":`Schedule & Temperatures`,"room.section.control_mode":`Control Mode`,"room.section.devices":`Devices`,"room.section.sensors":`Sensors`,"room.section.windows":`Window Sensors`,"room.control_mode.full_control":`Full Control`,"room.control_mode.managed":`Managed`,"room.control_mode.external_sensor":`External sensor: {sensor}`,"room.control_mode.no_sensor":`No external temperature sensor assigned`,"room.control_mode.mpc_active":`MPC active`,"room.control_mode.mpc_learning":`Learning`,"room.control_mode.device_setpoint":`Device setpoint: {temp}`,"room.control_mode.power":`Power: {power}%`,"room.control_mode.full_control_info":`RoomMind has full control over your climate devices. An external temperature sensor provides the actual room temperature, enabling proportional setpoint calculation. The device setpoint is dynamically adjusted based on MPC power output. The thermal model (EKF) learns your room's behavior for optimal comfort and energy efficiency.`,"room.control_mode.managed_info":`RoomMind sets the target temperature on your device (from schedule, override, or vacation settings), but the device self-regulates using its own internal sensor. No proportional boost, no thermal model learning, and no MPC optimization. For more precise control, assign an external temperature sensor in the Devices section.`,"room.delete":`Delete room`,"room.deleting":`Deleting...`,"room.saving":`Saving...`,"room.saved":`Saved`,"room.error_saving":`Error saving`,"room.confirm_delete":`Remove RoomMind configuration for "{name}"?`,"room.error_save_fallback":`Failed to save configuration`,"room.error_delete_fallback":`Failed to delete configuration`,"room.climate_control_toggle":`Climate control`,"room.climate_control_hint":`When disabled, RoomMind stops controlling devices in this room. They keep their current settings and may continue heating or cooling on their own. RoomMind will not turn them off.`,"room.outdoor_toggle":`Outdoor area`,"room.outdoor_hint":`Disables climate control, mold detection, and model training. Sensor monitoring continues.`,"room.alias.placeholder":`Custom display name`,"room.alias.clear":`Reset to area name`,"override.label":`Temporary Override`,"override.comfort":`Comfort`,"override.eco":`Eco`,"override.custom":`Custom`,"override.target":`Target:`,"override.heat_to":`Heat to:`,"override.cool_above":`Cool above:`,"override.invalid_band":`Cooling target must be at or above the heating target`,"override.activate_for":`Activate for:`,"override.error_set":`Failed to set override`,"override.error_clear":`Failed to clear override`,"hero.target":`Target`,"hero.override":`Override`,"hero.remaining":`{time} remaining`,"hero.humidity":`{value}% humidity`,"hero.device_setpoint":`Device set to {value}{unit}`,"hero.heat_source_primary":`Heating: TRV`,"hero.heat_source_secondary":`Heating: AC`,"hero.heat_source_both":`Heating: TRV + AC`,"hero.permanent":`Permanent`,"hero.waiting":`Waiting for sensor data...`,"hero.not_configured":`Not configured yet`,"hero.mpc_learning_paused":`MPC learning paused`,"hero.mpc_learning_paused.outdoor_unavailable":`RoomMind needs an outdoor temperature to learn this room's thermal model. The configured outdoor sensor is unavailable and no weather entity is set as a fallback. Configure either in Settings.`,"hero.compressor_protection_min_off":`Compressor protection: waiting for min-off`,"hero.compressor_protection_min_off_left":`Compressor protection: waiting for min-off, {minutes} min left`,"hero.compressor_protection_min_run":`Compressor protection: min-run active`,"hero.compressor_protection_min_run_left":`Compressor protection: min-run, {minutes} min left`,"hero.compressor_protection_info":`This room shares an outdoor compressor with other rooms. To prevent short-cycling, the shared compressor group enforces a minimum run time and a minimum off time before this device is allowed to switch again.`,"hero.coil_dry":`Drying ({minutes} min)`,"hero.coil_dry_drain":`Draining ({minutes} min)`,"hero.coil_dry_info":`The AC is running its evaporator drying cycle and switches off afterwards. Cooling demand cancels it immediately.`,"card.target":`Target`,"card.waiting":`Waiting for data...`,"card.humidity":`{value}% humidity`,"card.thermostat":`Thermostat`,"card.thermostats":`Thermostats`,"card.ac":`AC`,"card.acs":`ACs`,"card.climate_device":`climate device`,"card.climate_devices":`climate devices`,"card.temp_sensor":`temp sensor`,"card.temp_sensors":`temp sensors`,"card.no_climate":`No climate devices`,"card.outdoor":`Outdoor`,"card.tap_configure":`Tap to configure`,"card.mpc_active":`MPC active`,"card.mpc_learning":`MPC learning`,"card.compressor_min_run":`Min run {minutes} min`,"card.compressor_min_off":`Min off {minutes} min`,"card.not_controlled":`Not controlled by RoomMind`,"mode.auto":`Auto`,"mode.auto_desc":`Heats & cools automatically based on target temperature`,"mode.heat_only":`Heat Only`,"mode.heat_only_desc":`Heats only. With thermostats in the room, ACs stay off unless smart source selection is on`,"mode.cool_only":`Cool Only`,"mode.cool_only_desc":`Only uses ACs, thermostats stay off`,"mode.heating":`Heating`,"mode.cooling":`Cooling`,"mode.idle":`Standby`,"schedule.add_schedule":`Add schedule`,"schedule.select_schedule":`Select schedule helper`,"schedule.create_helper_hint":`Create new schedule helper in HA settings`,"schedule.selector_label":`Schedule selector entity`,"schedule.selector_value_boolean":`Current: {value}`,"schedule.selector_value_number":`Current value: {value}`,"schedule.selector_warning":`Multiple schedules but no selector set. Only the first will be used.`,"schedule.off_action_label":`Action when schedule is off`,"schedule.off_action_eco":`Use eco temperature`,"schedule.off_action_off":`Turn off devices`,"schedule.state_active":`Active`,"schedule.state_inactive":`Inactive`,"schedule.state_unreachable":`Unreachable`,"schedule.no_schedules":`No schedules configured`,"schedule.done":`Done`,"schedule.view_comfort":`Comfort: {temp}{unit}`,"schedule.view_eco":`Eco: {temp}{unit}`,"schedule.view_selector":`Active schedule selected by: {name}`,"schedule.view_selector_prefix":`Active schedule selected by:`,"schedule.help_header":`How do schedules work?`,"schedule.help_temps_title":`How is the target temperature determined?`,"schedule.help_temps":`The target temperature follows this priority chain:`,"schedule.help_temps_1":`<strong>Manual override</strong> – A temporary boost/eco/custom override always takes highest priority.`,"schedule.help_temps_2":`<strong>Block temperature</strong> – If the active schedule block has a <code>temperature</code> value in its data, that value is used.`,"schedule.help_temps_3":`<strong>Comfort temperature</strong> – If the schedule is "on" but the block has no temperature, the comfort fallback temperature below is used.`,"schedule.help_temps_4":`<strong>Eco temperature</strong> – When the schedule is "off" (outside all time blocks), the eco temperature is used.`,"schedule.help_block_title":`Setting temperature per time block`,"schedule.help_block":`You can set a specific temperature for each time block by adding a <code>temperature</code> value in the schedule's YAML configuration:`,"schedule.help_block_note":`If a block has no <code>temperature</code> data, the comfort fallback temperature is used instead.`,"schedule.help_split_title":`Separate heating/cooling targets per block`,"schedule.help_split":`For auto-mode rooms, you can set separate heating and cooling targets per time block using <code>heat_temperature</code> and <code>cool_temperature</code>:`,"schedule.help_split_note":`If only one is set, the other falls back to the room's comfort temperature. These keys take priority over <code>temperature</code> when present.`,"schedule.help_multi_title":`Multiple schedules`,"schedule.help_multi":`You can add multiple schedules and switch between them using a <strong>selector entity</strong>. This can be an <code>input_boolean</code> (toggles between schedule 1 and 2) or an <code>input_number</code> (selects by number). Without a selector entity, only the first schedule is used.`,"schedule.column_comfort":`Comfort`,"schedule.column_eco":`Eco`,"schedule.row_heat":`Heat`,"schedule.row_cool":`Cool`,"schedule.view_heat":`Heat: {comfort} / {eco}{unit}`,"schedule.view_cool":`Cool: {comfort} / {eco}{unit}`,"schedule.comfort_hint_auto":`Comfort: target when schedule is on. Eco: target when schedule is off. Rows set the target for heating and cooling.`,"schedule.comfort_label":`Fallback comfort temperature`,"schedule.eco_label":`Eco temperature`,"schedule.comfort_hint":`Used when schedule is "on" but no temperature is set in the block`,"schedule.from_schedule":`{temp}{unit} from schedule`,"schedule.from_schedule_split":`{heat}{unit} / {cool}{unit} from schedule`,"schedule.fallback":`{temp}{unit} (fallback)`,"schedule.block_temp_rejected":`Values outside the valid range {min}–{max}{unit}: {values}. The comfort target is used instead — check the schedule helper for a typo.`,"schedule.eco_detail":`{temp}{unit} (eco)`,"devices.climate_entities":`Climate entities`,"devices.temp_sensors":`Temperature sensors`,"devices.humidity_sensors":`Humidity sensors`,"devices.no_climate":`No climate entities found in this area.`,"devices.no_temp_sensors":`No temperature sensors found in this area.`,"devices.no_humidity_sensors":`No humidity sensors found in this area.`,"devices.occupancy_sensors":`Occupancy Sensors`,"devices.no_occupancy_sensors":`No occupancy sensors found in this area`,"devices.occupancy_sensor_hint":`Improves thermal model accuracy by tracking room occupancy`,"devices.occupancy_eco":`Eco when the room is empty`,"devices.occupancy_eco_hint":`When all occupancy sensors report the room empty for longer than the delay, the room drops to its eco temperature. As soon as someone is detected again, it follows its schedule. An empty room is kept at eco and only heats to comfort once someone is in it, so it takes a while to warm up. Temporary overrides, vacation mode and presence detection take priority.`,"devices.occupancy_eco_delay":`Delay before eco`,"devices.occupancy_eco_view":`Eco after {minutes} min without occupancy`,"devices.window_sensors":`Window / door sensors`,"devices.no_window_sensors":`No window/door sensors found in this area.`,"devices.window_open_delay":`Delay before pausing`,"devices.window_close_delay":`Delay before resuming`,"devices.add_entity":`Add entity`,"devices.done":`Done`,"devices.other_area":`Other area`,"devices.type_thermostat":`Thermostat`,"devices.type_ac":`Climate Device`,"devices.type_label":`Type`,"devices.select_to_configure":`Select a device to configure`,"devices.heating_system_type":`Heating System Type`,"devices.heating_system_type_info":`After heating stops, radiators and especially underfloor systems continue to release stored heat. RoomMind accounts for this residual heat to avoid overshooting and improve model accuracy. Underfloor rooms also get longer minimum run times.`,"devices.system_type_none":`Standard (no residual heat)`,"devices.system_type_radiator":`Radiator`,"devices.system_type_underfloor":`Underfloor Heating`,"devices.underfloor_delay_hint":`Underfloor heating has long restart times. A window-open delay of at least 5 minutes is recommended to avoid unnecessary shutoffs.`,"devices.heating_system_type_boost_hint":`Tip: If the heating system has changed, you can accelerate re-learning under Settings.`,"devices.idle_action":`When idle`,"devices.idle_action_off":`Turn off`,"devices.idle_action_fan_only":`Fan only`,"devices.idle_action_setback":`Setback`,"devices.idle_action_low":`Low setpoint (keep awake)`,"devices.idle_action_low_hint":`Lowers the setpoint to the device minimum instead of sending off. Prevents TRVs that hibernate in off mode from losing later commands.`,"devices.idle_fan_mode":`Fan speed`,"devices.idle_fan_mode_keep":`Don't change`,"devices.setpoint_mode":`Setpoint mode`,"devices.setpoint_mode_proportional":`Proportional (raised setpoint)`,"devices.setpoint_mode_direct":`Direct (device regulates)`,"devices.setpoint_offset":`Setpoint offset`,"devices.setpoint_offset_hint":`Use this if the device's own sensor reads differently from your room sensor. The offset is added to the room target before it is sent to the device (heating and cooling). Device reads colder than the room: negative value. Device reads warmer: positive value. Example: you want 24°, but while cooling the device thinks the room is 2° colder than it is and stops too early. Enter -2: the device then gets 22° and keeps running until the room is really at 24°. 0 = no offset.`,"devices.setpoint_mode_hint":`Direct sends the actual room target to the device — best for thermostats and space heaters that regulate themselves. Proportional sends a boosted setpoint toward the device max_temp — best for radiator valves (TRVs).`,"devices.coil_dry":`Evaporator drying`,"devices.coil_dry_inherit":`Use global setting`,"devices.coil_dry_on":`Always on`,"devices.coil_dry_off":`Always off`,"devices.coil_dry_minutes":`Drying time (0 = global: {minutes} min)`,"devices.coil_dry_mode":`Drying mode`,"devices.coil_dry_mode_inherit":`Global ({value})`,"devices.coil_dry_fan_mode":`Fan speed while drying`,"devices.coil_dry_fan_mode_inherit":`Global ({value})`,"devices.coil_dry_fan_mode_keep":`Keep current speed`,"devices.coil_dry_summary":`Drying`,"devices.coil_dry_global_off_hint":`Evaporator drying is switched off globally, so nothing runs for this device. Turn it on in the settings, or set this device to "Always on".`,"devices.valve_protection_excluded":`Excluded from valve protection`,"devices.valve_protection_exclude_hint":`This entity will not be cycled by valve protection (e.g. virtual boiler entities)`,"devices.valve_direct_control":`Direct valve control`,"devices.valve_opening_entity":`Valve opening degree`,"devices.valve_closing_entity":`Valve closing degree`,"devices.valve_direct_control_hint":`For thermostats that let Home Assistant set the valve opening (e.g. SONOFF TRVZB: valve_opening_degree and valve_closing_degree, both needed). RoomMind then holds the valve at the opening the room needs, e.g. 30 %, instead of opening it fully: fewer valve movements, quieter and more even heat. Clear the fields or switch off climate control and RoomMind sets both back to 100 %.`,"devices.valve_direct_control_toggle_hint":`For thermostats that let Home Assistant set the valve opening (e.g. SONOFF TRVZB). RoomMind then holds the valve at the opening the room needs, e.g. 30 %, instead of opening it fully: fewer valve movements, quieter and more even heat. Switched off, or with climate control off, the valve goes back to the thermostat's own control.`,"devices.valve_direct_badge":`Direct valve`,"devices.info.types_title":`Device types`,"devices.info.types_body":`Thermostat means a radiator thermostat / TRV. Climate Device means an AC, heat pump, or other climate entity used for cooling or forced-air heating. Both are Home Assistant climate entities; the distinction is how RoomMind controls them.`,"devices.info.control_title":`How RoomMind controls them`,"devices.info.control_body":`Setpoint mode only applies to thermostats in Full Control rooms with an external temperature sensor. Use Proportional when RoomMind should drive heating output by sending boosted setpoints. Use Direct when the device should regulate itself around the real target temperature.`,"devices.info.modes_title":`Idle behavior`,"devices.info.modes_body":`When idle only applies to Climate Devices. Turn off powers the device down. Fan only keeps airflow without heating or cooling. Setback keeps the current mode active but moves the target 2°C away from the room target. This setback offset is currently fixed. With an external temperature sensor and a trained model, the device is turned off after an hour without heating or cooling if RoomMind does not expect to need it in the next hour. For Thermostats, Low keeps the TRV active at its minimum setpoint instead of off, useful for battery-powered Zigbee TRVs that sleep when set to off.`,"devices.info.heat_source_title":`Smart source selection`,"devices.info.heat_source_body":`This appears only when a room has both a thermostat/TRV and a Climate Device plus an external temperature sensor. RoomMind can then choose which source should handle heating based on temperature gap and outdoor conditions.`,"hero.window_open":`Window open – paused`,"card.window_open":`Window open`,"room.section.covers":`Covers & Blinds`,"covers.section_title":`Covers & Blinds`,"covers.auto_control":`Automatic blind control`,"covers.auto_control_hint":`RoomMind closes blinds when solar gain is predicted to overheat the room.`,"covers.deploy_threshold":`Deploy threshold`,"covers.deploy_threshold_hint":`Close blinds when predicted temperature exceeds target by this amount.`,"covers.min_position":`Minimum open position`,"covers.min_position_hint":`Blinds will never close further than this (0 = fully closed allowed).`,"covers.override_minutes":`Override pause duration`,"covers.override_minutes_hint":`How long to pause automatic control after manual cover movement. Set to 0 for no pause.`,"covers.no_covers":`No cover entities configured.`,"covers.no_covers_in_area":`No cover entities found in this area.`,"covers.add_cover":`Add cover entity...`,"covers.shading_active":`Shading active`,"covers.auto_paused":`Auto paused (manual override)`,"covers.auto_paused_until":`Auto control paused until`,"covers.resume_auto":`Resume automatic control`,"covers.done":`Done`,"covers.night_close":`Close at night`,"covers.night_close_hint":`Automatically close covers at sunset and open at sunrise.`,"covers.night_close_active":`Night closing active`,"covers.schedule_group_title":`Schedule`,"covers.solar_group_title":`Solar control`,"covers.schedule_section":`Cover schedules`,"covers.schedule_section_hint":`Define time windows for cover control using HA schedule helpers. In Force position mode the schedule's position overrides solar/thermal logic. In Allow solar protection mode RoomMind decides the position within the active window.`,"covers.add_schedule":`Add cover schedule...`,"covers.schedule_mode_force":`Force position`,"covers.schedule_mode_gate":`Allow solar protection`,"covers.schedule_mode_gate_short":`Solar gate`,"covers.schedule_position":`Position`,"covers.schedule_position_hint":`Cover position when this schedule is active (0% = fully closed, 100% = fully open).`,"covers.schedule_selector":`Schedule selector entity`,"covers.schedule_selector_hint":`Choose which schedule is active. input_boolean: off=#1, on=#2. input_number: value selects schedule number.`,"covers.schedule_selector_warning":`Multiple schedules configured but no selector set. Only the first schedule will be used.`,"covers.schedule_state_active":`Active`,"covers.schedule_state_inactive":`Inactive`,"covers.schedule_state_unreachable":`Unreachable`,"covers.schedule_active":`Schedule active`,"covers.schedule_create_link":`Create schedule helper`,"covers.night_position":`Night position`,"covers.night_position_hint":`Cover position when night close is active (0% = fully closed). Covers with an individual min. position will never go below that.`,"covers.night_close_advanced":`Advanced`,"covers.night_close_elevation":`Sun position threshold`,"covers.night_close_elevation_hint":`How far below or above the horizon the sun must be. 0° = exactly at sunset/sunrise. Negative = darker (e.g. -6° = dusk, when it's noticeably dark). Positive = still bright (e.g. 5° = sun still visible above horizon).`,"covers.night_close_offset":`Time offset`,"covers.night_close_offset_hint":`Additional shift relative to the sun position threshold. Positive = close later (e.g. +20 = 20 min after threshold is reached), negative = close earlier.`,"covers.outdoor_min_temp":`Min. outdoor temperature`,"covers.outdoor_min_temp_hint":`Don't close covers for solar protection below this outdoor temperature. Solar heat gain is welcome when it's cold.`,"covers.per_cover_title":`Per-cover settings`,"covers.per_cover_hint":`Set the compass direction each cover faces and optional individual minimum positions.`,"covers.per_cover_min_short":`Min`,"covers.per_cover_min_position":`Min. position`,"covers.per_cover_min_position_hint":`Individual minimum position per cover. Covers will never close further than this. Useful when blinds are physically fully closed at a position > 0%.`,"covers.snap_deploy":`Snap to minimum position`,"covers.snap_deploy_hint":`Close covers directly to the minimum position instead of gradually closing. Recommended for triple-pane windows where intermediate positions can cause thermal stress.`,"covers.info.selection_title":`Cover selection`,"covers.info.selection_body":`Select covers/blinds from this area or add entities from other areas. RoomMind tracks their position and can control them automatically.`,"covers.info.schedule_title":`Schedule control`,"covers.info.schedule_body":`Use HA schedule helpers to define times when covers should close (e.g. privacy in the evening). The schedule's position attribute determines how far they close. Schedules override all other automatic logic.`,"covers.info.solar_title":`Solar/thermal control`,"covers.info.solar_body":`When automatic control is enabled, RoomMind predicts whether solar radiation will overheat the room and closes blinds preventively. It uses learned thermal data when available, otherwise a conservative default. The deploy threshold controls how much predicted overshoot is needed before blinds close.`,"covers.info.night_title":`Night closing`,"covers.info.night_body":`Closes covers at sunset and opens them at sunrise. You can set a custom night position (e.g. 10% = almost closed but not fully).`,"covers.info.override_title":`Manual override`,"covers.info.override_body":`If you manually move a cover, RoomMind detects this and pauses automatic control for the configured duration. This prevents fighting with the user.`,"covers.info.priority_title":`Priority order`,"covers.info.priority_body":`Manual override > Schedule > Night close > Solar/thermal control. Higher priority rules always win. When no rule applies, covers stay open.`,"covers.info.entities_title":`HA entities`,"covers.info.entities_body":`RoomMind creates two entities per room for external use: switch.roommind_{area}_cover_auto (enable/disable automatic cover control — usable in automations or dashboards) and binary_sensor.roommind_{area}_cover_paused (on when manual override is active, e.g. after manually moving a cover).`,"covers.orientation_group_title":`Cover orientation`,"covers.orientation_hint":`Set the compass direction each cover faces. RoomMind then shades only while the sun is actually on that side of the building. Without a direction, covers react to sunshine in general and may close from sunrise, even on a north window.`,"covers.orientation_none":`Any direction`,"covers.orientation_N":`N`,"covers.orientation_NE":`NE`,"covers.orientation_E":`E`,"covers.orientation_SE":`SE`,"covers.orientation_S":`S`,"covers.orientation_SW":`SW`,"covers.orientation_W":`W`,"covers.orientation_NW":`NW`,"covers.orientation_N_full":`North`,"covers.orientation_NE_full":`Northeast`,"covers.orientation_E_full":`East`,"covers.orientation_SE_full":`Southeast`,"covers.orientation_S_full":`South`,"covers.orientation_SW_full":`Southwest`,"covers.orientation_W_full":`West`,"covers.orientation_NW_full":`Northwest`,"settings.general_title":`General`,"settings.group_by_floor":`Group rooms by floor`,"settings.climate_control_active":`Climate control active`,"settings.climate_control_hint":`When disabled, RoomMind continues to monitor all sensors and train the model, but sends no commands to your heating or cooling devices. Your devices keep their current mode and setpoint and may continue heating or cooling on their own. RoomMind will not turn them off.`,"settings.learning_title":`Model Training`,"settings.learning_hint":`When paused, RoomMind stops collecting new measurement data and training the thermal model. Existing model data is preserved.`,"settings.learning_exceptions":`Exceptions`,"settings.learning_room_paused":`room paused`,"settings.learning_rooms_paused":`rooms paused`,"settings.sensors_title":`Sensors & Data Sources`,"settings.control_title":`Control`,"settings.outdoor_sensor":`Outdoor Temperature`,"settings.outdoor_sensor_label":`Outdoor temperature sensor`,"settings.outdoor_current":`Currently {temp}{unit} outside`,"settings.outdoor_waiting":`Waiting for sensor data...`,"settings.outdoor_humidity_sensor":`Outdoor Humidity`,"settings.outdoor_humidity_label":`Outdoor humidity sensor`,"settings.outdoor_humidity_current":`Currently {value}% outside`,"settings.smart_control":`Smart Climate Control`,"settings.smart_control_hint":`Configure outdoor temperature limits for heating and cooling.`,"settings.outdoor_cooling_min":`Minimum outdoor temp for cooling`,"settings.outdoor_cooling_min_hint":`AC stays off when outdoor temperature is below this value. A manual override ignores this limit`,"settings.outdoor_heating_max":`Maximum outdoor temp for heating`,"settings.outdoor_heating_max_hint":`Heating stays off when outdoor temperature exceeds this value. A manual override ignores this limit`,"settings.saving":`Saving...`,"settings.saved":`Saved`,"settings.error":`Error saving`,"devices.using_builtin_sensor":`Using thermostat's built-in sensor`,"settings.climate_intelligence":`Climate Intelligence`,"settings.control_mode":`Control Mode`,"settings.control_mode_simple":`Simple (Bang-Bang)`,"settings.control_mode_mpc":`Intelligent (MPC)`,"settings.control_mode_hint":`Intelligent: MPC learns each room's thermal behavior and plans ahead (on/off control while it is still learning). Simple: on/off control with hysteresis only; the model keeps learning in the background but does not make decisions, and automatic blinds use a simpler solar estimate instead of the MPC forecast.`,"settings.comfort_weight":`Priority`,"settings.comfort_weight_comfort":`Comfort`,"settings.comfort_weight_efficiency":`Efficiency`,"settings.comfort_weight_hint":`Balances temperature precision against energy use. Comfort reacts earlier and stays closer to target. Efficiency allows more drift to reduce heating/cooling runtime. At the default and above, rooms are heated up ahead of a schedule block so they are warm when it starts; below the default it starts later, at full efficiency only shortly before the block.`,"settings.weather_entity":`Weather Forecast`,"settings.weather_entity_hint":`Optional: enables predictive outdoor temperature planning, and acts as a fallback when the outdoor sensor is unavailable`,"settings.outdoor_unavailable_notify":`Notify when outdoor temperature is unavailable`,"settings.outdoor_unavailable_notify_hint":`Show a Home Assistant notification when neither the outdoor sensor nor the weather entity has reported a temperature for 30 minutes. While this is the case, RoomMind pauses thermal model learning to avoid corruption.`,"settings.prediction_enabled":`Temperature prediction`,"settings.prediction_enabled_hint":`Show predicted temperature trend in analytics charts. Disable if you experience slow performance.`,"vacation.title":`Vacation Mode`,"vacation.hint":`Sets all rooms to a setback temperature until the end date.`,"vacation.active_label":`Vacation mode active`,"vacation.end_date":`End date & time`,"vacation.setback_temp":`Setback temperature`,"vacation.no_end_date":`No end date`,"vacation.deactivate":`Deactivate`,"tabs.analytics":`Analytics`,"analytics.select_room":`Select Room`,"analytics.temperature":`Temperature`,"analytics.target":`Target`,"analytics.prediction":`Prediction`,"analytics.outdoor":`Outdoor`,"analytics.model_status":`Model Status`,"analytics.confidence":`Confidence`,"analytics.heating_rate":`Heating Strength`,"analytics.cooling_rate":`Cooling Strength`,"analytics.solar_gain":`Solar Gain (full sun)`,"analytics.solar_gain_sub":`now {now} · today up to {today}`,"analytics.occupancy_gain":`Occupancy Gain`,"analytics.time_constant":`Time Constant`,"analytics.samples":`Samples`,"analytics.prediction_accuracy":`Prediction Accuracy`,"analytics.avg_deviation":`Avg. Deviation`,"analytics.data_sources":`Data Sources`,"analytics.data_points":`Data Points`,"analytics.control_mode":`Control Mode`,"analytics.control_mode_mpc":`MPC active`,"analytics.control_mode_bangbang":`MPC learning`,"analytics.last_model_update":`Last Model Update`,"analytics.accuracy_idle":`Accuracy (Idle)`,"analytics.accuracy_heating":`Accuracy (Heating)`,"analytics.info.accuracy_idle":`How precisely the model predicts temperature when neither heating nor cooling is active. A lower value means the model understands your room's natural heat loss well. This is the first value to improve because idle data is collected continuously.`,"analytics.info.accuracy_heating":`How precisely the model predicts temperature during active heating. This value stays high initially because the model needs real heating cycles to learn from. Once your heating has run a few times, this value will drop and MPC control becomes available.`,"analytics.info.confidence":`Overall model readiness for intelligent MPC control, combining two factors: data quantity (how many idle and active-mode samples have been collected) and prediction accuracy (how precise the temperature forecasts are). Confidence starts at 0% and rises as the model collects data and learns. Around 50% means enough idle data but still waiting for heating/cooling cycles. Above 80% means the model has enough data and accurate predictions — MPC control becomes available. 100% is the theoretical maximum when predictions are as accurate as physically possible.`,"analytics.info.time_constant":`How long it takes your room to naturally cool down halfway toward the outdoor temperature when heating is off. A longer time constant means better insulation — the room holds warmth longer. A short time constant means the room cools quickly. The model learns this by observing temperature drops during idle periods.`,"analytics.info.heating_rate":`How strongly your heating affects the room temperature. A higher value means your heating system warms the room faster relative to its thermal mass. The model learns this by observing how quickly the temperature rises during active heating, and uses it to predict how long heating needs to run.`,"analytics.info.cooling_rate":`How strongly your AC affects the room temperature. A higher value means the AC cools the room faster relative to its thermal mass. The model learns this by observing how quickly the temperature drops during active cooling, and uses it to predict how long the AC needs to run. The air near the sensor drops faster in the first minutes of a run and warms back up after it stops; the model tracks that part separately, so this value describes how fast the AC cools the whole room including walls and furniture.`,"analytics.info.solar_gain":`How fast the sun warms the room at full sunshine (1000 W/m², a clear summer noon). Most of the time far less sun reaches the window: the line below shows what the sun adds right now (clouds and blinds included) and at most today under a clear sky. In winter that is often only a quarter of the full-sun value. Compare the heating strength with these two values. The model learns this by observing how the room warms during sunny periods when heating is off and uses it to reduce heating when sun is expected.`,"analytics.info.occupancy_gain":`The estimated heat contribution from occupancy (people, pets, computers) while the room is occupied. The model learns this by observing temperature changes when the configured occupancy sensors are active. Separating this from solar gain prevents body heat from being misattributed to sunlight. Only shown when at least one occupancy sensor is configured for this room.`,"analytics.info.data_sources":`Number of measurement samples used for model training.`,"analytics.info.data_points":`Total number of observations the model has been trained on. More data points generally lead to better predictions. The model collects a new data point roughly every 3 minutes while RoomMind is running.`,"analytics.no_data":`No data yet — model is learning`,"analytics.loading":`Loading analytics...`,"settings.reset_title":`Reset Thermal Data`,"settings.reset_hint":`Clear learned thermal model data and history. The model will start learning from scratch.`,"settings.reset_all_label":`All rooms`,"settings.reset_all_hint":`Clear thermal data and history for all rooms at once.`,"settings.reset_all_btn":`Reset all`,"settings.reset_all_confirm":`Clear all learned thermal data and history for ALL rooms? All models will start learning from scratch.`,"settings.reset_room_label":`Individual room`,"settings.reset_room_hint":`Select a room to clear its thermal data and history.`,"settings.reset_room_confirm":`Clear all learned thermal data and history for this room? The model will start learning from scratch.`,"settings.reset_room_select":`Select room`,"settings.reset_btn":`Reset`,"settings.reset_no_rooms":`No configured rooms.`,"settings.boost_title":`Accelerate Learning`,"settings.boost_hint":`The thermal model learns your room's heating and cooling behavior over time. After major changes (new radiator, AC, insulation, furniture), the model may be inaccurate. This increases the model's uncertainty so it adapts faster to new conditions.`,"settings.boost_label":`Accelerate learning`,"settings.boost_room_select":`Select room`,"settings.boost_btn":`Accelerate`,"settings.boost_cooldown":`Active – re-learning in progress`,"settings.boost_no_rooms":`No configured rooms.`,"analytics.range_1d":`Today`,"analytics.range_2d":`2 days`,"analytics.range_7d":`Week`,"analytics.range_30d":`Month`,"analytics.export":`Measurements`,"analytics.heating_period":`Heating`,"analytics.cooling_period":`Cooling`,"analytics.blind_position":`Blind position`,"analytics.window_open_period":`Window open`,"analytics.chart_info_title":`How to read this chart`,"analytics.exported":`Exported!`,"analytics.copy_diagnostics":`Diagnostics`,"analytics.export_download":`Download file`,"analytics.export_clipboard":`Copy to clipboard`,"analytics.copied_to_clipboard":`Copied!`,"analytics.range_from":`From`,"analytics.range_to":`To`,"analytics.chart_info_body":`**Lines:** The solid orange line shows the measured room temperature. The green dashed line is the target temperature from your schedule. The blue dotted line is the model's temperature prediction.

**Shaded areas:** Red shading marks heating periods, blue marks cooling, and teal marks times when a window was open.

**Future forecast (right of the 'now' line):** The green dashed line shows the upcoming schedule targets for the next 3 hours. The blue dotted line shows the predicted temperature trend.

**Prediction modes:** When 'MPC active' is shown, the prediction uses the full MPC optimizer with intelligent pre-heating/pre-cooling. While the model is still learning, a simpler simulation is used.

**Limitations:** The prediction assumes current conditions stay constant (outdoor temperature, window state). The simulation accuracy depends on how well the thermal model has learned your room — early on, predictions may be less accurate. Once MPC activates, predictions become significantly more reliable.`,"presence.title":`Presence Detection`,"presence.hint":`Uses eco temperature when nobody is home.`,"presence.hint_detail":`When enabled, all rooms switch to eco temperature as soon as none of the configured persons are home. You can optionally restrict per room which persons are relevant.`,"presence.add_person":`Add person`,"presence.add_entity":`Add presence entity`,"presence.person_label":`Person`,"room.section.presence":`Presence`,"presence.room_help_header":`How does per-room presence work?`,"presence.room_help_body":`Select which persons are relevant for this room. The room switches to eco temperature when none of the selected persons are home. Without selection, the global rule applies: eco when nobody is home.`,"presence.state_home":`Home`,"presence.state_away":`Away`,"presence.room_none_assigned":`Global rule — eco when nobody is home`,"presence.missing_entity_hint":`This entity no longer exists in Home Assistant — uncheck it to remove it from this room.`,"presence.ignore_toggle":`Ignore presence`,"presence.ignore_hint":`Controls how this room reacts to presence. You can assign specific persons below. The room switches to eco when none of the assigned persons are home. Use the toggle above to skip detection entirely and always follow the schedule.`,"presence.help_ignore_title":`What does "Ignore presence" do?`,"presence.help_ignore_body":`When enabled, this room skips presence detection entirely. It always follows its schedule and never switches to eco based on who is home. Useful for rooms that should maintain temperature regardless of presence, such as a server room, a pet room, or a guest room used by someone not tracked by Home Assistant.`,"presence.tile_ignored":`Presence detection is ignored. Room always follows its schedule.`,"presence.away_action_label":`Action when nobody is home`,"presence.away_action_eco":`Use eco temperature`,"presence.away_action_off":`Turn off devices`,"presence.clears_override_label":`Absence stops override`,"presence.clears_override_hint":`When nobody is home, manual overrides are paused and the room follows the away action. When someone returns, the override resumes until it expires.`,"card.presence_away":`Away`,"valve_protection.title":`Valve Protection`,"valve_protection.hint":`Periodically opens idle TRV valves briefly to prevent seizing or calcification.`,"valve_protection.interval_label":`Cycle interval`,"valve_protection.interval_suffix":`days`,"valve_protection.interval_hint":`How long a valve can be idle before being cycled (1–90 days)`,"compressor.title":`Compressor Protection`,"compressor.no_groups":`No compressor groups configured.`,"compressor.add_group":`Add compressor group`,"compressor.group_name":`Group name`,"compressor.members":`Indoor units`,"compressor.members_hint":`Select all climate devices powered by this compressor (indoor splits, TRVs on radiators, fan coils).`,"compressor.min_run":`Minimum run time`,"compressor.min_run_hint":`Compressor must run at least this long once started.`,"compressor.min_run_suffix":`min`,"compressor.min_off":`Minimum off time`,"compressor.min_off_hint":`Compressor must stay off at least this long after stopping.`,"compressor.min_off_suffix":`min`,"compressor.delete":`Delete group`,"compressor.delete_confirm":`Delete compressor group "{name}"?`,"compressor.master_entity":`Master device`,"compressor.master_entity_hint":`The central unit that powers the indoor devices in this group, e.g. a gas boiler, outdoor heat pump unit, or ducted AC master switch. RoomMind will turn it on when any room needs heating or cooling, and off when all rooms are idle. Leave empty to use only the action script or short-cycle protection.`,"compressor.conflict_resolution":`Conflict resolution`,"compressor.conflict_resolution_hint":`Determines what happens when some rooms need heating while others need cooling at the same time. Heating priority: heating always wins (safest for frost protection). Cooling priority: cooling always wins. Majority: the mode with more rooms wins, ties go to heating. Outdoor temperature: uses the outdoor heating max threshold from settings to decide automatically.`,"compressor.conflict_heating_priority":`Heating priority (frost protection)`,"compressor.conflict_cooling_priority":`Cooling priority`,"compressor.conflict_majority":`Majority wins`,"compressor.conflict_outdoor_temp":`Based on outdoor temperature`,"compressor.action_script":`Action script`,"compressor.action_script_hint":`A Home Assistant script that runs whenever the heating/cooling demand changes. Useful for systems that need special commands, e.g. cancelling a Vaillant Quick Veto or toggling a relay. Works with or without a master device. Without a master device, only the script is triggered. Receives variables: action (heat/cool/idle), master_entity, members, active_members.`,"compressor.enforce_uniform_mode":`Enforce uniform mode`,"compressor.enforce_uniform_mode_hint":`All thermostats in this group must operate in the same HVAC mode (all heating or all cooling). Rooms that disagree with the resolved group mode will be set to idle. Use this for heat pumps that start automatically but require all connected units to run the same mode.`,"coil_dry.title":`Evaporator drying`,"coil_dry.hint":`After cooling, keep the indoor fan running for a while before the AC really switches off. Dries the evaporator so no biofilm forms and the next start does not smell musty.`,"coil_dry.duration_label":`Drying time`,"coil_dry.duration_suffix":`min`,"coil_dry.duration_hint":`How long the fan keeps running (1–60 min). At a low fan speed allow roughly twice as long as at a high one.`,"coil_dry.min_cooling_label":`Minimum cooling time`,"coil_dry.min_cooling_suffix":`min`,"coil_dry.min_cooling_hint":`Only dry after the AC has cooled for at least this long. Short cooling bursts are added up (1–240 min).`,"coil_dry.mode_label":`Drying mode`,"coil_dry.mode_fan_only":`fan_only (fan only)`,"coil_dry.mode_dry":`dry (dehumidify)`,"coil_dry.mode_dry_warning":`In dry mode the compressor keeps running and cools the coil down again, which works against drying. Only pick this if your unit's dry mode is fan-driven.`,"coil_dry.fan_mode_label":`Fan speed while drying`,"coil_dry.fan_mode_keep":`Keep current speed`,"coil_dry.fan_mode_hint":`A higher speed dries faster but is louder. Speeds the device does not report are skipped — it then keeps its current one.`,"coil_dry.drain_label":`Drain delay`,"coil_dry.drain_suffix":`min`,"coil_dry.drain_hint":`Leave the AC off first so condensate can drain, then start the fan (0–15 min). Reduces how much moisture is blown back into the room.`,"mold.title":`Mold Risk Protection`,"mold.detection":`Mold Detection`,"mold.detection_desc":`Receive notifications when humidity indicates mold risk`,"mold.threshold":`Humidity threshold (%)`,"mold.threshold_hint":`Alert when room humidity stays above this value`,"mold.insulation":`Wall insulation`,"mold.insulation_hint":`Used to estimate how cold the coldest spot of your exterior walls gets (corners, window reveals). If unsure, keep Standard. Needs an outdoor temperature.`,"mold.insulation_poor":`Uninsulated old building`,"mold.insulation_standard":`Standard`,"mold.insulation_good":`Well insulated (new or renovated)`,"mold.sustained":`Sustained duration (minutes)`,"mold.sustained_hint":`Alert only after risk persists for this long`,"mold.prevention":`Mold Prevention`,"mold.prevention_desc":`Automatically raise temperature to reduce mold risk`,"mold.intensity":`Intensity`,"mold.intensity_light":`Light (+{delta}{unit})`,"mold.intensity_medium":`Medium (+{delta}{unit})`,"mold.intensity_strong":`Strong (+{delta}{unit})`,"mold.intensity_hint":`Warmer air reduces surface humidity on cold walls. Light is usually sufficient for moderate risk, Strong can lower surface humidity by up to 8–10% — but uses noticeably more energy.`,"card.mold_warning":`Mold risk`,"card.mold_critical":`Mold danger!`,"card.mold_prevention":`Mold prevention +{delta}{unit}`,"room.mold_surface_rh":`Est. surface humidity: {value}%`,"room.mold_surface_temp":`wall {value}{unit}`,"settings.intro.general":`Basic display and control settings.`,"settings.intro.sensors":`Configure outdoor sensors and weather data for accurate climate control.`,"settings.intro.control":`Choose how RoomMind controls your climate devices and set priority and thresholds.`,"settings.intro.presence":`Automatically reduce temperature when nobody is home.`,"settings.intro.vacation":`Set all rooms to a reduced temperature while you are away.`,"settings.intro.valve":`Periodically move idle TRV valves to prevent seizing or calcification.`,"settings.intro.compressor":`Manage groups of indoor units that share an outdoor compressor or central heating source. Optionally assign a master device (boiler, outdoor unit) to automatically turn on/off based on room demand. Short-cycle protection prevents rapid on/off switching that can damage equipment.`,"settings.intro.mold":`Monitor humidity and automatically reduce mold risk.`,"settings.intro.notifications":`Configure who receives alerts and how.`,"settings.intro.learning":`Manage thermal model training and accelerate re-learning after changes.`,"settings.intro.reset":`Clear learned thermal model data. The model will start learning from scratch.`,"notifications.title":`Notifications`,"notifications.enabled":`Enable notifications`,"notifications.enabled_hint":`When disabled, no notifications are sent — neither to devices nor to the HA sidebar.`,"notifications.desc":`Choose which devices receive alerts. Without targets, alerts appear in the HA sidebar.`,"notifications.add_target_label":`Add notification device`,"notifications.add_target_hint":`Type the entity ID if your device is not listed (e.g. notify.mobile_app_...). You can find it under Settings → Devices → your phone → Notify entity.`,"notifications.target_unnamed":`Unnamed device`,"notifications.target_person":`Person`,"notifications.target_when_always":`Always`,"notifications.target_when_home":`Only when home`,"notifications.cooldown":`Notification cooldown (minutes)`,"notifications.cooldown_hint":`Minimum time between repeated alerts per room`,"notifications.mold_prevention_notify":`Notify when mold prevention activates`,"notifications.mold_prevention_notify_hint":`Also send a notification when prevention activates (temperature raised)`,"room.section.heat_source":`Heat Source Orchestration`,"heat_source.toggle":`Smart source selection`,"heat_source.toggle_hint":`When this room has both radiator thermostats and an AC/heat pump, RoomMind intelligently routes heating demand to the most efficient device based on temperature gap and outdoor conditions.`,"heat_source.primary_delta":`Boiler activation threshold`,"heat_source.primary_delta_hint":`Only activate the primary source when the temperature gap exceeds this value. Below this threshold, only the fast secondary source is used.`,"heat_source.primary_delta_suffix":`°C`,"heat_source.outdoor_threshold":`Outdoor preference switchover`,"heat_source.outdoor_threshold_hint":`Above this outdoor temperature, prefer the AC/heat pump (higher efficiency). Below, prefer the gas boiler/radiator.`,"heat_source.outdoor_threshold_suffix":`°C`,"heat_source.ac_min_outdoor":`Min. outdoor temp for AC heating`,"heat_source.ac_min_outdoor_hint":`Disable AC heating entirely below this temperature to protect the heat pump hardware.`,"heat_source.ac_min_outdoor_suffix":`°C`,"heat_source.summary_disabled":`Smart source selection is off`,"devices.valve_closing_entity_hint":`Keeps the valve at the set opening whatever the thermostat's own control wants. Filled in automatically when the device has one.`,"room.section.thermostat":`Thermostat`,"thermostat.info":`Turn the dial to hold a temperature until the next schedule change. Mode and preset buttons act like on a wall thermostat.`,"thermostat.not_available":`The room thermostat entity is not available yet. It appears after the room has been saved.`,"thermostat.load_failed":`The thermostat card could not be loaded.`,"room.thermostat_toggle":`Show thermostat`,"room.thermostat_hint":`Show a thermostat dial for this room to change the temperature directly.`,"schedule_editor.title_new":`New schedule`,"schedule_editor.title_edit":`Edit schedule`,"schedule_editor.create":`Create schedule`,"schedule_editor.edit":`Edit schedule`,"schedule_editor.read_only":`This schedule is defined in YAML and cannot be edited here. Edit it in your configuration or create a new schedule.`,"schedule_editor.name":`Name`,"schedule_editor.no_blocks":`No time blocks on this day: the eco temperature applies all day.`,"schedule_editor.add_block":`Add time block`,"schedule_editor.remove_block":`Remove time block`,"schedule_editor.copy_weekdays":`Copy to Mon–Fri`,"schedule_editor.copy_all":`Copy to all days`,"schedule_editor.hint":`Inside a time block the room heats to the block's temperature, or to comfort when the field is empty. Outside the blocks eco applies. An end time of 00:00 means midnight.`,"schedule_editor.hint_auto":`Inside a time block the room keeps between the heat and cool temperatures of the block (empty = comfort). Outside the blocks eco applies. An end time of 00:00 means midnight.`,"schedule_editor.cancel":`Cancel`,"schedule_editor.save":`Save`,"schedule_editor.comfort_placeholder":`comfort`,"schedule_editor.from":`From`,"schedule_editor.to":`To`,"schedule_editor.heat":`Heat`,"schedule_editor.cool":`Cool`,"schedule_editor.temperature":`Temperature`,"schedule_editor.err_time":`Please enter a valid time.`,"schedule_editor.err_order":`A time block must end after it starts.`,"schedule_editor.err_overlap":`Time blocks on the same day must not overlap.`,"schedule_editor.err_temp":`Please enter a valid temperature.`,"schedule_editor.err_band":`The cool temperature must not be below the heat temperature.`,"schedule_editor.err_entity":`The schedule was created, but its entity could not be found. Add it from the list.`,"schedule_editor.day_short.monday":`Mon`,"schedule_editor.day_short.tuesday":`Tue`,"schedule_editor.day_short.wednesday":`Wed`,"schedule_editor.day_short.thursday":`Thu`,"schedule_editor.day_short.friday":`Fri`,"schedule_editor.day_short.saturday":`Sat`,"schedule_editor.day_short.sunday":`Sun`,"compressor.release_title":`Heat release (boiler / oil heating)`,"compressor.release_entity":`Release entity`,"compressor.release_entity_hint":`Optional. An input_boolean or switch that enables the burner. RoomMind turns it on when enough rooms of this group need heat and keeps the min run/off times above.`,"compressor.release_on":`Release on`,"compressor.release_off":`Release off`,"compressor.release_demand":`{count} rooms need heat (weighted {weighted})`,"compressor.release_min_demand":`Rooms needed for release`,"compressor.release_min_demand_hint":`How many rooms must need heat before the burner starts. Once running it stays on while any room still heats.`,"compressor.release_smart":`Smart release`,"compressor.release_smart_hint":`Weighs each room by the heat its learned model asks for (a room wanting 100 % counts fully, one wanting 10 % only a little), so the burner runs fewer, longer cycles. A room far below its target or waiting too long releases it on its own.`,"compressor.release_urgent_delta":`Urgent below target`,"compressor.release_urgent_delta_hint":`A room this far below its target releases the burner immediately.`,"compressor.release_max_wait":`Maximum wait`,"compressor.release_max_wait_hint":`A room that has needed heat this long releases the burner even if not enough other rooms do.`,"compressor.release_reason.no_demand":`no room needs heat`,"compressor.release_reason.running":`running while rooms heat`,"compressor.release_reason.demand_count":`enough rooms need heat`,"compressor.release_reason.weighted_demand":`enough weighted demand`,"compressor.release_reason.urgent":`a room is far below target`,"compressor.release_reason.max_wait":`a room waited too long`,"compressor.release_reason.collecting_demand":`collecting demand`,"compressor.release_reason.min_run":`minimum run time`,"compressor.release_reason.min_off":`minimum off time`,"thermostat.writes_schedule":`Thermostat changes the schedule`,"thermostat.writes_schedule_hint":`Turning the dial during a schedule block sets the day temperature of the active schedule for the whole week; outside the blocks it sets the night temperature. Off: the change holds only until the next schedule change.`,"schedule_editor.copy_hint":`This schedule is defined in YAML and cannot be changed here. Saving takes it over as a new, editable schedule that replaces it in this room.`,"schedule_editor.day_temp":`Day temperature`,"schedule_editor.night_temp":`Night temperature`,"schedule_editor.day_night_hint":`Day applies inside the time blocks (sets all blocks), night outside them (the room's eco temperature).`,"compressor.boiler_title":`Boiler temperature (optional)`,"compressor.boiler_temp_sensor":`Boiler / flow temperature sensor`,"compressor.boiler_temp_sensor_hint":`With the boiler temperature RoomMind learns how fast the boiler heats up and cools down. A boiler that is still warm is released for any room so its heat is used, and smart mode starts a cold boiler early by its heat-up time.`,"compressor.boiler_usable_temp":`Boiler warm from`,"compressor.boiler_usable_temp_hint":`Water temperature from which the radiators give off useful heat.`,"compressor.boiler_status":`Boiler {temp} °C · heats up {heat} K/min · cools {cool} K/min`,"compressor.boiler_learning":`learning…`,"compressor.boiler_lead":`warm in ~{min} min`,"compressor.boiler_warm":`stays warm ~{min} min`,"compressor.release_reason.residual_heat":`using heat still in the boiler`,"compressor.release_reason.preheat":`preheating a cold boiler`,"panel.tab.heating":`Heating`,"heating.no_groups":`Create a group first under Settings → Compressor protection and add the thermostats of the rooms this boiler heats. Its boiler settings, status and analysis then appear here.`,"heating.unnamed":`Unnamed group`,"heating.unknown":`unknown`,"heating.on":`On`,"heating.off":`Off`,"heating.release":`Release`,"heating.demand":`Heat demand`,"heating.demand_value":`{count} rooms · weighted {weighted}`,"heating.boiler_temp":`Boiler temperature`,"heating.burner":`Burner`,"heating.pump":`Circuit pump`,"heating.dhw":`Hot water`,"heating.learned":`Learned boiler behaviour`,"heating.heat_rate":`Heats up`,"heating.cool_rate":`Cools down`,"heating.reset_learning":`Reset learning`,"heating.reset_confirm":`Forget what RoomMind has learned about this boiler?`,"heating.learned_hint":`Learned from the boiler temperature: heat-up while the burner fires (or while released), cool-down while idle. Paused while hot water is charged. Used to start a cold boiler in time and to use heat still in a warm one.`,"heating.waiting_status":`Waiting for the first control cycle…`,"heating.status":`Status`,"heating.range.24h":`24 h`,"heating.range.7d":`7 days`,"heating.range.30d":`30 days`,"heating.kpi_starts":`{what} starts`,"heating.kpi_avg_run":`Ø {min} min per run`,"heating.kpi_runtime":`{what} runtime`,"heating.kpi_release_time":`Released`,"heating.kpi_oil":`Oil`,"heating.kpi_oil_estimated":`estimated from burner runtime`,"heating.kpi_pump":`Pump runtime`,"heating.kpi_dhw":`Hot water`,"heating.kpi_dhw_count":`{count} charges`,"heating.kpi_boiler":`Ø boiler`,"heating.kpi_boiler_max":`max {max} °C`,"heating.reasons":`Why the release was on or off`,"heating.oil_hint":`For oil consumption add an oil meter, or the burner and its nozzle flow (L/h) in the settings below.`,"heating.analysis":`Analysis`,"heating.settings":`Boiler settings`,"heating.settings_intro":`Everything RoomMind needs to know about this boiler. Only the release entity is required; every further entity improves the learning and the analysis. Domestic hot water is not controlled by RoomMind, only taken into account.`,"heating.section_release":`Release`,"heating.section_boiler":`Boiler & circuit`,"heating.section_oil":`Oil consumption`,"heating.burner_entity":`Burner running`,"heating.burner_entity_hint":`Optional. Shows when the burner really fires (binary sensor, switch, or a power sensor > 0). Improves the heat-up learning and counts burner starts.`,"heating.pump_entity":`Heating circuit pump`,"heating.pump_entity_hint":`Optional. Pump runtime in the analysis.`,"heating.dhw_entity":`Hot water charging`,"heating.dhw_entity_hint":`Optional. While hot water is charged the boiler temperature is not used for learning; charges and runtime appear in the analysis.`,"heating.oil_sensor":`Oil meter`,"heating.oil_sensor_hint":`Optional. A sensor counting litres (total). Increases are summed, a refill or reset does not count.`,"heating.oil_nozzle":`Nozzle flow`,"heating.oil_nozzle_hint":`Without an oil meter: litres per hour the burner nozzle uses (see the nozzle or burner label, e.g. 2.0 L/h). With the burner entity RoomMind estimates the consumption.`,"heating.members_hint":`Rooms and thermostats of this boiler, minimum run and off times: Settings → Compressor protection.`,"compressor.release_moved":`No boiler release set up`,"compressor.release_open_tab":`Open heating tab`,"quick.day":`Day`,"quick.day_hint":`Target without a schedule (comfort)`,"quick.day_hint_schedule":`Inside the schedule blocks, all week (also set by the thermostat)`,"quick.day_hint_yaml":`This schedule is YAML: only the comfort value changes`,"quick.take_over":`Take over schedule so day temperature and thermostat can change it`,"quick.night":`Night`,"quick.night_hint":`Outside the schedule blocks (eco)`,"quick.away":`Away`,"quick.away_hint":`While everyone is away`,"quick.away_hint_same":`While everyone is away – same as night`,"quick.away_reset":`Use night temperature`,"quick.arrival":`Expected home ~{time}`,"quick.arrival_heating":`Heating up – expected home ~{time}`,"presence.preheat_label":`Warm on arrival (learning)`,"presence.preheat_hint":`Learns per weekday when people usually come home. While everyone is away, a room heats up so it reaches its schedule temperature by the expected arrival, using its learned heat-up time.`,"presence.preheat_minutes":`Heat-up time without learned model`,"presence.preheat_minutes_hint":`Used until a room's thermal model is trained; afterwards each room uses its own learned heat-up time.`,"presence.learned_title":`Learned arrival times`,"presence.learned_count":`{count} arrivals`,"presence.learned_next":`expected today ~{time}`,"presence.learned_hint":`Typical arrival per weekday (median of the last 8 weeks). A prediction needs arrivals on at least 3 different days; absences under 20 minutes are ignored.`},de:{"panel.title":`RoomMind`,"panel.subtitle":`Klimasteuerung`,"panel.tab.rooms":`Räume`,"panel.tab.settings":`Einstellungen`,"panel.edit":`Raum bearbeiten`,"panel.loading":`Laden...`,"panel.no_areas":`Keine Bereiche in Home Assistant konfiguriert.`,"panel.no_areas_hint":`Bereiche in den HA-Einstellungen anlegen.`,"badge.beta":`Beta`,"badge.beta_hint":`Dieses Feature ist in der Beta-Phase und kann sich in zukünftigen Updates noch ändern.`,"common.learn_more":`Mehr erfahren`,"panel.stat.rooms":`Räume`,"panel.stat.heating":`Heizen`,"panel.stat.cooling":`Kühlen`,"panel.stat.vacation":`Urlaub`,"panel.stat.away":`Abwesend`,"panel.stat.mold":`Schimmel`,"panel.hide_room":`Ausblenden`,"panel.unhide":`Einblenden`,"panel.hidden_rooms":`Ausgeblendete Räume`,"panel.floor_other":`Sonstige`,"panel.reorder":`Räume sortieren`,"panel.reorder_done":`Fertig`,"room.back":`Zurück zu den Räumen`,"room.section.climate_mode":`Klimamodus`,"room.section.schedule":`Zeitplan & Temperaturen`,"room.section.control_mode":`Steuerungsmodus`,"room.section.devices":`Geräte`,"room.section.sensors":`Sensoren`,"room.section.windows":`Fenstersensoren`,"room.control_mode.full_control":`Full Control`,"room.control_mode.managed":`Managed`,"room.control_mode.external_sensor":`Externer Sensor: {sensor}`,"room.control_mode.no_sensor":`Kein externer Temperatursensor zugewiesen`,"room.control_mode.mpc_active":`MPC aktiv`,"room.control_mode.mpc_learning":`Lernphase`,"room.control_mode.device_setpoint":`Geräte-Setpoint: {temp}`,"room.control_mode.power":`Leistung: {power}%`,"room.control_mode.full_control_info":`RoomMind hat volle Kontrolle über deine Klimageräte. Ein externer Temperatursensor liefert die tatsächliche Raumtemperatur, was eine proportionale Setpoint-Berechnung ermöglicht. Der Geräte-Setpoint wird dynamisch basierend auf der MPC-Leistung angepasst. Das thermische Modell (EKF) lernt das Verhalten deines Raums für optimalen Komfort und Energieeffizienz.`,"room.control_mode.managed_info":`RoomMind setzt die Zieltemperatur auf deinem Gerät (aus Zeitplan, Override oder Urlaubsmodus), aber das Gerät regelt selbstständig mit seinem internen Sensor. Kein proportionaler Boost, kein thermisches Modell-Lernen und keine MPC-Optimierung. Für präzisere Steuerung einen externen Temperatursensor in der Geräte-Sektion zuweisen.`,"room.delete":`Raum löschen`,"room.deleting":`Wird gelöscht...`,"room.saving":`Speichern...`,"room.saved":`Gespeichert`,"room.error_saving":`Fehler beim Speichern`,"room.confirm_delete":`RoomMind-Konfiguration für "{name}" entfernen?`,"room.error_save_fallback":`Konfiguration konnte nicht gespeichert werden`,"room.error_delete_fallback":`Konfiguration konnte nicht gelöscht werden`,"room.climate_control_toggle":`Klimasteuerung`,"room.climate_control_hint":`Wenn deaktiviert, steuert RoomMind die Geräte in diesem Raum nicht mehr. Sie behalten ihre aktuellen Einstellungen und können eigenständig weiter heizen oder kühlen. RoomMind schaltet sie nicht aus.`,"room.outdoor_toggle":`Außenbereich`,"room.outdoor_hint":`Deaktiviert Klimasteuerung, Schimmelerkennung und Modell-Training. Sensorüberwachung läuft weiter.`,"room.alias.placeholder":`Eigener Anzeigename`,"room.alias.clear":`Auf Bereichsname zurücksetzen`,"override.label":`Temporärer Override`,"override.comfort":`Komfort`,"override.eco":`Eco`,"override.custom":`Individuell`,"override.target":`Ziel:`,"override.heat_to":`Heizen bis:`,"override.cool_above":`Kühlen ab:`,"override.invalid_band":`Das Kühlziel muss mindestens so hoch wie das Heizziel sein`,"override.activate_for":`Aktivieren für:`,"override.error_set":`Override konnte nicht gesetzt werden`,"override.error_clear":`Override konnte nicht aufgehoben werden`,"hero.target":`Ziel`,"hero.override":`Override`,"hero.remaining":`noch {time}`,"hero.humidity":`{value}% Luftfeuchtigkeit`,"hero.device_setpoint":`Gerät auf {value}{unit}`,"hero.heat_source_primary":`Heizung: TRV`,"hero.heat_source_secondary":`Heizung: AC`,"hero.heat_source_both":`Heizung: TRV + AC`,"hero.permanent":`Dauerhaft`,"hero.waiting":`Warte auf Sensordaten...`,"hero.not_configured":`Noch nicht konfiguriert`,"hero.mpc_learning_paused":`MPC-Lernen pausiert`,"hero.mpc_learning_paused.outdoor_unavailable":`RoomMind benötigt eine Außentemperatur, um das thermische Modell dieses Raums zu lernen. Der konfigurierte Außensensor ist nicht verfügbar und es ist keine Wetter-Entity als Fallback gesetzt. Konfiguriere eine der beiden in den Einstellungen.`,"hero.compressor_protection_min_off":`Kompressorschutz: wartet auf Mindestpause`,"hero.compressor_protection_min_off_left":`Kompressorschutz: Mindestpause, noch {minutes} Min`,"hero.compressor_protection_min_run":`Kompressorschutz: Mindestlaufzeit aktiv`,"hero.compressor_protection_min_run_left":`Kompressorschutz: Mindestlaufzeit, noch {minutes} Min`,"hero.compressor_protection_info":`Dieser Raum teilt sich eine Außeneinheit (Kompressor) mit anderen Räumen. Um Kurzzyklen zu vermeiden, erzwingt die Kompressorgruppe eine Mindestlaufzeit und eine Mindestpause, bevor dieses Gerät wieder umschalten darf.`,"hero.coil_dry":`Trocknet ({minutes} Min)`,"hero.coil_dry_drain":`Kondensat läuft ab ({minutes} Min)`,"hero.coil_dry_info":`Das Klimagerät führt seinen Verdampfer-Trocknungslauf aus und schaltet danach ab. Kühlbedarf bricht ihn sofort ab.`,"card.target":`Ziel`,"card.waiting":`Warte auf Daten...`,"card.humidity":`{value}% Luftfeuchtigkeit`,"card.thermostat":`Thermostat`,"card.thermostats":`Thermostate`,"card.ac":`Klimaanlage`,"card.acs":`Klimaanlagen`,"card.climate_device":`Klimagerät`,"card.climate_devices":`Klimageräte`,"card.temp_sensor":`Temperatursensor`,"card.temp_sensors":`Temperatursensoren`,"card.no_climate":`Keine Klimageräte`,"card.outdoor":`Außen`,"card.tap_configure":`Tippen zum Konfigurieren`,"card.mpc_active":`MPC aktiv`,"card.mpc_learning":`MPC lernt`,"card.compressor_min_run":`Mindestlauf {minutes} Min`,"card.compressor_min_off":`Mindestpause {minutes} Min`,"card.not_controlled":`Nicht von RoomMind gesteuert`,"mode.auto":`Automatisch`,"mode.auto_desc":`Heizt und kühlt automatisch basierend auf der Zieltemperatur`,"mode.heat_only":`Nur Heizen`,"mode.heat_only_desc":`Nur Heizen. Mit Thermostaten im Raum bleiben Klimaanlagen aus, außer die intelligente Quellenauswahl ist an`,"mode.cool_only":`Nur Kühlen`,"mode.cool_only_desc":`Nutzt nur Klimaanlagen, Thermostate bleiben aus`,"mode.heating":`Heizen`,"mode.cooling":`Kühlen`,"mode.idle":`Standby`,"schedule.add_schedule":`Zeitplan hinzufügen`,"schedule.select_schedule":`Zeitplan-Helfer auswählen`,"schedule.create_helper_hint":`Neuen Zeitplan-Helfer in HA erstellen`,"schedule.selector_label":`Zeitplan-Auswahl`,"schedule.selector_value_boolean":`Aktuell: {value}`,"schedule.selector_value_number":`Aktueller Wert: {value}`,"schedule.selector_warning":`Mehrere Zeitpläne, aber keine Auswahl-Entity gesetzt. Nur der erste wird verwendet.`,"schedule.off_action_label":`Aktion wenn Zeitplan aus`,"schedule.off_action_eco":`Eco-Temperatur verwenden`,"schedule.off_action_off":`Geräte ausschalten`,"schedule.state_active":`Aktiv`,"schedule.state_inactive":`Inaktiv`,"schedule.state_unreachable":`Nicht erreichbar`,"schedule.no_schedules":`Keine Zeitpläne konfiguriert`,"schedule.done":`Fertig`,"schedule.view_comfort":`Komfort: {temp}{unit}`,"schedule.view_eco":`Eco: {temp}{unit}`,"schedule.view_selector":`Aktiver Zeitplan gewählt durch: {name}`,"schedule.view_selector_prefix":`Aktiver Zeitplan gewählt durch:`,"schedule.help_header":`Wie funktionieren Zeitpläne?`,"schedule.help_temps_title":`Wie wird die Zieltemperatur bestimmt?`,"schedule.help_temps":`Die Zieltemperatur folgt dieser Prioritätskette:`,"schedule.help_temps_1":`<strong>Manueller Override</strong> – Ein temporärer Komfort-/Eco-/Individueller Override hat immer die höchste Priorität.`,"schedule.help_temps_2":`<strong>Block-Temperatur</strong> – Wenn der aktive Zeitblock einen <code>temperature</code>-Wert in seinen Daten hat, wird dieser verwendet.`,"schedule.help_temps_3":`<strong>Komforttemperatur</strong> – Wenn der Zeitplan "an" ist, aber der Block keine Temperatur hat, wird die Komfort-Fallback-Temperatur verwendet.`,"schedule.help_temps_4":`<strong>Eco-Temperatur</strong> – Wenn der Zeitplan "aus" ist (außerhalb aller Zeitblöcke), wird die Eco-Temperatur verwendet.`,"schedule.help_block_title":`Temperatur pro Zeitblock setzen`,"schedule.help_block":`Du kannst für jeden Zeitblock eine eigene Temperatur setzen, indem du einen <code>temperature</code>-Wert in der YAML-Konfiguration des Zeitplans angibst:`,"schedule.help_block_note":`Wenn ein Block keinen <code>temperature</code>-Wert hat, wird stattdessen die Komfort-Fallback-Temperatur verwendet.`,"schedule.help_split_title":`Getrennte Heiz-/Kühlziele pro Block`,"schedule.help_split":`Für Räume im Auto-Modus kannst du pro Zeitblock separate Heiz- und Kühlziele mit <code>heat_temperature</code> und <code>cool_temperature</code> setzen:`,"schedule.help_split_note":`Wenn nur eines gesetzt ist, wird das andere auf die Komforttemperatur des Raumes zurückgesetzt. Diese Schlüssel haben Vorrang vor <code>temperature</code>.`,"schedule.help_multi_title":`Mehrere Zeitpläne`,"schedule.help_multi":`Du kannst mehrere Zeitpläne hinzufügen und mit einer <strong>Auswahl-Entity</strong> zwischen ihnen wechseln. Das kann ein <code>input_boolean</code> (wechselt zwischen Zeitplan 1 und 2) oder ein <code>input_number</code> (wählt nach Nummer) sein. Ohne Auswahl-Entity wird nur der erste Zeitplan verwendet.`,"schedule.column_comfort":`Komfort`,"schedule.column_eco":`Eco`,"schedule.row_heat":`Heizen`,"schedule.row_cool":`Kühlen`,"schedule.view_heat":`Heizen: {comfort} / {eco}{unit}`,"schedule.view_cool":`Kühlen: {comfort} / {eco}{unit}`,"schedule.comfort_hint_auto":`Komfort: Ziel wenn Zeitplan an. Eco: Ziel wenn Zeitplan aus. Zeilen: Ziel für Heizen bzw. Kühlen.`,"schedule.comfort_label":`Komfort-Fallback-Temperatur`,"schedule.eco_label":`Eco-Temperatur`,"schedule.comfort_hint":`Wird verwendet wenn der Zeitplan "an" ist, aber keine Temperatur im Block gesetzt ist`,"schedule.from_schedule":`{temp}{unit} vom Zeitplan`,"schedule.from_schedule_split":`{heat}{unit} / {cool}{unit} vom Zeitplan`,"schedule.fallback":`{temp}{unit} (Fallback)`,"schedule.block_temp_rejected":`Werte außerhalb des gültigen Bereichs {min}–{max}{unit}: {values}. Stattdessen gilt die Komforttemperatur — bitte den Zeitplan-Helfer auf einen Tippfehler prüfen.`,"schedule.eco_detail":`{temp}{unit} (Eco)`,"devices.climate_entities":`Klimageräte`,"devices.temp_sensors":`Temperatursensoren`,"devices.humidity_sensors":`Feuchtigkeitssensoren`,"devices.no_climate":`Keine Klimageräte in diesem Bereich gefunden.`,"devices.no_temp_sensors":`Keine Temperatursensoren in diesem Bereich gefunden.`,"devices.no_humidity_sensors":`Keine Feuchtigkeitssensoren in diesem Bereich gefunden.`,"devices.occupancy_sensors":`Anwesenheitssensoren`,"devices.no_occupancy_sensors":`Keine Anwesenheitssensoren in diesem Bereich gefunden`,"devices.occupancy_sensor_hint":`Verbessert die Genauigkeit des Wärmemodells durch Erkennung der Raumbelegung`,"devices.occupancy_eco":`Eco, wenn der Raum leer ist`,"devices.occupancy_eco_hint":`Melden alle Anwesenheitssensoren den Raum länger als die Verzögerung leer, wechselt er auf seine Eco-Temperatur. Sobald wieder jemand erkannt wird, folgt er seinem Zeitplan. Ein leerer Raum wird auf Eco gehalten und heizt erst auf Komfort, wenn jemand drin ist. Bis er warm ist, dauert es dann eine Weile. Temporärer Override, Urlaubsmodus und Anwesenheitserkennung haben Vorrang.`,"devices.occupancy_eco_delay":`Verzögerung bis Eco`,"devices.occupancy_eco_view":`Eco nach {minutes} min ohne Anwesenheit`,"devices.window_sensors":`Fenster- / Türsensoren`,"devices.no_window_sensors":`Keine Fenster-/Türsensoren in diesem Bereich gefunden.`,"devices.window_open_delay":`Verzögerung vor Pause`,"devices.window_close_delay":`Verzögerung vor Wiederaufnahme`,"devices.add_entity":`Entität hinzufügen`,"devices.done":`Fertig`,"devices.other_area":`Anderer Bereich`,"devices.type_thermostat":`Thermostat`,"devices.type_ac":`Klimagerät`,"devices.type_label":`Typ`,"devices.select_to_configure":`Gerät zum Konfigurieren auswählen`,"devices.heating_system_type":`Heizungstyp`,"devices.heating_system_type_info":`Nach dem Abschalten geben Heizkörper und besonders Fußbodenheizungen gespeicherte Wärme weiter ab. RoomMind berücksichtigt diese Nachlaufwärme, um Überschwingen zu vermeiden und die Modellgenauigkeit zu verbessern. Fußbodenheizungen erhalten außerdem längere Mindestlaufzeiten.`,"devices.system_type_none":`Standard (kein Nachlauf)`,"devices.system_type_radiator":`Heizkörper`,"devices.system_type_underfloor":`Fußbodenheizung`,"devices.underfloor_delay_hint":`Fußbodenheizung hat lange Anlaufzeiten. Eine Fenster-Verzögerung von mindestens 5 Minuten wird empfohlen, um unnötige Abschaltungen zu vermeiden.`,"devices.heating_system_type_boost_hint":`Tipp: Wenn sich die Heizungsart geändert hat, kannst du unter Einstellungen das Lernen beschleunigen.`,"devices.idle_action":`Im Leerlauf`,"devices.idle_action_off":`Ausschalten`,"devices.idle_action_fan_only":`Nur Ventilator`,"devices.idle_action_setback":`Absenkung`,"devices.idle_action_low":`Niedriger Sollwert (wach halten)`,"devices.idle_action_low_hint":`Senkt den Sollwert auf das Geräteminimum ab, statt auszuschalten. Verhindert, dass TRVs, die im Aus-Modus in Tiefschlaf gehen, spätere Befehle verlieren.`,"devices.idle_fan_mode":`Lüftergeschwindigkeit`,"devices.idle_fan_mode_keep":`Nicht ändern`,"devices.setpoint_mode":`Sollwert-Modus`,"devices.setpoint_mode_proportional":`Proportional (erhöhter Sollwert)`,"devices.setpoint_mode_direct":`Direkt (Gerät regelt selbst)`,"devices.setpoint_offset":`Sollwert-Versatz`,"devices.setpoint_offset_hint":`Nutze das, wenn das Gerät die Temperatur anders misst als dein Raumsensor. Der Versatz wird zum Raumziel addiert, bevor es ans Gerät geht (Heizen und Kühlen). Misst das Gerät kälter als der Raum: negativer Wert. Misst es wärmer: positiver Wert. Beispiel: Du willst 24°, das Gerät hält den Raum beim Kühlen aber für 2° kälter als er ist und schaltet zu früh ab. Trag -2 ein: Das Gerät bekommt dann 22° und läuft weiter, bis der Raum wirklich 24° hat. 0 = kein Versatz.`,"devices.setpoint_mode_hint":`Direkt sendet die tatsächliche Raum-Zieltemperatur ans Gerät — geeignet für Thermostate und Heizlüfter mit eigener Regelung. Proportional sendet einen erhöhten Sollwert Richtung Geräte-max_temp — geeignet für Heizkörperventile (TRVs).`,"devices.coil_dry":`Verdampfer-Trocknung`,"devices.coil_dry_inherit":`Globale Einstellung nutzen`,"devices.coil_dry_on":`Immer an`,"devices.coil_dry_off":`Immer aus`,"devices.coil_dry_minutes":`Trocknungsdauer (0 = global: {minutes} Min)`,"devices.coil_dry_mode":`Trocknungsmodus`,"devices.coil_dry_mode_inherit":`Global ({value})`,"devices.coil_dry_fan_mode":`Lüfterstufe beim Trocknen`,"devices.coil_dry_fan_mode_inherit":`Global ({value})`,"devices.coil_dry_fan_mode_keep":`Aktuelle Stufe beibehalten`,"devices.coil_dry_summary":`Trocknung`,"devices.coil_dry_global_off_hint":`Die Verdampfer-Trocknung ist global ausgeschaltet, für dieses Gerät läuft also keine. In den Einstellungen einschalten oder dieses Gerät auf „Immer an“ stellen.`,"devices.valve_protection_excluded":`Vom Ventilschutz ausgenommen`,"devices.valve_protection_exclude_hint":`Dieses Gerät wird nicht vom Ventilschutz bewegt (z.B. virtuelle Kessel-Entitäten)`,"devices.valve_direct_control":`Direkte Ventilsteuerung`,"devices.valve_opening_entity":`Ventil-Öffnungsgrad`,"devices.valve_closing_entity":`Ventil-Schließgrad`,"devices.valve_direct_control_hint":`Für Thermostate, bei denen Home Assistant die Ventilöffnung setzen kann (z. B. SONOFF TRVZB: valve_opening_degree und valve_closing_degree, beide nötig). RoomMind hält das Ventil dann auf der Öffnung, die der Raum braucht, z. B. 30 %, statt es ganz aufzumachen: weniger Ventilbewegungen, leiser und gleichmäßiger. Felder leeren oder Klimasteuerung ausschalten setzt beide wieder auf 100 %.`,"devices.valve_direct_control_toggle_hint":`Für Thermostate, bei denen Home Assistant die Ventilöffnung setzen kann (z. B. SONOFF TRVZB). RoomMind hält das Ventil dann auf der Öffnung, die der Raum braucht, z. B. 30 %, statt es ganz aufzumachen: weniger Ventilbewegungen, leiser und gleichmäßiger. Ausgeschaltet oder bei abgeschalteter Klimasteuerung regelt das Thermostat das Ventil wieder selbst.`,"devices.valve_direct_badge":`Direktes Ventil`,"devices.info.types_title":`Gerätetypen`,"devices.info.types_body":`Thermostat bedeutet Heizkörperthermostat / TRV. Klimagerät bedeutet AC, Wärmepumpe oder eine andere Klima-Entität für Kühlung oder Warmluftheizung. Beides sind Home-Assistant-Klima-Entitäten; der Unterschied liegt darin, wie RoomMind sie ansteuert.`,"devices.info.control_title":`Wie RoomMind sie steuert`,"devices.info.control_body":`Der Sollwert-Modus gilt nur für Thermostate in Räumen mit Full Control und externem Temperatursensor. Verwende Proportional, wenn RoomMind die Heizleistung über angehobene Sollwerte steuern soll. Verwende Direkt, wenn das Gerät selbst um den echten Zielwert regeln soll.`,"devices.info.modes_title":`Verhalten im Leerlauf`,"devices.info.modes_body":`Im Leerlauf gilt nur für Klimageräte. Ausschalten schaltet das Gerät aus. Nur Ventilator hält die Luftzirkulation ohne Heizen oder Kühlen aufrecht. Absenkung lässt den aktuellen Modus aktiv, verschiebt den Sollwert aber um 2°C vom Raumziel weg. Dieser Offset ist derzeit fest. Mit externem Temperatursensor und gelerntem Modell wird das Gerät nach einer Stunde ohne Heizen oder Kühlen ausgeschaltet, wenn RoomMind es in der nächsten Stunde nicht braucht. Für Thermostate hält Niedrig den TRV aktiv auf minimalem Sollwert statt ihn auszuschalten, nützlich für batteriebetriebene Zigbee-TRVs, die beim Ausschalten in den Tiefschlaf gehen.`,"devices.info.heat_source_title":`Intelligente Quellenwahl`,"devices.info.heat_source_body":`Diese Funktion erscheint nur, wenn ein Raum sowohl ein Thermostat/TRV als auch ein Klimagerät und zusätzlich einen externen Temperatursensor hat. RoomMind kann dann je nach Temperaturdifferenz und Außenbedingungen auswählen, welche Quelle das Heizen übernimmt.`,"hero.window_open":`Fenster offen – pausiert`,"card.window_open":`Fenster offen`,"room.section.covers":`Rollos & Jalousien`,"covers.section_title":`Rollos & Jalousien`,"covers.auto_control":`Automatische Rollosteuerung`,"covers.auto_control_hint":`RoomMind schließt Rollos, wenn Solarwärme den Raum voraussichtlich überhitzen würde.`,"covers.deploy_threshold":`Auslöseschwelle`,"covers.deploy_threshold_hint":`Rollos schließen, wenn die vorhergesagte Temperatur den Zielwert um diesen Betrag übersteigt.`,"covers.min_position":`Minimale Öffnungsposition`,"covers.min_position_hint":`Rollos werden nie weiter als diese Position geschlossen (0 = vollständig schließen erlaubt).`,"covers.override_minutes":`Override-Pausendauer`,"covers.override_minutes_hint":`Wie lange die automatische Steuerung nach manueller Rolloverstellung pausiert. 0 = keine Pause.`,"covers.no_covers":`Keine Rollo-Entitäten konfiguriert.`,"covers.no_covers_in_area":`Keine Rollo-Entitäten in diesem Bereich gefunden.`,"covers.add_cover":`Rollo-Entität hinzufügen...`,"covers.shading_active":`Beschattung aktiv`,"covers.auto_paused":`Automatik pausiert (manuell übersteuert)`,"covers.auto_paused_until":`Automatik pausiert bis`,"covers.resume_auto":`Automatik jetzt fortsetzen`,"covers.done":`Fertig`,"covers.night_close":`Nachts automatisch schließen`,"covers.night_close_hint":`Rolläden bei Sonnenuntergang schließen und bei Sonnenaufgang öffnen.`,"covers.night_close_active":`Nachtschließung aktiv`,"covers.schedule_group_title":`Zeitplan`,"covers.solar_group_title":`Solar-Steuerung`,"covers.schedule_section":`Rolläden-Zeitpläne`,"covers.schedule_section_hint":`Definiere Zeitfenster für die Rolladensteuerung. Im Modus 'Position erzwingen' überschreibt der Zeitplan die Solar-/Thermik-Logik. Im Modus 'Sonnenschutz erlauben' entscheidet RoomMind innerhalb des aktiven Zeitfensters selbst über die Position.`,"covers.add_schedule":`Zeitplan hinzufügen...`,"covers.schedule_mode_force":`Position erzwingen`,"covers.schedule_mode_gate":`Sonnenschutz erlauben`,"covers.schedule_mode_gate_short":`Solarschutz-Gate`,"covers.schedule_position":`Position`,"covers.schedule_position_hint":`Rolloposition wenn dieser Zeitplan aktiv ist (0% = vollständig geschlossen, 100% = vollständig offen).`,"covers.schedule_selector":`Zeitplan-Selektor`,"covers.schedule_selector_hint":`Bestimmt welcher Zeitplan aktiv ist. input_boolean: aus=#1, an=#2. input_number: Wert wählt Zeitplan-Nummer.`,"covers.schedule_selector_warning":`Mehrere Zeitpläne konfiguriert aber kein Selektor gesetzt. Nur der erste Zeitplan wird verwendet.`,"covers.schedule_state_active":`Aktiv`,"covers.schedule_state_inactive":`Inaktiv`,"covers.schedule_state_unreachable":`Nicht erreichbar`,"covers.schedule_active":`Zeitplan aktiv`,"covers.schedule_create_link":`Zeitplan-Helfer erstellen`,"covers.night_position":`Nachtposition`,"covers.night_position_hint":`Rolloposition wenn Nachtschließung aktiv ist (0% = vollständig geschlossen). Bei Rollos mit individueller Min. Position wird diese nie unterschritten.`,"covers.night_close_advanced":`Erweitert`,"covers.night_close_elevation":`Sonnenstand-Schwellwert`,"covers.night_close_elevation_hint":`Wie weit die Sonne unter oder über dem Horizont stehen muss. 0° = genau bei Sonnenuntergang/-aufgang. Negativ = dunkler (z.B. -6° = Dämmerung, wenn es merklich dunkel wird). Positiv = noch hell (z.B. 5° = Sonne noch sichtbar).`,"covers.night_close_offset":`Zeitversatz`,"covers.night_close_offset_hint":`Zusätzliche Verschiebung relativ zum Sonnenstand-Schwellwert. Positiv = später schließen (z.B. +20 = 20 Min. nach Erreichen des Schwellwerts), negativ = früher.`,"covers.outdoor_min_temp":`Min. Außentemperatur`,"covers.outdoor_min_temp_hint":`Rollos bei dieser Außentemperatur nicht für Sonnenschutz schließen. Bei Kälte ist der Solareintrag erwünscht.`,"covers.per_cover_title":`Pro-Rollo Einstellungen`,"covers.per_cover_hint":`Himmelsrichtung pro Rollo und optionale individuelle Mindestposition.`,"covers.per_cover_min_short":`Min`,"covers.per_cover_min_position":`Min. Position`,"covers.per_cover_min_position_hint":`Individuelle Mindestposition pro Rollo. Rollos werden nicht weiter geschlossen. Nützlich wenn Rollos physisch schon bei > 0% ganz zu sind.`,"covers.snap_deploy":`Direkt auf Minimalposition`,"covers.snap_deploy_hint":`Rolläden direkt auf die Minimalposition schließen statt schrittweise. Empfohlen für Dreifachverglasung, bei der Zwischenpositionen thermische Spannungen verursachen können.`,"covers.info.selection_title":`Rollo-Auswahl`,"covers.info.selection_body":`Wähle Rollos/Jalousien aus diesem Bereich oder füge Entitäten aus anderen Bereichen hinzu. RoomMind verfolgt deren Position und kann sie automatisch steuern.`,"covers.info.schedule_title":`Zeitplan-Steuerung`,"covers.info.schedule_body":`Verwende HA-Zeitplan-Helfer um festzulegen, wann Rollos schließen sollen (z.B. Sichtschutz am Abend). Das Positions-Attribut des Zeitplans bestimmt, wie weit sie schließen. Zeitpläne überschreiben alle andere Automatik-Logik.`,"covers.info.solar_title":`Solar-/Thermik-Steuerung`,"covers.info.solar_body":`Bei aktivierter Automatik sagt RoomMind vorher, ob Sonneneinstrahlung den Raum überhitzen wird und schließt Rollos präventiv. Es nutzt gelernte Thermodaten wenn verfügbar, sonst einen konservativen Standardwert. Die Auslöseschwelle bestimmt, wie viel vorhergesagte Überschreitung nötig ist.`,"covers.info.night_title":`Nachtschließung`,"covers.info.night_body":`Schließt Rollos bei Sonnenuntergang und öffnet sie bei Sonnenaufgang. Du kannst eine eigene Nachtposition setzen (z.B. 10% = fast geschlossen aber nicht komplett).`,"covers.info.override_title":`Manuelles Übersteuern`,"covers.info.override_body":`Wenn du ein Rollo manuell bewegst, erkennt RoomMind dies und pausiert die Automatik für die konfigurierte Dauer. So wird nicht gegen den Nutzer gearbeitet.`,"covers.info.priority_title":`Prioritätsreihenfolge`,"covers.info.priority_body":`Manuelles Override > Zeitplan > Nachtschließung > Solar-/Thermik-Steuerung. Höhere Priorität gewinnt immer. Wenn keine Regel greift, bleiben Rollos offen.`,"covers.info.entities_title":`HA-Entitäten`,"covers.info.entities_body":`RoomMind erstellt zwei Entitäten pro Raum zur externen Nutzung: switch.roommind_{area}_cover_auto (automatische Rollosteuerung ein-/ausschalten — nutzbar in Automatisierungen oder Dashboards) und binary_sensor.roommind_{area}_cover_paused (an wenn manuelles Override aktiv ist, z.B. nach manuellem Bewegen eines Rollos).`,"covers.orientation_group_title":`Rolloausrichtung`,"covers.orientation_hint":`Himmelsrichtung, in die das Rollo zeigt. RoomMind beschattet dann nur, solange die Sonne wirklich auf diese Gebäudeseite scheint. Ohne Richtung reagieren die Rollos auf Sonnenschein allgemein und können schon ab Sonnenaufgang schließen, auch an einem Nordfenster.`,"covers.orientation_none":`Beliebige Richtung`,"covers.orientation_N":`N`,"covers.orientation_NE":`NO`,"covers.orientation_E":`O`,"covers.orientation_SE":`SO`,"covers.orientation_S":`S`,"covers.orientation_SW":`SW`,"covers.orientation_W":`W`,"covers.orientation_NW":`NW`,"covers.orientation_N_full":`Nord`,"covers.orientation_NE_full":`Nordost`,"covers.orientation_E_full":`Ost`,"covers.orientation_SE_full":`Südost`,"covers.orientation_S_full":`Süd`,"covers.orientation_SW_full":`Südwest`,"covers.orientation_W_full":`West`,"covers.orientation_NW_full":`Nordwest`,"settings.general_title":`Allgemein`,"settings.group_by_floor":`Räume nach Etagen gruppieren`,"settings.climate_control_active":`Klimasteuerung aktiv`,"settings.climate_control_hint":`Wenn deaktiviert, überwacht RoomMind weiterhin alle Sensoren und trainiert das Modell, sendet aber keine Befehle an deine Heizungen oder Klimaanlagen. Die Geräte behalten ihren aktuellen Modus und Sollwert und können eigenständig weiter heizen oder kühlen. RoomMind schaltet sie nicht aus.`,"settings.learning_title":`Modell-Training`,"settings.learning_hint":`Wenn pausiert, sammelt RoomMind keine neuen Messdaten und trainiert das thermische Modell nicht weiter. Bestehende Modelldaten bleiben erhalten.`,"settings.learning_exceptions":`Ausnahmen`,"settings.learning_room_paused":`Raum pausiert`,"settings.learning_rooms_paused":`Räume pausiert`,"settings.sensors_title":`Sensoren & Datenquellen`,"settings.control_title":`Steuerung`,"settings.outdoor_sensor":`Außentemperatur`,"settings.outdoor_sensor_label":`Außentemperatursensor`,"settings.outdoor_current":`Aktuell {temp}{unit} draußen`,"settings.outdoor_waiting":`Warte auf Sensordaten...`,"settings.outdoor_humidity_sensor":`Außenluftfeuchtigkeit`,"settings.outdoor_humidity_label":`Außenluftfeuchtigkeitssensor`,"settings.outdoor_humidity_current":`Aktuell {value}% draußen`,"settings.smart_control":`Intelligente Klimasteuerung`,"settings.smart_control_hint":`Außentemperaturgrenzen für Heiz- und Kühlentscheidungen konfigurieren.`,"settings.outdoor_cooling_min":`Mindest-Außentemperatur für Kühlung`,"settings.outdoor_cooling_min_hint":`Klimaanlage bleibt aus wenn Außentemperatur unter diesem Wert. Ein manueller Override ignoriert diese Grenze`,"settings.outdoor_heating_max":`Maximal-Außentemperatur für Heizung`,"settings.outdoor_heating_max_hint":`Heizung bleibt aus wenn Außentemperatur über diesem Wert. Ein manueller Override ignoriert diese Grenze`,"settings.saving":`Speichern...`,"settings.saved":`Gespeichert`,"settings.error":`Fehler beim Speichern`,"devices.using_builtin_sensor":`Nutzt den eingebauten Thermostat-Sensor`,"settings.climate_intelligence":`Klimaintelligenz`,"settings.control_mode":`Steuerungsmodus`,"settings.control_mode_simple":`Einfach (Ein/Aus)`,"settings.control_mode_mpc":`Intelligent (MPC)`,"settings.control_mode_hint":`Intelligent: MPC lernt das thermische Verhalten jedes Raums und plant voraus (Ein/Aus-Regelung, solange es noch lernt). Einfach: nur Ein/Aus-Regelung mit Hysterese; das Modell lernt im Hintergrund weiter, entscheidet aber nicht, und automatische Rollläden nutzen eine einfachere Sonnenschätzung statt der MPC-Vorhersage.`,"settings.comfort_weight":`Priorität`,"settings.comfort_weight_comfort":`Komfort`,"settings.comfort_weight_efficiency":`Effizienz`,"settings.comfort_weight_hint":`Gewichtet Temperaturgenauigkeit gegen Energieverbrauch. Komfort reagiert früher und bleibt näher am Zielwert. Effizienz erlaubt mehr Abweichung, um Heiz- und Kühllaufzeiten zu reduzieren. Ab der Standardeinstellung heizt RoomMind vor einem Zeitplanblock vor, damit der Raum zum Beginn warm ist; darunter beginnt es später, ganz auf Effizienz erst kurz vor dem Block.`,"settings.weather_entity":`Wettervorhersage`,"settings.weather_entity_hint":`Optional: ermöglicht vorausschauende Außentemperaturplanung und dient als Fallback wenn der Außensensor nicht verfügbar ist`,"settings.outdoor_unavailable_notify":`Hinweis bei fehlender Außentemperatur`,"settings.outdoor_unavailable_notify_hint":`Zeigt eine Home-Assistant-Benachrichtigung, wenn weder Außensensor noch Wetter-Entity 30 Minuten lang eine Temperatur geliefert haben. In dieser Zeit pausiert RoomMind das Lernen des thermischen Modells, um Korruption zu vermeiden.`,"settings.prediction_enabled":`Temperaturvorhersage`,"settings.prediction_enabled_hint":`Zeigt den vorhergesagten Temperaturverlauf im Analyse-Diagramm. Bei langsamer Performance deaktivieren.`,"vacation.title":`Urlaubsmodus`,"vacation.hint":`Setzt alle Räume auf eine Absenktemperatur bis zum Enddatum.`,"vacation.active_label":`Urlaubsmodus aktiv`,"vacation.end_date":`Enddatum & Uhrzeit`,"vacation.setback_temp":`Absenktemperatur`,"vacation.no_end_date":`Kein Enddatum`,"vacation.deactivate":`Deaktivieren`,"tabs.analytics":`Analyse`,"analytics.select_room":`Raum auswählen`,"analytics.temperature":`Temperatur`,"analytics.target":`Ziel`,"analytics.prediction":`Vorhersage`,"analytics.outdoor":`Außen`,"analytics.model_status":`Modellstatus`,"analytics.confidence":`Konfidenz`,"analytics.heating_rate":`Heizstärke`,"analytics.cooling_rate":`Kühlstärke`,"analytics.solar_gain":`Solargewinn (volle Sonne)`,"analytics.solar_gain_sub":`jetzt {now} · heute bis {today}`,"analytics.occupancy_gain":`Anwesenheitsgewinn`,"analytics.time_constant":`Zeitkonstante`,"analytics.samples":`Datenpunkte`,"analytics.prediction_accuracy":`Vorhersagegenauigkeit`,"analytics.avg_deviation":`Durchschn. Abweichung`,"analytics.data_sources":`Datenquellen`,"analytics.data_points":`Datenpunkte`,"analytics.control_mode":`Steuerungsmodus`,"analytics.control_mode_mpc":`MPC aktiv`,"analytics.control_mode_bangbang":`MPC wird trainiert`,"analytics.last_model_update":`Letztes Modell-Update`,"analytics.accuracy_idle":`Genauigkeit (Leerlauf)`,"analytics.accuracy_heating":`Genauigkeit (Heizen)`,"analytics.info.accuracy_idle":`Wie genau das Modell die Temperatur vorhersagt, wenn weder geheizt noch gekühlt wird. Ein niedrigerer Wert bedeutet, dass das Modell den natürlichen Wärmeverlust deines Raums gut versteht. Dieser Wert verbessert sich als erstes, da Leerlauf-Daten kontinuierlich gesammelt werden.`,"analytics.info.accuracy_heating":`Wie genau das Modell die Temperatur während des aktiven Heizens vorhersagt. Dieser Wert bleibt anfangs hoch, da das Modell echte Heizzyklen zum Lernen braucht. Sobald deine Heizung ein paar Mal gelaufen ist, sinkt dieser Wert und die intelligente MPC-Steuerung wird verfügbar.`,"analytics.info.confidence":`Gesamte Modellreife für die intelligente MPC-Steuerung, basierend auf zwei Faktoren: Datenmenge (wie viele Leerlauf- und Aktiv-Messwerte gesammelt wurden) und Vorhersagegenauigkeit (wie präzise die Temperaturprognosen sind). Die Konfidenz startet bei 0% und steigt mit zunehmenden Daten. Etwa 50% bedeutet: genug Leerlaufdaten, aber noch zu wenig Heiz-/Kühlzyklen. Über 80% bedeutet: genug Daten und genaue Vorhersagen — MPC-Steuerung wird verfügbar. 100% ist das theoretische Maximum, wenn die Vorhersagen so genau wie physikalisch möglich sind.`,"analytics.info.time_constant":`Wie lange es dauert, bis sich die Raumtemperatur bei ausgeschalteter Heizung halbwegs der Außentemperatur annähert. Eine längere Zeitkonstante bedeutet bessere Dämmung — der Raum hält die Wärme länger. Eine kurze Zeitkonstante bedeutet schnelles Auskühlen. Das Modell lernt diesen Wert, indem es Temperaturabfälle im Leerlauf beobachtet.`,"analytics.info.heating_rate":`Wie stark deine Heizung die Raumtemperatur beeinflusst. Ein höherer Wert bedeutet, dass dein Heizsystem den Raum schneller erwärmt relativ zur thermischen Masse. Das Modell lernt dies durch Beobachtung der Temperaturanstiege beim Heizen und nutzt es um vorherzusagen, wie lange geheizt werden muss.`,"analytics.info.cooling_rate":`Wie stark deine Klimaanlage die Raumtemperatur beeinflusst. Ein höherer Wert bedeutet schnellere Kühlung relativ zur thermischen Masse. Das Modell lernt dies durch Beobachtung der Temperaturabfälle bei aktiver Kühlung und nutzt es um vorherzusagen, wie lange gekühlt werden muss. In den ersten Minuten eines Laufs fällt die Luft am Sensor schneller und steigt nach dem Abschalten wieder an. Diesen Anteil rechnet das Modell getrennt, der Wert hier beschreibt, wie schnell die Anlage den ganzen Raum samt Wänden und Möbeln kühlt.`,"analytics.info.solar_gain":`Wie schnell die Sonne den Raum bei voller Einstrahlung erwärmt (1000 W/m², klarer Sommermittag). Meist kommt deutlich weniger an: Die Zeile darunter zeigt, was die Sonne gerade beiträgt (mit Wolken und Beschattung) und heute bei klarem Himmel höchstens. Im Winter ist das oft nur ein Viertel des Werts bei voller Sonne. Für den Vergleich mit der Heizstärke zählen diese beiden Werte. Das Modell lernt den Wert, indem es beobachtet, wie sich der Raum bei Sonnenschein ohne Heizung erwärmt, und heizt weniger, wenn Sonne erwartet wird.`,"analytics.info.occupancy_gain":`Der geschätzte Wärmebeitrag durch Anwesenheit (Personen, Haustiere, Computer), solange der Raum belegt ist. Wird gelernt, indem Temperaturänderungen beobachtet werden, während die konfigurierten Anwesenheitssensoren aktiv sind. Durch die Trennung vom Solargewinn wird Körperwärme nicht mehr fälschlich der Sonneneinstrahlung zugeschrieben. Wird nur angezeigt, wenn für diesen Raum mindestens ein Anwesenheitssensor konfiguriert ist.`,"analytics.info.data_sources":`Anzahl der Messwerte, die für das Modelltraining verwendet werden.`,"analytics.info.data_points":`Gesamtzahl der Beobachtungen, mit denen das Modell trainiert wurde. Mehr Datenpunkte führen in der Regel zu besseren Vorhersagen. Das Modell sammelt etwa alle 3 Minuten einen neuen Datenpunkt während RoomMind läuft.`,"analytics.no_data":`Noch keine Daten — Modell lernt`,"analytics.loading":`Analyse wird geladen...`,"settings.reset_title":`Thermische Daten zurücksetzen`,"settings.reset_hint":`Gelernte thermische Modelldaten und Verlauf löschen. Das Modell beginnt von vorne zu lernen.`,"settings.reset_all_label":`Alle Räume`,"settings.reset_all_hint":`Thermische Daten und Verlauf für alle Räume auf einmal löschen.`,"settings.reset_all_btn":`Alle zurücksetzen`,"settings.reset_all_confirm":`Alle gelernten thermischen Daten und Verlauf für ALLE Räume löschen? Alle Modelle beginnen von vorne zu lernen.`,"settings.reset_room_label":`Einzelner Raum`,"settings.reset_room_hint":`Wähle einen Raum, um dessen thermische Daten und Verlauf zu löschen.`,"settings.reset_room_confirm":`Alle gelernten thermischen Daten und Verlauf für diesen Raum löschen? Das Modell beginnt von vorne zu lernen.`,"settings.reset_room_select":`Raum auswählen`,"settings.reset_btn":`Zurücksetzen`,"settings.reset_no_rooms":`Keine konfigurierten Räume.`,"settings.boost_title":`Lernen beschleunigen`,"settings.boost_hint":`Das thermische Modell lernt das Heiz- und Kühlverhalten deines Raumes über die Zeit. Nach grösseren Änderungen (neuer Heizkörper, Klimaanlage, Dämmung, Möbel) kann das Modell ungenau sein. Dies erhöht die Unsicherheit des Modells, damit es sich schneller an die neuen Bedingungen anpasst.`,"settings.boost_label":`Lernen beschleunigen`,"settings.boost_room_select":`Raum auswählen`,"settings.boost_btn":`Beschleunigen`,"settings.boost_cooldown":`Aktiv – Neues Lernen läuft`,"settings.boost_no_rooms":`Keine konfigurierten Räume.`,"analytics.range_1d":`Heute`,"analytics.range_2d":`2 Tage`,"analytics.range_7d":`Woche`,"analytics.range_30d":`Monat`,"analytics.export":`Messdaten`,"analytics.heating_period":`Heizen`,"analytics.cooling_period":`Kühlung`,"analytics.window_open_period":`Fenster offen`,"analytics.blind_position":`Rolloposition`,"analytics.chart_info_title":`So liest du dieses Diagramm`,"analytics.exported":`Exportiert!`,"analytics.copy_diagnostics":`Diagnose`,"analytics.export_download":`Datei herunterladen`,"analytics.export_clipboard":`In Zwischenablage kopieren`,"analytics.copied_to_clipboard":`Kopiert!`,"analytics.range_from":`Von`,"analytics.range_to":`Bis`,"analytics.chart_info_body":`**Linien:** Die durchgezogene orangene Linie zeigt die gemessene Raumtemperatur. Die grüne gestrichelte Linie ist die Zieltemperatur aus deinem Zeitplan. Die blaue gepunktete Linie ist die Temperaturvorhersage des Modells.

**Schattierte Bereiche:** Rote Schattierung markiert Heizperioden, blaue Kühlung und türkise Bereiche zeigen an, wenn ein Fenster offen war.

**Zukunftsprognose (rechts der 'Jetzt'-Linie):** Die grüne gestrichelte Linie zeigt die kommenden Zieltemperaturen für die nächsten 3 Stunden. Die blaue gepunktete Linie zeigt den vorhergesagten Temperaturverlauf.

**Vorhersage-Modus:** Wenn 'MPC aktiv' angezeigt wird, nutzt die Vorhersage den vollständigen MPC-Optimizer mit intelligentem Vorheizen/-kühlen. Solange das Modell noch lernt, wird eine einfachere Simulation verwendet.

**Einschränkungen:** Die Vorhersage nimmt an, dass aktuelle Bedingungen konstant bleiben (Außentemperatur, Fensterstatus). Die Genauigkeit hängt davon ab, wie gut das Modell deinen Raum bereits gelernt hat — anfangs können die Vorhersagen ungenau sein. Sobald MPC aktiviert wird, werden die Vorhersagen deutlich zuverlässiger.`,"presence.title":`Anwesenheitserkennung`,"presence.hint":`Eco-Temperatur wenn niemand zu Hause ist.`,"presence.hint_detail":`Wenn aktiviert, werden alle Räume auf Eco-Temperatur gesetzt, sobald keine der konfigurierten Personen zu Hause ist. Pro Raum kann optional eingeschränkt werden, welche Personen relevant sind.`,"presence.add_person":`Person hinzufügen`,"presence.add_entity":`Präsenz-Entity hinzufügen`,"presence.person_label":`Person`,"room.section.presence":`Anwesenheit`,"presence.room_help_header":`Wie funktioniert die Raum-Anwesenheit?`,"presence.room_help_body":`Wähle aus, welche Personen für diesen Raum relevant sind. Der Raum schaltet auf Eco-Temperatur, wenn keine der ausgewählten Personen zu Hause ist. Ohne Auswahl greift die globale Regel: Eco wenn niemand zu Hause ist.`,"presence.state_home":`Zu Hause`,"presence.state_away":`Abwesend`,"presence.room_none_assigned":`Globale Regel — Eco wenn niemand zu Hause ist`,"presence.missing_entity_hint":`Diese Entity existiert nicht mehr in Home Assistant — abwählen, um sie aus diesem Raum zu entfernen.`,"presence.ignore_toggle":`Anwesenheit ignorieren`,"presence.ignore_hint":`Hier wird festgelegt, wie dieser Raum auf Anwesenheit reagiert. Unten kannst du einzelne Personen zuweisen. Der Raum wechselt auf Eco, wenn keine der zugewiesenen Personen zu Hause ist. Mit dem Toggle oben wird die Erkennung komplett übersprungen und der Raum heizt immer nach Zeitplan.`,"presence.help_ignore_title":`Was bewirkt "Ignore presence"?`,"presence.help_ignore_body":`Wenn aktiviert, ignoriert dieser Raum die Anwesenheitserkennung komplett. Er folgt immer seinem Zeitplan und wechselt nie aufgrund von Anwesenheit auf Eco. Nützlich für Räume, die unabhängig von Anwesenheit ihre Temperatur halten sollen, etwa Serverräume, Tierzimmer oder Gästezimmer mit Personen, die nicht in Home Assistant getrackt werden.`,"presence.tile_ignored":`Anwesenheitserkennung ist deaktiviert. Raum folgt immer dem Zeitplan.`,"presence.away_action_label":`Aktion wenn niemand zuhause`,"presence.away_action_eco":`Eco-Temperatur verwenden`,"presence.away_action_off":`Geräte ausschalten`,"presence.clears_override_label":`Abwesenheit beendet Override`,"presence.clears_override_hint":`Sobald niemand zuhause ist, wird ein manueller Override pausiert und der Raum folgt der Abwesenheits-Aktion. Kommt jemand zurück, läuft der Override weiter, bis er abläuft.`,"card.presence_away":`Abwesend`,"valve_protection.title":`Ventilschutz`,"valve_protection.hint":`Bewegt inaktive TRV-Ventile regelmäßig kurz, um Festsitzen oder Verkalkung zu verhindern.`,"valve_protection.interval_label":`Zyklusintervall`,"valve_protection.interval_suffix":`Tage`,"valve_protection.interval_hint":`Wie lange ein Ventil inaktiv sein darf, bevor es bewegt wird (1–90 Tage)`,"compressor.title":`Kompressorschutz`,"compressor.no_groups":`Keine Kompressorgruppen konfiguriert.`,"compressor.add_group":`Kompressorgruppe hinzufügen`,"compressor.group_name":`Gruppenname`,"compressor.members":`Innengeräte`,"compressor.members_hint":`Alle Klimageräte auswählen, die von diesem Kompressor versorgt werden (Splits, TRVs an Radiatoren, Fan Coils).`,"compressor.min_run":`Mindestlaufzeit`,"compressor.min_run_hint":`Kompressor muss nach dem Start mindestens so lange laufen.`,"compressor.min_run_suffix":`Min.`,"compressor.min_off":`Mindestauszeit`,"compressor.min_off_hint":`Kompressor muss nach dem Stopp mindestens so lange aus bleiben.`,"compressor.min_off_suffix":`Min.`,"compressor.delete":`Gruppe löschen`,"compressor.delete_confirm":`Kompressorgruppe "{name}" löschen?`,"compressor.master_entity":`Hauptgerät`,"compressor.master_entity_hint":`Das zentrale Gerät das die Innengeräte dieser Gruppe versorgt, z.B. ein Gaskessel, eine Wärmepumpen-Außeneinheit oder ein Kanalklima-Hauptschalter. RoomMind schaltet es ein wenn ein Raum Heiz- oder Kühlbedarf hat und aus wenn alle Räume im Leerlauf sind. Leer lassen um nur das Aktionsskript oder den Kurzzyklusschutz zu verwenden.`,"compressor.conflict_resolution":`Konfliktlösung`,"compressor.conflict_resolution_hint":`Bestimmt was passiert wenn einige Räume heizen und andere gleichzeitig kühlen wollen. Heizpriorität: Heizen gewinnt immer (sicherste Option für Frostschutz). Kühlpriorität: Kühlen gewinnt immer. Mehrheit: Der Modus mit mehr Räumen gewinnt, bei Gleichstand wird geheizt. Außentemperatur: Entscheidet automatisch anhand des Heiz-Schwellwerts aus den Einstellungen.`,"compressor.conflict_heating_priority":`Heizpriorität (Frostschutz)`,"compressor.conflict_cooling_priority":`Kühlpriorität`,"compressor.conflict_majority":`Mehrheit gewinnt`,"compressor.conflict_outdoor_temp":`Nach Außentemperatur`,"compressor.action_script":`Aktionsskript`,"compressor.action_script_hint":`Ein Home Assistant Skript das bei jedem Wechsel des Heiz-/Kühlbedarfs ausgeführt wird. Nützlich für Systeme die spezielle Befehle benötigen, z.B. zum Aufheben eines Vaillant Quick Veto oder Schalten eines Relais. Funktioniert mit oder ohne Hauptgerät. Ohne Hauptgerät wird nur das Skript ausgelöst. Erhält Variablen: action (heat/cool/idle), master_entity, members, active_members.`,"compressor.enforce_uniform_mode":`Einheitlichen Modus erzwingen`,"compressor.enforce_uniform_mode_hint":`Alle Thermostate in dieser Gruppe müssen im gleichen HVAC-Modus arbeiten (alle heizen oder alle kühlen). Räume, die dem aufgelösten Gruppenmodus widersprechen, werden auf Leerlauf gesetzt. Für Wärmepumpen die automatisch starten, aber alle angeschlossenen Geräte im gleichen Modus benötigen.`,"coil_dry.title":`Verdampfer-Trocknung`,"coil_dry.hint":`Lässt das Innengebläse nach dem Kühlen noch eine Weile laufen, bevor das Klimagerät wirklich abschaltet. Trocknet den Verdampfer, damit sich kein Biofilm bildet und es beim nächsten Start nicht muffig riecht.`,"coil_dry.duration_label":`Trocknungsdauer`,"coil_dry.duration_suffix":`Min`,"coil_dry.duration_hint":`Wie lange das Gebläse nachläuft (1–60 Min). Bei niedriger Lüfterstufe etwa doppelt so lange ansetzen wie bei hoher.`,"coil_dry.min_cooling_label":`Mindest-Kühllaufzeit`,"coil_dry.min_cooling_suffix":`Min`,"coil_dry.min_cooling_hint":`Erst trocknen, wenn das Gerät mindestens so lange gekühlt hat. Kurze Kühltakte werden zusammengezählt (1–240 Min).`,"coil_dry.mode_label":`Trocknungsmodus`,"coil_dry.mode_fan_only":`fan_only (nur Gebläse)`,"coil_dry.mode_dry":`dry (Entfeuchten)`,"coil_dry.mode_dry_warning":`Im dry-Modus läuft der Kompressor weiter und kühlt die Lamellen wieder ab — das arbeitet gegen das Trocknen. Nur wählen, wenn der dry-Modus deines Geräts gebläsedominiert ist.`,"coil_dry.fan_mode_label":`Lüfterstufe beim Trocknen`,"coil_dry.fan_mode_keep":`Aktuelle Stufe beibehalten`,"coil_dry.fan_mode_hint":`Eine höhere Stufe trocknet schneller, ist aber lauter. Stufen, die das Gerät nicht meldet, werden übersprungen — es behält dann seine aktuelle.`,"coil_dry.drain_label":`Ablaufverzögerung`,"coil_dry.drain_suffix":`Min`,"coil_dry.drain_hint":`Gerät zuerst aus lassen, damit Kondensat ablaufen kann, dann das Gebläse starten (0–15 Min). Verringert, wie viel Feuchte in den Raum zurückgeblasen wird.`,"mold.title":`Schimmelschutz`,"mold.detection":`Schimmelerkennung`,"mold.detection_desc":`Benachrichtigung bei Schimmelgefahr durch hohe Luftfeuchtigkeit`,"mold.threshold":`Feuchtigkeitsschwelle (%)`,"mold.threshold_hint":`Warnung wenn die Raumluftfeuchte diesen Wert dauerhaft überschreitet`,"mold.insulation":`Wanddämmung`,"mold.insulation_hint":`Damit schätzt RoomMind, wie kalt die kälteste Stelle der Außenwand wird (Ecken, Fensterlaibungen). Im Zweifel Standard lassen. Braucht eine Außentemperatur.`,"mold.insulation_poor":`Ungedämmter Altbau`,"mold.insulation_standard":`Standard`,"mold.insulation_good":`Gut gedämmt (Neubau oder saniert)`,"mold.sustained":`Mindestdauer (Minuten)`,"mold.sustained_hint":`Warnung erst nach anhaltender Überschreitung`,"mold.prevention":`Schimmelprävention`,"mold.prevention_desc":`Temperatur automatisch erhöhen um Schimmelrisiko zu senken`,"mold.intensity":`Intensität`,"mold.intensity_light":`Leicht (+{delta}{unit})`,"mold.intensity_medium":`Mittel (+{delta}{unit})`,"mold.intensity_strong":`Stark (+{delta}{unit})`,"mold.intensity_hint":`Wärmere Raumluft senkt die Oberflächenfeuchte an kalten Wänden. Leicht reicht meist bei moderatem Risiko, Stark kann die Oberflächenfeuchte um bis zu 8–10 % senken — verbraucht aber deutlich mehr Energie.`,"card.mold_warning":`Schimmelrisiko`,"card.mold_critical":`Schimmelgefahr!`,"card.mold_prevention":`Schimmelschutz +{delta}{unit}`,"room.mold_surface_rh":`Geschätzte Oberflächenfeuchte: {value}%`,"room.mold_surface_temp":`Wand {value}{unit}`,"settings.intro.general":`Grundlegende Anzeige- und Steuerungseinstellungen.`,"settings.intro.sensors":`Außensensoren und Wetterdaten für eine präzise Klimasteuerung konfigurieren.`,"settings.intro.control":`Wähle, wie RoomMind deine Klimageräte steuert und setze Priorität und Schwellenwerte.`,"settings.intro.presence":`Temperatur automatisch absenken wenn niemand zu Hause ist.`,"settings.intro.vacation":`Alle Räume auf eine reduzierte Temperatur setzen während du abwesend bist.`,"settings.intro.valve":`Inaktive TRV-Ventile regelmäßig bewegen um Festsitzen oder Verkalkung zu verhindern.`,"settings.intro.compressor":`Gruppen von Innengeräten verwalten die sich einen Außenkompressor oder eine zentrale Heizquelle teilen. Optional ein Hauptgerät (Kessel, Außeneinheit) zuweisen das automatisch je nach Raumbedarf ein- und ausgeschaltet wird. Kurzzyklusschutz verhindert schnelles Ein-/Ausschalten das Geräte beschädigen kann.`,"settings.intro.mold":`Luftfeuchtigkeit überwachen und Schimmelrisiko automatisch reduzieren.`,"settings.intro.notifications":`Konfiguriere wer Benachrichtigungen erhält und wie.`,"settings.intro.learning":`Thermisches Modelltraining verwalten und Lernen nach Änderungen beschleunigen.`,"settings.intro.reset":`Gelernte thermische Modelldaten löschen. Das Modell beginnt von vorne zu lernen.`,"notifications.title":`Benachrichtigungen`,"notifications.enabled":`Benachrichtigungen aktivieren`,"notifications.enabled_hint":`Wenn deaktiviert, werden keine Benachrichtigungen gesendet — weder an Geräte noch an die HA-Seitenleiste.`,"notifications.desc":`Wähle die Geräte, die Benachrichtigungen erhalten. Ohne Ziele erscheint eine Meldung in der HA-Seitenleiste.`,"notifications.add_target_label":`Benachrichtigungsgerät hinzufügen`,"notifications.add_target_hint":`Tippe die Entity-ID ein, falls dein Gerät nicht angezeigt wird (z.B. notify.mobile_app_...). Du findest sie unter Einstellungen → Geräte → dein Telefon → Notify-Entität.`,"notifications.target_unnamed":`Unbenanntes Gerät`,"notifications.target_person":`Person`,"notifications.target_when_always":`Immer`,"notifications.target_when_home":`Nur wenn zuhause`,"notifications.cooldown":`Benachrichtigungspause (Minuten)`,"notifications.cooldown_hint":`Mindestabstand zwischen wiederholten Warnungen pro Raum`,"notifications.mold_prevention_notify":`Bei Aktivierung der Prävention benachrichtigen`,"notifications.mold_prevention_notify_hint":`Auch benachrichtigen wenn die Prävention aktiviert wird (Temperaturerhöhung)`,"room.section.heat_source":`Heizquellen-Orchestrierung`,"heat_source.toggle":`Intelligente Quellenauswahl`,"heat_source.toggle_hint":`Wenn dieser Raum sowohl Heizkörper-Thermostate als auch eine AC/Wärmepumpe hat, leitet RoomMind die Heizanforderung intelligent an das effizienteste Gerät weiter, basierend auf Temperaturlücke und Außenbedingungen.`,"heat_source.primary_delta":`Boiler-Aktivierungsschwelle`,"heat_source.primary_delta_hint":`Primärquelle erst aktivieren, wenn die Temperaturlücke diesen Wert überschreitet. Darunter wird nur die schnelle Sekundärquelle genutzt.`,"heat_source.primary_delta_suffix":`°C`,"heat_source.outdoor_threshold":`Außentemperatur-Umschaltpunkt`,"heat_source.outdoor_threshold_hint":`Über dieser Außentemperatur die AC/Wärmepumpe bevorzugen (höhere Effizienz). Darunter den Gas-Boiler/Heizkörper.`,"heat_source.outdoor_threshold_suffix":`°C`,"heat_source.ac_min_outdoor":`Min. Außentemp. für AC-Heizen`,"heat_source.ac_min_outdoor_hint":`AC-Heizen unter dieser Temperatur komplett deaktivieren, um die Wärmepumpen-Hardware zu schützen.`,"heat_source.ac_min_outdoor_suffix":`°C`,"heat_source.summary_disabled":`Intelligente Quellenwahl ist aus`,"devices.valve_closing_entity_hint":`Hält das Ventil auf der gesetzten Öffnung, egal was die Regelung des Thermostats will. Wird automatisch eingetragen, wenn das Gerät eine hat.`,"room.section.thermostat":`Thermostat`,"thermostat.info":`Am Regler drehen hält eine Temperatur bis zum nächsten Zeitplanwechsel. Modus- und Preset-Tasten wirken wie an einem Wandthermostat.`,"thermostat.not_available":`Die Raum-Thermostat-Entität ist noch nicht verfügbar. Sie erscheint, sobald der Raum gespeichert ist.`,"thermostat.load_failed":`Die Thermostat-Karte konnte nicht geladen werden.`,"room.thermostat_toggle":`Thermostat anzeigen`,"room.thermostat_hint":`Zeigt für diesen Raum einen Thermostat-Regler, um die Temperatur direkt zu ändern.`,"schedule_editor.title_new":`Neuer Zeitplan`,"schedule_editor.title_edit":`Zeitplan bearbeiten`,"schedule_editor.create":`Zeitplan erstellen`,"schedule_editor.edit":`Zeitplan bearbeiten`,"schedule_editor.read_only":`Dieser Zeitplan ist in YAML definiert und kann hier nicht bearbeitet werden. Bearbeite ihn in der Konfiguration oder erstelle einen neuen Zeitplan.`,"schedule_editor.name":`Name`,"schedule_editor.no_blocks":`Keine Zeitblöcke an diesem Tag: den ganzen Tag gilt die Eco-Temperatur.`,"schedule_editor.add_block":`Zeitblock hinzufügen`,"schedule_editor.remove_block":`Zeitblock entfernen`,"schedule_editor.copy_weekdays":`Auf Mo–Fr kopieren`,"schedule_editor.copy_all":`Auf alle Tage kopieren`,"schedule_editor.hint":`Innerhalb eines Zeitblocks wird auf dessen Temperatur geregelt, bei leerem Feld auf Komfort. Außerhalb der Blöcke gilt Eco. Endzeit 00:00 bedeutet Mitternacht.`,"schedule_editor.hint_auto":`Innerhalb eines Zeitblocks wird zwischen dessen Heiz- und Kühltemperatur gehalten (leer = Komfort). Außerhalb der Blöcke gilt Eco. Endzeit 00:00 bedeutet Mitternacht.`,"schedule_editor.cancel":`Abbrechen`,"schedule_editor.save":`Speichern`,"schedule_editor.comfort_placeholder":`Komfort`,"schedule_editor.from":`Von`,"schedule_editor.to":`Bis`,"schedule_editor.heat":`Heizen`,"schedule_editor.cool":`Kühlen`,"schedule_editor.temperature":`Temperatur`,"schedule_editor.err_time":`Bitte eine gültige Uhrzeit eingeben.`,"schedule_editor.err_order":`Ein Zeitblock muss nach seinem Beginn enden.`,"schedule_editor.err_overlap":`Zeitblöcke am selben Tag dürfen sich nicht überschneiden.`,"schedule_editor.err_temp":`Bitte eine gültige Temperatur eingeben.`,"schedule_editor.err_band":`Die Kühltemperatur darf nicht unter der Heiztemperatur liegen.`,"schedule_editor.err_entity":`Der Zeitplan wurde erstellt, aber die Entität wurde nicht gefunden. Bitte aus der Liste hinzufügen.`,"schedule_editor.day_short.monday":`Mo`,"schedule_editor.day_short.tuesday":`Di`,"schedule_editor.day_short.wednesday":`Mi`,"schedule_editor.day_short.thursday":`Do`,"schedule_editor.day_short.friday":`Fr`,"schedule_editor.day_short.saturday":`Sa`,"schedule_editor.day_short.sunday":`So`,"compressor.release_title":`Heizungs-Freigabe (Kessel / Ölheizung)`,"compressor.release_entity":`Freigabe-Entität`,"compressor.release_entity_hint":`Optional. Ein input_boolean oder Schalter, der den Brenner freigibt. RoomMind schaltet ihn ein, wenn genug Räume dieser Gruppe Wärme brauchen, und hält die Mindestlauf-/Pausenzeiten oben ein.`,"compressor.release_on":`Freigabe an`,"compressor.release_off":`Freigabe aus`,"compressor.release_demand":`{count} Räume brauchen Wärme (gewichtet {weighted})`,"compressor.release_min_demand":`Räume für Freigabe`,"compressor.release_min_demand_hint":`Wie viele Räume Wärme brauchen müssen, bevor der Brenner startet. Läuft er, bleibt er an, solange noch ein Raum heizt.`,"compressor.release_smart":`Intelligente Freigabe`,"compressor.release_smart_hint":`Gewichtet jeden Raum nach dem Wärmebedarf aus seinem gelernten Modell (100 % zählt voll, 10 % nur wenig), damit der Brenner seltener und länger läuft. Ein Raum weit unter Soll oder mit zu langer Wartezeit gibt allein frei.`,"compressor.release_urgent_delta":`Dringend unter Soll`,"compressor.release_urgent_delta_hint":`Ein Raum, der so weit unter Soll liegt, gibt den Brenner sofort frei.`,"compressor.release_max_wait":`Maximale Wartezeit`,"compressor.release_max_wait_hint":`Ein Raum, der so lange Wärme braucht, gibt den Brenner frei, auch wenn nicht genug andere Räume wollen.`,"compressor.release_reason.no_demand":`kein Raum braucht Wärme`,"compressor.release_reason.running":`läuft, solange Räume heizen`,"compressor.release_reason.demand_count":`genug Räume brauchen Wärme`,"compressor.release_reason.weighted_demand":`genug gewichteter Bedarf`,"compressor.release_reason.urgent":`ein Raum liegt weit unter Soll`,"compressor.release_reason.max_wait":`ein Raum hat zu lange gewartet`,"compressor.release_reason.collecting_demand":`sammelt Bedarf`,"compressor.release_reason.min_run":`Mindestlaufzeit`,"compressor.release_reason.min_off":`Mindestpause`,"thermostat.writes_schedule":`Thermostat ändert den Zeitplan`,"thermostat.writes_schedule_hint":`Drehen während eines Zeitblocks setzt die Tagestemperatur im aktiven Zeitplan für die ganze Woche, außerhalb der Blöcke die Nachttemperatur. Aus: Die Änderung gilt nur bis zum nächsten Zeitplanwechsel.`,"schedule_editor.copy_hint":`Dieser Zeitplan ist in YAML definiert und kann hier nicht geändert werden. Beim Speichern wird er als neuer, bearbeitbarer Zeitplan übernommen und ersetzt ihn in diesem Raum.`,"schedule_editor.day_temp":`Tagestemperatur`,"schedule_editor.night_temp":`Nachttemperatur`,"schedule_editor.day_night_hint":`Tag gilt innerhalb der Zeitblöcke (setzt alle Blöcke), Nacht außerhalb (Eco-Temperatur des Raums).`,"compressor.boiler_title":`Kesseltemperatur (optional)`,"compressor.boiler_temp_sensor":`Sensor Kessel-/Vorlauftemperatur`,"compressor.boiler_temp_sensor_hint":`Mit der Kesseltemperatur lernt RoomMind, wie schnell der Kessel aufheizt und auskühlt. Ein noch warmer Kessel wird für jeden Raum freigegeben, damit seine Wärme genutzt wird, und die intelligente Freigabe startet einen kalten Kessel um seine Aufheizzeit früher.`,"compressor.boiler_usable_temp":`Kessel warm ab`,"compressor.boiler_usable_temp_hint":`Wassertemperatur, ab der die Heizkörper nutzbare Wärme abgeben.`,"compressor.boiler_status":`Kessel {temp} °C · heizt {heat} K/min · kühlt {cool} K/min`,"compressor.boiler_learning":`lernt…`,"compressor.boiler_lead":`warm in ~{min} Min.`,"compressor.boiler_warm":`bleibt ~{min} Min. warm`,"compressor.release_reason.residual_heat":`nutzt Restwärme im Kessel`,"compressor.release_reason.preheat":`heizt kalten Kessel vor`,"panel.tab.heating":`Heizung`,"heating.no_groups":`Lege zuerst unter Einstellungen → Kompressorschutz eine Gruppe an und füge die Thermostate der Räume hinzu, die dieser Kessel beheizt. Kessel-Einstellungen, Status und Analyse erscheinen dann hier.`,"heating.unnamed":`Unbenannte Gruppe`,"heating.unknown":`unbekannt`,"heating.on":`An`,"heating.off":`Aus`,"heating.release":`Freigabe`,"heating.demand":`Wärmebedarf`,"heating.demand_value":`{count} Räume · gewichtet {weighted}`,"heating.boiler_temp":`Kesseltemperatur`,"heating.burner":`Brenner`,"heating.pump":`Heizkreispumpe`,"heating.dhw":`Warmwasser`,"heating.learned":`Gelerntes Kesselverhalten`,"heating.heat_rate":`Heizt auf`,"heating.cool_rate":`Kühlt ab`,"heating.reset_learning":`Lerndaten zurücksetzen`,"heating.reset_confirm":`Gelerntes Kesselverhalten wirklich vergessen?`,"heating.learned_hint":`Gelernt aus der Kesseltemperatur: Aufheizen, solange der Brenner läuft (sonst solange freigegeben), Abkühlen im Stillstand. Pausiert während Warmwasserbereitung. Dient dazu, einen kalten Kessel rechtzeitig zu starten und die Restwärme eines warmen zu nutzen.`,"heating.waiting_status":`Warte auf den ersten Regelzyklus…`,"heating.status":`Status`,"heating.range.24h":`24 Std.`,"heating.range.7d":`7 Tage`,"heating.range.30d":`30 Tage`,"heating.kpi_starts":`{what}-Starts`,"heating.kpi_avg_run":`Ø {min} Min. pro Lauf`,"heating.kpi_runtime":`{what}-Laufzeit`,"heating.kpi_release_time":`Freigegeben`,"heating.kpi_oil":`Öl`,"heating.kpi_oil_estimated":`geschätzt aus Brennerlaufzeit`,"heating.kpi_pump":`Pumpenlaufzeit`,"heating.kpi_dhw":`Warmwasser`,"heating.kpi_dhw_count":`{count} Ladungen`,"heating.kpi_boiler":`Ø Kessel`,"heating.kpi_boiler_max":`max. {max} °C`,"heating.reasons":`Warum die Freigabe an oder aus war`,"heating.oil_hint":`Für den Ölverbrauch unten einen Ölzähler eintragen, oder Brenner und Düsendurchsatz (L/h).`,"heating.analysis":`Analyse`,"heating.settings":`Kessel-Einstellungen`,"heating.settings_intro":`Alles, was RoomMind über diesen Kessel wissen muss. Nur die Freigabe-Entität ist nötig; jede weitere Entität verbessert Lernen und Analyse. Warmwasser wird von RoomMind nicht geregelt, nur berücksichtigt.`,"heating.section_release":`Freigabe`,"heating.section_boiler":`Kessel & Heizkreis`,"heating.section_oil":`Ölverbrauch`,"heating.burner_entity":`Brenner läuft`,"heating.burner_entity_hint":`Optional. Zeigt, wann der Brenner wirklich brennt (Binärsensor, Schalter oder Leistungssensor > 0). Verbessert das Aufheiz-Lernen und zählt Brennerstarts.`,"heating.pump_entity":`Heizkreispumpe`,"heating.pump_entity_hint":`Optional. Pumpenlaufzeit in der Analyse.`,"heating.dhw_entity":`Warmwasserbereitung`,"heating.dhw_entity_hint":`Optional. Während der Warmwasserbereitung wird die Kesseltemperatur nicht zum Lernen genutzt; Ladungen und Laufzeit erscheinen in der Analyse.`,"heating.oil_sensor":`Ölzähler`,"heating.oil_sensor_hint":`Optional. Ein Sensor, der Liter zählt (Gesamt). Anstiege werden summiert, Nachfüllen oder Zurücksetzen zählt nicht.`,"heating.oil_nozzle":`Düsendurchsatz`,"heating.oil_nozzle_hint":`Ohne Ölzähler: Liter pro Stunde der Brennerdüse (siehe Düse/Typenschild, z. B. 2,0 L/h). Mit der Brenner-Entität schätzt RoomMind den Verbrauch.`,"heating.members_hint":`Räume/Thermostate dieses Kessels sowie Mindestlauf- und Pausenzeit: Einstellungen → Kompressorschutz.`,"compressor.release_moved":`Keine Kessel-Freigabe eingerichtet`,"compressor.release_open_tab":`Zum Tab Heizung`,"quick.day":`Tag`,"quick.day_hint":`Soll ohne Zeitplan (Komfort)`,"quick.day_hint_schedule":`In den Zeitblöcken, ganze Woche (auch per Thermostat)`,"quick.day_hint_yaml":`Zeitplan ist YAML: nur der Komfortwert ändert sich`,"quick.take_over":`Zeitplan übernehmen, damit Tagestemperatur und Thermostat ihn ändern können`,"quick.night":`Nacht`,"quick.night_hint":`Außerhalb der Zeitblöcke (Eco)`,"quick.away":`Abwesend`,"quick.away_hint":`Wenn alle weg sind`,"quick.away_hint_same":`Wenn alle weg sind – wie Nacht`,"quick.away_reset":`Wie Nacht verwenden`,"quick.arrival":`Heimkehr erwartet ~{time}`,"quick.arrival_heating":`Heizt vor – Heimkehr erwartet ~{time}`,"presence.preheat_label":`Warm bei Heimkehr (lernend)`,"presence.preheat_hint":`Lernt pro Wochentag, wann Personen meist heimkommen. Sind alle weg, heizt ein Raum so früh vor, dass er zur erwarteten Heimkehr seine Zeitplan-Temperatur erreicht – mit seiner gelernten Aufheizzeit.`,"presence.preheat_minutes":`Vorheizzeit ohne gelerntes Modell`,"presence.preheat_minutes_hint":`Gilt, bis das Wärmemodell eines Raums trainiert ist; danach nutzt jeder Raum seine eigene gelernte Aufheizzeit.`,"presence.learned_title":`Gelernte Heimkehrzeiten`,"presence.learned_count":`{count} Heimkehren`,"presence.learned_next":`heute erwartet ~{time}`,"presence.learned_hint":`Typische Heimkehr pro Wochentag (Median der letzten 8 Wochen). Eine Vorhersage braucht Heimkehren an mindestens 3 verschiedenen Tagen; Abwesenheiten unter 20 Minuten zählen nicht.`},fr:{"panel.title":`RoomMind`,"panel.subtitle":`Gestion du climat`,"panel.tab.rooms":`Pièces`,"panel.edit":`Éditer la pièce`,"panel.tab.settings":`Réglages`,"panel.loading":`Chargement...`,"panel.no_areas":`Aucune pièce configurée dans Home Assistant.`,"panel.no_areas_hint":`Ajoutez des pièces dans les réglages HA pour commencer.`,"badge.beta":`Bêta`,"badge.beta_hint":`Cette fonctionnalité est en version bêta et est susceptible d'être modifiée ou restructurée lors de futures mises à jour.`,"common.learn_more":`En savoir plus`,"panel.stat.rooms":`Pièces`,"panel.stat.heating":`Chauffage`,"panel.stat.cooling":`Refroidissement`,"panel.stat.vacation":`Vacances`,"panel.stat.away":`Absent`,"panel.stat.mold":`Moisissure`,"panel.hide_room":`Masquer`,"panel.unhide":`Afficher`,"panel.hidden_rooms":`Pièces masquées`,"panel.floor_other":`Autre`,"panel.reorder":`Réorganiser les pièces`,"panel.reorder_done":`Terminé`,"room.back":`Retour aux pièces`,"room.section.climate_mode":`Mode climatique`,"room.section.schedule":`Planification et températures`,"room.section.control_mode":`Mode de contrôle`,"room.section.devices":`Appareils`,"room.section.sensors":`Capteurs`,"room.section.windows":`Capteurs de fenêtres`,"room.control_mode.full_control":`Contrôle total`,"room.control_mode.managed":`Mode géré`,"room.control_mode.external_sensor":`Capteur externe: {sensor}`,"room.control_mode.no_sensor":`Aucun capteur de température externe configuré`,"room.control_mode.mpc_active":`MPC actif`,"room.control_mode.mpc_learning":`Apprentissage`,"room.control_mode.device_setpoint":`Consigne de l'appareil: {temp}`,"room.control_mode.power":`Puissance: {power}%`,"room.control_mode.full_control_info":`RoomMind assure un contrôle total de vos appareils de climatisation. Un capteur de température externe mesure la température réelle de la pièce, ce qui permet de calculer la consigne de manière proportionnelle. La consigne de l'appareil est ajustée de manière dynamique en fonction de la puissance de sortie du MPC. Le modèle thermique (EKF) apprend le comportement de votre pièce afin d'optimiser le confort et l'efficacité énergétique.`,"room.control_mode.managed_info":`RoomMind définit la température cible sur votre appareil (à partir de la planification, des dérogations ou du mode vacances), mais l'appareil s'autorégule à l'aide de son propre capteur interne. Pas d'amplification proportionnelle, pas d'apprentissage de modèle thermique et pas d'optimisation MPC. Pour un contrôle plus précis, configurez un capteur de température externe dans la section Appareils.`,"room.delete":`Supprimer une pièce`,"room.deleting":`Suppression...`,"room.saving":`Enregistrement...`,"room.saved":`Enregistré`,"room.error_saving":`Erreur pendant l'enregistrement`,"room.confirm_delete":`Effacer la configuration RoomMind de "{name}"?`,"room.error_save_fallback":`Échec de l'enregistrement de la configuration`,"room.error_delete_fallback":`Échec de la suppression de la configuration`,"room.climate_control_toggle":`Contrôle climatique`,"room.climate_control_hint":`Si désactivé, RoomMind ne contrôle plus les appareils de cette pièce. Ils conservent leurs réglages actuels et peuvent continuer à chauffer ou refroidir d'eux-mêmes. RoomMind ne les éteint pas.`,"room.outdoor_toggle":`Zone extérieure`,"room.outdoor_hint":`Désactive le contrôle climatique, la détection de moisissures et l'entraînement du modèle. La surveillance des capteurs se poursuit.`,"room.alias.placeholder":`Nom d'affichage personnalisé`,"room.alias.clear":`Revenir au nom de la pièce`,"override.label":`Dérogation temporaire`,"override.comfort":`Confort`,"override.eco":`Éco`,"override.custom":`Personnalisé`,"override.target":`Cible:`,"override.heat_to":`Chauffer jusqu'à:`,"override.cool_above":`Refroidir au-dessus de:`,"override.invalid_band":`La cible de refroidissement doit être supérieure ou égale à la cible de chauffage`,"override.activate_for":`Activer pendant:`,"override.error_set":`Échec lors de la configuration de la dérogation`,"override.error_clear":`Échec lors de la suppression de la dérogation`,"hero.target":`Cible`,"hero.override":`Dérogation`,"hero.remaining":`{time} restant`,"hero.humidity":`{value}% humidité`,"hero.device_setpoint":`Appareil réglé sur {value}{unit}`,"hero.heat_source_primary":`Chauffage: vannes thermostatiques`,"hero.heat_source_secondary":`Chauffage: Climatisation`,"hero.heat_source_both":`Chauffage: Vannes thermostatiques + Climatisation`,"hero.permanent":`Permanent`,"hero.waiting":`En attente des données du capteur...`,"hero.not_configured":`Pas encore configuré`,"hero.mpc_learning_paused":`Apprentissage du MPC en pause`,"hero.mpc_learning_paused.outdoor_unavailable":`RoomMind a besoin d'une température extérieure pour apprendre le modèle thermique de cette pièce. Le capteur extérieur configuré n'est pas disponible et aucune entité météo n'est définie comme solution de secours. Configurez l'un ou l'autre dans les Paramètres.`,"hero.compressor_protection_min_off":`Protection du compresseur : attente du délai minimal d'arrêt`,"hero.compressor_protection_min_off_left":`Protection du compresseur : délai minimal d'arrêt, encore {minutes} min`,"hero.compressor_protection_min_run":`Protection du compresseur : durée minimale de fonctionnement active`,"hero.compressor_protection_min_run_left":`Protection du compresseur : durée minimale de fonctionnement, encore {minutes} min`,"hero.compressor_protection_info":`Cette pièce partage une unité extérieure (compresseur) avec d'autres pièces. Pour éviter les cycles courts, le groupe de compresseurs impose une durée minimale de fonctionnement et un délai minimal d'arrêt avant que cet appareil ne puisse à nouveau changer d'état.`,"hero.coil_dry":`Séchage ({minutes} min)`,"hero.coil_dry_drain":`Écoulement ({minutes} min)`,"hero.coil_dry_info":`Le climatiseur effectue son cycle de séchage de l'évaporateur puis s'arrête. Une demande de refroidissement l'interrompt immédiatement.`,"card.target":`Cible`,"card.waiting":`En attente de données...`,"card.humidity":`{value}% humidité`,"card.thermostat":`Thermostat`,"card.thermostats":`Thermostats`,"card.ac":`Climatisation`,"card.acs":`Climatisations`,"card.climate_device":`appareil de climatisation`,"card.climate_devices":`appareils de climatisation`,"card.temp_sensor":`capteur temp.`,"card.temp_sensors":`capteurs temp.`,"card.no_climate":`Aucun appareil de climatisation`,"card.outdoor":`Extérieur`,"card.tap_configure":`Appuyez pour configurer`,"card.mpc_active":`MPC actif`,"card.mpc_learning":`MPC en apprentissage`,"card.compressor_min_run":`Marche min. {minutes} min`,"card.compressor_min_off":`Arrêt min. {minutes} min`,"card.not_controlled":`Pas contrôlé par RoomMind`,"mode.auto":`Auto`,"mode.auto_desc":`Chauffe et refroidit automatiquement en fonction de la température cible`,"mode.heat_only":`Chauffer seulement`,"mode.heat_only_desc":`Chauffe uniquement. Avec des thermostats dans la pièce, la climatisation reste éteinte, sauf si la sélection intelligente de la source est active`,"mode.cool_only":`Refroidir seulement`,"mode.cool_only_desc":`Utilise seulement la climatisation, les thermostats restent éteints`,"mode.heating":`Chauffage`,"mode.cooling":`Refroidissement`,"mode.idle":`En veille`,"schedule.add_schedule":`Ajouter une planification`,"schedule.select_schedule":`Sélectionnez la planification`,"schedule.create_helper_hint":`Créer une nouvelle planification dans les réglages HA`,"schedule.selector_label":`Entité sélecteur de planification`,"schedule.selector_value_boolean":`Actuel: {value}`,"schedule.selector_value_number":`Valeur actuelle: {value}`,"schedule.selector_warning":`Plusieurs planifications définies mais aucun sélecteur défini. Seule la première planification sera utilisée.`,"schedule.off_action_label":`Action quand la planification est désactivée`,"schedule.off_action_eco":`Utiliser la température Éco`,"schedule.off_action_off":`Éteindre les appareils`,"schedule.state_active":`Actif`,"schedule.state_inactive":`Inactif`,"schedule.state_unreachable":`Inaccessible`,"schedule.no_schedules":`Aucune planification configurée`,"schedule.done":`Terminé`,"schedule.view_comfort":`Confort: {temp}{unit}`,"schedule.view_eco":`Éco: {temp}{unit}`,"schedule.view_selector":`Planification active sélectionnée par: {name}`,"schedule.view_selector_prefix":`Planification active sélectionnée par:`,"schedule.help_header":`Comment fonctionnent les planifications ?`,"schedule.help_temps_title":`Comment la température cible est-elle déterminée ?`,"schedule.help_temps":`La température cible suit cette chaîne de priorité:`,"schedule.help_temps_1":`<strong>Dérogation manuelle</strong> – Une dérogation confort/éco/personnalisée a toujours la priorité la plus élevée.`,"schedule.help_temps_2":`<strong>Température du bloc</strong> – Si le bloc de planification actif possède une valeur <code>temperature</code> dans ses données, cette valeur est utilisée.`,"schedule.help_temps_3":`<strong>Température de confort</strong> – Si la planification est "activée" mais que le bloc n'a pas de température, la température de secours de confort ci-dessous est utilisée.`,"schedule.help_temps_4":`<strong>Température éco</strong> – Lorsque la planification est "désactivée" (en dehors de tous les blocs temporels), la température éco est utilisée.`,"schedule.help_block_title":`Définir la température par bloc horaire`,"schedule.help_block":`Vous pouvez définir une température spécifique pour chaque bloc horaire en ajoutant une valeur <code>temperature</code> dans la configuration YAML de la planification:`,"schedule.help_block_note":`Si un bloc n'a pas de donnée <code>temperature</code>, la température de secours de confort est utilisée à la place.`,"schedule.help_split_title":`Cibles de chauffage/refroidissement différentes par bloc`,"schedule.help_split":`Pour les pièces en mode auto, vous pouvez définir des cibles de chauffage et de refroidissement différentes par bloc horaire en utilisant <code>heat_temperature</code> et <code>cool_temperature</code> :`,"schedule.help_split_note":`Si une seule est définie, l'autre revient à la température de confort de la pièce. Ces clés ont la priorité sur <code>temperature</code> quand elles sont présentes.`,"schedule.help_multi_title":`Planifications multiples`,"schedule.help_multi":`Vous pouvez ajouter plusieurs planifications et basculer entre elles à l'aide d'une <strong>entité sélecteur</strong>. Cela peut être un <code>input_boolean</code> (bascule entre les planifications 1 et 2) ou un <code>input_number</code> (sélection par numéro). Sans entité sélecteur, seule la première planification est utilisée.`,"schedule.column_comfort":`Confort`,"schedule.column_eco":`Éco`,"schedule.row_heat":`Chauffage`,"schedule.row_cool":`Refroidissement`,"schedule.view_heat":`Chauffage : {comfort} / {eco}{unit}`,"schedule.view_cool":`Refroidissement : {comfort} / {eco}{unit}`,"schedule.comfort_hint_auto":`Confort : cible lorsque la planification est activée. Éco : cible lorsque la planification est désactivée. Les lignes définissent la cible pour le chauffage et le refroidissement.`,"schedule.comfort_label":`Température de confort de secours`,"schedule.eco_label":`Température éco`,"schedule.comfort_hint":`Utilisée lorsque la planification est "activée" mais aucune température n'est définie dans le bloc`,"schedule.from_schedule":`{temp}{unit} provenant de la planification`,"schedule.from_schedule_split":`{heat}{unit} / {cool}{unit} provenant de la planification`,"schedule.fallback":`{temp}{unit} (secours)`,"schedule.block_temp_rejected":`Valeurs hors de la plage valide {min}–{max}{unit} : {values}. La température de confort est utilisée à la place — vérifiez l'assistant de planification.`,"schedule.eco_detail":`{temp}{unit} (éco)`,"devices.climate_entities":`Entités climatiques`,"devices.temp_sensors":`Capteurs de température`,"devices.humidity_sensors":`Capteurs d'humidité`,"devices.no_climate":`Aucune entité climatique trouvée dans cette pièce.`,"devices.no_temp_sensors":`Aucun capteur de température trouvé dans cette pièce.`,"devices.no_humidity_sensors":`Aucun capteur d'humidité trouvé dans cette pièce.`,"devices.occupancy_sensors":`Capteurs de présence`,"devices.no_occupancy_sensors":`Aucun capteur de présence trouvé dans cette pièce`,"devices.occupancy_sensor_hint":`Améliore la précision du modèle thermique en suivant l'occupation de la pièce`,"devices.occupancy_eco":`Éco quand la pièce est vide`,"devices.occupancy_eco_hint":`Lorsque tous les capteurs de présence signalent la pièce vide plus longtemps que le délai, elle passe à sa température éco. Dès que quelqu'un est de nouveau détecté, elle suit son planning. Une pièce vide est maintenue en éco et ne chauffe au confort que lorsque quelqu'un s'y trouve, il lui faut donc un moment pour se réchauffer. La dérogation temporaire, le mode vacances et la détection de présence restent prioritaires.`,"devices.occupancy_eco_delay":`Délai avant éco`,"devices.occupancy_eco_view":`Éco après {minutes} min sans présence`,"devices.window_sensors":`Capteurs de fenêtre/porte`,"devices.no_window_sensors":`Aucun capteur de fenêtre/porte trouvé dans cette pièce.`,"devices.window_open_delay":`Délai avant la pause`,"devices.window_close_delay":`Délai avant la reprise`,"devices.add_entity":`Ajouter une entité`,"devices.done":`Terminé`,"devices.other_area":`Autre pièce`,"devices.type_thermostat":`Thermostat`,"devices.type_ac":`Appareil climatique`,"devices.type_label":`Type`,"devices.select_to_configure":`Sélectionnez un appareil à configurer`,"devices.heating_system_type":`Type de système de chauffage`,"devices.heating_system_type_info":`Après l'arrêt du chauffage, les radiateurs et surtout les systèmes de chauffage au sol continuent de libérer la chaleur stockée. RoomMind tient compte de cette chaleur résiduelle pour éviter le dépassement et améliorer la précision du modèle. Les pièces avec chauffage au sol bénéficient également de temps de marche minimum plus longs.`,"devices.system_type_none":`Standard (pas de chaleur résiduelle)`,"devices.system_type_radiator":`Radiateur`,"devices.system_type_underfloor":`Chauffage au sol`,"devices.underfloor_delay_hint":`Le chauffage au sol a des temps de redémarrage longs. Un délai d'ouverture de fenêtre d'au moins 5 minutes est recommandé pour éviter des arrêts inutiles.`,"devices.heating_system_type_boost_hint":`Astuce : Si le système de chauffage a changé, vous pouvez accélérer le réapprentissage dans les Paramètres.`,"devices.idle_action":`Lorsque inactif`,"devices.idle_action_off":`Éteindre`,"devices.idle_action_fan_only":`Ventilateur uniquement`,"devices.idle_action_setback":`Décalage`,"devices.idle_action_low":`Consigne basse (maintenir actif)`,"devices.idle_action_low_hint":`Abaisse la consigne au minimum de l'appareil au lieu de l'éteindre. Empêche les TRV qui hibernent en mode off de perdre les commandes ultérieures.`,"devices.idle_fan_mode":`Vitesse du ventilateur`,"devices.idle_fan_mode_keep":`Ne pas changer`,"devices.setpoint_mode":`Mode de consigne`,"devices.setpoint_mode_proportional":`Proportionnel (consigne relevée)`,"devices.setpoint_mode_direct":`Direct (l'appareil régule)`,"devices.setpoint_offset":`Décalage de consigne`,"devices.setpoint_offset_hint":`À utiliser si le capteur interne de l'appareil mesure autrement que votre capteur de pièce. Le décalage est ajouté à la cible de la pièce avant l'envoi à l'appareil (chauffage et refroidissement). L'appareil mesure plus froid que la pièce : valeur négative. Il mesure plus chaud : valeur positive. Exemple : vous voulez 24°, mais en refroidissement l'appareil croit la pièce 2° plus froide qu'elle ne l'est et s'arrête trop tôt. Saisissez -2 : l'appareil reçoit 22° et continue jusqu'à ce que la pièce soit vraiment à 24°. 0 = aucun décalage.`,"devices.setpoint_mode_hint":`Direct envoie la cible réelle de la pièce à l'appareil — idéal pour les thermostats et les chauffages d'appoint qui se régulent eux-mêmes. Proportionnel envoie une consigne renforcée vers la température maximale de l'appareil — idéal pour les vannes de radiateur (TRV).`,"devices.coil_dry":`Séchage de l'évaporateur`,"devices.coil_dry_inherit":`Utiliser le réglage global`,"devices.coil_dry_on":`Toujours activé`,"devices.coil_dry_off":`Toujours désactivé`,"devices.coil_dry_minutes":`Durée de séchage (0 = global : {minutes} min)`,"devices.coil_dry_mode":`Mode de séchage`,"devices.coil_dry_mode_inherit":`Global ({value})`,"devices.coil_dry_fan_mode":`Vitesse du ventilateur pendant le séchage`,"devices.coil_dry_fan_mode_inherit":`Global ({value})`,"devices.coil_dry_fan_mode_keep":`Conserver la vitesse actuelle`,"devices.coil_dry_summary":`Séchage`,"devices.coil_dry_global_off_hint":`Le séchage de l'évaporateur est désactivé globalement, rien ne se déclenche donc pour cet appareil. Activez-le dans les réglages ou passez cet appareil sur « Toujours actif ».`,"devices.valve_protection_excluded":`Exclu de la protection des vannes`,"devices.valve_protection_exclude_hint":`Cette entité ne sera pas cyclée par la protection des vannes (ex. entités chaudière virtuelles)`,"devices.valve_direct_control":`Contrôle direct de la vanne`,"devices.valve_opening_entity":`Degré d'ouverture de la vanne`,"devices.valve_closing_entity":`Degré de fermeture de la vanne`,"devices.valve_direct_control_hint":`Pour les têtes thermostatiques dont Home Assistant peut régler l'ouverture (p. ex. SONOFF TRVZB : valve_opening_degree et valve_closing_degree, les deux sont nécessaires). RoomMind maintient alors la vanne à l'ouverture dont la pièce a besoin, p. ex. 30 %, au lieu de l'ouvrir complètement : moins de mouvements, plus silencieux et une chaleur plus régulière. Videz les champs ou désactivez le contrôle climatique et RoomMind remet les deux à 100 %.`,"devices.valve_direct_control_toggle_hint":`Pour les têtes thermostatiques dont Home Assistant peut régler l'ouverture (p. ex. SONOFF TRVZB). RoomMind maintient alors la vanne à l'ouverture dont la pièce a besoin, p. ex. 30 %, au lieu de l'ouvrir complètement : moins de mouvements, plus silencieux et une chaleur plus régulière. Désactivé, ou avec le contrôle climatique désactivé, la tête régule de nouveau la vanne elle-même.`,"devices.valve_direct_badge":`Vanne directe`,"devices.info.types_title":`Types d'appareil`,"devices.info.types_body":`Thermostat désigne un thermostat de radiateur / TRV. Appareil climatique désigne un climatiseur, une pompe à chaleur ou autre entité climatique utilisée pour le refroidissement ou le chauffage à air pulsé. Les deux sont des entités climatiques dans Home Assistant; la différence réside dans la façon dont RoomMind les contrôle.`,"devices.info.control_title":`Comment RoomMind les contrôle`,"devices.info.control_body":`Le mode de consigne ne s'applique qu'aux thermostats dans les pièces en Contrôle total disposant d'un capteur de température externe. Utilisez Proportionnel lorsque RoomMind doit piloter le chauffage en envoyant des consignes renforcées. Utilisez Direct lorsque l'appareil doit se réguler autour de la vraie température cible.`,"devices.info.modes_title":`Comportement en inactivité`,"devices.info.modes_body":`Lorsque inactif ne s'applique qu'aux appareils climatiques. Éteindre met l'appareil hors tension. Ventilateur uniquement maintient le débit d'air sans chauffage ni refroidissement. Décalage garde le mode actuel actif mais décale la cible de 2°C par rapport à la cible de la pièce. Ce décalage de réduction est actuellement fixe. Avec un capteur de température externe et un modèle appris, l'appareil est éteint après une heure sans chauffage ni refroidissement si RoomMind ne prévoit pas d'en avoir besoin dans l'heure qui suit. Pour les thermostats, Consigne basse garde le TRV actif à sa consigne minimale au lieu de l'éteindre, utile pour les TRV Zigbee à batterie qui se mettent en veille lorsqu'ils sont à off.`,"devices.info.heat_source_title":`Sélection intelligente de source`,"devices.info.heat_source_body":`Cela apparaît uniquement lorsqu'une pièce possède à la fois un thermostat/TRV et un appareil climatique ainsi qu'un capteur de température externe. RoomMind peut alors choisir la source qui gérera le chauffage en fonction de l'écart de température et des conditions extérieures.`,"hero.window_open":`Fenêtre ouverte - en pause`,"card.window_open":`Fenêtre ouverte`,"room.section.covers":`Rideaux & stores`,"covers.section_title":`Rideaux & stores`,"covers.auto_control":`Contrôle automatique des stores`,"covers.auto_control_hint":`RoomMind ferme les stores lorsque le gain solaire risque de surchauffer la pièce.`,"covers.deploy_threshold":`Seuil de déploiement`,"covers.deploy_threshold_hint":`Ferme les stores lorsque la température prévue dépasse la cible de cette quantité.`,"covers.min_position":`Position d'ouverture minimale`,"covers.min_position_hint":`Les stores ne se fermeront jamais plus que cela (0 = fermeture totale autorisée).`,"covers.override_minutes":`Durée de pause de la dérogation`,"covers.override_minutes_hint":`Durée pendant laquelle le contrôle automatique est mis en pause après un mouvement manuel du store. Mettre 0 pour aucune pause.`,"covers.no_covers":`Aucune entité de store configurée.`,"covers.no_covers_in_area":`Aucune entité de store trouvée dans cette pièce.`,"covers.add_cover":`Ajouter une entité de store...`,"covers.shading_active":`Ombrage activé`,"covers.auto_paused":`Pause auto (dérogation manuelle)`,"covers.auto_paused_until":`Contrôle automatique en pause jusqu'à`,"covers.resume_auto":`Reprendre le contrôle automatique`,"covers.done":`Terminé`,"covers.night_close":`Fermer la nuit`,"covers.night_close_hint":`Ferme automatiquement les stores au coucher du soleil et les ouvre au lever du soleil.`,"covers.night_close_active":`Fermeture nocturne active`,"covers.schedule_group_title":`Planification`,"covers.solar_group_title":`Contrôle solaire`,"covers.schedule_section":`Planification des stores`,"covers.schedule_section_hint":`Définissez des créneaux horaires pour le contrôle des stores à l'aide des assistants de planification HA. En mode Forcer la position, la position de la planification l'emporte sur la logique solaire/thermique. En mode Autoriser la protection solaire, RoomMind décide de la position dans la fenêtre active.`,"covers.add_schedule":`Ajouter un horaire de store...`,"covers.schedule_mode_force":`Forcer la position`,"covers.schedule_mode_gate":`Autoriser la protection solaire`,"covers.schedule_mode_gate_short":`Portail solaire`,"covers.schedule_position":`Position`,"covers.schedule_position_hint":`Position du store lorsque cette planification est active (0% = entièrement fermé, 100% = entièrement ouvert).`,"covers.schedule_selector":`Entité sélecteur de planification`,"covers.schedule_selector_hint":`Choisissez quelle planification est active. input_boolean: off=#1, on=#2. input_number: la valeur sélectionne le numéro de planification.`,"covers.schedule_selector_warning":`Plusieurs planifications configurées mais aucun sélecteur défini. Seule la première planification sera utilisée.`,"covers.schedule_state_active":`Actif`,"covers.schedule_state_inactive":`Inactif`,"covers.schedule_state_unreachable":`Inaccessible`,"covers.schedule_active":`Horaire actif`,"covers.schedule_create_link":`Créer un assistant de planification`,"covers.night_position":`Position nocturne`,"covers.night_position_hint":`Position du store lorsque la fermeture nocturne est active (0% = entièrement fermé). Les stores avec une position minimale individuelle ne descendront jamais en dessous.`,"covers.night_close_advanced":`Avancé`,"covers.night_close_elevation":`Seuil de position du soleil`,"covers.night_close_elevation_hint":`À quelle distance sous ou au-dessus de l'horizon le soleil doit être. 0° = exactement au coucher/lever du soleil. Négatif = plus sombre (ex. -6° = crépuscule, lorsqu'il fait clairement sombre). Positif = encore lumineux (ex. 5° = le soleil encore visible au-dessus de l'horizon).`,"covers.night_close_offset":`Décalage horaire`,"covers.night_close_offset_hint":`Décalage supplémentaire par rapport au seuil de position du soleil. Positif = fermeture plus tard (ex. +20 = 20 min après le seuil), négatif = fermeture plus tôt.`,"covers.outdoor_min_temp":`Température extérieure min.`,"covers.outdoor_min_temp_hint":`Ne pas fermer les stores pour protéger du soleil en dessous de cette température extérieure. Le gain de chaleur solaire est bienvenu quand il fait froid.`,"covers.per_cover_title":`Paramètres par store`,"covers.per_cover_hint":`Définissez la direction cardinale de chaque store et les positions minimales individuelles éventuelles.`,"covers.per_cover_min_short":`Min`,"covers.per_cover_min_position":`Position min.`,"covers.per_cover_min_position_hint":`Position minimale individuelle par store. Les stores ne se fermeront jamais plus que cela. Utile lorsque les stores sont physiquement complètement fermés à une position > 0%.`,"covers.snap_deploy":`Forcer à la position minimale`,"covers.snap_deploy_hint":`Fermer les stores directement à la position minimale au lieu de les fermer progressivement. Recommandé pour les fenêtres à triple vitrage où les positions intermédiaires peuvent causer du stress thermique.`,"covers.info.selection_title":`Sélection de stores`,"covers.info.selection_body":`Sélectionnez les rideaux/stores de cette zone ou ajoutez des entités d'autres zones. RoomMind suit leur position et peut les contrôler automatiquement.`,"covers.info.schedule_title":`Contrôle via planification`,"covers.info.schedule_body":`Utilisez les assistants de planification HA pour définir les moments où les stores doivent se fermer (ex. intimité le soir). L'attribut de position de l'horaire détermine le degré de fermeture. Les planifications remplacent toute autre logique automatique.`,"covers.info.solar_title":`Contrôle solaire/thermique`,"covers.info.solar_body":`Lorsque le contrôle automatique est activé, RoomMind prédit si le rayonnement solaire surchaufferait la pièce et ferme les stores de manière préventive. Il utilise les données thermiques apprises lorsqu'elles sont disponibles, sinon une valeur par défaut prudente. Le seuil de déploiement détermine le dépassement prédit nécessaire avant de fermer les stores.`,"covers.info.night_title":`Fermeture nocturne`,"covers.info.night_body":`Ferme les stores au coucher du soleil et les ouvre au lever du soleil. Vous pouvez définir une position nocturne personnalisée (ex. 10% = presque fermé mais pas totalement).`,"covers.info.override_title":`Dérogation manuelle`,"covers.info.override_body":`Si vous déplacez manuellement un store, RoomMind le détecte et met le contrôle automatique en pause pendant la durée configurée. Cela évite les conflits avec l'utilisateur.`,"covers.info.priority_title":`Ordre de priorité`,"covers.info.priority_body":`Dérogation manuelle > Planification > Fermeture nocturne > Contrôle solaire/thermique. Les règles de priorité supérieure l'emportent toujours. Lorsqu'aucune règle ne s'applique, les stores restent ouverts.`,"covers.info.entities_title":`Entités HA`,"covers.info.entities_body":`RoomMind crée deux entités par pièce pour une utilisation externe: switch.roommind_{area}_cover_auto (activer/désactiver le contrôle automatique des stores — utilisable dans les automatisations ou tableaux de bord) et binary_sensor.roommind_{area}_cover_paused (activé lorsque la dérogation manuelle est en cours, ex. après un déplacement manuel d'un store).`,"covers.orientation_group_title":`Orientation du store`,"covers.orientation_hint":`Définissez la direction cardinale vers laquelle chaque store fait face. RoomMind n'ombrage alors que lorsque le soleil éclaire réellement ce côté du bâtiment. Sans direction, les stores réagissent à l'ensoleillement en général et peuvent se fermer dès le lever du soleil, même sur une fenêtre au nord.`,"covers.orientation_none":`Pas de direction`,"covers.orientation_N":`N`,"covers.orientation_NE":`NE`,"covers.orientation_E":`E`,"covers.orientation_SE":`SE`,"covers.orientation_S":`S`,"covers.orientation_SW":`SO`,"covers.orientation_W":`O`,"covers.orientation_NW":`NO`,"covers.orientation_N_full":`Nord`,"covers.orientation_NE_full":`Nord-Est`,"covers.orientation_E_full":`Est`,"covers.orientation_SE_full":`Sud-Est`,"covers.orientation_S_full":`Sud`,"covers.orientation_SW_full":`Sud-Ouest`,"covers.orientation_W_full":`Ouest`,"covers.orientation_NW_full":`Nord-Ouest`,"settings.general_title":`Général`,"settings.group_by_floor":`Regrouper les pièces par étage`,"settings.climate_control_active":`Contrôle climatique actif`,"settings.climate_control_hint":`Lorsqu'il est désactivé, RoomMind continue de surveiller tous les capteurs et d'entraîner le modèle, mais n'envoie aucune commande à vos appareils de chauffage ou de refroidissement. Vos appareils conservent leur mode et leur consigne actuels et peuvent continuer à chauffer ou refroidir d'eux-mêmes. RoomMind ne les éteint pas.`,"settings.learning_title":`Entraînement du modèle`,"settings.learning_hint":`Lorsqu'il est en pause, RoomMind cesse de collecter de nouvelles mesures et d'entraîner le modèle thermique. Les données du modèle existant sont conservées.`,"settings.learning_exceptions":`Exceptions`,"settings.learning_room_paused":`pièce en pause`,"settings.learning_rooms_paused":`pièces en pause`,"settings.sensors_title":`Capteurs & sources de données`,"settings.control_title":`Contrôle`,"settings.outdoor_sensor":`Température extérieure`,"settings.outdoor_sensor_label":`Capteur de température extérieure`,"settings.outdoor_current":`Actuellement {temp}{unit} dehors`,"settings.outdoor_waiting":`En attente des données du capteur...`,"settings.outdoor_humidity_sensor":`Humidité extérieure`,"settings.outdoor_humidity_label":`Capteur d'humidité extérieure`,"settings.outdoor_humidity_current":`Actuellement {value}% dehors`,"settings.smart_control":`Contrôle climatique intelligent`,"settings.smart_control_hint":`Configurez les limites de température extérieure pour le chauffage et le refroidissement.`,"settings.outdoor_cooling_min":`Température extérieure minimale pour le refroidissement`,"settings.outdoor_cooling_min_hint":`Le climatiseur reste éteint lorsque la température extérieure est inférieure à cette valeur. Une dérogation manuelle ignore cette limite`,"settings.outdoor_heating_max":`Température extérieure maximale pour le chauffage`,"settings.outdoor_heating_max_hint":`Le chauffage reste éteint lorsque la température extérieure dépasse cette valeur. Une dérogation manuelle ignore cette limite`,"settings.saving":`Enregistrement...`,"settings.saved":`Enregistré`,"settings.error":`Erreur lors de l'enregistrement`,"devices.using_builtin_sensor":`Utilisation du capteur intégré du thermostat`,"settings.climate_intelligence":`Intelligence climatique`,"settings.control_mode":`Mode de contrôle`,"settings.control_mode_simple":`Simple (Bang-Bang)`,"settings.control_mode_mpc":`Intelligent (MPC)`,"settings.control_mode_hint":`Intelligent : le MPC apprend le comportement thermique de chaque pièce et anticipe (régulation marche/arrêt tant qu'il apprend). Simple : uniquement une régulation marche/arrêt avec hystérésis ; le modèle continue d'apprendre en arrière-plan mais ne prend aucune décision, et les stores automatiques utilisent une estimation solaire simplifiée au lieu de la prévision MPC.`,"settings.comfort_weight":`Priorité`,"settings.comfort_weight_comfort":`Confort`,"settings.comfort_weight_efficiency":`Efficacité`,"settings.comfort_weight_hint":`Équilibre la précision de la température avec la consommation d'énergie. Le confort réagit plus tôt et reste plus proche de la cible. L'efficacité permet plus de dérive pour réduire la durée de chauffage/refroidissement. À partir du réglage par défaut, RoomMind préchauffe avant une plage horaire pour que la pièce soit chaude à son début ; en dessous, il commence plus tard, et en pleine efficacité seulement peu avant la plage.`,"settings.weather_entity":`Prévision météo`,"settings.weather_entity_hint":`Optionnel : active la planification prédictive de la température extérieure et sert de secours lorsque le capteur extérieur est indisponible`,"settings.outdoor_unavailable_notify":`Notifier lorsque la température extérieure est indisponible`,"settings.outdoor_unavailable_notify_hint":`Afficher une notification Home Assistant lorsqu'aucun des capteurs extérieurs ni l'entité météo n'a signalé de température pendant 30 minutes. Pendant ce temps, RoomMind met en pause l'apprentissage du modèle thermique pour éviter la corruption.`,"settings.prediction_enabled":`Prédiction de température`,"settings.prediction_enabled_hint":`Afficher la tendance de température prédite dans les graphiques d'analyse. A désactiver si vous constatez de mauvaises performances.`,"vacation.title":`Mode vacances`,"vacation.hint":`Règle toutes les pièces sur une température réduite jusqu'à la date de fin.`,"vacation.active_label":`Mode vacances actif`,"vacation.end_date":`Date et heure de fin`,"vacation.setback_temp":`Température de réduction`,"vacation.no_end_date":`Pas de date de fin`,"vacation.deactivate":`Désactiver`,"tabs.analytics":`Analyses`,"analytics.select_room":`Sélectionner une pièce`,"analytics.temperature":`Température`,"analytics.target":`Cible`,"analytics.prediction":`Prédiction`,"analytics.outdoor":`Extérieur`,"analytics.model_status":`Statut du modèle`,"analytics.confidence":`Confiance`,"analytics.heating_rate":`Puissance de chauffage`,"analytics.cooling_rate":`Puissance de refroidissement`,"analytics.solar_gain":`Gain solaire (plein soleil)`,"analytics.solar_gain_sub":`maintenant {now} · aujourd'hui jusqu'à {today}`,"analytics.occupancy_gain":`Gain d'occupation`,"analytics.time_constant":`Constante de temps`,"analytics.samples":`Échantillons`,"analytics.prediction_accuracy":`Précision de la prédiction`,"analytics.avg_deviation":`Écart moyen`,"analytics.data_sources":`Sources de données`,"analytics.data_points":`Points de données`,"analytics.control_mode":`Mode de contrôle`,"analytics.control_mode_mpc":`MPC actif`,"analytics.control_mode_bangbang":`MPC en apprentissage`,"analytics.last_model_update":`Dernière mise à jour du modèle`,"analytics.accuracy_idle":`Précision (Inactif)`,"analytics.accuracy_heating":`Précision (Chauffage)`,"analytics.info.accuracy_idle":`À quel point le modèle prédit précisément la température lorsqu'aucun chauffage ni refroidissement n'est actif. Une valeur plus basse signifie que le modèle comprend bien la perte de chaleur naturelle de votre pièce. C'est la première valeur qui s'améliore car les données au repos sont collectées en continu.`,"analytics.info.accuracy_heating":`À quel point le modèle prédit précisément la température pendant que le chauffage est actif. Cette valeur reste élevée au début car le modèle a besoin de véritables cycles de chauffage pour apprendre. Une fois que votre chauffage a fonctionné plusieurs fois, cette valeur diminuera et le contrôle MPC deviendra disponible.`,"analytics.info.confidence":`Niveau global de préparation du modèle pour le contrôle MPC intelligent, combinant deux facteurs : la quantité de données (nombre d'échantillons en mode repos et actif) et la précision des prédictions (précision des prévisions de température). La confiance démarre à 0% et augmente à mesure que le modèle collecte des données et apprend. Environ 50% signifie qu'il y a suffisamment de données au repos mais qu'on attend encore des cycles de chauffage/refroidissement. Au-delà de 80% le modèle dispose de suffisamment de données et de prédictions précises — le contrôle MPC devient disponible. 100% est le maximum théorique lorsque les prédictions sont aussi précises que physiquement possible.`,"analytics.info.time_constant":`Durée nécessaire à votre pièce pour se refroidir naturellement jusqu'à la moitié de la différence avec la température extérieure lorsque le chauffage est éteint. Un temps constant plus long indique une meilleure isolation — la pièce conserve la chaleur plus longtemps. Un temps constant court signifie que la pièce se refroidit rapidement. Le modèle apprend cela en observant les baisses de température pendant les périodes d'inactivité.`,"analytics.info.heating_rate":`Intensité de l'effet de votre chauffage sur la température de la pièce. Une valeur plus élevée signifie que votre système de chauffage réchauffe la pièce plus rapidement par rapport à sa masse thermique. Le modèle apprend cela en observant la vitesse à laquelle la température augmente pendant que le chauffage est actif, et l'utilise pour prévoir la durée nécessaire du chauffage.`,"analytics.info.cooling_rate":`Intensité de l'effet de votre climatiseur sur la température de la pièce. Une valeur plus élevée signifie que le climatiseur refroidit la pièce plus rapidement par rapport à sa masse thermique. Le modèle apprend cela en observant la vitesse à laquelle la température baisse pendant le refroidissement actif, et l'utilise pour prévoir la durée nécessaire du fonctionnement du climatiseur. Pendant les premières minutes, l'air près du capteur baisse plus vite, puis remonte après l'arrêt ; le modèle traite cette part séparément, cette valeur indique donc la vitesse à laquelle le climatiseur refroidit toute la pièce, murs et meubles compris.`,"analytics.info.solar_gain":`Vitesse à laquelle le soleil réchauffe la pièce en plein soleil (1000 W/m², midi d'été par ciel clair). La plupart du temps, la fenêtre reçoit bien moins : la ligne en dessous indique l'apport actuel du soleil (nuages et stores compris) et le maximum d'aujourd'hui par ciel clair. En hiver, c'est souvent un quart de la valeur en plein soleil. Comparez la puissance de chauffage à ces deux valeurs. Le modèle l'apprend en observant le réchauffement de la pièce par temps ensoleillé sans chauffage et l'utilise pour réduire le chauffage quand du soleil est attendu.`,"analytics.info.occupancy_gain":`Contribution thermique estimée due à l'occupation (personnes, animaux, ordinateurs) lorsque la pièce est occupée. Le modèle apprend cela en observant les variations de température lorsque les capteurs d'occupation configurés sont actifs. Séparer cela du gain solaire évite que la chaleur corporelle ne soit attribuée à tort à la lumière du soleil. Affiché uniquement lorsqu'au moins un capteur d'occupation est configuré pour cette pièce.`,"analytics.info.data_sources":`Nombre d'échantillons de mesure utilisés pour l'entraînement du modèle.`,"analytics.info.data_points":`Nombre total d'observations sur lesquelles le modèle a été entraîné. Plus de points de données conduisent généralement à de meilleures prédictions. Le modèle collecte un nouveau point de donnée environ toutes les 3 minutes tant que RoomMind fonctionne.`,"analytics.no_data":`Aucune donnée pour le moment — le modèle apprend`,"analytics.loading":`Chargement des analyses...`,"settings.reset_title":`Réinitialiser les données thermiques`,"settings.reset_hint":`Effacer les données thermiques du modèle et l'historique. Le modèle recommencera à apprendre à partir de zéro.`,"settings.reset_all_label":`Toutes les pièces`,"settings.reset_all_hint":`Effacer les données thermiques et l'historique de toutes les pièces en une fois.`,"settings.reset_all_btn":`Tout réinitialiser`,"settings.reset_all_confirm":`Effacer toutes les données thermiques et l'historique pour TOUTES les pièces ? Tous les modèles recommenceront à apprendre à partir de zéro.`,"settings.reset_room_label":`Pièce individuelle`,"settings.reset_room_hint":`Sélectionnez une pièce pour effacer ses données thermiques et son historique.`,"settings.reset_room_confirm":`Effacer toutes les données thermiques apprises et l'historique pour cette pièce ? Le modèle recommencera à apprendre à partir de zéro.`,"settings.reset_room_select":`Sélectionner une pièce`,"settings.reset_btn":`Réinitialiser`,"settings.reset_no_rooms":`Aucune pièce configurée.`,"settings.boost_title":`Accélérer l'apprentissage`,"settings.boost_hint":`Le modèle thermique apprend le comportement de chauffage et de refroidissement de votre pièce au fil du temps. Après des changements majeurs (nouveau radiateur, climatiseur, isolation, mobilier), le modèle peut être imprécis. Cela augmente l'incertitude du modèle afin qu'il s'adapte plus rapidement aux nouvelles conditions.`,"settings.boost_label":`Accélérer l'apprentissage`,"settings.boost_room_select":`Sélectionner une pièce`,"settings.boost_btn":`Accélérer`,"settings.boost_cooldown":`Actif - réapprentissage en cours`,"settings.boost_no_rooms":`Aucune pièce configurée.`,"analytics.range_1d":`Aujourd'hui`,"analytics.range_2d":`2 jours`,"analytics.range_7d":`Semaine`,"analytics.range_30d":`Mois`,"analytics.export":`Mesures`,"analytics.heating_period":`Chauffage`,"analytics.cooling_period":`Refroidissement`,"analytics.blind_position":`Position du store`,"analytics.window_open_period":`Fenêtre ouverte`,"analytics.chart_info_title":`Comment lire ce graphique`,"analytics.exported":`Exporté !`,"analytics.copy_diagnostics":`Diagnostics`,"analytics.export_download":`Télécharger le fichier`,"analytics.export_clipboard":`Copier dans le presse-papiers`,"analytics.copied_to_clipboard":`Copié !`,"analytics.range_from":`De`,"analytics.range_to":`À`,"analytics.chart_info_body":`**Lignes:** La ligne orange solide montre la température mesurée de la pièce. La ligne verte en pointillé représente la température cible de votre planning. La ligne bleue pointillée est la prédiction de température du modèle.

**Zones colorées:** Le rouge indique les périodes de chauffage, le bleu les périodes de refroidissement, et le turquoise les moments où une fenêtre était ouverte.

**Prévision future (à droite de la ligne « now »)** : La ligne verte en pointillé montre les objectifs de planning à venir pour les 3 prochaines heures. La ligne bleue pointillée montre la tendance de température prévue.

**Modes de prédiction :** Lorsque « MPC actif » est affiché, la prédiction utilise l'optimiseur complet MPC avec pré-chauffage/pré-refroidissement intelligent. Tant que le modèle apprend encore, une simulation plus simple est utilisée.

**Limites :** La prédiction suppose que les conditions actuelles restent constantes (température extérieure, état des fenêtres). La précision de la simulation dépend de la qualité d'apprentissage du modèle thermique de votre pièce — au début, les prédictions peuvent être moins précises. Une fois le MPC activé, les prédictions deviennent nettement plus fiables.`,"presence.title":`Détection de présence`,"presence.hint":`Utilise la température éco lorsque personne n'est présent.`,"presence.hint_detail":`Lorsque activé, toutes les pièces passent à la température éco dès qu'aucune des personnes configurées n'est à la maison. Vous pouvez éventuellement restreindre, par pièce, quelles personnes sont prises en compte.`,"presence.add_person":`Ajouter une personne`,"presence.add_entity":`Ajouter une entité de présence`,"presence.person_label":`Personne`,"room.section.presence":`Présence`,"presence.room_help_header":`Comment fonctionne la présence par pièce ?`,"presence.room_help_body":`Sélectionnez les personnes pertinentes pour cette pièce. La pièce passe à la température éco lorsqu'aucune des personnes sélectionnées n'est à la maison. Sans sélection, la règle globale s'applique : éco lorsqu'aucun occupant n'est présent.`,"presence.state_home":`À la maison`,"presence.state_away":`Absent`,"presence.room_none_assigned":`Règle globale — éco lorsqu'aucun occupant n'est présent`,"presence.missing_entity_hint":`Cette entité n'existe plus dans Home Assistant — décochez-la pour la retirer de cette pièce.`,"presence.ignore_toggle":`Ignorer la présence`,"presence.ignore_hint":`Contrôle la façon dont cette pièce réagit à la présence. Vous pouvez attribuer des personnes spécifiques ci-dessous. La pièce passe à l'éco lorsqu'aucune des personnes assignées n'est à la maison. Utilisez le commutateur ci-dessus pour ignorer totalement la détection et suivre toujours le planning.`,"presence.help_ignore_title":`Que fait « Ignorer la présence » ?`,"presence.help_ignore_body":`Lorsqu'elle est activée, cette pièce ignore complètement la détection de présence. Elle suit toujours son planning et ne passe jamais en mode éco en fonction de la présence. Utile pour les pièces qui doivent maintenir la température quel que soit l'occupant, comme une salle serveur, un espace pour animaux ou une chambre d'ami non suivie par Home Assistant.`,"presence.tile_ignored":`Détection de présence ignorée. La pièce suit toujours son planning.`,"presence.away_action_label":`Action lorsque personne n'est à la maison`,"presence.away_action_eco":`Utiliser la température éco`,"presence.away_action_off":`Éteindre les appareils`,"presence.clears_override_label":`L'absence annule la dérogation`,"presence.clears_override_hint":`Lorsque personne n'est à la maison, les dérogations manuelles sont suspendues et la pièce suit l'action d'absence. Quand quelqu'un revient, la dérogation reprend jusqu'à son expiration.`,"card.presence_away":`Absent`,"valve_protection.title":`Protection des vannes`,"valve_protection.hint":`Ouvre périodiquement et brièvement les vannes TRV inactives pour éviter le blocage ou la calcification.`,"valve_protection.interval_label":`Intervalle du cycle`,"valve_protection.interval_suffix":`jours`,"valve_protection.interval_hint":`Durée pendant laquelle une valve peut rester inactive avant d'être cyclée (1-90 jours)`,"compressor.title":`Protection du compresseur`,"compressor.no_groups":`Aucun groupe de compresseurs configuré.`,"compressor.add_group":`Ajouter un groupe de compresseur`,"compressor.group_name":`Nom du groupe`,"compressor.members":`Unités intérieures`,"compressor.members_hint":`Sélectionnez tous les appareils climatiques alimentés par ce compresseur (unités intérieures, TRV sur radiateurs, ventilo-convecteurs).`,"compressor.min_run":`Durée minimale de fonctionnement`,"compressor.min_run_hint":`Le compresseur doit fonctionner au moins aussi longtemps une fois démarré.`,"compressor.min_run_suffix":`min`,"compressor.min_off":`Durée minimale d'arrêt`,"compressor.min_off_hint":`Le compresseur doit rester arrêté au moins aussi longtemps après l'arrêt.`,"compressor.min_off_suffix":`min`,"compressor.delete":`Supprimer le groupe`,"compressor.delete_confirm":`Supprimer le groupe de compresseur "{name}" ?`,"compressor.master_entity":`Appareil maître`,"compressor.master_entity_hint":`L'unité centrale qui alimente les appareils intérieurs de ce groupe, par ex. une chaudière à gaz, une unité extérieure de pompe à chaleur ou l'interrupteur maître d'un système de climatisation gainé. RoomMind l'allumera dès qu'une pièce a besoin de chauffage ou de refroidissement, et l'éteindra lorsque toutes les pièces sont au repos. Laisser vide pour n'utiliser que le script d'action ou la protection contre les courts cycles.`,"compressor.conflict_resolution":`Résolution des conflits`,"compressor.conflict_resolution_hint":`Détermine ce qui se passe lorsque certaines pièces ont besoin de chauffage tandis que d'autres ont besoin de refroidissement simultanément. Priorité chauffage : le chauffage l'emporte toujours (le plus sûr pour la protection contre le gel). Priorité refroidissement : le refroidissement l'emporte toujours. Majorité : le mode avec le plus de pièces l'emporte, les égalités vont au chauffage. Température extérieure : utilise le seuil maximal de chauffage extérieur des paramètres pour décider automatiquement.`,"compressor.conflict_heating_priority":`Priorité chauffage (protection contre le gel)`,"compressor.conflict_cooling_priority":`Priorité refroidissement`,"compressor.conflict_majority":`Majorité l'emporte`,"compressor.conflict_outdoor_temp":`Selon la température extérieure`,"compressor.action_script":`Script d'action`,"compressor.action_script_hint":`Un script Home Assistant qui s'exécute chaque fois que la demande de chauffage/refroidissement change. Utile pour les systèmes nécessitant des commandes spécifiques, par ex. annuler un Vaillant Quick Veto ou basculer un relais. Fonctionne avec ou sans appareil maître. Sans appareil maître, seul le script est déclenché. Reçoit les variables : action (heat/cool/idle), master_entity, members, active_members.`,"compressor.enforce_uniform_mode":`Imposer un mode uniforme`,"compressor.enforce_uniform_mode_hint":`Tous les thermostats de ce groupe doivent fonctionner dans le même mode HVAC (tout chauffage ou tout refroidissement). Les pièces qui ne sont pas d'accord avec le mode de groupe résolu seront mises en mode repos. Utilisez cela pour les pompes à chaleur qui démarrent automatiquement mais exigent que toutes les unités connectées fonctionnent dans le même mode.`,"coil_dry.title":`Séchage de l'évaporateur`,"coil_dry.hint":`Après le refroidissement, laissez tourner le ventilateur intérieur un moment avant l'arrêt réel du climatiseur. Cela sèche l'évaporateur pour éviter la formation d'un biofilm et l'odeur de moisi au démarrage suivant.`,"coil_dry.duration_label":`Durée de séchage`,"coil_dry.duration_suffix":`min`,"coil_dry.duration_hint":`Durée pendant laquelle le ventilateur continue (1–60 min). À vitesse basse, comptez environ le double d'une vitesse élevée.`,"coil_dry.min_cooling_label":`Durée de refroidissement minimale`,"coil_dry.min_cooling_suffix":`min`,"coil_dry.min_cooling_hint":`Ne sécher que si l'appareil a refroidi au moins aussi longtemps. Les courts cycles de refroidissement sont cumulés (1–240 min).`,"coil_dry.mode_label":`Mode de séchage`,"coil_dry.mode_fan_only":`fan_only (ventilateur seul)`,"coil_dry.mode_dry":`dry (déshumidification)`,"coil_dry.mode_dry_warning":`En mode dry, le compresseur continue de tourner et refroidit à nouveau les ailettes, ce qui va à l'encontre du séchage. À choisir uniquement si le mode dry de votre appareil privilégie le ventilateur.`,"coil_dry.fan_mode_label":`Vitesse du ventilateur pendant le séchage`,"coil_dry.fan_mode_keep":`Conserver la vitesse actuelle`,"coil_dry.fan_mode_hint":`Une vitesse plus élevée sèche plus vite mais fait plus de bruit. Les vitesses non signalées par l'appareil sont ignorées : il conserve alors la sienne.`,"coil_dry.drain_label":`Délai d'écoulement`,"coil_dry.drain_suffix":`min`,"coil_dry.drain_hint":`Laisser d'abord l'appareil éteint pour que les condensats s'écoulent, puis démarrer le ventilateur (0–15 min). Réduit l'humidité renvoyée dans la pièce.`,"mold.title":`Protection contre le risque de moisissure`,"mold.detection":`Détection de moisissure`,"mold.detection_desc":`Recevoir des notifications lorsque l'humidité indique un risque de moisissure`,"mold.threshold":`Seuil d'humidité (%)`,"mold.threshold_hint":`Alerter lorsque l'humidité de la pièce reste au-dessus de cette valeur`,"mold.insulation":`Isolation des murs`,"mold.insulation_hint":`Sert à estimer la température du point le plus froid des murs extérieurs (angles, embrasures de fenêtres). En cas de doute, gardez Standard. Nécessite une température extérieure.`,"mold.insulation_poor":`Bâtiment ancien non isolé`,"mold.insulation_standard":`Standard`,"mold.insulation_good":`Bien isolé (neuf ou rénové)`,"mold.sustained":`Durée écoulée (minutes)`,"mold.sustained_hint":`Alerter uniquement quand le risque persiste aussi longtemps`,"mold.prevention":`Prévention de la moisissure`,"mold.prevention_desc":`Augmenter automatiquement la température pour réduire le risque de moisissure`,"mold.intensity":`Intensité`,"mold.intensity_light":`Léger (+{delta}{unit})`,"mold.intensity_medium":`Moyen (+{delta}{unit})`,"mold.intensity_strong":`Fort (+{delta}{unit})`,"mold.intensity_hint":`L'air plus chaud réduit l'humidité de surface sur les murs froids. Léger suffit généralement pour un risque modéré, Fort peut abaisser l'humidité de surface jusqu'à 8-10% — mais consomme nettement plus d'énergie.`,"card.mold_warning":`Risque de moisissure`,"card.mold_critical":`Danger de moisissure !`,"card.mold_prevention":`Prévention de la moisissure +{delta}{unit}`,"room.mold_surface_rh":`Humidité de surface estimée : {value}%`,"room.mold_surface_temp":`mur {value}{unit}`,"settings.intro.general":`Paramètres d'affichage et de contrôle de base.`,"settings.intro.sensors":`Configurez les capteurs extérieurs et les données météo pour un contrôle climatique précis.`,"settings.intro.control":`Choisissez comment RoomMind contrôle vos appareils climatiques et définissez les priorités et seuils.`,"settings.intro.presence":`Réduisez automatiquement la température lorsqu'aucun occupant n'est présent.`,"settings.intro.vacation":`Réglez toutes les pièces à une température réduite pendant votre absence.`,"settings.intro.valve":`Déplacez périodiquement les vannes TRV inactives pour éviter le blocage ou la calcification.`,"settings.intro.compressor":`Gérez les groupes d'unités intérieures qui partagent un compresseur extérieur ou une source de chauffage centrale. Vous pouvez assigner un dispositif maître (chaudière, unité extérieure) pour l'allumer/éteindre automatiquement selon la demande des pièces. La protection contre les courts cycles évite les commutations rapides qui peuvent endommager l'équipement.`,"settings.intro.mold":`Surveillez l'humidité et réduisez automatiquement le risque de moisissure.`,"settings.intro.notifications":`Configurez qui reçoit les alertes et comment.`,"settings.intro.learning":`Gérez l'entraînement du modèle thermique et accélérez le réapprentissage après des changements.`,"settings.intro.reset":`Effacez les données du modèle thermique appris. Le modèle recommencera à apprendre à partir de zéro.`,"notifications.title":`Notifications`,"notifications.enabled":`Activer les notifications`,"notifications.enabled_hint":`Lorsqu'elles sont désactivées, aucune notification n'est envoyée — ni aux appareils, ni à la barre latérale HA.`,"notifications.desc":`Choisissez quels appareils reçoivent les alertes. Sans cibles, les alertes apparaissent dans la barre latérale HA.`,"notifications.add_target_label":`Ajouter un appareil de notification`,"notifications.add_target_hint":`Saisissez l'ID d'entité si votre appareil n'est pas répertorié (ex. notify.mobile_app_...). Vous pouvez le trouver sous Paramètres → Appareils → votre téléphone → entité de notification.`,"notifications.target_unnamed":`Appareil sans nom`,"notifications.target_person":`Personne`,"notifications.target_when_always":`Toujours`,"notifications.target_when_home":`Seulement lorsqu'à la maison`,"notifications.cooldown":`Temps de pause entre les notifications (minutes)`,"notifications.cooldown_hint":`Temps minimum entre des alertes répétées par pièce`,"notifications.mold_prevention_notify":`Notifier lorsque la prévention de moisissure s'active`,"notifications.mold_prevention_notify_hint":`Envoyer également une notification lorsque la prévention s'active (température augmentée)`,"room.section.heat_source":`Orchestration de la source de chaleur`,"heat_source.toggle":`Sélection intelligente de la source`,"heat_source.toggle_hint":`Lorsque cette pièce possède à la fois des thermostats de radiateur et une climatisation/pompe à chaleur, RoomMind oriente intelligemment la demande de chauffage vers l'appareil le plus efficace en fonction de l'écart de température et des conditions extérieures.`,"heat_source.primary_delta":`Seuil d'activation de la chaudière`,"heat_source.primary_delta_hint":`Activez la source principale uniquement lorsque l'écart de température dépasse cette valeur. En dessous de ce seuil, seule la source secondaire rapide est utilisée.`,"heat_source.primary_delta_suffix":`°C`,"heat_source.outdoor_threshold":`Seuil de préférence extérieur`,"heat_source.outdoor_threshold_hint":`Au-dessus de cette température extérieure, privilégier la climatisation/pompe à chaleur (efficacité supérieure). En dessous, privilégier la chaudière à gaz/radiateur.`,"heat_source.outdoor_threshold_suffix":`°C`,"heat_source.ac_min_outdoor":`Température extérieure min. pour la climatisation`,"heat_source.ac_min_outdoor_hint":`Désactiver complètement la climatisation en dessous de cette température pour protéger le matériel de la pompe à chaleur.`,"heat_source.ac_min_outdoor_suffix":`°C`,"heat_source.summary_disabled":`La sélection intelligente de la source est désactivée`,"devices.valve_closing_entity_hint":`Maintient la vanne à l'ouverture réglée, quoi que veuille la régulation de la tête. Rempli automatiquement si l'appareil en a une.`,"room.section.thermostat":`Thermostat`,"thermostat.info":`Tournez le cadran pour maintenir une température jusqu'au prochain changement de planning. Les boutons de mode et de préréglage agissent comme sur un thermostat mural.`,"thermostat.not_available":`L'entité thermostat de la pièce n'est pas encore disponible. Elle apparaît une fois la pièce enregistrée.`,"thermostat.load_failed":`La carte thermostat n'a pas pu être chargée.`,"room.thermostat_toggle":`Afficher le thermostat`,"room.thermostat_hint":`Affiche un cadran de thermostat pour modifier directement la température de cette pièce.`,"schedule_editor.title_new":`Nouveau planning`,"schedule_editor.title_edit":`Modifier le planning`,"schedule_editor.create":`Créer un planning`,"schedule_editor.edit":`Modifier le planning`,"schedule_editor.read_only":`Ce planning est défini en YAML et ne peut pas être modifié ici. Modifiez-le dans la configuration ou créez un nouveau planning.`,"schedule_editor.name":`Nom`,"schedule_editor.no_blocks":`Aucun créneau ce jour-là : la température éco s'applique toute la journée.`,"schedule_editor.add_block":`Ajouter un créneau`,"schedule_editor.remove_block":`Supprimer le créneau`,"schedule_editor.copy_weekdays":`Copier lun–ven`,"schedule_editor.copy_all":`Copier sur tous les jours`,"schedule_editor.hint":`Pendant un créneau, la pièce vise la température du créneau, ou le confort si le champ est vide. En dehors, l'éco s'applique. Une fin à 00:00 signifie minuit.`,"schedule_editor.hint_auto":`Pendant un créneau, la pièce reste entre ses températures de chauffage et de refroidissement (vide = confort). En dehors, l'éco s'applique. Une fin à 00:00 signifie minuit.`,"schedule_editor.cancel":`Annuler`,"schedule_editor.save":`Enregistrer`,"schedule_editor.comfort_placeholder":`confort`,"schedule_editor.from":`De`,"schedule_editor.to":`À`,"schedule_editor.heat":`Chauffage`,"schedule_editor.cool":`Refroid.`,"schedule_editor.temperature":`Température`,"schedule_editor.err_time":`Veuillez saisir une heure valide.`,"schedule_editor.err_order":`Un créneau doit se terminer après son début.`,"schedule_editor.err_overlap":`Les créneaux d'un même jour ne doivent pas se chevaucher.`,"schedule_editor.err_temp":`Veuillez saisir une température valide.`,"schedule_editor.err_band":`La température de refroidissement ne doit pas être inférieure à celle de chauffage.`,"schedule_editor.err_entity":`Le planning a été créé, mais son entité est introuvable. Ajoutez-le depuis la liste.`,"schedule_editor.day_short.monday":`Lun`,"schedule_editor.day_short.tuesday":`Mar`,"schedule_editor.day_short.wednesday":`Mer`,"schedule_editor.day_short.thursday":`Jeu`,"schedule_editor.day_short.friday":`Ven`,"schedule_editor.day_short.saturday":`Sam`,"schedule_editor.day_short.sunday":`Dim`,"compressor.release_title":`Autorisation de chauffe (chaudière / fioul)`,"compressor.release_entity":`Entité d'autorisation`,"compressor.release_entity_hint":`Facultatif. Un input_boolean ou interrupteur qui autorise le brûleur. RoomMind l'active quand assez de pièces du groupe demandent de la chaleur et respecte les durées minimales ci-dessus.`,"compressor.release_on":`Autorisation active`,"compressor.release_off":`Autorisation inactive`,"compressor.release_demand":`{count} pièces demandent de la chaleur (pondéré {weighted})`,"compressor.release_min_demand":`Pièces nécessaires`,"compressor.release_min_demand_hint":`Nombre de pièces qui doivent demander de la chaleur avant le démarrage du brûleur. Une fois lancé, il reste actif tant qu'une pièce chauffe.`,"compressor.release_smart":`Autorisation intelligente`,"compressor.release_smart_hint":`Pondère chaque pièce selon la chaleur demandée par son modèle appris (100 % compte pleinement, 10 % peu), pour des cycles moins nombreux et plus longs. Une pièce très en dessous de sa consigne ou qui attend trop longtemps autorise seule.`,"compressor.release_urgent_delta":`Urgent sous la consigne`,"compressor.release_urgent_delta_hint":`Une pièce aussi loin sous sa consigne autorise immédiatement le brûleur.`,"compressor.release_max_wait":`Attente maximale`,"compressor.release_max_wait_hint":`Une pièce qui demande de la chaleur depuis ce délai autorise le brûleur même si les autres ne suivent pas.`,"compressor.release_reason.no_demand":`aucune demande`,"compressor.release_reason.running":`actif tant que des pièces chauffent`,"compressor.release_reason.demand_count":`assez de pièces demandent`,"compressor.release_reason.weighted_demand":`demande pondérée suffisante`,"compressor.release_reason.urgent":`une pièce est très sous la consigne`,"compressor.release_reason.max_wait":`une pièce a trop attendu`,"compressor.release_reason.collecting_demand":`collecte de la demande`,"compressor.release_reason.min_run":`durée minimale de marche`,"compressor.release_reason.min_off":`durée minimale d'arrêt`,"thermostat.writes_schedule":`Le thermostat modifie le planning`,"thermostat.writes_schedule_hint":`Tourner le cadran pendant un créneau règle la température de jour du planning actif pour toute la semaine ; en dehors, la température de nuit. Désactivé : le changement ne vaut que jusqu'au prochain changement de planning.`,"schedule_editor.copy_hint":`Ce planning est défini en YAML et ne peut pas être modifié ici. L'enregistrement le reprend comme nouveau planning modifiable qui le remplace dans cette pièce.`,"schedule_editor.day_temp":`Température de jour`,"schedule_editor.night_temp":`Température de nuit`,"schedule_editor.day_night_hint":`Le jour s'applique dans les créneaux (règle tous les créneaux), la nuit en dehors (température éco de la pièce).`,"compressor.boiler_title":`Température chaudière (facultatif)`,"compressor.boiler_temp_sensor":`Capteur température chaudière / départ`,"compressor.boiler_temp_sensor_hint":`Avec la température de la chaudière, RoomMind apprend sa vitesse de chauffe et de refroidissement. Une chaudière encore chaude est autorisée pour toute pièce afin d'utiliser sa chaleur, et le mode intelligent démarre une chaudière froide plus tôt selon son temps de chauffe.`,"compressor.boiler_usable_temp":`Chaudière chaude à partir de`,"compressor.boiler_usable_temp_hint":`Température de l'eau à partir de laquelle les radiateurs chauffent utilement.`,"compressor.boiler_status":`Chaudière {temp} °C · chauffe {heat} K/min · refroidit {cool} K/min`,"compressor.boiler_learning":`apprentissage…`,"compressor.boiler_lead":`chaude dans ~{min} min`,"compressor.boiler_warm":`reste chaude ~{min} min`,"compressor.release_reason.residual_heat":`utilise la chaleur résiduelle`,"compressor.release_reason.preheat":`préchauffe la chaudière froide`,"panel.tab.heating":`Chauffage`,"heating.no_groups":`Créez d'abord un groupe sous Paramètres → Protection compresseur avec les thermostats des pièces chauffées par cette chaudière. Réglages, état et analyse apparaissent ensuite ici.`,"heating.unnamed":`Groupe sans nom`,"heating.unknown":`inconnu`,"heating.on":`Marche`,"heating.off":`Arrêt`,"heating.release":`Autorisation`,"heating.demand":`Demande de chaleur`,"heating.demand_value":`{count} pièces · pondéré {weighted}`,"heating.boiler_temp":`Température chaudière`,"heating.burner":`Brûleur`,"heating.pump":`Circulateur`,"heating.dhw":`Eau chaude`,"heating.learned":`Comportement appris de la chaudière`,"heating.heat_rate":`Chauffe`,"heating.cool_rate":`Refroidit`,"heating.reset_learning":`Réinitialiser l'apprentissage`,"heating.reset_confirm":`Oublier ce que RoomMind a appris sur cette chaudière ?`,"heating.learned_hint":`Appris de la température de la chaudière : chauffe pendant que le brûleur fonctionne (ou l'autorisation), refroidissement à l'arrêt. En pause pendant la production d'eau chaude.`,"heating.waiting_status":`En attente du premier cycle de régulation…`,"heating.status":`État`,"heating.range.24h":`24 h`,"heating.range.7d":`7 jours`,"heating.range.30d":`30 jours`,"heating.kpi_starts":`Démarrages {what}`,"heating.kpi_avg_run":`Ø {min} min par cycle`,"heating.kpi_runtime":`Durée {what}`,"heating.kpi_release_time":`Autorisé`,"heating.kpi_oil":`Fioul`,"heating.kpi_oil_estimated":`estimé d'après la durée du brûleur`,"heating.kpi_pump":`Durée circulateur`,"heating.kpi_dhw":`Eau chaude`,"heating.kpi_dhw_count":`{count} charges`,"heating.kpi_boiler":`Ø chaudière`,"heating.kpi_boiler_max":`max {max} °C`,"heating.reasons":`Pourquoi l'autorisation était active ou non`,"heating.oil_hint":`Pour la consommation, indiquez un compteur de fioul, ou le brûleur et le débit du gicleur (L/h) ci-dessous.`,"heating.analysis":`Analyse`,"heating.settings":`Réglages chaudière`,"heating.settings_intro":`Tout ce que RoomMind doit savoir sur cette chaudière. Seule l'entité d'autorisation est requise ; chaque entité supplémentaire améliore l'apprentissage et l'analyse. L'eau chaude n'est pas régulée, seulement prise en compte.`,"heating.section_release":`Autorisation`,"heating.section_boiler":`Chaudière & circuit`,"heating.section_oil":`Consommation de fioul`,"heating.burner_entity":`Brûleur en marche`,"heating.burner_entity_hint":`Facultatif. Indique quand le brûleur fonctionne réellement (capteur binaire, interrupteur ou puissance > 0). Améliore l'apprentissage et compte les démarrages.`,"heating.pump_entity":`Circulateur de chauffage`,"heating.pump_entity_hint":`Facultatif. Durée du circulateur dans l'analyse.`,"heating.dhw_entity":`Production d'eau chaude`,"heating.dhw_entity_hint":`Facultatif. Pendant la production d'eau chaude la température n'est pas utilisée pour l'apprentissage ; charges et durée figurent dans l'analyse.`,"heating.oil_sensor":`Compteur de fioul`,"heating.oil_sensor_hint":`Facultatif. Un capteur comptant les litres (total). Les hausses sont additionnées, un remplissage ou une remise à zéro ne compte pas.`,"heating.oil_nozzle":`Débit du gicleur`,"heating.oil_nozzle_hint":`Sans compteur : litres par heure du gicleur (voir plaque, ex. 2,0 L/h). Avec l'entité brûleur, RoomMind estime la consommation.`,"heating.members_hint":`Pièces/thermostats de cette chaudière et durées minimales : Paramètres → Protection compresseur.`,"compressor.release_moved":`Aucune autorisation chaudière`,"compressor.release_open_tab":`Ouvrir l'onglet Chauffage`,"quick.day":`Jour`,"quick.day_hint":`Consigne sans planning (confort)`,"quick.day_hint_schedule":`Dans les créneaux, toute la semaine (aussi via le thermostat)`,"quick.day_hint_yaml":`Planning YAML : seule la valeur confort change`,"quick.take_over":`Reprendre le planning pour que la température de jour et le thermostat puissent le modifier`,"quick.night":`Nuit`,"quick.night_hint":`En dehors des créneaux (éco)`,"quick.away":`Absent`,"quick.away_hint":`Quand tout le monde est absent`,"quick.away_hint_same":`Quand tout le monde est absent – comme la nuit`,"quick.away_reset":`Utiliser la température de nuit`,"quick.arrival":`Retour prévu ~{time}`,"quick.arrival_heating":`Préchauffe – retour prévu ~{time}`,"presence.preheat_label":`Chaud au retour (apprentissage)`,"presence.preheat_hint":`Apprend par jour de la semaine quand les personnes rentrent. Quand tout le monde est absent, la pièce préchauffe pour atteindre sa température au retour prévu, selon son temps de chauffe appris.`,"presence.preheat_minutes":`Temps de préchauffe sans modèle appris`,"presence.preheat_minutes_hint":`Utilisé tant que le modèle thermique de la pièce n'est pas entraîné ; ensuite chaque pièce utilise son propre temps appris.`,"presence.learned_title":`Heures de retour apprises`,"presence.learned_count":`{count} retours`,"presence.learned_next":`attendu aujourd'hui ~{time}`,"presence.learned_hint":`Retour typique par jour (médiane des 8 dernières semaines). Une prévision nécessite des retours sur au moins 3 jours différents ; les absences de moins de 20 minutes sont ignorées.`},it:{"panel.title":`RoomMind`,"panel.subtitle":`Gestione climatizzazione`,"panel.tab.rooms":`Stanze`,"panel.edit":`Modifica stanza`,"panel.tab.settings":`Impostazioni`,"panel.loading":`Caricamento...`,"panel.no_areas":`Nessuna area configurata in Home Assistant.`,"panel.no_areas_hint":`Aggiungi delle aree nelle impostazioni di HA per iniziare.`,"badge.beta":`Beta`,"badge.beta_hint":`Questa funzione è in beta e potrebbe cambiare o essere ristrutturata nei prossimi aggiornamenti.`,"common.learn_more":`Scopri di più`,"panel.stat.rooms":`Stanze`,"panel.stat.heating":`Riscaldamento`,"panel.stat.cooling":`Raffrescamento`,"panel.stat.vacation":`Vacanza`,"panel.stat.away":`Fuori casa`,"panel.stat.mold":`Muffa`,"panel.hide_room":`Nascondi`,"panel.unhide":`Mostra`,"panel.hidden_rooms":`Stanze nascoste`,"panel.floor_other":`Altro`,"panel.reorder":`Riordina stanze`,"panel.reorder_done":`Fatto`,"room.back":`Torna alle stanze`,"room.section.climate_mode":`Modalità climatizzazione`,"room.section.schedule":`Programma e temperature`,"room.section.control_mode":`Modalità di controllo`,"room.section.devices":`Dispositivi`,"room.section.sensors":`Sensori`,"room.section.windows":`Sensori finestre`,"room.control_mode.full_control":`Controllo completo`,"room.control_mode.managed":`Gestito`,"room.control_mode.external_sensor":`Sensore esterno: {sensor}`,"room.control_mode.no_sensor":`Nessun sensore di temperatura esterno assegnato`,"room.control_mode.mpc_active":`MPC attivo`,"room.control_mode.mpc_learning":`Apprendimento`,"room.control_mode.device_setpoint":`Setpoint del dispositivo: {temp}`,"room.control_mode.power":`Potenza: {power}%`,"room.control_mode.full_control_info":`RoomMind ha il controllo completo dei tuoi dispositivi di climatizzazione. Un sensore di temperatura esterno fornisce la temperatura reale della stanza, permettendo il calcolo proporzionale del setpoint. Il setpoint del dispositivo viene regolato dinamicamente in base alla potenza calcolata dall'MPC. Il modello termico (EKF) apprende il comportamento della stanza per ottimizzare comfort ed efficienza energetica.`,"room.control_mode.managed_info":`RoomMind imposta la temperatura obiettivo sul dispositivo (da programma, forzatura o impostazioni vacanza), ma il dispositivo si autoregola usando il proprio sensore interno. Nessuna spinta proporzionale, nessun apprendimento del modello termico, nessuna ottimizzazione MPC. Per un controllo più preciso, assegna un sensore di temperatura esterno nella sezione Dispositivi.`,"room.delete":`Elimina stanza`,"room.deleting":`Eliminazione...`,"room.saving":`Salvataggio...`,"room.saved":`Salvato`,"room.error_saving":`Errore nel salvataggio`,"room.confirm_delete":`Rimuovere la configurazione RoomMind di "{name}"?`,"room.error_save_fallback":`Salvataggio della configurazione non riuscito`,"room.error_delete_fallback":`Eliminazione della configurazione non riuscita`,"room.climate_control_toggle":`Controllo climatizzazione`,"room.climate_control_hint":`Se disattivato, RoomMind smette di controllare i dispositivi di questa stanza. I dispositivi mantengono le impostazioni correnti e potrebbero continuare a riscaldare o raffrescare per conto proprio. RoomMind non li spegnerà.`,"room.outdoor_toggle":`Area esterna`,"room.outdoor_hint":`Disattiva controllo climatizzazione, rilevamento muffa e addestramento del modello. Il monitoraggio dei sensori resta attivo.`,"room.alias.placeholder":`Nome visualizzato personalizzato`,"room.alias.clear":`Ripristina il nome dell'area`,"override.label":`Forzatura temporanea`,"override.comfort":`Comfort`,"override.eco":`Eco`,"override.custom":`Personalizzata`,"override.target":`Obiettivo:`,"override.heat_to":`Riscalda fino a:`,"override.cool_above":`Raffresca sopra:`,"override.invalid_band":`L'obiettivo di raffrescamento deve essere uguale o superiore a quello di riscaldamento`,"override.activate_for":`Attiva per:`,"override.error_set":`Impostazione della forzatura non riuscita`,"override.error_clear":`Annullamento della forzatura non riuscito`,"hero.target":`Obiettivo`,"hero.override":`Forzatura`,"hero.remaining":`{time} rimanenti`,"hero.humidity":`{value}% di umidità`,"hero.device_setpoint":`Dispositivo impostato a {value}{unit}`,"hero.heat_source_primary":`Riscaldamento: TRV`,"hero.heat_source_secondary":`Riscaldamento: AC`,"hero.heat_source_both":`Riscaldamento: TRV + AC`,"hero.permanent":`Permanente`,"hero.waiting":`In attesa dei dati dai sensori...`,"hero.not_configured":`Non ancora configurata`,"hero.mpc_learning_paused":`Apprendimento MPC in pausa`,"hero.mpc_learning_paused.outdoor_unavailable":`RoomMind ha bisogno di una temperatura esterna per apprendere il modello termico di questa stanza. Il sensore esterno configurato non è disponibile e non è impostata alcuna entità meteo come alternativa. Configurane una nelle Impostazioni.`,"hero.compressor_protection_min_off":`Protezione compressore: attesa tempo minimo di spegnimento`,"hero.compressor_protection_min_off_left":`Protezione compressore: tempo minimo di spegnimento, ancora {minutes} min`,"hero.compressor_protection_min_run":`Protezione compressore: tempo minimo di funzionamento attivo`,"hero.compressor_protection_min_run_left":`Protezione compressore: tempo minimo di funzionamento, ancora {minutes} min`,"hero.compressor_protection_info":`Questa stanza condivide un compressore esterno con altre stanze. Per evitare cicli troppo brevi, il gruppo compressore condiviso impone un tempo minimo di funzionamento e un tempo minimo di spegnimento prima che questo dispositivo possa commutare di nuovo.`,"hero.coil_dry":`Asciugatura ({minutes} min)`,"hero.coil_dry_drain":`Scarico ({minutes} min)`,"hero.coil_dry_info":`Il condizionatore sta eseguendo il ciclo di asciugatura dell'evaporatore e poi si spegne. Una richiesta di raffreddamento lo annulla subito.`,"card.target":`Obiettivo`,"card.waiting":`In attesa di dati...`,"card.humidity":`{value}% di umidità`,"card.thermostat":`termostato`,"card.thermostats":`termostati`,"card.ac":`AC`,"card.acs":`AC`,"card.climate_device":`dispositivo di climatizzazione`,"card.climate_devices":`dispositivi di climatizzazione`,"card.temp_sensor":`sensore temp.`,"card.temp_sensors":`sensori temp.`,"card.no_climate":`Nessun dispositivo di climatizzazione`,"card.outdoor":`Esterno`,"card.tap_configure":`Tocca per configurare`,"card.mpc_active":`MPC attivo`,"card.mpc_learning":`MPC in apprendimento`,"card.compressor_min_run":`Funz. minimo {minutes} min`,"card.compressor_min_off":`Pausa minima {minutes} min`,"card.not_controlled":`Non controllata da RoomMind`,"mode.auto":`Auto`,"mode.auto_desc":`Riscalda e raffresca automaticamente in base alla temperatura obiettivo`,"mode.heat_only":`Solo riscaldamento`,"mode.heat_only_desc":`Solo riscaldamento. Con termostati nella stanza, gli AC restano spenti, salvo con la scelta intelligente della fonte attiva`,"mode.cool_only":`Solo raffrescamento`,"mode.cool_only_desc":`Usa solo gli AC, i termostati restano spenti`,"mode.heating":`Riscaldamento`,"mode.cooling":`Raffrescamento`,"mode.idle":`Standby`,"schedule.add_schedule":`Aggiungi programma`,"schedule.select_schedule":`Seleziona helper programma`,"schedule.create_helper_hint":`Crea un nuovo helper programma nelle impostazioni di HA`,"schedule.selector_label":`Entità selettore del programma`,"schedule.selector_value_boolean":`Attuale: {value}`,"schedule.selector_value_number":`Valore attuale: {value}`,"schedule.selector_warning":`Più programmi ma nessun selettore impostato. Verrà usato solo il primo.`,"schedule.off_action_label":`Azione quando il programma è spento`,"schedule.off_action_eco":`Usa la temperatura eco`,"schedule.off_action_off":`Spegni i dispositivi`,"schedule.state_active":`Attivo`,"schedule.state_inactive":`Non attivo`,"schedule.state_unreachable":`Non raggiungibile`,"schedule.no_schedules":`Nessun programma configurato`,"schedule.done":`Fatto`,"schedule.view_comfort":`Comfort: {temp}{unit}`,"schedule.view_eco":`Eco: {temp}{unit}`,"schedule.view_selector":`Programma attivo selezionato da: {name}`,"schedule.view_selector_prefix":`Programma attivo selezionato da:`,"schedule.help_header":`Come funzionano i programmi?`,"schedule.help_temps_title":`Come viene determinata la temperatura obiettivo?`,"schedule.help_temps":`La temperatura obiettivo segue questa catena di priorità:`,"schedule.help_temps_1":`<strong>Forzatura manuale</strong> – Una forzatura temporanea boost/eco/personalizzata ha sempre la priorità massima.`,"schedule.help_temps_2":`<strong>Temperatura del blocco</strong> – Se il blocco di programma attivo ha un valore <code>temperature</code> nei suoi dati, viene usato quel valore.`,"schedule.help_temps_3":`<strong>Temperatura comfort</strong> – Se il programma è "acceso" ma il blocco non ha una temperatura, viene usata la temperatura comfort di riserva indicata sotto.`,"schedule.help_temps_4":`<strong>Temperatura eco</strong> – Quando il programma è "spento" (fuori da tutti i blocchi orari), viene usata la temperatura eco.`,"schedule.help_block_title":`Impostare la temperatura per singolo blocco orario`,"schedule.help_block":`Puoi impostare una temperatura specifica per ogni blocco orario aggiungendo un valore <code>temperature</code> nella configurazione YAML del programma:`,"schedule.help_block_note":`Se un blocco non ha il dato <code>temperature</code>, viene usata al suo posto la temperatura comfort di riserva.`,"schedule.help_split_title":`Obiettivi separati di riscaldamento/raffrescamento per blocco`,"schedule.help_split":`Per le stanze in modalità auto puoi impostare obiettivi separati di riscaldamento e raffrescamento per ogni blocco orario usando <code>heat_temperature</code> e <code>cool_temperature</code>:`,"schedule.help_split_note":`Se ne è impostato solo uno, l'altro ricade sulla temperatura comfort della stanza. Quando presenti, queste chiavi hanno la priorità su <code>temperature</code>.`,"schedule.help_multi_title":`Programmi multipli`,"schedule.help_multi":`Puoi aggiungere più programmi e passare dall'uno all'altro usando un'<strong>entità selettore</strong>. Può essere un <code>input_boolean</code> (alterna tra programma 1 e 2) oppure un <code>input_number</code> (seleziona per numero). Senza entità selettore viene usato solo il primo programma.`,"schedule.column_comfort":`Comfort`,"schedule.column_eco":`Eco`,"schedule.row_heat":`Caldo`,"schedule.row_cool":`Freddo`,"schedule.view_heat":`Caldo: {comfort} / {eco}{unit}`,"schedule.view_cool":`Freddo: {comfort} / {eco}{unit}`,"schedule.comfort_hint_auto":`Comfort: obiettivo quando il programma è acceso. Eco: obiettivo quando il programma è spento. Le righe impostano l'obiettivo per riscaldamento e raffrescamento.`,"schedule.comfort_label":`Temperatura comfort di riserva`,"schedule.eco_label":`Temperatura eco`,"schedule.comfort_hint":`Usata quando il programma è "acceso" ma nel blocco non è impostata alcuna temperatura`,"schedule.from_schedule":`{temp}{unit} dal programma`,"schedule.from_schedule_split":`{heat}{unit} / {cool}{unit} dal programma`,"schedule.fallback":`{temp}{unit} (di riserva)`,"schedule.block_temp_rejected":`Valori fuori dall'intervallo valido {min}–{max}{unit}: {values}. Al loro posto viene usato l'obiettivo comfort — controlla se c'è un errore di battitura nell'helper del programma.`,"schedule.eco_detail":`{temp}{unit} (eco)`,"devices.climate_entities":`Entità di climatizzazione`,"devices.temp_sensors":`Sensori di temperatura`,"devices.humidity_sensors":`Sensori di umidità`,"devices.no_climate":`Nessuna entità di climatizzazione trovata in quest'area.`,"devices.no_temp_sensors":`Nessun sensore di temperatura trovato in quest'area.`,"devices.no_humidity_sensors":`Nessun sensore di umidità trovato in quest'area.`,"devices.occupancy_sensors":`Sensori di occupazione`,"devices.no_occupancy_sensors":`Nessun sensore di occupazione trovato in quest'area`,"devices.occupancy_sensor_hint":`Migliora la precisione del modello termico tenendo traccia dell'occupazione della stanza`,"devices.occupancy_eco":`Eco quando la stanza è vuota`,"devices.occupancy_eco_hint":`Quando tutti i sensori di occupazione segnalano la stanza vuota più a lungo del ritardo, la stanza passa alla temperatura eco. Appena viene rilevato di nuovo qualcuno, segue il suo programma. Una stanza vuota resta in eco e riscalda al comfort solo quando c'è qualcuno, quindi impiega un po' a scaldarsi. Forzatura temporanea, modalità vacanza e rilevamento della presenza hanno la precedenza.`,"devices.occupancy_eco_delay":`Ritardo prima di eco`,"devices.occupancy_eco_view":`Eco dopo {minutes} min senza occupazione`,"devices.window_sensors":`Sensori finestre / porte`,"devices.no_window_sensors":`Nessun sensore finestra/porta trovato in quest'area.`,"devices.window_open_delay":`Ritardo prima della pausa`,"devices.window_close_delay":`Ritardo prima della ripresa`,"devices.add_entity":`Aggiungi entità`,"devices.done":`Fatto`,"devices.other_area":`Altra area`,"devices.type_thermostat":`Termostato`,"devices.type_ac":`Dispositivo di climatizzazione`,"devices.type_label":`Tipo`,"devices.select_to_configure":`Seleziona un dispositivo da configurare`,"devices.heating_system_type":`Tipo di impianto di riscaldamento`,"devices.heating_system_type_info":`Quando il riscaldamento si ferma, i radiatori e soprattutto gli impianti a pavimento continuano a cedere il calore accumulato. RoomMind tiene conto di questo calore residuo per evitare di superare l'obiettivo e per migliorare la precisione del modello. Le stanze con impianto a pavimento ricevono anche tempi minimi di funzionamento più lunghi.`,"devices.system_type_none":`Standard (nessun calore residuo)`,"devices.system_type_radiator":`Radiatore`,"devices.system_type_underfloor":`Riscaldamento a pavimento`,"devices.underfloor_delay_hint":`Il riscaldamento a pavimento ha tempi di riavvio lunghi. Si consiglia un ritardo per finestra aperta di almeno 5 minuti, per evitare spegnimenti inutili.`,"devices.heating_system_type_boost_hint":`Suggerimento: se l'impianto di riscaldamento è cambiato, puoi accelerare il riapprendimento dalle Impostazioni.`,"devices.idle_action":`Quando è inattivo`,"devices.idle_action_off":`Spegni`,"devices.idle_action_fan_only":`Solo ventola`,"devices.idle_action_setback":`Riduzione`,"devices.idle_action_low":`Setpoint minimo (tieni sveglio)`,"devices.idle_action_low_hint":`Abbassa il setpoint al minimo del dispositivo invece di inviare lo spegnimento. Evita che le valvole TRV che vanno in letargo da spente perdano i comandi successivi.`,"devices.idle_fan_mode":`Velocità ventola`,"devices.idle_fan_mode_keep":`Non modificare`,"devices.setpoint_mode":`Modalità setpoint`,"devices.setpoint_mode_proportional":`Proporzionale (setpoint maggiorato)`,"devices.setpoint_mode_direct":`Diretta (regola il dispositivo)`,"devices.setpoint_offset":`Scostamento del setpoint`,"devices.setpoint_offset_hint":`Usalo se il sensore del dispositivo misura una temperatura diversa dal sensore della stanza. Lo scostamento viene sommato all'obiettivo della stanza prima di inviarlo al dispositivo (riscaldamento e raffrescamento). Il dispositivo misura più freddo della stanza: valore negativo. Misura più caldo: valore positivo. Esempio: vuoi 24°, ma durante il raffrescamento il dispositivo crede che la stanza sia 2° più fredda di quanto sia e si ferma troppo presto. Inserisci -2: il dispositivo riceve 22° e continua a funzionare finché la stanza non è davvero a 24°. 0 = nessuno scostamento.`,"devices.setpoint_mode_hint":`Diretta invia al dispositivo l'obiettivo reale della stanza — ideale per termostati e stufe che si autoregolano. Proporzionale invia un setpoint maggiorato verso il max_temp del dispositivo — ideale per le valvole termostatiche (TRV).`,"devices.coil_dry":`Asciugatura evaporatore`,"devices.coil_dry_inherit":`Usa impostazione globale`,"devices.coil_dry_on":`Sempre attiva`,"devices.coil_dry_off":`Sempre disattivata`,"devices.coil_dry_minutes":`Durata asciugatura (0 = globale: {minutes} min)`,"devices.coil_dry_mode":`Modalità di asciugatura`,"devices.coil_dry_mode_inherit":`Globale ({value})`,"devices.coil_dry_fan_mode":`Velocità ventola durante l'asciugatura`,"devices.coil_dry_fan_mode_inherit":`Globale ({value})`,"devices.coil_dry_fan_mode_keep":`Mantieni la velocità corrente`,"devices.coil_dry_summary":`Asciugatura`,"devices.coil_dry_global_off_hint":`L'asciugatura dell'evaporatore è disattivata a livello globale, quindi per questo dispositivo non viene eseguita. Attivala nelle impostazioni, oppure imposta questo dispositivo su "Sempre attiva".`,"devices.valve_protection_excluded":`Escluso dalla protezione valvole`,"devices.valve_protection_exclude_hint":`Questa entità non verrà azionata dalla protezione valvole (es. entità caldaia virtuali)`,"devices.valve_direct_control":`Controllo diretto della valvola`,"devices.valve_opening_entity":`Grado di apertura della valvola`,"devices.valve_closing_entity":`Grado di chiusura della valvola`,"devices.valve_direct_control_hint":`Per le valvole termostatiche di cui Home Assistant può impostare l'apertura (p. es. SONOFF TRVZB: valve_opening_degree e valve_closing_degree, servono entrambe). RoomMind mantiene la valvola all'apertura di cui la stanza ha bisogno, p. es. 30 %, invece di aprirla del tutto: meno movimenti, più silenzio e un calore più uniforme. Svuota i campi o disattiva il controllo del clima e RoomMind le riporta entrambe al 100 %.`,"devices.valve_direct_control_toggle_hint":`Per le valvole termostatiche di cui Home Assistant può impostare l'apertura (p. es. SONOFF TRVZB). RoomMind mantiene la valvola all'apertura di cui la stanza ha bisogno, p. es. 30 %, invece di aprirla del tutto: meno movimenti, più silenzio e un calore più uniforme. Disattivato, o con il controllo del clima disattivato, la valvola torna alla regolazione della testina.`,"devices.valve_direct_badge":`Valvola diretta`,"devices.info.types_title":`Tipi di dispositivo`,"devices.info.types_body":`Termostato indica un termostato per radiatore / TRV. Dispositivo di climatizzazione indica un condizionatore, una pompa di calore o un'altra entità climate usata per raffrescare o riscaldare ad aria. Entrambi sono entità climate di Home Assistant; la differenza sta nel modo in cui RoomMind li controlla.`,"devices.info.control_title":`Come li controlla RoomMind`,"devices.info.control_body":`La modalità setpoint vale solo per i termostati nelle stanze a Controllo completo con un sensore di temperatura esterno. Usa Proporzionale quando vuoi che RoomMind piloti la resa del riscaldamento inviando setpoint maggiorati. Usa Diretta quando il dispositivo deve autoregolarsi attorno alla temperatura obiettivo reale.`,"devices.info.modes_title":`Comportamento a riposo`,"devices.info.modes_body":`Quando è inattivo vale solo per i Dispositivi di climatizzazione. Spegni toglie alimentazione al dispositivo. Solo ventola mantiene il flusso d'aria senza riscaldare né raffrescare. Riduzione mantiene attiva la modalità corrente ma sposta l'obiettivo di 2°C rispetto a quello della stanza. Questo scostamento è attualmente fisso. Con un sensore di temperatura esterno e un modello addestrato, il dispositivo viene spento dopo un'ora senza riscaldamento né raffrescamento, se RoomMind non prevede di averne bisogno nell'ora successiva. Per i Termostati, Minimo tiene la TRV attiva al suo setpoint minimo invece di spegnerla: utile per le TRV Zigbee a batteria che vanno in sospensione quando sono spente.`,"devices.info.heat_source_title":`Scelta intelligente della fonte`,"devices.info.heat_source_body":`Compare solo quando una stanza ha sia un termostato/TRV sia un Dispositivo di climatizzazione, oltre a un sensore di temperatura esterno. In quel caso RoomMind può scegliere quale fonte debba occuparsi del riscaldamento, in base allo scarto di temperatura e alle condizioni esterne.`,"hero.window_open":`Finestra aperta – in pausa`,"card.window_open":`Finestra aperta`,"room.section.covers":`Tapparelle e tende`,"covers.section_title":`Tapparelle e tende`,"covers.auto_control":`Controllo automatico tapparelle`,"covers.auto_control_hint":`RoomMind chiude le tapparelle quando si prevede che l'apporto solare surriscaldi la stanza.`,"covers.deploy_threshold":`Soglia di intervento`,"covers.deploy_threshold_hint":`Chiudi le tapparelle quando la temperatura prevista supera l'obiettivo di questo scarto.`,"covers.min_position":`Posizione minima di apertura`,"covers.min_position_hint":`Le tapparelle non si chiuderanno mai oltre questo valore (0 = chiusura totale consentita).`,"covers.override_minutes":`Durata della pausa dopo intervento manuale`,"covers.override_minutes_hint":`Per quanto tempo sospendere il controllo automatico dopo un movimento manuale della tapparella. Imposta 0 per nessuna pausa.`,"covers.no_covers":`Nessuna entità tapparella configurata.`,"covers.no_covers_in_area":`Nessuna entità tapparella trovata in quest'area.`,"covers.add_cover":`Aggiungi entità tapparella...`,"covers.shading_active":`Ombreggiamento attivo`,"covers.auto_paused":`Automatismo in pausa (intervento manuale)`,"covers.auto_paused_until":`Controllo automatico in pausa fino a`,"covers.resume_auto":`Riprendi il controllo automatico`,"covers.done":`Fatto`,"covers.night_close":`Chiudi di notte`,"covers.night_close_hint":`Chiude automaticamente le tapparelle al tramonto e le apre all'alba.`,"covers.night_close_active":`Chiusura notturna attiva`,"covers.schedule_group_title":`Programma`,"covers.solar_group_title":`Controllo solare`,"covers.schedule_section":`Programmi tapparelle`,"covers.schedule_section_hint":`Definisci finestre orarie per il controllo delle tapparelle usando gli helper programma di HA. In modalità Posizione forzata la posizione del programma prevale sulla logica solare/termica. In modalità Consenti protezione solare è RoomMind a decidere la posizione all'interno della finestra attiva.`,"covers.add_schedule":`Aggiungi programma tapparelle...`,"covers.schedule_mode_force":`Posizione forzata`,"covers.schedule_mode_gate":`Consenti protezione solare`,"covers.schedule_mode_gate_short":`Protezione solare`,"covers.schedule_position":`Posizione`,"covers.schedule_position_hint":`Posizione della tapparella quando questo programma è attivo (0% = tutta chiusa, 100% = tutta aperta).`,"covers.schedule_selector":`Entità selettore del programma`,"covers.schedule_selector_hint":`Scegli quale programma è attivo. input_boolean: off=#1, on=#2. input_number: il valore seleziona il numero del programma.`,"covers.schedule_selector_warning":`Più programmi configurati ma nessun selettore impostato. Verrà usato solo il primo programma.`,"covers.schedule_state_active":`Attivo`,"covers.schedule_state_inactive":`Non attivo`,"covers.schedule_state_unreachable":`Non raggiungibile`,"covers.schedule_active":`Programma attivo`,"covers.schedule_create_link":`Crea helper programma`,"covers.night_position":`Posizione notturna`,"covers.night_position_hint":`Posizione della tapparella quando la chiusura notturna è attiva (0% = tutta chiusa). Le tapparelle con una posizione minima individuale non scenderanno mai sotto quel valore.`,"covers.night_close_advanced":`Avanzate`,"covers.night_close_elevation":`Soglia di posizione del sole`,"covers.night_close_elevation_hint":`Quanto il sole deve trovarsi sotto o sopra l'orizzonte. 0° = esattamente al tramonto/all'alba. Negativo = più buio (es. -6° = crepuscolo, quando è già sensibilmente scuro). Positivo = ancora chiaro (es. 5° = sole ancora visibile sopra l'orizzonte).`,"covers.night_close_offset":`Scostamento temporale`,"covers.night_close_offset_hint":`Spostamento aggiuntivo rispetto alla soglia di posizione del sole. Positivo = chiudi più tardi (es. +20 = 20 min dopo il raggiungimento della soglia), negativo = chiudi prima.`,"covers.outdoor_min_temp":`Temperatura esterna minima`,"covers.outdoor_min_temp_hint":`Non chiudere le tapparelle per protezione solare al di sotto di questa temperatura esterna. Quando fa freddo l'apporto di calore del sole è il benvenuto.`,"covers.per_cover_title":`Impostazioni per singola tapparella`,"covers.per_cover_hint":`Imposta il punto cardinale verso cui è esposta ogni tapparella ed eventuali posizioni minime individuali.`,"covers.per_cover_min_short":`Min`,"covers.per_cover_min_position":`Posizione minima`,"covers.per_cover_min_position_hint":`Posizione minima individuale per ogni tapparella. Le tapparelle non si chiuderanno mai oltre questo valore. Utile quando le tapparelle sono fisicamente già del tutto chiuse a una posizione > 0%.`,"covers.snap_deploy":`Vai diretto alla posizione minima`,"covers.snap_deploy_hint":`Chiudi le tapparelle direttamente alla posizione minima invece di chiuderle gradualmente. Consigliato per i vetri tripli, dove le posizioni intermedie possono causare stress termico.`,"covers.info.selection_title":`Scelta delle tapparelle`,"covers.info.selection_body":`Seleziona le tapparelle di quest'area oppure aggiungi entità di altre aree. RoomMind ne segue la posizione e può controllarle automaticamente.`,"covers.info.schedule_title":`Controllo a programma`,"covers.info.schedule_body":`Usa gli helper programma di HA per definire gli orari in cui le tapparelle devono chiudersi (es. privacy la sera). L'attributo di posizione del programma determina quanto si chiudono. I programmi prevalgono su ogni altra logica automatica.`,"covers.info.solar_title":`Controllo solare/termico`,"covers.info.solar_body":`Quando il controllo automatico è attivo, RoomMind prevede se la radiazione solare surriscalderà la stanza e chiude le tapparelle in anticipo. Usa i dati termici appresi quando disponibili, altrimenti un valore prudenziale predefinito. La soglia di intervento stabilisce quanto superamento previsto serve prima che le tapparelle si chiudano.`,"covers.info.night_title":`Chiusura notturna`,"covers.info.night_body":`Chiude le tapparelle al tramonto e le riapre all'alba. Puoi impostare una posizione notturna personalizzata (es. 10% = quasi chiusa ma non del tutto).`,"covers.info.override_title":`Intervento manuale`,"covers.info.override_body":`Se muovi una tapparella a mano, RoomMind se ne accorge e sospende il controllo automatico per la durata configurata. Serve a non entrare in conflitto con l'utente.`,"covers.info.priority_title":`Ordine di priorità`,"covers.info.priority_body":`Intervento manuale > Programma > Chiusura notturna > Controllo solare/termico. Le regole a priorità più alta vincono sempre. Quando non si applica nessuna regola, le tapparelle restano aperte.`,"covers.info.entities_title":`Entità HA`,"covers.info.entities_body":`RoomMind crea due entità per stanza a uso esterno: switch.roommind_{area}_cover_auto (attiva/disattiva il controllo automatico delle tapparelle — utilizzabile in automazioni o dashboard) e binary_sensor.roommind_{area}_cover_paused (acceso quando è attivo un intervento manuale, es. dopo aver mosso una tapparella a mano).`,"covers.orientation_group_title":`Orientamento delle tapparelle`,"covers.orientation_hint":`Imposta il punto cardinale verso cui è esposta ogni tapparella. RoomMind ombreggia solo mentre il sole batte davvero su quel lato dell'edificio. Senza direzione, le tapparelle reagiscono al sole in generale e possono chiudersi già dall'alba, anche su una finestra a nord.`,"covers.orientation_none":`Qualsiasi direzione`,"covers.orientation_N":`N`,"covers.orientation_NE":`NE`,"covers.orientation_E":`E`,"covers.orientation_SE":`SE`,"covers.orientation_S":`S`,"covers.orientation_SW":`SO`,"covers.orientation_W":`O`,"covers.orientation_NW":`NO`,"covers.orientation_N_full":`Nord`,"covers.orientation_NE_full":`Nord-est`,"covers.orientation_E_full":`Est`,"covers.orientation_SE_full":`Sud-est`,"covers.orientation_S_full":`Sud`,"covers.orientation_SW_full":`Sud-ovest`,"covers.orientation_W_full":`Ovest`,"covers.orientation_NW_full":`Nord-ovest`,"settings.general_title":`Generali`,"settings.group_by_floor":`Raggruppa le stanze per piano`,"settings.climate_control_active":`Controllo climatizzazione attivo`,"settings.climate_control_hint":`Se disattivato, RoomMind continua a monitorare tutti i sensori e ad addestrare il modello, ma non invia alcun comando ai dispositivi di riscaldamento o raffrescamento. I dispositivi mantengono modalità e setpoint correnti e potrebbero continuare a riscaldare o raffrescare per conto proprio. RoomMind non li spegnerà.`,"settings.learning_title":`Addestramento del modello`,"settings.learning_hint":`In pausa, RoomMind smette di raccogliere nuovi dati di misura e di addestrare il modello termico. I dati del modello già acquisiti vengono conservati.`,"settings.learning_exceptions":`Eccezioni`,"settings.learning_room_paused":`stanza in pausa`,"settings.learning_rooms_paused":`stanze in pausa`,"settings.sensors_title":`Sensori e sorgenti dati`,"settings.control_title":`Controllo`,"settings.outdoor_sensor":`Temperatura esterna`,"settings.outdoor_sensor_label":`Sensore di temperatura esterna`,"settings.outdoor_current":`Attualmente {temp}{unit} all'esterno`,"settings.outdoor_waiting":`In attesa dei dati dal sensore...`,"settings.outdoor_humidity_sensor":`Umidità esterna`,"settings.outdoor_humidity_label":`Sensore di umidità esterna`,"settings.outdoor_humidity_current":`Attualmente {value}% all'esterno`,"settings.smart_control":`Controllo climatico intelligente`,"settings.smart_control_hint":`Configura i limiti di temperatura esterna per riscaldamento e raffrescamento.`,"settings.outdoor_cooling_min":`Temperatura esterna minima per il raffrescamento`,"settings.outdoor_cooling_min_hint":`L'AC resta spento quando la temperatura esterna è sotto questo valore. Una forzatura manuale ignora questo limite`,"settings.outdoor_heating_max":`Temperatura esterna massima per il riscaldamento`,"settings.outdoor_heating_max_hint":`Il riscaldamento resta spento quando la temperatura esterna supera questo valore. Una forzatura manuale ignora questo limite`,"settings.saving":`Salvataggio...`,"settings.saved":`Salvato`,"settings.error":`Errore nel salvataggio`,"devices.using_builtin_sensor":`Uso del sensore integrato nel termostato`,"settings.climate_intelligence":`Intelligenza climatica`,"settings.control_mode":`Modalità di controllo`,"settings.control_mode_simple":`Semplice (on/off)`,"settings.control_mode_mpc":`Intelligente (MPC)`,"settings.control_mode_hint":`Intelligente: l'MPC apprende il comportamento termico di ogni stanza e pianifica in anticipo (controllo on/off finché sta ancora imparando). Semplice: solo controllo on/off con isteresi; il modello continua ad apprendere in background ma non prende decisioni, e le tapparelle automatiche usano una stima solare più semplice al posto della previsione MPC.`,"settings.comfort_weight":`Priorità`,"settings.comfort_weight_comfort":`Comfort`,"settings.comfort_weight_efficiency":`Efficienza`,"settings.comfort_weight_hint":`Bilancia la precisione della temperatura rispetto ai consumi. Comfort reagisce prima e resta più vicino all'obiettivo. Efficienza tollera uno scostamento maggiore per ridurre il tempo di funzionamento di riscaldamento e raffrescamento. Dal valore predefinito in su, le stanze vengono riscaldate in anticipo rispetto a un blocco orario, così sono calde quando inizia; sotto il valore predefinito il riscaldamento parte più tardi, con la massima efficienza solo poco prima del blocco.`,"settings.weather_entity":`Previsioni meteo`,"settings.weather_entity_hint":`Opzionale: abilita la pianificazione predittiva sulla temperatura esterna e fa da riserva quando il sensore esterno non è disponibile`,"settings.outdoor_unavailable_notify":`Avvisa quando la temperatura esterna non è disponibile`,"settings.outdoor_unavailable_notify_hint":`Mostra una notifica di Home Assistant quando né il sensore esterno né l'entità meteo hanno riportato una temperatura per 30 minuti. Finché dura questa condizione, RoomMind sospende l'apprendimento del modello termico per non corromperlo.`,"settings.prediction_enabled":`Previsione della temperatura`,"settings.prediction_enabled_hint":`Mostra l'andamento previsto della temperatura nei grafici delle statistiche. Disattivalo se noti rallentamenti.`,"vacation.title":`Modalità vacanza`,"vacation.hint":`Imposta tutte le stanze a una temperatura ridotta fino alla data di fine.`,"vacation.active_label":`Modalità vacanza attiva`,"vacation.end_date":`Data e ora di fine`,"vacation.setback_temp":`Temperatura ridotta`,"vacation.no_end_date":`Nessuna data di fine`,"vacation.deactivate":`Disattiva`,"tabs.analytics":`Statistiche`,"analytics.select_room":`Seleziona stanza`,"analytics.temperature":`Temperatura`,"analytics.target":`Obiettivo`,"analytics.prediction":`Previsione`,"analytics.outdoor":`Esterna`,"analytics.model_status":`Stato del modello`,"analytics.confidence":`Affidabilità`,"analytics.heating_rate":`Intensità di riscaldamento`,"analytics.cooling_rate":`Intensità di raffrescamento`,"analytics.solar_gain":`Apporto solare (pieno sole)`,"analytics.solar_gain_sub":`ora {now} · oggi fino a {today}`,"analytics.occupancy_gain":`Apporto da occupazione`,"analytics.time_constant":`Costante di tempo`,"analytics.samples":`Campioni`,"analytics.prediction_accuracy":`Precisione della previsione`,"analytics.avg_deviation":`Scostamento medio`,"analytics.data_sources":`Sorgenti dati`,"analytics.data_points":`Punti dati`,"analytics.control_mode":`Modalità di controllo`,"analytics.control_mode_mpc":`MPC attivo`,"analytics.control_mode_bangbang":`MPC in apprendimento`,"analytics.last_model_update":`Ultimo aggiornamento del modello`,"analytics.accuracy_idle":`Precisione (a riposo)`,"analytics.accuracy_heating":`Precisione (in riscaldamento)`,"analytics.info.accuracy_idle":`Con quanta precisione il modello prevede la temperatura quando non è attivo né il riscaldamento né il raffrescamento. Un valore più basso significa che il modello ha capito bene la dispersione naturale di calore della stanza. È il primo valore a migliorare, perché i dati a riposo vengono raccolti di continuo.`,"analytics.info.accuracy_heating":`Con quanta precisione il modello prevede la temperatura durante il riscaldamento attivo. All'inizio questo valore resta alto perché il modello ha bisogno di cicli di riscaldamento reali da cui imparare. Dopo qualche accensione il valore scende e il controllo MPC diventa disponibile.`,"analytics.info.confidence":`Quanto il modello è pronto per il controllo intelligente MPC, combinando due fattori: quantità di dati (quanti campioni a riposo e in funzionamento sono stati raccolti) e precisione della previsione (quanto sono accurate le stime di temperatura). L'affidabilità parte da 0% e cresce man mano che il modello raccoglie dati e impara. Intorno al 50% significa dati a riposo sufficienti ma cicli di riscaldamento/raffrescamento ancora attesi. Sopra l'80% il modello ha dati sufficienti e previsioni accurate — il controllo MPC diventa disponibile. 100% è il massimo teorico, quando le previsioni sono accurate quanto è fisicamente possibile.`,"analytics.info.time_constant":`Quanto tempo impiega la stanza a raffreddarsi naturalmente fino a metà strada verso la temperatura esterna, con il riscaldamento spento. Una costante di tempo più lunga indica un isolamento migliore: la stanza trattiene il calore più a lungo. Una costante breve significa che la stanza si raffredda in fretta. Il modello lo apprende osservando i cali di temperatura nei periodi a riposo.`,"analytics.info.heating_rate":`Quanto incide il riscaldamento sulla temperatura della stanza. Un valore più alto significa che l'impianto scalda la stanza più rapidamente rispetto alla sua massa termica. Il modello lo apprende osservando quanto in fretta sale la temperatura durante il riscaldamento attivo, e lo usa per prevedere quanto a lungo deve funzionare.`,"analytics.info.cooling_rate":`Quanto incide l'AC sulla temperatura della stanza. Un valore più alto significa che l'AC raffresca la stanza più rapidamente rispetto alla sua massa termica. Il modello lo apprende osservando quanto in fretta scende la temperatura durante il raffrescamento attivo, e lo usa per prevedere quanto a lungo deve funzionare l'AC. L'aria vicino al sensore si raffredda più in fretta nei primi minuti di funzionamento e si riscalda di nuovo dopo l'arresto; il modello tiene conto di questa parte separatamente, quindi questo valore descrive quanto velocemente l'AC raffresca l'intera stanza, pareti e mobili compresi.`,"analytics.info.solar_gain":`Quanto velocemente il sole scalda la stanza in pieno sole (1000 W/m², un mezzogiorno estivo sereno). Il più delle volte alla finestra arriva molto meno sole: la riga sotto mostra quanto aggiunge il sole in questo momento (nuvole e tapparelle comprese) e il massimo di oggi con cielo sereno. In inverno spesso è solo un quarto del valore in pieno sole. Confronta l'intensità di riscaldamento con questi due valori. Il modello lo apprende osservando come la stanza si scalda nei periodi soleggiati con il riscaldamento spento e lo usa per ridurre il riscaldamento quando è previsto sole.`,"analytics.info.occupancy_gain":`Il contributo di calore stimato dell'occupazione (persone, animali, computer) mentre la stanza è occupata. Il modello lo apprende osservando le variazioni di temperatura quando i sensori di occupazione configurati sono attivi. Separarlo dall'apporto solare evita che il calore corporeo venga attribuito per errore al sole. Compare solo se per questa stanza è configurato almeno un sensore di occupazione.`,"analytics.info.data_sources":`Numero di campioni di misura usati per addestrare il modello.`,"analytics.info.data_points":`Numero totale di osservazioni su cui il modello è stato addestrato. In generale, più punti dati portano a previsioni migliori. Il modello raccoglie un nuovo punto dati all'incirca ogni 3 minuti mentre RoomMind è in funzione.`,"analytics.no_data":`Ancora nessun dato — il modello sta imparando`,"analytics.loading":`Caricamento statistiche...`,"settings.reset_title":`Azzera i dati termici`,"settings.reset_hint":`Cancella i dati del modello termico appresi e lo storico. Il modello ricomincerà a imparare da zero.`,"settings.reset_all_label":`Tutte le stanze`,"settings.reset_all_hint":`Cancella dati termici e storico di tutte le stanze in una volta sola.`,"settings.reset_all_btn":`Azzera tutto`,"settings.reset_all_confirm":`Cancellare tutti i dati termici appresi e lo storico di TUTTE le stanze? Tutti i modelli ricominceranno a imparare da zero.`,"settings.reset_room_label":`Singola stanza`,"settings.reset_room_hint":`Seleziona una stanza di cui cancellare dati termici e storico.`,"settings.reset_room_confirm":`Cancellare tutti i dati termici appresi e lo storico di questa stanza? Il modello ricomincerà a imparare da zero.`,"settings.reset_room_select":`Seleziona stanza`,"settings.reset_btn":`Azzera`,"settings.reset_no_rooms":`Nessuna stanza configurata.`,"settings.boost_title":`Accelera l'apprendimento`,"settings.boost_hint":`Il modello termico impara nel tempo il comportamento della stanza in riscaldamento e raffrescamento. Dopo cambiamenti importanti (nuovo radiatore, AC, isolamento, arredamento) il modello può risultare impreciso. Questa funzione aumenta l'incertezza del modello, così si adatta più in fretta alle nuove condizioni.`,"settings.boost_label":`Accelera l'apprendimento`,"settings.boost_room_select":`Seleziona stanza`,"settings.boost_btn":`Accelera`,"settings.boost_cooldown":`Attivo – riapprendimento in corso`,"settings.boost_no_rooms":`Nessuna stanza configurata.`,"analytics.range_1d":`Oggi`,"analytics.range_2d":`2 giorni`,"analytics.range_7d":`Settimana`,"analytics.range_30d":`Mese`,"analytics.export":`Misurazioni`,"analytics.heating_period":`Riscaldamento`,"analytics.cooling_period":`Raffrescamento`,"analytics.blind_position":`Posizione tapparella`,"analytics.window_open_period":`Finestra aperta`,"analytics.chart_info_title":`Come leggere questo grafico`,"analytics.exported":`Esportato!`,"analytics.copy_diagnostics":`Diagnostica`,"analytics.export_download":`Scarica file`,"analytics.export_clipboard":`Copia negli appunti`,"analytics.copied_to_clipboard":`Copiato!`,"analytics.range_from":`Da`,"analytics.range_to":`A`,"analytics.chart_info_body":`**Linee:** la linea arancione continua mostra la temperatura misurata nella stanza. La linea verde tratteggiata è la temperatura obiettivo del tuo programma. La linea blu punteggiata è la temperatura prevista dal modello.

**Aree colorate:** il rosso indica i periodi di riscaldamento, il blu quelli di raffrescamento e il verde acqua i momenti in cui una finestra era aperta.

**Previsione futura (a destra della linea 'adesso'):** la linea verde tratteggiata mostra gli obiettivi del programma per le prossime 3 ore. La linea blu punteggiata mostra l'andamento previsto della temperatura.

**Modalità di previsione:** quando compare 'MPC attivo', la previsione usa l'ottimizzatore MPC completo, con pre-riscaldamento e pre-raffrescamento intelligenti. Finché il modello sta ancora imparando viene usata una simulazione più semplice.

**Limiti:** la previsione assume che le condizioni attuali restino costanti (temperatura esterna, stato delle finestre). La precisione della simulazione dipende da quanto bene il modello termico ha imparato a conoscere la stanza: all'inizio le previsioni possono essere meno accurate. Una volta attivo l'MPC, diventano molto più affidabili.`,"presence.title":`Rilevamento presenza`,"presence.hint":`Usa la temperatura eco quando non c'è nessuno in casa.`,"presence.hint_detail":`Se attivo, tutte le stanze passano alla temperatura eco non appena nessuna delle persone configurate è in casa. Puoi eventualmente restringere per singola stanza quali persone sono rilevanti.`,"presence.add_person":`Aggiungi persona`,"presence.add_entity":`Aggiungi entità di presenza`,"presence.person_label":`Persona`,"room.section.presence":`Presenza`,"presence.room_help_header":`Come funziona la presenza per singola stanza?`,"presence.room_help_body":`Seleziona quali persone sono rilevanti per questa stanza. La stanza passa alla temperatura eco quando nessuna delle persone selezionate è in casa. Senza selezione vale la regola globale: eco quando non c'è nessuno in casa.`,"presence.state_home":`In casa`,"presence.state_away":`Fuori casa`,"presence.room_none_assigned":`Regola globale — eco quando non c'è nessuno in casa`,"presence.missing_entity_hint":`Questa entità non esiste più in Home Assistant — deselezionala per rimuoverla da questa stanza.`,"presence.ignore_toggle":`Ignora la presenza`,"presence.ignore_hint":`Determina come questa stanza reagisce alla presenza. Puoi assegnare persone specifiche qui sotto: la stanza passa a eco quando nessuna delle persone assegnate è in casa. Usa l'interruttore qui sopra per saltare del tutto il rilevamento e seguire sempre il programma.`,"presence.help_ignore_title":`Che cosa fa "Ignora la presenza"?`,"presence.help_ignore_body":`Se attivo, questa stanza salta completamente il rilevamento della presenza. Segue sempre il suo programma e non passa mai a eco in base a chi è in casa. Utile per stanze che devono mantenere la temperatura a prescindere dalla presenza, come una sala server, la stanza degli animali o una camera per ospiti non tracciati da Home Assistant.`,"presence.tile_ignored":`Il rilevamento presenza è ignorato. La stanza segue sempre il suo programma.`,"presence.away_action_label":`Azione quando non c'è nessuno in casa`,"presence.away_action_eco":`Usa la temperatura eco`,"presence.away_action_off":`Spegni i dispositivi`,"presence.clears_override_label":`L'assenza sospende la forzatura`,"presence.clears_override_hint":`Quando non c'è nessuno in casa, le forzature manuali vengono sospese e la stanza segue l'azione di assenza. Al rientro la forzatura riprende fino alla sua scadenza.`,"card.presence_away":`Fuori casa`,"valve_protection.title":`Protezione valvole`,"valve_protection.hint":`Apre brevemente e a intervalli regolari le valvole TRV inutilizzate, per evitare che si blocchino o si calcifichino.`,"valve_protection.interval_label":`Intervallo tra i cicli`,"valve_protection.interval_suffix":`giorni`,"valve_protection.interval_hint":`Per quanto tempo una valvola può restare ferma prima di essere azionata (1–90 giorni)`,"compressor.title":`Protezione compressore`,"compressor.no_groups":`Nessun gruppo compressore configurato.`,"compressor.add_group":`Aggiungi gruppo compressore`,"compressor.group_name":`Nome del gruppo`,"compressor.members":`Unità interne`,"compressor.members_hint":`Seleziona tutti i dispositivi di climatizzazione alimentati da questo compressore (split interni, TRV sui radiatori, ventilconvettori).`,"compressor.min_run":`Tempo minimo di funzionamento`,"compressor.min_run_hint":`Una volta avviato, il compressore deve funzionare almeno per questo tempo.`,"compressor.min_run_suffix":`min`,"compressor.min_off":`Tempo minimo di spegnimento`,"compressor.min_off_hint":`Dopo l'arresto, il compressore deve restare spento almeno per questo tempo.`,"compressor.min_off_suffix":`min`,"compressor.delete":`Elimina gruppo`,"compressor.delete_confirm":`Eliminare il gruppo compressore "{name}"?`,"compressor.master_entity":`Dispositivo principale`,"compressor.master_entity_hint":`L'unità centrale che alimenta i dispositivi interni di questo gruppo: per esempio una caldaia a gas, l'unità esterna di una pompa di calore o l'interruttore principale di un impianto canalizzato. RoomMind la accenderà quando una stanza qualsiasi richiede riscaldamento o raffrescamento, e la spegnerà quando tutte le stanze sono a riposo. Lascia vuoto per usare solo lo script di azione o la protezione dai cicli brevi.`,"compressor.conflict_resolution":`Risoluzione dei conflitti`,"compressor.conflict_resolution_hint":`Stabilisce cosa succede quando alcune stanze richiedono riscaldamento e altre raffrescamento nello stesso momento. Priorità al riscaldamento: vince sempre il riscaldamento (la scelta più sicura contro il gelo). Priorità al raffrescamento: vince sempre il raffrescamento. Maggioranza: vince la modalità con più stanze, in caso di parità il riscaldamento. Temperatura esterna: decide automaticamente usando la soglia massima esterna per il riscaldamento definita nelle impostazioni.`,"compressor.conflict_heating_priority":`Priorità al riscaldamento (antigelo)`,"compressor.conflict_cooling_priority":`Priorità al raffrescamento`,"compressor.conflict_majority":`Vince la maggioranza`,"compressor.conflict_outdoor_temp":`In base alla temperatura esterna`,"compressor.action_script":`Script di azione`,"compressor.action_script_hint":`Uno script di Home Assistant eseguito ogni volta che cambia la richiesta di riscaldamento/raffrescamento. Utile per impianti che richiedono comandi particolari, per esempio annullare un Quick Veto Vaillant o commutare un relè. Funziona con o senza dispositivo principale: senza, viene eseguito solo lo script. Riceve le variabili: action (heat/cool/idle), master_entity, members, active_members.`,"compressor.enforce_uniform_mode":`Imponi modalità uniforme`,"compressor.enforce_uniform_mode_hint":`Tutti i termostati di questo gruppo devono operare nella stessa modalità HVAC (tutti in riscaldamento o tutti in raffrescamento). Le stanze in disaccordo con la modalità risolta per il gruppo verranno messe a riposo. Usalo per le pompe di calore che si avviano automaticamente ma richiedono che tutte le unità collegate funzionino nella stessa modalità.`,"coil_dry.title":`Asciugatura evaporatore`,"coil_dry.hint":`Dopo il raffreddamento mantiene la ventola interna in funzione per un po' prima che il condizionatore si spenga davvero. Asciuga l'evaporatore, così non si forma biofilm e alla riaccensione non c'è odore di muffa.`,"coil_dry.duration_label":`Durata asciugatura`,"coil_dry.duration_suffix":`min`,"coil_dry.duration_hint":`Per quanto tempo la ventola resta in funzione (1–60 min). A velocità bassa serve circa il doppio del tempo che a velocità alta.`,"coil_dry.min_cooling_label":`Durata minima di raffreddamento`,"coil_dry.min_cooling_suffix":`min`,"coil_dry.min_cooling_hint":`Asciuga solo dopo che il condizionatore ha raffreddato almeno per questo tempo. I raffreddamenti brevi vengono sommati (1–240 min).`,"coil_dry.mode_label":`Modalità di asciugatura`,"coil_dry.mode_fan_only":`fan_only (solo ventola)`,"coil_dry.mode_dry":`dry (deumidificazione)`,"coil_dry.mode_dry_warning":`In modalità dry il compressore resta in funzione e raffredda di nuovo l'evaporatore, lavorando contro l'asciugatura. Scegli questa opzione solo se la modalità dry della tua unità funziona a ventola.`,"coil_dry.fan_mode_label":`Velocità ventola durante l'asciugatura`,"coil_dry.fan_mode_keep":`Mantieni la velocità corrente`,"coil_dry.fan_mode_hint":`Una velocità più alta asciuga più in fretta ma è più rumorosa. Le velocità che il dispositivo non dichiara vengono ignorate — in quel caso mantiene quella corrente.`,"coil_dry.drain_label":`Attesa di scarico`,"coil_dry.drain_suffix":`min`,"coil_dry.drain_hint":`Tiene prima il condizionatore spento perché la condensa possa scolare, poi avvia la ventola (0–15 min). Riduce l'umidità che viene rimandata nella stanza.`,"mold.title":`Protezione dal rischio muffa`,"mold.detection":`Rilevamento muffa`,"mold.detection_desc":`Ricevi notifiche quando l'umidità segnala un rischio di muffa`,"mold.threshold":`Soglia di umidità (%)`,"mold.threshold_hint":`Avvisa quando l'umidità della stanza resta sopra questo valore`,"mold.insulation":`Isolamento delle pareti`,"mold.insulation_hint":`Serve a stimare quanto diventa fredda la parte più fredda delle pareti esterne (angoli, spallette delle finestre). Nel dubbio lascia Standard. Richiede una temperatura esterna.`,"mold.insulation_poor":`Edificio vecchio non isolato`,"mold.insulation_standard":`Standard`,"mold.insulation_good":`Ben isolato (nuovo o ristrutturato)`,"mold.sustained":`Durata continuativa (minuti)`,"mold.sustained_hint":`Avvisa solo dopo che il rischio persiste per questo tempo`,"mold.prevention":`Prevenzione muffa`,"mold.prevention_desc":`Alza automaticamente la temperatura per ridurre il rischio di muffa`,"mold.intensity":`Intensità`,"mold.intensity_light":`Leggera (+{delta}{unit})`,"mold.intensity_medium":`Media (+{delta}{unit})`,"mold.intensity_strong":`Forte (+{delta}{unit})`,"mold.intensity_hint":`L'aria più calda riduce l'umidità superficiale sulle pareti fredde. Leggera è di solito sufficiente per un rischio moderato; Forte può abbassare l'umidità superficiale fino all'8–10%, ma consuma sensibilmente di più.`,"card.mold_warning":`Rischio muffa`,"card.mold_critical":`Pericolo muffa!`,"card.mold_prevention":`Prevenzione muffa +{delta}{unit}`,"room.mold_surface_rh":`Umidità superficiale stimata: {value}%`,"room.mold_surface_temp":`parete {value}{unit}`,"settings.intro.general":`Impostazioni di base di visualizzazione e controllo.`,"settings.intro.sensors":`Configura i sensori esterni e i dati meteo per un controllo climatico accurato.`,"settings.intro.control":`Scegli come RoomMind controlla i dispositivi di climatizzazione e imposta priorità e soglie.`,"settings.intro.presence":`Abbassa automaticamente la temperatura quando non c'è nessuno in casa.`,"settings.intro.vacation":`Imposta tutte le stanze a una temperatura ridotta mentre sei via.`,"settings.intro.valve":`Muove periodicamente le valvole TRV inutilizzate per evitare che si blocchino o si calcifichino.`,"settings.intro.compressor":`Gestisci gruppi di unità interne che condividono un compressore esterno o una fonte di calore centralizzata. Puoi assegnare un dispositivo principale (caldaia, unità esterna) da accendere e spegnere automaticamente in base alla richiesta delle stanze. La protezione dai cicli brevi evita accensioni e spegnimenti ravvicinati che possono danneggiare l'impianto.`,"settings.intro.mold":`Monitora l'umidità e riduci automaticamente il rischio di muffa.`,"settings.intro.notifications":`Configura chi riceve gli avvisi e in che modo.`,"settings.intro.learning":`Gestisci l'addestramento del modello termico e accelera il riapprendimento dopo delle modifiche.`,"settings.intro.reset":`Cancella i dati del modello termico appresi. Il modello ricomincerà a imparare da zero.`,"notifications.title":`Notifiche`,"notifications.enabled":`Attiva le notifiche`,"notifications.enabled_hint":`Se disattivate, non viene inviata alcuna notifica — né ai dispositivi né alla barra laterale di HA.`,"notifications.desc":`Scegli quali dispositivi ricevono gli avvisi. Senza destinatari, gli avvisi compaiono nella barra laterale di HA.`,"notifications.add_target_label":`Aggiungi dispositivo per le notifiche`,"notifications.add_target_hint":`Digita l'entity ID se il tuo dispositivo non è in elenco (es. notify.mobile_app_...). Lo trovi in Impostazioni → Dispositivi → il tuo telefono → entità Notify.`,"notifications.target_unnamed":`Dispositivo senza nome`,"notifications.target_person":`Persona`,"notifications.target_when_always":`Sempre`,"notifications.target_when_home":`Solo quando è in casa`,"notifications.cooldown":`Attesa tra le notifiche (minuti)`,"notifications.cooldown_hint":`Tempo minimo tra avvisi ripetuti per la stessa stanza`,"notifications.mold_prevention_notify":`Avvisa quando si attiva la prevenzione muffa`,"notifications.mold_prevention_notify_hint":`Invia una notifica anche quando la prevenzione si attiva (temperatura alzata)`,"room.section.heat_source":`Orchestrazione delle fonti di calore`,"heat_source.toggle":`Scelta intelligente della fonte`,"heat_source.toggle_hint":`Quando questa stanza ha sia termostati per radiatore sia un AC/pompa di calore, RoomMind indirizza in modo intelligente la richiesta di riscaldamento al dispositivo più efficiente, in base allo scarto di temperatura e alle condizioni esterne.`,"heat_source.primary_delta":`Soglia di attivazione della caldaia`,"heat_source.primary_delta_hint":`Attiva la fonte primaria solo quando lo scarto di temperatura supera questo valore. Sotto questa soglia viene usata solo la fonte secondaria, più rapida.`,"heat_source.primary_delta_suffix":`°C`,"heat_source.outdoor_threshold":`Commutazione per temperatura esterna`,"heat_source.outdoor_threshold_hint":`Sopra questa temperatura esterna preferisci l'AC/pompa di calore (efficienza maggiore). Sotto, preferisci la caldaia a gas/radiatore.`,"heat_source.outdoor_threshold_suffix":`°C`,"heat_source.ac_min_outdoor":`Temp. esterna minima per riscaldare con l'AC`,"heat_source.ac_min_outdoor_hint":`Sotto questa temperatura disabilita del tutto il riscaldamento tramite AC, per proteggere la pompa di calore.`,"heat_source.ac_min_outdoor_suffix":`°C`,"heat_source.summary_disabled":`La scelta intelligente della fonte è disattivata`,"devices.valve_closing_entity_hint":`Mantiene la valvola all'apertura impostata, qualunque cosa voglia la regolazione della testina. Viene compilato automaticamente se il dispositivo ne ha uno.`,"room.section.thermostat":`Termostato`,"thermostat.info":`Ruota la manopola per mantenere una temperatura fino al prossimo cambio di programma. I pulsanti di modalità e preset funzionano come su un termostato a parete.`,"thermostat.not_available":`L'entità termostato della stanza non è ancora disponibile. Appare dopo aver salvato la stanza.`,"thermostat.load_failed":`Impossibile caricare la scheda termostato.`,"room.thermostat_toggle":`Mostra termostato`,"room.thermostat_hint":`Mostra una manopola termostato per modificare direttamente la temperatura di questa stanza.`,"schedule_editor.title_new":`Nuovo programma`,"schedule_editor.title_edit":`Modifica programma`,"schedule_editor.create":`Crea programma`,"schedule_editor.edit":`Modifica programma`,"schedule_editor.read_only":`Questo programma è definito in YAML e non può essere modificato qui. Modificalo nella configurazione o crea un nuovo programma.`,"schedule_editor.name":`Nome`,"schedule_editor.no_blocks":`Nessuna fascia oraria in questo giorno: tutto il giorno vale la temperatura eco.`,"schedule_editor.add_block":`Aggiungi fascia oraria`,"schedule_editor.remove_block":`Rimuovi fascia oraria`,"schedule_editor.copy_weekdays":`Copia su lun–ven`,"schedule_editor.copy_all":`Copia su tutti i giorni`,"schedule_editor.hint":`Durante una fascia la stanza punta alla temperatura della fascia, o al comfort se il campo è vuoto. Fuori dalle fasce vale l'eco. Fine alle 00:00 significa mezzanotte.`,"schedule_editor.hint_auto":`Durante una fascia la stanza resta tra le sue temperature di riscaldamento e raffrescamento (vuoto = comfort). Fuori dalle fasce vale l'eco. Fine alle 00:00 significa mezzanotte.`,"schedule_editor.cancel":`Annulla`,"schedule_editor.save":`Salva`,"schedule_editor.comfort_placeholder":`comfort`,"schedule_editor.from":`Da`,"schedule_editor.to":`A`,"schedule_editor.heat":`Riscaldamento`,"schedule_editor.cool":`Raffresc.`,"schedule_editor.temperature":`Temperatura`,"schedule_editor.err_time":`Inserisci un orario valido.`,"schedule_editor.err_order":`Una fascia deve terminare dopo l'inizio.`,"schedule_editor.err_overlap":`Le fasce dello stesso giorno non devono sovrapporsi.`,"schedule_editor.err_temp":`Inserisci una temperatura valida.`,"schedule_editor.err_band":`La temperatura di raffrescamento non deve essere inferiore a quella di riscaldamento.`,"schedule_editor.err_entity":`Il programma è stato creato, ma la sua entità non è stata trovata. Aggiungilo dall'elenco.`,"schedule_editor.day_short.monday":`Lun`,"schedule_editor.day_short.tuesday":`Mar`,"schedule_editor.day_short.wednesday":`Mer`,"schedule_editor.day_short.thursday":`Gio`,"schedule_editor.day_short.friday":`Ven`,"schedule_editor.day_short.saturday":`Sab`,"schedule_editor.day_short.sunday":`Dom`,"compressor.release_title":`Consenso caldaia (caldaia / gasolio)`,"compressor.release_entity":`Entità di consenso`,"compressor.release_entity_hint":`Facoltativo. Un input_boolean o interruttore che abilita il bruciatore. RoomMind lo attiva quando abbastanza stanze del gruppo chiedono calore e rispetta i tempi minimi sopra.`,"compressor.release_on":`Consenso attivo`,"compressor.release_off":`Consenso disattivo`,"compressor.release_demand":`{count} stanze chiedono calore (ponderato {weighted})`,"compressor.release_min_demand":`Stanze necessarie`,"compressor.release_min_demand_hint":`Quante stanze devono chiedere calore prima che il bruciatore parta. Una volta acceso resta attivo finché una stanza riscalda.`,"compressor.release_smart":`Consenso intelligente`,"compressor.release_smart_hint":`Pondera ogni stanza in base al calore richiesto dal suo modello appreso (100 % conta pienamente, 10 % poco), così il bruciatore fa cicli più lunghi e rari. Una stanza molto sotto il target o in attesa da troppo abilita da sola.`,"compressor.release_urgent_delta":`Urgente sotto il target`,"compressor.release_urgent_delta_hint":`Una stanza così sotto il target abilita subito il bruciatore.`,"compressor.release_max_wait":`Attesa massima`,"compressor.release_max_wait_hint":`Una stanza che chiede calore da così tanto abilita il bruciatore anche senza altre stanze.`,"compressor.release_reason.no_demand":`nessuna richiesta`,"compressor.release_reason.running":`attivo finché le stanze riscaldano`,"compressor.release_reason.demand_count":`abbastanza stanze richiedono`,"compressor.release_reason.weighted_demand":`richiesta ponderata sufficiente`,"compressor.release_reason.urgent":`una stanza è molto sotto il target`,"compressor.release_reason.max_wait":`una stanza ha atteso troppo`,"compressor.release_reason.collecting_demand":`raccolta richieste`,"compressor.release_reason.min_run":`tempo minimo di funzionamento`,"compressor.release_reason.min_off":`tempo minimo di pausa`,"thermostat.writes_schedule":`Il termostato modifica il programma`,"thermostat.writes_schedule_hint":`Ruotare durante una fascia imposta la temperatura diurna del programma attivo per tutta la settimana; fuori dalle fasce la temperatura notturna. Disattivato: la modifica vale solo fino al prossimo cambio di programma.`,"schedule_editor.copy_hint":`Questo programma è definito in YAML e non può essere modificato qui. Salvando viene ripreso come nuovo programma modificabile che lo sostituisce in questa stanza.`,"schedule_editor.day_temp":`Temperatura diurna`,"schedule_editor.night_temp":`Temperatura notturna`,"schedule_editor.day_night_hint":`Il giorno vale nelle fasce (imposta tutte le fasce), la notte fuori (temperatura eco della stanza).`,"compressor.boiler_title":`Temperatura caldaia (facoltativo)`,"compressor.boiler_temp_sensor":`Sensore temperatura caldaia / mandata`,"compressor.boiler_temp_sensor_hint":`Con la temperatura della caldaia RoomMind impara quanto velocemente si scalda e si raffredda. Una caldaia ancora calda viene abilitata per qualsiasi stanza per usarne il calore, e la modalità intelligente avvia prima una caldaia fredda in base al suo tempo di riscaldamento.`,"compressor.boiler_usable_temp":`Caldaia calda da`,"compressor.boiler_usable_temp_hint":`Temperatura dell'acqua da cui i radiatori cedono calore utile.`,"compressor.boiler_status":`Caldaia {temp} °C · scalda {heat} K/min · raffredda {cool} K/min`,"compressor.boiler_learning":`in apprendimento…`,"compressor.boiler_lead":`calda tra ~{min} min`,"compressor.boiler_warm":`resta calda ~{min} min`,"compressor.release_reason.residual_heat":`usa il calore residuo`,"compressor.release_reason.preheat":`preriscalda la caldaia fredda`,"panel.tab.heating":`Riscaldamento`,"heating.no_groups":`Crea prima un gruppo in Impostazioni → Protezione compressore con i termostati delle stanze riscaldate da questa caldaia. Impostazioni, stato e analisi appaiono poi qui.`,"heating.unnamed":`Gruppo senza nome`,"heating.unknown":`sconosciuto`,"heating.on":`Acceso`,"heating.off":`Spento`,"heating.release":`Consenso`,"heating.demand":`Richiesta di calore`,"heating.demand_value":`{count} stanze · ponderato {weighted}`,"heating.boiler_temp":`Temperatura caldaia`,"heating.burner":`Bruciatore`,"heating.pump":`Circolatore`,"heating.dhw":`Acqua calda`,"heating.learned":`Comportamento appreso della caldaia`,"heating.heat_rate":`Si scalda`,"heating.cool_rate":`Si raffredda`,"heating.reset_learning":`Azzera apprendimento`,"heating.reset_confirm":`Dimenticare ciò che RoomMind ha appreso su questa caldaia?`,"heating.learned_hint":`Appreso dalla temperatura della caldaia: riscaldamento mentre il bruciatore è acceso (o il consenso), raffreddamento a riposo. In pausa durante la produzione di acqua calda.`,"heating.waiting_status":`In attesa del primo ciclo di regolazione…`,"heating.status":`Stato`,"heating.range.24h":`24 h`,"heating.range.7d":`7 giorni`,"heating.range.30d":`30 giorni`,"heating.kpi_starts":`Avvii {what}`,"heating.kpi_avg_run":`Ø {min} min per ciclo`,"heating.kpi_runtime":`Durata {what}`,"heating.kpi_release_time":`Abilitato`,"heating.kpi_oil":`Gasolio`,"heating.kpi_oil_estimated":`stimato dalla durata del bruciatore`,"heating.kpi_pump":`Durata circolatore`,"heating.kpi_dhw":`Acqua calda`,"heating.kpi_dhw_count":`{count} cariche`,"heating.kpi_boiler":`Ø caldaia`,"heating.kpi_boiler_max":`max {max} °C`,"heating.reasons":`Perché il consenso era attivo o no`,"heating.oil_hint":`Per il consumo indica un contatore del gasolio, oppure il bruciatore e la portata dell'ugello (L/h) qui sotto.`,"heating.analysis":`Analisi`,"heating.settings":`Impostazioni caldaia`,"heating.settings_intro":`Tutto ciò che RoomMind deve sapere su questa caldaia. Serve solo l'entità di consenso; ogni altra entità migliora apprendimento e analisi. L'acqua calda non è regolata, solo considerata.`,"heating.section_release":`Consenso`,"heating.section_boiler":`Caldaia & circuito`,"heating.section_oil":`Consumo di gasolio`,"heating.burner_entity":`Bruciatore acceso`,"heating.burner_entity_hint":`Facoltativo. Indica quando il bruciatore è realmente acceso (sensore binario, interruttore o potenza > 0). Migliora l'apprendimento e conta gli avvii.`,"heating.pump_entity":`Circolatore riscaldamento`,"heating.pump_entity_hint":`Facoltativo. Durata del circolatore nell'analisi.`,"heating.dhw_entity":`Produzione acqua calda`,"heating.dhw_entity_hint":`Facoltativo. Durante la produzione di acqua calda la temperatura non serve all'apprendimento; cariche e durata appaiono nell'analisi.`,"heating.oil_sensor":`Contatore gasolio`,"heating.oil_sensor_hint":`Facoltativo. Un sensore che conta i litri (totale). Si sommano gli aumenti; rifornimento o azzeramento non contano.`,"heating.oil_nozzle":`Portata ugello`,"heating.oil_nozzle_hint":`Senza contatore: litri all'ora dell'ugello (vedi targhetta, es. 2,0 L/h). Con l'entità bruciatore RoomMind stima il consumo.`,"heating.members_hint":`Stanze/termostati di questa caldaia e tempi minimi: Impostazioni → Protezione compressore.`,"compressor.release_moved":`Nessun consenso caldaia`,"compressor.release_open_tab":`Apri scheda Riscaldamento`,"quick.day":`Giorno`,"quick.day_hint":`Target senza programma (comfort)`,"quick.day_hint_schedule":`Nelle fasce, tutta la settimana (anche dal termostato)`,"quick.day_hint_yaml":`Programma YAML: cambia solo il valore comfort`,"quick.take_over":`Riprendi il programma così temperatura diurna e termostato possono modificarlo`,"quick.night":`Notte`,"quick.night_hint":`Fuori dalle fasce (eco)`,"quick.away":`Assente`,"quick.away_hint":`Quando tutti sono fuori`,"quick.away_hint_same":`Quando tutti sono fuori – come la notte`,"quick.away_reset":`Usa la temperatura notturna`,"quick.arrival":`Rientro previsto ~{time}`,"quick.arrival_heating":`Preriscalda – rientro previsto ~{time}`,"presence.preheat_label":`Caldo al rientro (apprendimento)`,"presence.preheat_hint":`Impara per giorno della settimana quando le persone rientrano. Quando tutti sono fuori, la stanza preriscalda per raggiungere la temperatura al rientro previsto, con il suo tempo di riscaldamento appreso.`,"presence.preheat_minutes":`Tempo di preriscaldo senza modello appreso`,"presence.preheat_minutes_hint":`Usato finché il modello termico della stanza non è addestrato; poi ogni stanza usa il proprio tempo appreso.`,"presence.learned_title":`Orari di rientro appresi`,"presence.learned_count":`{count} rientri`,"presence.learned_next":`previsto oggi ~{time}`,"presence.learned_hint":`Rientro tipico per giorno (mediana delle ultime 8 settimane). Una previsione richiede rientri in almeno 3 giorni diversi; assenze sotto i 20 minuti sono ignorate.`}};function S(e,t,n){let r=(vt[t]??vt[t.split(`-`)[0]]??vt.en)[e]??vt.en[e]??e;if(n)for(let[e,t]of Object.entries(n))r=r.replaceAll(`{${e}}`,String(t));return r}function yt(e,t){if(e.area_id)return e.area_id;if(e.device_id&&t){let n=t[e.device_id];if(n?.area_id)return n.area_id}return null}function bt(e,t,n){return t?Object.values(t).filter(t=>yt(t,n)===e):[]}function xt(e){switch(e){case`heating`:return`mode-heating`;case`cooling`:return`mode-cooling`;case`idle`:return`mode-idle`;default:return`mode-other`}}var St={heating:`mode.heating`,cooling:`mode.cooling`,idle:`mode.idle`};function Ct(e,t){return S(St[e],t)}function wt(e){return e==null?1:Math.max(1,Math.ceil((e*1e3-Date.now())/6e4))}var Tt=l`
  .mode-pill {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-size: 13px;
    font-weight: 500;
    padding: 4px 14px;
    border-radius: 16px;
  }

  .mode-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
  }

  .mode-heating {
    color: var(--warning-color, #ff9800);
    background: rgba(255, 152, 0, 0.12);
  }
  .mode-heating .mode-dot {
    background: var(--warning-color, #ff9800);
  }

  .mode-cooling {
    color: #2196f3;
    background: rgba(33, 150, 243, 0.12);
  }
  .mode-cooling .mode-dot {
    background: #2196f3;
  }

  .mode-idle {
    color: var(--secondary-text-color, #757575);
    background: rgba(0, 0, 0, 0.05);
  }
  .mode-idle .mode-dot {
    background: var(--disabled-text-color, #bdbdbd);
  }

  .mode-other {
    color: var(--secondary-text-color);
    background: rgba(0, 0, 0, 0.05);
  }
  .mode-other .mode-dot {
    background: var(--secondary-text-color);
  }
`,Et=`M11.83,9L15,12.16C15,12.11 15,12.05 15,12A3,3 0 0,0 12,9C11.94,9 11.89,9 11.83,9M7.53,9.8L9.08,11.35C9.03,11.56 9,11.77 9,12A3,3 0 0,0 12,15C12.22,15 12.44,14.97 12.65,14.92L14.2,16.47C13.53,16.8 12.79,17 12,17A5,5 0 0,1 7,12C7,11.21 7.2,10.47 7.53,9.8M2,4.27L4.28,6.55L4.73,7C3.08,8.3 1.78,10 1,12C2.73,16.39 7,19.5 12,19.5C13.55,19.5 15.03,19.2 16.38,18.66L16.81,19.08L19.73,22L21,20.73L3.27,3M12,7A5,5 0 0,1 17,12C17,12.64 16.87,13.26 16.64,13.82L19.57,16.75C21.07,15.5 22.27,13.86 23,12C21.27,7.61 17,4.5 12,4.5C10.6,4.5 9.26,4.75 8,5.2L10.17,7.35C10.74,7.13 11.35,7 12,7Z`;function Dt(e){return e.config?.unit_system?.temperature===`°F`}function C(e){return Dt(e)?`°F`:`°C`}function w(e,t){return Dt(t)?e*9/5+32:e}function T(e,t){return Dt(t)?(e-32)*5/9:e}function E(e,t){return Dt(t)?e*9/5:e}function Ot(e,t){return Dt(t)?e*5/9:e}function D(e,t,n=1){return w(e,t).toFixed(n)}function O(e){return Dt(e)?`1`:`0.5`}function k(e,t,n){return{min:String(Math.round(w(e,n))),max:String(Math.round(w(t,n)))}}function kt(e,t){let n=Number(e);if(!Number.isFinite(n))return!1;let r=T(n,t);return r>=5&&r<=35}function A(e,t,n,r){var i=arguments.length,a=i<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,o;if(typeof Reflect==`object`&&typeof Reflect.decorate==`function`)a=Reflect.decorate(e,t,n,r);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(i<3?o(a):i>3?o(t,n,a):o(t,n))||a);return i>3&&a&&Object.defineProperty(t,n,a),a}var j=t((()=>{}));_(),j();var M=class extends g{constructor(...e){super(...e),this.config=null,this.climateEntityCount=0,this.tempSensorCount=0,this.controlMode=`mpc`,this.climateControlActive=!0,this.reordering=!1,this.canMoveUp=!1,this.canMoveDown=!1,this._lastRender=0}static{this.styles=[Tt,l`
      :host {
        display: block;
      }

      ha-card {
        cursor: pointer;
        transition:
          box-shadow 0.2s ease,
          transform 0.15s ease;
        overflow: hidden;
        position: relative;
        height: 100%;
        box-sizing: border-box;
      }

      ha-card:hover {
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
        transform: translateY(-1px);
      }

      .hide-btn {
        --mdc-icon-button-size: 28px;
        --mdc-icon-size: 16px;
        color: var(--secondary-text-color);
        opacity: 0;
        transition: opacity 0.2s ease;
        position: absolute;
        top: 8px;
        right: 8px;
      }

      ha-card:hover .hide-btn {
        opacity: 0.4;
      }

      .hide-btn:hover {
        opacity: 1 !important;
      }

      /* Colored left accent based on mode */
      .accent {
        position: absolute;
        left: 0;
        top: 0;
        bottom: 0;
        width: 4px;
      }

      .accent-heating {
        background: var(--warning-color, #ff9800);
      }

      .accent-cooling {
        background: #2196f3;
      }

      .accent-idle {
        background: var(--disabled-text-color, #bdbdbd);
      }

      .accent-unconfigured {
        background: transparent;
      }

      .card-inner {
        padding: 20px 20px 16px;
      }

      /* Header row: name + badge */
      .card-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
      }

      .area-name {
        font-size: 15px;
        font-weight: 500;
        color: var(--primary-text-color);
        margin: 0;
        letter-spacing: 0.01em;
      }

      /* Card-specific mode-pill overrides (smaller than default) */
      .mode-pill {
        gap: 5px;
        font-size: 12px;
        padding: 3px 10px;
        border-radius: 12px;
      }

      .mode-dot {
        width: 7px;
        height: 7px;
      }

      /* Temperature display */
      .temp-section {
        display: flex;
        align-items: baseline;
        gap: 8px;
        margin: 12px 0 0 0;
      }

      .current-temp {
        font-size: 36px;
        font-weight: 300;
        color: var(--primary-text-color);
        line-height: 1;
      }

      .temp-unit {
        font-size: 18px;
        font-weight: 300;
        color: var(--secondary-text-color);
      }

      .target-info {
        font-size: 13px;
        color: var(--secondary-text-color);
        margin-left: auto;
      }

      .target-value {
        font-weight: 500;
        color: var(--primary-text-color);
      }

      .override-icon {
        --mdc-icon-size: 14px;
        vertical-align: middle;
        margin-left: 4px;
        color: var(--warning-color, #ff9800);
      }

      .window-icon {
        --mdc-icon-size: 14px;
        vertical-align: middle;
        margin-left: 4px;
        color: var(--warning-color, #ff9800);
      }

      .away-icon {
        --mdc-icon-size: 14px;
        vertical-align: middle;
        margin-left: 4px;
        color: var(--info-color, #2196f3);
      }

      /* Footer row: humidity + MPC status */
      .card-footer {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-top: 8px;
        min-height: 20px;
      }

      .humidity-info {
        font-size: 13px;
        color: var(--secondary-text-color);
      }

      .mpc-badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        font-size: 11px;
        font-weight: 500;
        padding: 2px 8px 2px 6px;
        border-radius: 10px;
        --mdc-icon-size: 14px;
      }

      .mpc-badge.active {
        color: var(--success-color, #4caf50);
        background: rgba(76, 175, 80, 0.12);
      }

      .mpc-badge.learning {
        color: var(--secondary-text-color);
        background: rgba(158, 158, 158, 0.1);
      }

      .compressor-badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        font-size: 11px;
        font-weight: 500;
        padding: 2px 8px 2px 6px;
        border-radius: 10px;
        --mdc-icon-size: 14px;
        color: var(--info-color, #2196f3);
        background: rgba(33, 150, 243, 0.12);
      }

      .mold-badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        font-size: 11px;
        font-weight: 500;
        padding: 2px 8px 2px 6px;
        border-radius: 10px;
        --mdc-icon-size: 14px;
      }

      .mold-badge.warning {
        color: var(--warning-color, #ff9800);
        background: rgba(255, 152, 0, 0.12);
      }

      .mold-badge.critical {
        color: var(--error-color, #db4437);
        background: rgba(219, 68, 55, 0.12);
      }

      .mold-badge.prevention {
        color: var(--info-color, #2196f3);
        background: rgba(33, 150, 243, 0.12);
      }

      .outdoor-badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        font-size: 11px;
        font-weight: 500;
        padding: 2px 8px 2px 6px;
        border-radius: 10px;
        --mdc-icon-size: 14px;
        color: var(--success-color, #4caf50);
        background: rgba(76, 175, 80, 0.12);
      }

      .badge-row {
        display: flex;
        gap: 6px;
        flex-wrap: wrap;
      }

      .no-temp {
        font-size: 24px;
        font-weight: 300;
        color: var(--secondary-text-color);
        line-height: 1;
      }

      .uncontrolled-hint {
        font-size: 11px;
        color: var(--disabled-text-color, #9e9e9e);
        margin-top: 6px;
      }

      .reorder-overlay {
        position: absolute;
        inset: 0;
        z-index: 2;
        display: flex;
        pointer-events: none;
        border-radius: inherit;
        overflow: hidden;
      }

      .reorder-half {
        pointer-events: auto;
        flex: 0 0 40px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: background 0.15s ease;
        background: rgba(var(--rgb-primary-text-color, 0, 0, 0), 0.05);
      }

      .reorder-half.left {
        border-radius: inherit;
        border-top-right-radius: 0;
        border-bottom-right-radius: 0;
        border-right: 1px solid rgba(var(--rgb-primary-text-color, 0, 0, 0), 0.08);
      }

      .reorder-half.right {
        border-radius: inherit;
        border-top-left-radius: 0;
        border-bottom-left-radius: 0;
        border-left: 1px solid rgba(var(--rgb-primary-text-color, 0, 0, 0), 0.08);
        margin-left: auto;
      }

      .reorder-half:hover {
        background: rgba(var(--rgb-primary-text-color, 0, 0, 0), 0.1);
      }

      .reorder-half ha-icon-button {
        --mdc-icon-button-size: 36px;
        --mdc-icon-size: 20px;
        color: var(--secondary-text-color);
        pointer-events: none;
      }

      .reorder-half:hover ha-icon-button {
        color: var(--primary-text-color);
      }

      .reorder-half.disabled {
        opacity: 0.25;
        cursor: default;
      }

      .reorder-half.disabled:hover {
        background: rgba(var(--rgb-primary-text-color, 0, 0, 0), 0.05);
      }

      /* Device summary for unconfigured cards */
      .device-summary {
        font-size: 13px;
        color: var(--secondary-text-color);
        margin-top: 8px;
      }

      .device-summary.empty {
        color: var(--disabled-text-color, #9e9e9e);
        font-style: italic;
      }

      /* Configure prompt for unconfigured areas */
      .configure-prompt {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-top: 12px;
        padding-top: 12px;
        border-top: 1px solid var(--divider-color, #eee);
      }

      .configure-text {
        font-size: 13px;
        color: var(--secondary-text-color);
      }

      .configure-arrow {
        font-size: 18px;
        color: var(--primary-color);
      }

      /* Waiting state */
      .waiting {
        font-size: 13px;
        color: var(--disabled-text-color, #9e9e9e);
        font-style: italic;
        margin-top: 8px;
      }
    `]}shouldUpdate(e){if(e.size!==1||!e.has(`hass`))return!0;let t=e.get(`hass`);return!t||t.language!==this.hass.language||t.config?.unit_system?.temperature!==this.hass.config?.unit_system?.temperature||Date.now()-this._lastRender>3e4}render(){this._lastRender=Date.now();let e=this.climateEntityCount>0,t=(this.config?.devices?.length??0)>0||(this.config?.thermostats?.length??0)>0||(this.config?.acs?.length??0)>0,n=this.config?.is_outdoor??!1,r=this.config!==null&&t&&!n,i=this.config?.live,a=i?.mode,o=(!r||n)&&i&&(i.current_temp!==null||i.current_humidity!==null),s=r?a===`heating`?`accent-heating`:a===`cooling`?`accent-cooling`:`accent-idle`:o?`accent-idle`:`accent-unconfigured`;return m`
      <ha-card @click=${this._onCardClick}>
        <div class="accent ${s}"></div>
        ${this.reordering?h:m`<ha-icon-button
                class="hide-btn"
                .path=${Et}
                @click=${this._onHideClick}
              ></ha-icon-button>`}
        ${this.reordering?m`<div class="reorder-overlay">
                <div
                  class="reorder-half left ${this.canMoveUp?``:`disabled`}"
                  @click=${this._onMoveUp}
                >
                  <ha-icon-button
                    .path=${`M15.41,16.58L10.83,12L15.41,7.41L14,6L8,12L14,18L15.41,16.58Z`}
                  ></ha-icon-button>
                </div>
                <div
                  class="reorder-half right ${this.canMoveDown?``:`disabled`}"
                  @click=${this._onMoveDown}
                >
                  <ha-icon-button
                    .path=${`M8.59,16.58L13.17,12L8.59,7.41L10,6L16,12L10,18L8.59,16.58Z`}
                  ></ha-icon-button>
                </div>
              </div>`:h}
        <div class="card-inner">
          <div class="card-header">
            <h3 class="area-name">${this.config?.display_name||this.area.name}</h3>
            ${r&&i?m`
                    <span class="mode-pill ${xt(i.mode)}">
                      <span class="mode-dot"></span>
                      ${Ct(i.mode,this.hass.language)}${i.heating_power>0&&i.heating_power<100?m` ${i.heating_power}%`:h}
                    </span>
                  `:h}
          </div>

          ${r?this._renderConfigured():this.config?.live&&(this.config.live.current_temp!==null||this.config.live.current_humidity!==null)?this._renderSensorOnly():this._renderUnconfigured(e)}
        </div>
      </ha-card>
    `}_renderConfigured(){let e=this.config?.live;if(!e)return m`<div class="waiting">${S(`card.waiting`,this.hass.language)}</div>`;let t=this.controlMode===`mpc`&&!!this.config?.temperature_sensor;return m`
      <div class="temp-section">
        ${e.current_temp===null?m`<span class="no-temp">--</span>`:m`
                <span class="current-temp">${D(e.current_temp,this.hass)}</span>
                <span class="temp-unit">${C(this.hass)}</span>
              `}
        ${this._renderTargetInfo(e)}
      </div>
      <div class="card-footer">
        <span class="humidity-info">
          ${e.current_humidity===null?h:S(`card.humidity`,this.hass.language,{value:e.current_humidity.toFixed(0)})}
        </span>
        <span class="badge-row">
          ${e.mold_risk_level&&e.mold_risk_level!==`ok`?m`<span class="mold-badge ${e.mold_risk_level}">
                  <ha-icon icon="mdi:water-alert"></ha-icon>
                  ${e.mold_risk_level===`critical`?S(`card.mold_critical`,this.hass.language):S(`card.mold_warning`,this.hass.language)}
                </span>`:h}
          ${e.mold_prevention_active?m`<span class="mold-badge prevention">
                  <ha-icon icon="mdi:shield-check"></ha-icon>
                  ${S(`card.mold_prevention`,this.hass.language,{delta:E(e.mold_prevention_delta,this.hass).toFixed(0),unit:C(this.hass)})}
                </span>`:h}
          ${e.compressor_protection_until==null?h:m`<span class="compressor-badge">
                  <ha-icon icon="mdi:timer-sand"></ha-icon>
                  ${S(e.compressor_protection_reason===`min_run`?`card.compressor_min_run`:`card.compressor_min_off`,this.hass.language,{minutes:wt(e.compressor_protection_until)})}
                </span>`}
          ${t?m`<span class="mpc-badge ${e.mpc_active?`active`:`learning`}">
                  <ha-icon .icon=${e.mpc_active?`mdi:brain`:`mdi:school-outline`}></ha-icon>
                  ${e.mpc_active?S(`card.mpc_active`,this.hass.language):S(`card.mpc_learning`,this.hass.language)}
                </span>`:h}
        </span>
      </div>
      ${!this.climateControlActive||this.config?.climate_control_enabled===!1?m`<div class="uncontrolled-hint">
              ${S(`card.not_controlled`,this.hass.language)}
            </div>`:h}
    `}_renderTargetInfo(e){if(e.target_temp===null&&e.heat_target===null)return h;let t=(this.config?.climate_mode??`auto`)===`auto`&&e.heat_target!=null&&e.cool_target!=null&&e.heat_target!==e.cool_target?m`<span class="target-value"
          >${D(e.heat_target,this.hass)} –
          ${D(e.cool_target,this.hass)}${C(this.hass)}</span
        >`:m`<span class="target-value"
          >${D(e.target_temp??e.heat_target,this.hass)}${C(this.hass)}</span
        >`;return m`
      <span class="target-info">
        ${S(`card.target`,this.hass.language)} ${t}
        ${e.override_active?m`<ha-icon class="override-icon" icon="mdi:timer-outline"></ha-icon>`:h}
        ${e.window_open?m`<ha-icon class="window-icon" icon="mdi:window-open-variant"></ha-icon>`:h}
        ${e.presence_away?m`<ha-icon class="away-icon" icon="mdi:home-off-outline"></ha-icon>`:e.occupancy_vacant&&!e.override_active?m`<ha-icon class="away-icon" icon="mdi:account-off-outline"></ha-icon>`:h}
      </span>
    `}_renderSensorOnly(){let e=this.config.live,t=this.config?.is_outdoor??!1;return m`
      <div class="temp-section">
        ${e.current_temp===null?m`<span class="no-temp">--</span>`:m`
                <span class="current-temp">${D(e.current_temp,this.hass)}</span>
                <span class="temp-unit">${C(this.hass)}</span>
              `}
      </div>
      <div class="card-footer">
        <span class="humidity-info">
          ${e.current_humidity===null?h:S(`card.humidity`,this.hass.language,{value:e.current_humidity.toFixed(0)})}
        </span>
        <span class="badge-row">
          ${t?m`<span class="outdoor-badge">
                  <ha-icon icon="mdi:tree"></ha-icon>
                  ${S(`card.outdoor`,this.hass.language)}
                </span>`:h}
          ${e.mold_risk_level&&e.mold_risk_level!==`ok`?m`<span class="mold-badge ${e.mold_risk_level}">
                  <ha-icon icon="mdi:water-alert"></ha-icon>
                  ${e.mold_risk_level===`critical`?S(`card.mold_critical`,this.hass.language):S(`card.mold_warning`,this.hass.language)}
                </span>`:h}
        </span>
      </div>
    `}_renderUnconfigured(e){let t=this.hass.language;if(!e)return m`<div class="device-summary empty">${S(`card.no_climate`,t)}</div>`;let n=this.climateEntityCount,r=this.tempSensorCount;return m`
      <div class="device-summary">
        ${n}
        ${S(n===1?`card.climate_device`:`card.climate_devices`,t)}${r>0?` \u00B7 ${r} ${S(r===1?`card.temp_sensor`:`card.temp_sensors`,t)}`:``}
      </div>
      <div class="configure-prompt">
        <span class="configure-text">${S(`card.tap_configure`,t)}</span>
        <span class="configure-arrow">›</span>
      </div>
    `}_onCardClick(){this.dispatchEvent(new CustomEvent(`area-selected`,{detail:{areaId:this.area.area_id},bubbles:!0,composed:!0}))}_onMoveUp(e){e.stopPropagation(),this.canMoveUp&&this.dispatchEvent(new CustomEvent(`move-room-up`,{detail:{areaId:this.area.area_id},bubbles:!0,composed:!0}))}_onMoveDown(e){e.stopPropagation(),this.canMoveDown&&this.dispatchEvent(new CustomEvent(`move-room-down`,{detail:{areaId:this.area.area_id},bubbles:!0,composed:!0}))}_onHideClick(e){e.stopPropagation(),this.dispatchEvent(new CustomEvent(`hide-room`,{detail:{areaId:this.area.area_id},bubbles:!0,composed:!0}))}};A([y({attribute:!1})],M.prototype,`area`,void 0),A([y({attribute:!1})],M.prototype,`config`,void 0),A([y({type:Number})],M.prototype,`climateEntityCount`,void 0),A([y({type:Number})],M.prototype,`tempSensorCount`,void 0),A([y({attribute:!1})],M.prototype,`hass`,void 0),A([y({type:String})],M.prototype,`controlMode`,void 0),A([y({type:Boolean})],M.prototype,`climateControlActive`,void 0),A([y({type:Boolean})],M.prototype,`reordering`,void 0),A([y({type:Boolean})],M.prototype,`canMoveUp`,void 0),A([y({type:Boolean})],M.prototype,`canMoveDown`,void 0),M=A([v(`rs-area-card`)],M);var At={ATTRIBUTE:1,CHILD:2,PROPERTY:3,BOOLEAN_ATTRIBUTE:4,EVENT:5,ELEMENT:6},jt=e=>(...t)=>({_$litDirective$:e,values:t}),Mt=class{constructor(e){}get _$AU(){return this._$AM._$AU}_$AT(e,t,n){this._$Ct=e,this._$AM=t,this._$Ci=n}_$AS(e,t){return this.update(e,t)}update(e,t){return this.render(...t)}};$e();var Nt=class extends Mt{constructor(e){if(super(e),this.it=h,e.type!==At.CHILD)throw Error(this.constructor.directiveName+`() can only be used in child bindings`)}render(e){if(e===h||e==null)return this._t=void 0,this.it=e;if(e===ze)return e;if(typeof e!=`string`)throw Error(this.constructor.directiveName+`() called with a non-string value`);if(e===this.it)return this._t;this.it=e;let t=[e];return t.raw=t,this._t={_$litType$:this.constructor.resultType,strings:t,values:[]}}};Nt.directiveName=`unsafeHTML`,Nt.resultType=1;var N=jt(Nt);_(),x(),j();var Pt=class extends g{constructor(...e){super(...e),this.text=``,this.icon=`mdi:information-outline`,this._open=!1,this._style=`visibility: hidden;`,this._onDocPointer=e=>{e.composedPath().includes(this)||this._close()},this._onKey=e=>{e.key===`Escape`&&(e.stopPropagation(),this._close())},this._onScroll=()=>this._close()}disconnectedCallback(){super.disconnectedCallback(),this._removeListeners()}static{this.styles=l`
    :host {
      display: inline-flex;
      position: relative;
      vertical-align: middle;
      line-height: 0;
    }

    button {
      background: none;
      border: none;
      padding: 2px;
      margin: 0;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      color: var(--secondary-text-color);
      opacity: 0.65;
      transition:
        opacity 0.15s,
        color 0.15s,
        background 0.15s;
      border-radius: 50%;
      line-height: 0;
    }

    button:hover,
    button:focus-visible {
      opacity: 1;
      color: var(--primary-color);
      background: rgba(3, 169, 244, 0.1);
      outline: none;
    }

    button.open {
      opacity: 1;
      color: var(--primary-color);
      background: rgba(3, 169, 244, 0.12);
    }

    ha-icon {
      --mdc-icon-size: 16px;
    }

    .tooltip {
      position: fixed;
      z-index: 1100;
      max-width: 280px;
      min-width: 180px;
      width: max-content;
      padding: 10px 12px;
      background: var(--card-background-color, #1f1f1f);
      border: 1px solid var(--divider-color, rgba(255, 255, 255, 0.12));
      border-radius: 8px;
      font-size: 12px;
      font-weight: 400;
      line-height: 1.5;
      letter-spacing: normal;
      text-transform: none;
      color: var(--primary-text-color);
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
      white-space: normal;
      pointer-events: auto;
      animation: tooltip-fade 0.15s ease-out;
    }

    @keyframes tooltip-fade {
      from {
        opacity: 0;
      }
      to {
        opacity: 1;
      }
    }
  `}render(){return m`
      <button
        type="button"
        class=${this._open?`open`:``}
        @click=${this._toggle}
        aria-label="Info"
        aria-expanded=${this._open?`true`:`false`}
      >
        <ha-icon .icon=${this.icon}></ha-icon>
      </button>
      ${this._open?m`<div
              class="tooltip"
              role="tooltip"
              style=${this._style}
              @click=${e=>e.stopPropagation()}
            >
              ${this.text?this.text:h}<slot></slot>
            </div>`:h}
    `}_toggle(e){e.stopPropagation(),this._open?this._close():this._openTooltip()}_openTooltip(){this._open=!0,this._style=`visibility: hidden;`,requestAnimationFrame(()=>{this._positionTooltip()}),setTimeout(()=>{document.addEventListener(`pointerdown`,this._onDocPointer,!0),document.addEventListener(`keydown`,this._onKey,!0),document.addEventListener(`scroll`,this._onScroll,!0),window.addEventListener(`resize`,this._onScroll,!0)},0)}_positionTooltip(){let e=this.renderRoot.querySelector(`.tooltip`),t=this.renderRoot.querySelector(`button`);if(!e||!t)return;let n=t.getBoundingClientRect(),r=e.getBoundingClientRect(),i=window.innerWidth,a=window.innerHeight,o=a-n.bottom,s=n.top,c;c=o>=r.height+8?n.bottom+6:s>=r.height+8?n.top-r.height-6:Math.max(8,(a-r.height)/2);let l=n.left+n.width/2-r.width/2;l=Math.max(8,Math.min(l,i-r.width-8)),this._style=`top: ${c}px; left: ${l}px;`}_close(){this._open&&(this._open=!1,this._style=`visibility: hidden;`,this._removeListeners())}_removeListeners(){document.removeEventListener(`pointerdown`,this._onDocPointer,!0),document.removeEventListener(`keydown`,this._onKey,!0),document.removeEventListener(`scroll`,this._onScroll,!0),window.removeEventListener(`resize`,this._onScroll,!0)}};A([y({type:String})],Pt.prototype,`text`,void 0),A([y({type:String})],Pt.prototype,`icon`,void 0),A([b()],Pt.prototype,`_open`,void 0),A([b()],Pt.prototype,`_style`,void 0),Pt=A([v(`rs-info-icon`)],Pt),_(),x(),j();var Ft=`M20.71,7.04C21.1,6.65 21.1,6 20.71,5.63L18.37,3.29C18,2.9 17.35,2.9 16.96,3.29L15.12,5.12L18.87,8.87M3,17.25V21H6.75L17.81,9.93L14.06,6.18L3,17.25Z`,It=`M21,7L9,19L3.5,13.5L4.91,12.09L9,16.17L19.59,5.59L21,7Z`,P=class extends g{constructor(...e){super(...e),this.config=null,this.climateControlActive=!0,this.isOutdoor=!1,this.overrideInfo=null,this._countdown=``,this._editingName=!1,this._nameInput=``,this._controlModeInfoExpanded=!1}static{this.styles=[Tt,l`
      :host {
        display: block;
      }

      ha-card {
        padding: 28px 24px;
        position: relative;
        overflow: hidden;
      }

      .hero-accent {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 4px;
      }

      .hero-accent-heating {
        background: linear-gradient(90deg, var(--warning-color, #ff9800), #ffb74d);
      }

      .hero-accent-cooling {
        background: linear-gradient(90deg, #2196f3, #64b5f6);
      }

      .hero-accent-idle {
        background: linear-gradient(90deg, var(--disabled-text-color, #bdbdbd), #e0e0e0);
      }

      .hero-accent-none {
        background: var(--divider-color, #e0e0e0);
      }

      .hero-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 16px;
      }

      .area-name {
        font-size: 22px;
        font-weight: 400;
        color: var(--primary-text-color);
        margin: 0;
      }

      .hero-temps {
        display: flex;
        align-items: baseline;
        gap: 8px;
      }

      .hero-current {
        font-size: 48px;
        font-weight: 300;
        color: var(--primary-text-color);
        line-height: 1;
      }

      .hero-unit {
        font-size: 24px;
        font-weight: 300;
        color: var(--secondary-text-color);
      }

      .hero-target {
        margin-left: auto;
        text-align: right;
      }

      .hero-target-label {
        font-size: 12px;
        color: var(--secondary-text-color);
        text-transform: uppercase;
        letter-spacing: 0.5px;
      }

      .hero-target-value {
        font-size: 22px;
        font-weight: 400;
        color: var(--primary-text-color);
      }

      /* Override-aware target styling */
      .hero-target-label.override-boost {
        color: var(--warning-color, #ff9800);
      }

      .hero-target-label.override-eco {
        color: #4caf50;
      }

      .hero-target-label.override-custom {
        color: #2196f3;
      }

      .hero-target-label ha-icon {
        --mdc-icon-size: 12px;
        vertical-align: middle;
      }

      .hero-target-countdown {
        font-size: 11px;
        color: var(--secondary-text-color);
        margin-top: 2px;
      }

      .hero-metric {
        display: flex;
        align-items: center;
        gap: 4px;
        font-size: 14px;
        color: var(--secondary-text-color);
        margin-top: 6px;
      }

      .hero-metric ha-icon {
        --mdc-icon-size: 16px;
        flex-shrink: 0;
      }

      .hero-metric.warning {
        color: var(--warning-color, #ff9800);
      }

      .hero-metric.critical {
        color: var(--error-color, #db4437);
      }

      .hero-metric.info {
        color: var(--info-color, #2196f3);
      }

      .hero-no-data {
        font-size: 14px;
        color: var(--disabled-text-color, #9e9e9e);
        font-style: italic;
        padding: 8px 0;
      }

      .hero-window-open {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 6px 10px;
        margin-bottom: 12px;
        border-radius: 8px;
        font-size: 13px;
        font-weight: 500;
        color: var(--warning-color, #ff9800);
        background: rgba(255, 152, 0, 0.1);
      }

      .hero-window-open ha-icon {
        --mdc-icon-size: 18px;
      }

      .name-row {
        display: flex;
        align-items: center;
        gap: 4px;
      }

      .name-edit-btn {
        --mdc-icon-button-size: 28px;
        --mdc-icon-size: 16px;
        color: var(--secondary-text-color);
        opacity: 0;
        transition: opacity 0.15s;
      }

      .name-row:hover .name-edit-btn {
        opacity: 1;
      }

      @media (hover: none) {
        .name-edit-btn {
          opacity: 0.5;
        }
      }

      .name-edit-row {
        display: flex;
        align-items: center;
        gap: 4px;
      }

      .name-input {
        font-size: 22px;
        font-weight: 400;
        color: var(--primary-text-color);
        background: transparent;
        border: none;
        border-bottom: 2px solid var(--primary-color);
        outline: none;
        padding: 0 0 2px;
        width: 100%;
        font-family: inherit;
      }

      .name-done-btn {
        --mdc-icon-button-size: 28px;
        --mdc-icon-size: 16px;
        color: var(--primary-color);
      }

      .name-clear-btn {
        background: none;
        border: none;
        color: var(--secondary-text-color);
        font-size: 12px;
        cursor: pointer;
        padding: 2px 0;
        text-decoration: underline;
      }

      .hero-status-pills {
        display: flex;
        flex-direction: column;
        align-items: flex-end;
        gap: 2px;
        flex-shrink: 0;
      }
      .control-mode-badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        font-size: 11px;
        color: var(--secondary-text-color);
        cursor: pointer;
      }
      .control-mode-info-icon {
        --mdc-icon-size: 14px;
        opacity: 0.4;
      }
      .control-mode-badge:hover .control-mode-info-icon,
      .control-mode-info-icon.active {
        opacity: 0.8;
      }
      .control-mode-info-panel {
        padding: 8px 12px;
        margin-bottom: 8px;
        font-size: 12px;
        line-height: 1.5;
        color: var(--secondary-text-color);
        background: var(--secondary-background-color);
        border-radius: 8px;
      }

      .learning-paused rs-info-icon {
        margin-left: 2px;
      }

      .uncontrolled-hint {
        font-size: 12px;
        color: var(--disabled-text-color, #9e9e9e);
        margin-top: 8px;
      }
    `]}disconnectedCallback(){super.disconnectedCallback(),this._clearCountdownTimer()}updated(e){(e.has(`overrideInfo`)||e.has(`config`))&&this._updateCountdown()}_clearCountdownTimer(){this._countdownTimer&&=(clearInterval(this._countdownTimer),void 0)}_getOverrideUntil(){return this.overrideInfo?.active?this.overrideInfo.until:null}_updateCountdown(){if(this._clearCountdownTimer(),!this._getOverrideUntil()){let e=this._getEffectiveOverride();this._countdown=e?S(`hero.permanent`,this.hass?.language??`en`):``;return}let e=()=>{let e=this._getOverrideUntil();if(!e){this._countdown=``,this._clearCountdownTimer();return}let t=e-Date.now()/1e3;if(t<=0){this._countdown=``,this._clearCountdownTimer();return}let n=Math.floor(t/3600),r=Math.floor(t%3600/60);this._countdown=n>0?`${n}h ${r}m`:`${r}m`};e(),this._countdownTimer=setInterval(e,3e4)}_getEffectiveOverride(){return this.overrideInfo?.active?this.overrideInfo:null}_renderTargetSection(e){let t=e.target_temp,n=this.hass?.language??`en`,r=this._getEffectiveOverride();if(r){let e=r.type===`boost`?`mdi:fire`:r.type===`eco`?`mdi:leaf`:`mdi:thermometer`,i=r.type===`boost`?S(`override.comfort`,n):r.type===`eco`?S(`override.eco`,n):S(`override.custom`,n),a=`override-${r.type}`,o=r.heat,s=r.cool,c=o!=null&&s!=null&&o!==s,l=o??s??t;return m`
        <div class="hero-target">
          <div class="hero-target-label ${a}">
            <ha-icon icon=${e}></ha-icon>
            ${i} ${S(`hero.override`,n)}
          </div>
          <div class="hero-target-value">
            ${c?m`${D(o,this.hass)} –
                  ${D(s,this.hass)}${C(this.hass)}`:l===null?`--`:m`${D(l,this.hass)}${C(this.hass)}`}
          </div>
          ${this._countdown?m`<div class="hero-target-countdown">
                  ${S(`hero.remaining`,n,{time:this._countdown})}
                </div>`:h}
        </div>
      `}if(t!==null||e.heat_target!=null&&e.cool_target!=null){let r=(this.config?.climate_mode??`auto`)===`auto`&&e.heat_target!=null&&e.cool_target!=null&&e.heat_target!==e.cool_target?m`${D(e.heat_target,this.hass)} –
          ${D(e.cool_target,this.hass)}${C(this.hass)}`:m`${D(t??e.heat_target,this.hass)}${C(this.hass)}`;return m`
        <div class="hero-target">
          <div class="hero-target-label">${S(`hero.target`,n)}</div>
          <div class="hero-target-value">${r}</div>
        </div>
      `}return h}_toggleControlModeInfo(){this._controlModeInfoExpanded=!this._controlModeInfoExpanded}_onEditName(){this._nameInput=this.config?.display_name||``,this._editingName=!0,this.updateComplete.then(()=>{let e=this.renderRoot.querySelector(`.name-input`);e?.focus(),e?.select()})}_onNameInput(e){this._nameInput=e.target.value}_onNameKeydown(e){e.key===`Enter`?this._onNameDone():e.key===`Escape`&&(this._editingName=!1)}_onNameDone(){let e=this._nameInput.trim();this.dispatchEvent(new CustomEvent(`display-name-changed`,{detail:{value:e},bubbles:!0,composed:!0})),this._editingName=!1}_onNameClear(){this.dispatchEvent(new CustomEvent(`display-name-changed`,{detail:{value:``},bubbles:!0,composed:!0})),this._editingName=!1,this._nameInput=``}render(){let e=this.config?.live,t=e?.mode;return m`
      <ha-card>
        <div class="hero-accent ${e?t===`heating`?`hero-accent-heating`:t===`cooling`?`hero-accent-cooling`:`hero-accent-idle`:`hero-accent-none`}"></div>
        <div class="hero-header">
          ${this._editingName?m`
                  <div class="name-edit-row">
                    <input
                      class="name-input"
                      type="text"
                      .value=${this._nameInput}
                      placeholder=${S(`room.alias.placeholder`,this.hass?.language??`en`)}
                      @input=${this._onNameInput}
                      @keydown=${this._onNameKeydown}
                    />
                    <ha-icon-button
                      class="name-done-btn"
                      .path=${It}
                      @click=${this._onNameDone}
                    ></ha-icon-button>
                  </div>
                  ${this.config?.display_name?m`<button class="name-clear-btn" @click=${this._onNameClear}>
                          ${S(`room.alias.clear`,this.hass?.language??`en`)}
                        </button>`:h}
                `:m`
                  <div class="name-row">
                    <h2 class="area-name">${this.config?.display_name||this.area.name}</h2>
                    <ha-icon-button
                      class="name-edit-btn"
                      .path=${Ft}
                      @click=${this._onEditName}
                    ></ha-icon-button>
                  </div>
                `}
          ${this.isOutdoor?h:m`
                  <div class="hero-status-pills">
                    ${e?m`
                            <span class="mode-pill ${xt(e.mode)}">
                              <span class="mode-dot"></span>
                              ${Ct(e.mode,this.hass?.language??`en`)}${e.heating_power>0&&e.heating_power<100?m` ${e.heating_power}%`:h}
                            </span>
                          `:h}
                    ${this.config?m`
                            <span class="control-mode-badge" @click=${this._toggleControlModeInfo}>
                              ${this.config.temperature_sensor?S(`room.control_mode.full_control`,this.hass?.language??`en`):S(`room.control_mode.managed`,this.hass?.language??`en`)}
                              <ha-icon
                                class="control-mode-info-icon ${this._controlModeInfoExpanded?`active`:``}"
                                icon="mdi:information-outline"
                              ></ha-icon>
                            </span>
                          `:h}
                  </div>
                `}
        </div>
        ${this._controlModeInfoExpanded&&this.config&&!this.isOutdoor?m`
                <div class="control-mode-info-panel">
                  ${this.config.temperature_sensor?S(`room.control_mode.full_control_info`,this.hass?.language??`en`):S(`room.control_mode.managed_info`,this.hass?.language??`en`)}
                </div>
              `:h}
        ${e?m`
                ${e.window_open&&!this.isOutdoor?m`<div class="hero-window-open">
                        <ha-icon icon="mdi:window-open-variant"></ha-icon>
                        ${S(`hero.window_open`,this.hass?.language??`en`)}
                      </div>`:h}
                <div class="hero-temps">
                  ${e.current_temp===null?m`<span class="hero-current" style="opacity: 0.3">--</span>`:m`
                          <span class="hero-current"
                            >${D(e.current_temp,this.hass)}</span
                          >
                          <span class="hero-unit">${C(this.hass)}</span>
                        `}
                  ${this.isOutdoor?h:this._renderTargetSection(e)}
                </div>
                ${e.current_humidity===null?h:m`<div class="hero-metric">
                        <ha-icon icon="mdi:water-percent"></ha-icon>
                        ${S(`hero.humidity`,this.hass?.language??`en`,{value:e.current_humidity.toFixed(0)})}
                      </div>`}
                ${e.device_setpoint!=null&&!this.isOutdoor?m`<div class="hero-metric">
                        <ha-icon
                          icon=${e.mode===`cooling`?`mdi:snowflake`:`mdi:radiator`}
                        ></ha-icon>
                        ${S(`hero.device_setpoint`,this.hass?.language??`en`,{value:D(e.device_setpoint,this.hass),unit:C(this.hass)})}
                      </div>`:h}
                ${e.active_heat_sources&&e.active_heat_sources!==`none`&&!this.isOutdoor?m`<div class="hero-metric">
                        <ha-icon icon="mdi:swap-horizontal"></ha-icon>
                        ${e.active_heat_sources===`primary`?S(`hero.heat_source_primary`,this.hass?.language??`en`):e.active_heat_sources===`secondary`?S(`hero.heat_source_secondary`,this.hass?.language??`en`):S(`hero.heat_source_both`,this.hass?.language??`en`)}
                      </div>`:h}
                ${e.compressor_protection_active&&!this.isOutdoor?m`<div class="hero-metric info">
                        <ha-icon icon="mdi:timer-sand"></ha-icon>
                        ${S(e.compressor_protection_reason===`min_run`?e.compressor_protection_until==null?`hero.compressor_protection_min_run`:`hero.compressor_protection_min_run_left`:e.compressor_protection_until==null?`hero.compressor_protection_min_off`:`hero.compressor_protection_min_off_left`,this.hass?.language??`en`,{minutes:wt(e.compressor_protection_until)})}
                        <rs-info-icon
                          icon="mdi:information-outline"
                          .text=${S(`hero.compressor_protection_info`,this.hass?.language??`en`)}
                        ></rs-info-icon>
                      </div>`:h}
                ${e.coil_dry_active&&!this.isOutdoor?m`<div class="hero-metric info">
                        <ha-icon icon="mdi:air-filter"></ha-icon>
                        ${S(e.coil_dry_phase===`drain`?`hero.coil_dry_drain`:`hero.coil_dry`,this.hass?.language??`en`,{minutes:wt(e.coil_dry_until)})}
                        <rs-info-icon
                          icon="mdi:information-outline"
                          .text=${S(`hero.coil_dry_info`,this.hass?.language??`en`)}
                        ></rs-info-icon>
                      </div>`:h}
                ${e.mold_surface_rh!=null&&!this.isOutdoor?m`<div
                        class="hero-metric ${e.mold_risk_level===`critical`?`critical`:e.mold_risk_level===`warning`?`warning`:``}"
                      >
                        <ha-icon icon="mdi:water-alert"></ha-icon>
                        ${S(`room.mold_surface_rh`,this.hass?.language??`en`,{value:String(e.mold_surface_rh.toFixed(0))})}
                        ${e.mold_surface_temp==null?h:m`·
                              ${S(`room.mold_surface_temp`,this.hass?.language??`en`,{value:D(e.mold_surface_temp,this.hass),unit:C(this.hass)})}`}
                      </div>`:h}
                ${e.mold_prevention_active&&!this.isOutdoor?m`<div class="hero-metric info">
                        <ha-icon icon="mdi:shield-check"></ha-icon>
                        ${S(`card.mold_prevention`,this.hass?.language??`en`,{delta:E(e.mold_prevention_delta,this.hass).toFixed(0),unit:C(this.hass)})}
                      </div>`:h}
                ${e.learning_paused_reason===`outdoor_unavailable`&&!this.isOutdoor?m`<div class="hero-metric warning learning-paused">
                        <ha-icon icon="mdi:school-outline"></ha-icon>
                        ${S(`hero.mpc_learning_paused`,this.hass?.language??`en`)}
                        <rs-info-icon
                          icon="mdi:information-outline"
                          .text=${S(`hero.mpc_learning_paused.outdoor_unavailable`,this.hass?.language??`en`)}
                        ></rs-info-icon>
                      </div>`:h}
                ${!this.climateControlActive&&!this.isOutdoor?m`<div class="uncontrolled-hint">
                        ${S(`card.not_controlled`,this.hass?.language??`en`)}
                      </div>`:h}
              `:this.config?m`<div class="hero-no-data">
                  ${S(`hero.waiting`,this.hass?.language??`en`)}
                </div>`:m`<div class="hero-no-data">
                  ${S(`hero.not_configured`,this.hass?.language??`en`)}
                </div>`}
      </ha-card>
    `}};A([y({attribute:!1})],P.prototype,`hass`,void 0),A([y({attribute:!1})],P.prototype,`area`,void 0),A([y({attribute:!1})],P.prototype,`config`,void 0),A([y({type:Boolean})],P.prototype,`climateControlActive`,void 0),A([y({type:Boolean})],P.prototype,`isOutdoor`,void 0),A([y({attribute:!1})],P.prototype,`overrideInfo`,void 0),A([b()],P.prototype,`_countdown`,void 0),A([b()],P.prototype,`_editingName`,void 0),A([b()],P.prototype,`_nameInput`,void 0),A([b()],P.prototype,`_controlModeInfoExpanded`,void 0),P=A([v(`rs-hero-status`)],P),_(),x(),j();var Lt=class extends g{constructor(...e){super(...e),this.climateMode=`auto`,this.language=`en`}static{this.styles=l`
    :host {
      display: block;
    }

    .mode-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 10px;
    }

    .mode-card {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 8px;
      padding: 14px 8px;
      border: 2px solid var(--divider-color, #e0e0e0);
      border-radius: 12px;
      cursor: pointer;
      transition:
        border-color 0.2s,
        background 0.2s,
        box-shadow 0.2s;
      background: transparent;
      font-family: inherit;
      color: var(--primary-text-color);
      text-align: center;
    }

    .mode-card:hover {
      border-color: var(--primary-color, #03a9f4);
      box-shadow: 0 2px 8px rgba(3, 169, 244, 0.1);
    }

    .mode-card[active] {
      border-color: var(--primary-color, #03a9f4);
      background: rgba(3, 169, 244, 0.06);
      box-shadow: 0 2px 8px rgba(3, 169, 244, 0.12);
    }

    .mode-card-icon {
      --mdc-icon-size: 24px;
    }

    .mode-card[active] .mode-card-icon {
      color: var(--primary-color, #03a9f4);
    }

    .mode-card-label {
      font-weight: 500;
      font-size: 13px;
    }

    .mode-card[active] .mode-card-label {
      color: var(--primary-color, #03a9f4);
    }
  `}render(){let e=this.language;return m`
      <div class="mode-grid">
        ${[{value:`auto`,labelKey:`mode.auto`,icon:`mdi:autorenew`},{value:`heat_only`,labelKey:`mode.heat_only`,icon:`mdi:fire`},{value:`cool_only`,labelKey:`mode.cool_only`,icon:`mdi:snowflake`}].map(t=>m`
            <button
              class="mode-card"
              ?active=${this.climateMode===t.value}
              @click=${()=>this._onModeClick(t.value)}
            >
              <ha-icon class="mode-card-icon" icon=${t.icon}></ha-icon>
              <div class="mode-card-label">${S(t.labelKey,e)}</div>
            </button>
          `)}
      </div>
    `}_onModeClick(e){this.dispatchEvent(new CustomEvent(`mode-changed`,{detail:{mode:e},bubbles:!0,composed:!0}))}};A([y({type:String})],Lt.prototype,`climateMode`,void 0),A([y({type:String})],Lt.prototype,`language`,void 0),Lt=A([v(`rs-climate-mode-selector`)],Lt);function F(e){return e.detail?.value??e.target.value??``}function I(e,t){e.dispatchEvent(new CustomEvent(`save-status`,{detail:{status:t},bubbles:!0,composed:!0}))}function Rt(e,t){e.dispatchEvent(new CustomEvent(`hass-more-info`,{bubbles:!0,composed:!0,detail:{entityId:t}}))}_(),x(),j();var zt=class e extends g{constructor(...e){super(...e),this.activeIndex=-1,this.selectorEntity=``,this.editing=!1}static{this.sharedStyles=l`
    :host {
      display: block;
    }

    .schedule-list {
      display: flex;
      flex-direction: column;
      gap: 8px;
      margin-bottom: 12px;
    }

    .schedule-row {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 10px 14px;
      border-radius: 8px;
      transition:
        background 0.3s,
        opacity 0.3s;
    }

    .schedule-row.active {
      background: rgba(76, 175, 80, 0.1);
    }
    .schedule-row.inactive {
      background: rgba(0, 0, 0, 0.04);
    }
    .schedule-row.unreachable {
      background: rgba(0, 0, 0, 0.02);
      opacity: 0.4;
    }

    .schedule-number {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      font-size: 12px;
      font-weight: 500;
      width: 20px;
      height: 20px;
      border-radius: 50%;
      background: var(--divider-color, #e0e0e0);
      color: var(--primary-text-color);
      flex-shrink: 0;
    }
    .schedule-row.active .schedule-number {
      background: #4caf50;
      color: #fff;
    }

    .schedule-status-dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      flex-shrink: 0;
    }
    .schedule-row.active .schedule-status-dot {
      background: #4caf50;
      box-shadow: 0 0 6px rgba(76, 175, 80, 0.5);
    }
    .schedule-row.inactive .schedule-status-dot {
      background: var(--disabled-text-color, #bdbdbd);
    }
    .schedule-row.unreachable .schedule-status-dot {
      background: var(--disabled-text-color, #bdbdbd);
    }

    .schedule-name {
      flex: 1;
      font-size: 14px;
      font-weight: 500;
      min-width: 0;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .schedule-link {
      cursor: pointer;
    }
    .schedule-link:hover {
      text-decoration: underline;
    }
    .schedule-row.active .schedule-name {
      color: var(--primary-text-color);
    }
    .schedule-row.inactive .schedule-name {
      color: var(--secondary-text-color);
    }
    .schedule-row.unreachable .schedule-name {
      color: var(--secondary-text-color);
    }

    .schedule-status {
      font-size: 12px;
      white-space: nowrap;
    }
    .schedule-row.active .schedule-status {
      color: #2e7d32;
    }
    .schedule-row.inactive .schedule-status {
      color: var(--secondary-text-color);
    }
    .schedule-row.unreachable .schedule-status {
      color: var(--secondary-text-color);
    }

    .schedule-controls {
      display: flex;
      align-items: center;
      gap: 2px;
      flex-shrink: 0;
    }
    .schedule-controls ha-icon-button {
      --mdc-icon-button-size: 28px;
      --mdc-icon-size: 16px;
    }

    .add-schedule-row {
      margin-top: 4px;
    }
    .add-schedule-row ha-select {
      width: 100%;
    }

    .helper-link {
      display: inline-block;
      margin-top: 4px;
      font-size: 12px;
      color: var(--primary-color);
      text-decoration: none;
    }
    .helper-link:hover {
      text-decoration: underline;
    }

    .no-schedules {
      font-size: 13px;
      color: var(--secondary-text-color);
      padding: 12px 0;
      text-align: center;
    }

    .form-label {
      display: block;
      font-size: 13px;
      font-weight: 500;
      color: var(--secondary-text-color);
      margin-bottom: 6px;
      text-transform: uppercase;
      letter-spacing: 0.3px;
    }

    .selector-section {
      margin-top: 16px;
    }

    .selector-value {
      font-size: 12px;
      color: var(--secondary-text-color);
      margin-top: 4px;
      padding-left: 4px;
    }

    /* .inline-warning is the same pill outside the selector context (#395). */
    .selector-warning,
    .inline-warning {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-top: 8px;
      padding: 10px 14px;
      border-radius: 8px;
      background: rgba(255, 152, 0, 0.08);
      color: var(--warning-color, #ff9800);
      font-size: 13px;
    }
    .selector-warning ha-icon,
    .inline-warning ha-icon {
      --mdc-icon-size: 18px;
      flex-shrink: 0;
    }

    .section-hint {
      font-size: 12px;
      color: var(--secondary-text-color);
      line-height: 1.5;
      margin-bottom: 12px;
    }
  `}static{this.ICON_CLOSE=`M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z`}static{this.ICON_UP=`M7.41,15.41L12,10.83L16.59,15.41L18,14L12,8L6,14L7.41,15.41Z`}static{this.ICON_DOWN=`M7.41,8.58L12,13.17L16.59,8.58L18,10L12,16L6,10L7.41,8.58Z`}_getScheduleState(e,t){if(t===0)return`inactive`;if(e===this.activeIndex)return`active`;if(!this.selectorEntity)return e===0?`active`:`unreachable`;let n=this.hass?.states?.[this.selectorEntity];if(!n)return`inactive`;if(this.selectorEntity.startsWith(`input_boolean.`))return e<=1?`inactive`:`unreachable`;if(this.selectorEntity.startsWith(`input_number.`)){let r=Number(n.attributes?.min??1),i=Number(n.attributes?.max??t);return e+1>=r&&e+1<=i?`inactive`:`unreachable`}return`inactive`}_getAvailableEntities(e){return this.hass?.states?Object.keys(this.hass.states).filter(t=>t.startsWith(`schedule.`)&&!e.has(t)):[]}_getFriendlyName(e){return this.hass?.states?.[e]?.attributes?.friendly_name||e}_renderAddRow(e,t,n,r){return m`
      <div class="add-schedule-row">
        <ha-select
          .value=${``}
          .label=${e}
          .options=${t.map(e=>({value:e,label:this._getFriendlyName(e)}))}
          @selected=${e=>{let t=F(e);t&&(n(t),requestAnimationFrame(()=>{e.target.value=``}))}}
          @closed=${e=>e.stopPropagation()}
          fixedMenuPosition
          naturalMenuWidth
        >
          ${t.map(e=>m`
              <ha-list-item value=${e}>${this._getFriendlyName(e)}</ha-list-item>
            `)}
        </ha-select>
        <a href="/config/helpers" target="_top" class="helper-link"> ${r} </a>
      </div>
    `}_renderSelectorSection(e,t,n,r,i){if(e<2)return h;let a=this.selectorEntity?this.hass?.states?.[this.selectorEntity]:null;return m`
      <div class="selector-section">
        <label class="form-label">${t}</label>
        <ha-entity-picker
          .hass=${this.hass}
          .value=${this.selectorEntity}
          .includeDomains=${[`input_boolean`,`input_number`]}
          allow-custom-entity
          @value-changed=${e=>{e.stopPropagation(),i(e.detail?.value??``)}}
        ></ha-entity-picker>
        ${this.selectorEntity&&a?m`
                <div class="selector-value">
                  ${this.selectorEntity.startsWith(`input_boolean.`)?S(`schedule.selector_value_boolean`,this.hass.language,{value:a.state===`on`?`On`:`Off`}):S(`schedule.selector_value_number`,this.hass.language,{value:a.state})}
                </div>
              `:h}
        <div class="section-hint" style="margin-top:4px">${n}</div>
        ${e>1&&!this.selectorEntity?m`
                <div class="selector-warning">
                  <ha-icon icon="mdi:alert-outline"></ha-icon>
                  ${r}
                </div>
              `:h}
      </div>
    `}_renderScheduleControls(t,n,r,i){let a=n>=2;return m`
      <span class="schedule-controls">
        ${a&&t>0?m`
                <ha-icon-button
                  .path=${e.ICON_UP}
                  @click=${()=>r(t,-1)}
                ></ha-icon-button>
              `:h}
        ${a&&t<n-1?m`
                <ha-icon-button
                  .path=${e.ICON_DOWN}
                  @click=${()=>r(t,1)}
                ></ha-icon-button>
              `:h}
        <ha-icon-button
          .path=${e.ICON_CLOSE}
          @click=${()=>i(t)}
        ></ha-icon-button>
      </span>
    `}_openEntityInfo(e){Rt(this,e)}};A([y({attribute:!1})],zt.prototype,`hass`,void 0),A([y({type:Number})],zt.prototype,`activeIndex`,void 0),A([y({type:String})],zt.prototype,`selectorEntity`,void 0),A([y({type:Boolean})],zt.prototype,`editing`,void 0),_();var L=l`
  ha-textfield,
  ha-select,
  ha-entity-picker,
  ha-combo-box {
    --mdc-shape-small: 8px;
    --mdc-shape-medium: 8px;
    --md-filled-text-field-container-shape: 8px;
    --md-outlined-text-field-container-shape: 8px;
    display: block;
    border-radius: 8px;
    overflow: hidden;
    isolation: isolate;
    /* clip-path is more reliable than overflow:hidden for shape clipping
       on the bottom corners of MDC filled inputs. */
    clip-path: inset(0 round 8px);
  }

  /* ha-entity-picker wraps an inner ha-combo-box that doesn't always
     reach the host's bottom edge. Use a tighter clip so the visible
     input's bottom matches the inner's top radius. */
  ha-entity-picker {
    clip-path: inset(0 round 8px 8px 4px 4px);
  }
`;_(),x(),j();var Bt=`M20.71,7.04C21.1,6.65 21.1,6 20.71,5.63L18.37,3.29C18,2.9 17.35,2.9 16.96,3.29L15.12,5.12L18.87,8.87M3,17.25V21H6.75L17.81,9.93L14.06,6.18L3,17.25Z`,Vt=`M19,19V8H5V19H19M16,1H18V3H19A2,2 0 0,1 21,5V19A2,2 0 0,1 19,21H5C3.89,21 3,20.1 3,19V5C3,3.89 3.89,3 5,3H6V1H8V3H16V1M11,9.5H13V12.5H16V14.5H13V17.5H11V14.5H8V12.5H11V9.5Z`,Ht=[`monday`,`tuesday`,`wednesday`,`thursday`,`friday`,`saturday`,`sunday`],R=class extends zt{constructor(...e){super(...e),this.schedules=[],this.comfortHeat=21,this.comfortCool=24,this.ecoHeat=17,this.ecoCool=27,this.climateMode=`auto`,this.scheduleTempWarnings=[],this.hideHeatTemps=!1}set scheduleSelectorEntity(e){this.selectorEntity=e}get scheduleSelectorEntity(){return this.selectorEntity}set activeScheduleIndex(e){this.activeIndex=e}get activeScheduleIndex(){return this.activeIndex}static{this.styles=[zt.sharedStyles,L,l`
      .create-schedule-btn {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        margin: 0 0 12px;
        padding: 6px 12px;
        border-radius: 8px;
        border: 1px dashed var(--primary-color);
        background: none;
        color: var(--primary-color);
        font: inherit;
        font-size: 13px;
        cursor: pointer;
      }
      .create-schedule-btn ha-svg-icon {
        --mdc-icon-size: 18px;
      }
      .edit-schedule-btn {
        --mdc-icon-button-size: 28px;
        --mdc-icon-size: 16px;
        flex-shrink: 0;
      }

      .fallback-hint {
        font-size: 11px;
        color: var(--secondary-text-color);
        margin-top: 4px;
        font-style: italic;
      }

      .temp-inputs {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 16px;
        margin-top: 16px;
      }

      .temp-input-group {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }

      ha-textfield {
        flex: 1;
      }

      .view-temps {
        display: flex;
        gap: 16px;
        font-size: 13px;
        color: var(--secondary-text-color);
        margin-top: 12px;
        padding-top: 12px;
        border-top: 1px solid var(--divider-color, #eee);
      }

      .view-temps span {
        font-weight: 500;
        color: var(--primary-text-color);
      }

      .view-selector-info {
        font-size: 12px;
        color: var(--secondary-text-color);
        margin-top: 8px;
      }

      .temp-grid-auto {
        display: grid;
        grid-template-columns: auto 1fr 1fr;
        gap: 8px 12px;
        align-items: center;
        margin-top: 16px;
      }
      .temp-grid-header {
        font-size: 12px;
        font-weight: 600;
        color: var(--secondary-text-color);
        text-transform: uppercase;
        letter-spacing: 0.3px;
        text-align: center;
      }
      .temp-grid-row-label {
        display: flex;
        align-items: center;
        gap: 4px;
        font-size: 13px;
        font-weight: 500;
        color: var(--secondary-text-color);
        white-space: nowrap;
      }

      @media (max-width: 600px) {
        .temp-grid-auto {
          grid-template-columns: 1fr 1fr;
        }
        .temp-grid-row-label {
          grid-column: 1 / -1;
          margin-top: 8px;
        }
        .temp-grid-header {
          display: none;
        }
      }
    `]}render(){return this.editing?this._renderEditMode():this._renderViewMode()}_renderViewMode(){let e=this.hass.language,t=this.schedules.length>=2;return m`
      ${this.schedules.length>0?m`
              <div class="schedule-list">
                ${this.schedules.map((n,r)=>{let i=this._getScheduleState(r,this.schedules.length);return m`
                    <div class="schedule-row ${i}">
                      ${t?m`<span class="schedule-number">${r+1}</span>`:h}
                      <span class="schedule-status-dot"></span>
                      <span
                        class="schedule-name schedule-link"
                        @click=${()=>this._openEntityInfo(n.entity_id)}
                        >${this._getFriendlyName(n.entity_id)}</span
                      >
                      <span class="schedule-status">${this._getStatusText(r,i)}</span>
                      <span class="schedule-controls">
                        <ha-icon-button
                          .path=${Bt}
                          .label=${S(`schedule_editor.edit`,e)}
                          @click=${()=>this._requestEditor(n.entity_id)}
                        ></ha-icon-button>
                      </span>
                    </div>
                    ${this._renderRejectedTempWarning(i)}
                  `})}
              </div>
            `:m`<div class="no-schedules">${S(`schedule.no_schedules`,e)}</div>
              ${this._renderCreateButton(e)}`}
      ${this.hideHeatTemps&&this.climateMode===`heat_only`?h:this.hideHeatTemps&&this.climateMode===`auto`?m`<div class="view-temps">
                ${S(`schedule.view_cool`,e,{comfort:D(this.comfortCool,this.hass),eco:D(this.ecoCool,this.hass),unit:C(this.hass)})}
              </div>`:this.climateMode===`auto`?m`
                  <div class="view-temps">
                    ${S(`schedule.view_heat`,e,{comfort:D(this.comfortHeat,this.hass),eco:D(this.ecoHeat,this.hass),unit:C(this.hass)})}
                     · 
                    ${S(`schedule.view_cool`,e,{comfort:D(this.comfortCool,this.hass),eco:D(this.ecoCool,this.hass),unit:C(this.hass)})}
                  </div>
                `:m`
                  <div class="view-temps">
                    ${S(`schedule.view_comfort`,e,{temp:D(this.climateMode===`cool_only`?this.comfortCool:this.comfortHeat,this.hass),unit:C(this.hass)})}
                     · 
                    ${S(`schedule.view_eco`,e,{temp:D(this.climateMode===`cool_only`?this.ecoCool:this.ecoHeat,this.hass),unit:C(this.hass)})}
                  </div>
                `}
      ${this.scheduleSelectorEntity?m`<div class="view-selector-info">
              ${S(`schedule.view_selector_prefix`,e)}
              <span
                class="schedule-link"
                @click=${()=>this._openEntityInfo(this.scheduleSelectorEntity)}
                >${this._getFriendlyName(this.scheduleSelectorEntity)}</span
              >
            </div>`:h}
    `}_renderEditMode(){let e=this.hass.language,t=this.schedules.length,n=new Set(this.schedules.map(e=>e.entity_id));return m`
      ${this._renderScheduleList()} ${this._renderCreateButton(e)}
      ${this._renderAddRow(S(`schedule.select_schedule`,e),this._getAvailableEntities(n),e=>this._addSchedule(e),S(`schedule.create_helper_hint`,e))}
      ${this._renderSelectorSection(t,S(`schedule.selector_label`,e),this.scheduleSelectorEntity?this._getSelectorValueText(e):``,S(`schedule.selector_warning`,e),e=>this._onSelectorEntityChange(e))}
      ${this._renderTemperatureInputs(e)}
    `}_renderCreateButton(e){return m`
      <button class="create-schedule-btn" @click=${()=>this._requestEditor(``)}>
        <ha-svg-icon .path=${Vt}></ha-svg-icon>
        ${S(`schedule_editor.create`,e)}
      </button>
    `}_requestEditor(e){this.dispatchEvent(new CustomEvent(`schedule-edit-request`,{detail:{entityId:e},bubbles:!0,composed:!0}))}_renderScheduleList(){let e=this.hass.language,t=this.schedules.length;return t===0?m`<div class="no-schedules">${S(`schedule.no_schedules`,e)}</div>`:m`
      <div class="schedule-list">
        ${this.schedules.map((n,r)=>{let i=this._getScheduleState(r,t);return m`
            <div class="schedule-row ${i}">
              ${t>=2?m`<span class="schedule-number">${r+1}</span>`:h}
              <span class="schedule-status-dot"></span>
              <span class="schedule-name">${this._getFriendlyName(n.entity_id)}</span>
              <span class="schedule-status">${this._getStatusText(r,i)}</span>
              <ha-icon-button
                class="edit-schedule-btn"
                .path=${Bt}
                .label=${S(`schedule_editor.edit`,e)}
                @click=${()=>this._requestEditor(n.entity_id)}
              ></ha-icon-button>
              ${this._renderScheduleControls(r,t,(e,t)=>this._moveSchedule(e,t),e=>this._removeSchedule(e))}
            </div>
            ${this._renderRejectedTempWarning(i)}
          `})}
      </div>
    `}_renderRejectedTempWarning(e){if(e!==`active`)return h;let t=this.scheduleTempWarnings??[];if(t.length===0)return h;let n=k(5,35,this.hass);return m`
      <div class="inline-warning">
        <ha-icon icon="mdi:alert-outline"></ha-icon>
        ${S(`schedule.block_temp_rejected`,this.hass.language,{values:t.map(e=>this._formatWarning(e)).join(`, `),min:n.min,max:n.max,unit:C(this.hass)})}
      </div>
    `}_formatWarning(e){let t=Ht.indexOf(e.day),n=e.from.slice(0,5);if(t>=0){let e=new Date(Date.UTC(2024,0,1+t));n=`${new Intl.DateTimeFormat(this.hass.language,{weekday:`short`,timeZone:`UTC`}).format(e)} ${n}`}return`${e.value} (${n})`}_renderTemperatureInputs(e){return this.climateMode===`auto`?m`
        <div class="temp-grid-auto">
          <div class="temp-grid-header"></div>
          <div class="temp-grid-header">${S(`schedule.column_comfort`,e)}</div>
          <div class="temp-grid-header">${S(`schedule.column_eco`,e)}</div>
          <div class="temp-grid-row-label">
            <ha-icon icon="mdi:fire" style="--mdc-icon-size:16px"></ha-icon>
            ${S(`schedule.row_heat`,e)}
          </div>
          <ha-textfield
            type="number"
            .value=${String(w(this.comfortHeat,this.hass))}
            suffix=${C(this.hass)}
            step=${O(this.hass)}
            min=${k(5,35,this.hass).min}
            max=${k(5,35,this.hass).max}
            @change=${this._onComfortHeatChange}
          ></ha-textfield>
          <ha-textfield
            type="number"
            .value=${String(w(this.ecoHeat,this.hass))}
            suffix=${C(this.hass)}
            step=${O(this.hass)}
            min=${k(5,35,this.hass).min}
            max=${k(5,35,this.hass).max}
            @change=${this._onEcoHeatChange}
          ></ha-textfield>
          <div class="temp-grid-row-label">
            <ha-icon icon="mdi:snowflake" style="--mdc-icon-size:16px"></ha-icon>
            ${S(`schedule.row_cool`,e)}
          </div>
          <ha-textfield
            type="number"
            .value=${String(w(this.comfortCool,this.hass))}
            suffix=${C(this.hass)}
            step=${O(this.hass)}
            min=${k(5,35,this.hass).min}
            max=${k(5,35,this.hass).max}
            @change=${this._onComfortCoolChange}
          ></ha-textfield>
          <ha-textfield
            type="number"
            .value=${String(w(this.ecoCool,this.hass))}
            suffix=${C(this.hass)}
            step=${O(this.hass)}
            min=${k(5,35,this.hass).min}
            max=${k(5,35,this.hass).max}
            @change=${this._onEcoCoolChange}
          ></ha-textfield>
        </div>
      `:m`
      <div class="temp-inputs">
        <div class="temp-input-group">
          <ha-textfield
            type="number"
            label=${S(`schedule.comfort_label`,e)}
            suffix=${C(this.hass)}
            step=${O(this.hass)}
            .value=${String(w(this.climateMode===`cool_only`?this.comfortCool:this.comfortHeat,this.hass))}
            min=${k(5,35,this.hass).min}
            max=${k(5,35,this.hass).max}
            @change=${this.climateMode===`cool_only`?this._onComfortCoolChange:this._onComfortHeatChange}
          ></ha-textfield>
        </div>
        <div class="temp-input-group">
          <ha-textfield
            type="number"
            label=${S(`schedule.eco_label`,e)}
            suffix=${C(this.hass)}
            step=${O(this.hass)}
            .value=${String(w(this.climateMode===`cool_only`?this.ecoCool:this.ecoHeat,this.hass))}
            min=${k(5,35,this.hass).min}
            max=${k(5,35,this.hass).max}
            @change=${this.climateMode===`cool_only`?this._onEcoCoolChange:this._onEcoHeatChange}
          ></ha-textfield>
        </div>
      </div>
      <div class="fallback-hint">${S(`schedule.comfort_hint`,e)}</div>
    `}_getSelectorValueText(e){let t=this.hass?.states?.[this.scheduleSelectorEntity];return t?this.scheduleSelectorEntity.startsWith(`input_boolean.`)?S(`schedule.selector_value_boolean`,e,{value:t.state===`on`?`On`:`Off`}):S(`schedule.selector_value_number`,e,{value:t.state}):``}_readBlockTemps(e){let t=this.hass?.states?.[this.schedules[e].entity_id]?.attributes??{},n=e=>e!=null&&kt(e,this.hass)?e:void 0;return{blockTemp:n(t.temperature),heatTemp:n(t.heat_temperature),coolTemp:n(t.cool_temperature)}}_getStatusText(e,t){let n=this.hass.language;if(t===`unreachable`)return S(`schedule.state_unreachable`,n);if(t===`inactive`)return S(`schedule.state_inactive`,n);let r=this.schedules[e],i=this.hass?.states?.[r.entity_id];if(!i)return S(`schedule.state_active`,n);if(i.state===`on`){let{blockTemp:t,heatTemp:r,coolTemp:i}=this._readBlockTemps(e);return t==null?r!=null||i!=null?S(`schedule.from_schedule_split`,n,{heat:r==null?D(this.comfortHeat,this.hass):String(r),cool:i==null?D(this.comfortCool,this.hass):String(i),unit:C(this.hass)}):S(`schedule.fallback`,n,{temp:D(this.climateMode===`cool_only`?this.comfortCool:this.comfortHeat,this.hass),unit:C(this.hass)}):S(`schedule.from_schedule`,n,{temp:String(t),unit:C(this.hass)})}return S(`schedule.eco_detail`,n,{temp:D(this.climateMode===`cool_only`?this.ecoCool:this.ecoHeat,this.hass),unit:C(this.hass)})}_addSchedule(e){this._emitSchedules([...this.schedules,{entity_id:e}])}_removeSchedule(e){this._emitSchedules(this.schedules.filter((t,n)=>n!==e))}_moveSchedule(e,t){let n=e+t;if(n<0||n>=this.schedules.length)return;let r=[...this.schedules];[r[e],r[n]]=[r[n],r[e]],this._emitSchedules(r)}_emitSchedules(e){this.dispatchEvent(new CustomEvent(`schedules-changed`,{detail:{value:e},bubbles:!0,composed:!0}))}_onSelectorEntityChange(e){this.dispatchEvent(new CustomEvent(`schedule-selector-changed`,{detail:{value:e},bubbles:!0,composed:!0}))}_onComfortHeatChange(e){let t=e.target,n=T(parseFloat(t.value)||w(21,this.hass),this.hass);this.dispatchEvent(new CustomEvent(`comfort-heat-changed`,{detail:{value:n},bubbles:!0,composed:!0})),this.comfortCool<n&&this.dispatchEvent(new CustomEvent(`comfort-cool-changed`,{detail:{value:n},bubbles:!0,composed:!0}))}_onComfortCoolChange(e){let t=e.target,n=T(parseFloat(t.value)||w(24,this.hass),this.hass);this.dispatchEvent(new CustomEvent(`comfort-cool-changed`,{detail:{value:n},bubbles:!0,composed:!0})),this.comfortHeat>n&&this.dispatchEvent(new CustomEvent(`comfort-heat-changed`,{detail:{value:n},bubbles:!0,composed:!0}))}_onEcoHeatChange(e){let t=e.target,n=T(parseFloat(t.value)||w(17,this.hass),this.hass);this.dispatchEvent(new CustomEvent(`eco-heat-changed`,{detail:{value:n},bubbles:!0,composed:!0})),this.ecoCool<n&&this.dispatchEvent(new CustomEvent(`eco-cool-changed`,{detail:{value:n},bubbles:!0,composed:!0}))}_onEcoCoolChange(e){let t=e.target,n=T(parseFloat(t.value)||w(27,this.hass),this.hass);this.dispatchEvent(new CustomEvent(`eco-cool-changed`,{detail:{value:n},bubbles:!0,composed:!0})),this.ecoHeat>n&&this.dispatchEvent(new CustomEvent(`eco-heat-changed`,{detail:{value:n},bubbles:!0,composed:!0}))}};A([y({attribute:!1})],R.prototype,`schedules`,void 0),A([y({type:String})],R.prototype,`scheduleSelectorEntity`,null),A([y({type:Number})],R.prototype,`activeScheduleIndex`,null),A([y({type:Number})],R.prototype,`comfortHeat`,void 0),A([y({type:Number})],R.prototype,`comfortCool`,void 0),A([y({type:Number})],R.prototype,`ecoHeat`,void 0),A([y({type:Number})],R.prototype,`ecoCool`,void 0),A([y({type:String})],R.prototype,`climateMode`,void 0),A([y({attribute:!1})],R.prototype,`scheduleTempWarnings`,void 0),A([y({type:Boolean})],R.prototype,`hideHeatTemps`,void 0),R=A([v(`rs-schedule-settings`)],R);var Ut={underfloor:2,radiator:1,"":0};function Wt(e){let t=``;for(let n of e){if(n.type!==`trv`)continue;let e=n.heating_system_type??``;(Ut[e]??0)>(Ut[t]??0)&&(t=e)}return t}_();var Gt=l`
  .master {
    display: flex;
    flex-direction: column;
    gap: 12px;
    min-width: 0;
  }

  .master-list {
    display: flex;
    flex-direction: column;
    gap: 4px;
    min-width: 0;
  }

  .master-row {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 8px 10px;
    border-radius: 10px;
    cursor: pointer;
    transition:
      background 0.15s,
      border-color 0.15s;
    border: 1px solid transparent;
    min-width: 0;
  }

  .master-row:hover {
    background: rgba(255, 255, 255, 0.03);
  }

  .master-row.focused {
    background: rgba(3, 169, 244, 0.08);
    border-color: rgba(3, 169, 244, 0.5);
  }

  .master-row ha-checkbox {
    flex-shrink: 0;
    margin-left: -8px;
  }

  .master-info {
    flex: 1;
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 2px;
  }

  .master-name-row {
    display: flex;
    align-items: center;
    gap: 6px;
    min-width: 0;
  }

  .master-name {
    font-size: 14px;
    font-weight: 450;
    color: var(--primary-text-color);
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    min-width: 0;
  }

  .master-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 4px;
  }

  .type-pill,
  .meta-pill {
    display: inline-block;
    font-size: 10px;
    font-weight: 500;
    padding: 1px 8px;
    border-radius: 8px;
    letter-spacing: 0.3px;
    text-transform: uppercase;
    color: var(--secondary-text-color);
    background: rgba(255, 255, 255, 0.05);
  }

  .type-pill {
    color: var(--primary-color);
    background: rgba(3, 169, 244, 0.12);
  }

  .external-badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    font-size: 10px;
    font-weight: 500;
    color: var(--warning-color, #ff9800);
    background: rgba(255, 152, 0, 0.1);
    padding: 2px 8px;
    border-radius: 10px;
    letter-spacing: 0.3px;
    text-transform: uppercase;
    flex-shrink: 0;
  }

  .detail-panel {
    display: flex;
    flex-direction: column;
    gap: 12px;
    padding: 12px 16px;
    background: rgba(255, 255, 255, 0.02);
    border: 1px solid var(--divider-color, rgba(255, 255, 255, 0.08));
    border-radius: 12px;
    min-width: 0;
    min-height: 200px;
  }

  .empty-detail {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 10px;
    flex: 1;
    min-height: 180px;
    color: var(--secondary-text-color);
    font-size: 13px;
    font-style: italic;
    opacity: 0.7;
    text-align: center;
  }

  .empty-detail ha-icon {
    --mdc-icon-size: 28px;
    opacity: 0.6;
  }

  .detail-head {
    display: flex;
    flex-direction: column;
    gap: 2px;
    padding-bottom: 6px;
    border-bottom: 1px solid var(--divider-color, rgba(255, 255, 255, 0.06));
  }

  .detail-title {
    font-size: 15px;
    font-weight: 500;
    color: var(--primary-text-color);
  }

  .detail-entity-id {
    font-family: var(--code-font-family, monospace);
    font-size: 11px;
    color: var(--secondary-text-color);
    opacity: 0.7;
  }

  .detail-field {
    display: flex;
    flex-direction: column;
  }

  .detail-field ha-select,
  .detail-field ha-textfield {
    width: 100%;
  }

  .detail-field.with-info {
    flex-direction: row;
    align-items: center;
    gap: 6px;
  }

  .detail-field.with-info ha-select,
  .detail-field.with-info ha-textfield {
    flex: 1;
    min-width: 0;
  }

  .detail-field.with-info rs-info-icon {
    flex-shrink: 0;
  }

  .detail-hint {
    font-size: 12px;
    color: var(--secondary-text-color);
    line-height: 1.5;
  }

  .detail-toggle-row {
    display: flex;
    align-items: flex-start;
    gap: 10px;
    padding: 8px 0;
  }

  .detail-toggle-row ha-checkbox {
    margin-top: -8px;
    margin-left: -8px;
  }

  .detail-toggle-label {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 14px;
    color: var(--primary-text-color);
  }

  .detail-toggle-label ha-icon {
    --mdc-icon-size: 16px;
    color: var(--secondary-text-color);
  }

  .inline-hint {
    margin-top: 2px;
  }

  .block {
    margin-top: 4px;
  }

  .block-divider {
    height: 1px;
    background: var(--divider-color, rgba(255, 255, 255, 0.08));
    margin: 16px 0 8px;
  }

  .block-title {
    font-size: 12px;
    font-weight: 500;
    color: var(--secondary-text-color);
    text-transform: uppercase;
    letter-spacing: 0.4px;
    margin-bottom: 8px;
  }

  .empty-list {
    color: var(--secondary-text-color);
    font-size: 13px;
    font-style: italic;
    padding: 12px 14px;
  }

  ha-entity-picker {
    width: 100%;
  }

  .picker-wrap {
    margin-top: 8px;
  }
`;_(),x(),j();var Kt=class extends g{constructor(...e){super(...e),this.masterWidth=`260px`,this.breakpoint=720}static{this.styles=l`
    :host {
      display: block;
      container-type: inline-size;
    }

    .wrap {
      display: grid;
      grid-template-columns: var(--rs-master-width, 260px) minmax(0, 1fr);
      gap: 20px;
      align-items: start;
    }

    @container (max-width: 720px) {
      .wrap {
        grid-template-columns: minmax(0, 1fr);
      }
    }

    /* Fallback for browsers without container queries */
    @media (max-width: 720px) {
      .wrap {
        grid-template-columns: minmax(0, 1fr);
      }
    }

    ::slotted([slot="master"]) {
      min-width: 0;
    }

    ::slotted([slot="detail"]) {
      min-width: 0;
    }
  `}render(){return m`
      <div class="wrap" style="--rs-master-width: ${this.masterWidth};">
        <div class="master"><slot name="master"></slot></div>
        <div class="detail"><slot name="detail"></slot></div>
      </div>
    `}};A([y({type:String})],Kt.prototype,`masterWidth`,void 0),A([y({type:Number})],Kt.prototype,`breakpoint`,void 0),Kt=A([v(`rs-master-detail`)],Kt),_(),x(),j();var qt=class extends g{constructor(...e){super(...e),this.label=``,this.hint=``,this.checked=!1,this.disabled=!1}static{this.styles=l`
    :host {
      display: block;
    }

    .toggle-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 16px;
    }

    .toggle-text {
      display: flex;
      align-items: center;
      gap: 4px;
      min-width: 0;
    }

    .toggle-label {
      font-weight: 500;
    }

    ha-switch {
      flex-shrink: 0;
    }
  `}render(){return m`
      <div class="toggle-row">
        <div class="toggle-text">
          <span class="toggle-label">${this.label}</span>
          ${this.hint?m`<rs-info-icon .text=${this.hint}></rs-info-icon>`:h}
        </div>
        <ha-switch
          .checked=${this.checked}
          .disabled=${this.disabled}
          @change=${this._onToggle}
        ></ha-switch>
      </div>
    `}_onToggle(e){this.dispatchEvent(new CustomEvent(`toggle-changed`,{detail:e.target.checked,bubbles:!0,composed:!0}))}};A([y({type:String})],qt.prototype,`label`,void 0),A([y({type:String})],qt.prototype,`hint`,void 0),A([y({type:Boolean})],qt.prototype,`checked`,void 0),A([y({type:Boolean})],qt.prototype,`disabled`,void 0),qt=A([v(`rs-toggle-row`)],qt),_(),x(),j();var Jt=`__inherit__`,Yt=e=>e===Jt?``:e??``,z=class extends g{constructor(...e){super(...e),this.devices=[],this.selectedTempSensor=``,this.valveProtectionExclude=new Set,this.valveProtectionEnabled=!1,this.coilDryEnabledGlobal=!1,this.coilDryMinutesGlobal=20,this.coilDryModeGlobal=`fan_only`,this.coilDryFanModeGlobal=`low`,this.editing=!1,this._systemTypeInfoExpanded=!1,this._showBoostHint=!1,this._selectedThermostats=new Set,this._selectedCoolingDevices=new Set,this._heatingSystemType=``,this._selectedForEdit=``,this._entityFilter=e=>{let t=e.entity_id;return t.substring(t.indexOf(`.`)+1).startsWith(`roommind_`)||this.devices.some(e=>e.entity_id===t)?!1:t.startsWith(`climate.`)}}willUpdate(e){if(e.has(`devices`)){this._selectedThermostats=new Set(this.devices.filter(e=>e.type===`trv`).map(e=>e.entity_id)),this._selectedCoolingDevices=new Set(this.devices.filter(e=>e.type===`ac`).map(e=>e.entity_id)),this._heatingSystemType=Wt(this.devices);let e=new Set(this.devices.map(e=>e.entity_id));this._selectedForEdit&&!e.has(this._selectedForEdit)&&(this._selectedForEdit=``),!this._selectedForEdit&&this.devices.length>0&&(this._selectedForEdit=this.devices[0].entity_id)}}static{this.styles=[Gt,L,l`
      :host {
        display: block;
      }

      .section-subtitle {
        font-size: 12px;
        font-weight: 500;
        color: var(--secondary-text-color);
        margin: 12px 0 8px 0;
        text-transform: uppercase;
        letter-spacing: 0.4px;
      }

      .section-subtitle:first-child {
        margin-top: 0;
      }

      .device-group {
        padding: 4px 0;
      }

      .device-group + .device-group {
        margin-top: 8px;
        padding-top: 12px;
        border-top: 1px solid var(--divider-color, #eee);
      }

      .device-list-scroll {
        max-height: 168px;
        overflow-y: auto;
        overflow-x: hidden;
        scrollbar-width: thin;
      }

      /* Device rows */
      .device-row {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 8px 14px;
        font-size: 14px;
        color: var(--primary-text-color);
        border-radius: 10px;
        margin-bottom: 2px;
        transition: background 0.15s;
      }

      .device-row:last-child {
        margin-bottom: 0;
      }

      .device-row:hover {
        background: rgba(0, 0, 0, 0.02);
      }

      .device-row.selected {
        background: rgba(3, 169, 244, 0.035);
      }

      .device-row ha-checkbox,
      .device-row ha-radio {
        flex-shrink: 0;
      }

      .device-info {
        flex: 1;
        min-width: 0;
      }

      .device-name-row {
        display: flex;
        align-items: center;
        gap: 8px;
      }

      .device-name {
        font-size: 14px;
        font-weight: 450;
        color: var(--primary-text-color);
      }

      .device-value {
        margin-left: auto;
        font-size: 14px;
        font-weight: 500;
        color: var(--primary-text-color);
        flex-shrink: 0;
      }

      .device-entity {
        font-family: var(--code-font-family, monospace);
        font-size: 11px;
        color: var(--secondary-text-color);
        margin-top: 2px;
        opacity: 0.7;
      }

      .external-badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        font-size: 10px;
        font-weight: 500;
        color: var(--warning-color, #ff9800);
        background: rgba(255, 152, 0, 0.1);
        padding: 2px 8px;
        border-radius: 10px;
        letter-spacing: 0.3px;
        text-transform: uppercase;
        flex-shrink: 0;
      }

      .device-type-select {
        flex-shrink: 0;
        --ha-select-min-width: 90px;
      }

      .no-devices {
        color: var(--secondary-text-color);
        font-size: 13px;
        font-style: italic;
        padding: 12px 14px;
      }

      .entity-picker-wrap {
        margin-top: 12px;
        padding-top: 12px;
        border-top: 1px solid var(--divider-color, #eee);
      }

      .subtitle-row {
        display: flex;
        align-items: center;
        gap: 4px;
      }

      .info-icon {
        --mdc-icon-size: 16px;
        color: var(--secondary-text-color);
        cursor: pointer;
        opacity: 0.6;
      }
      .info-icon:hover,
      .info-icon.info-active {
        opacity: 1;
        color: var(--primary-color);
      }

      .system-type-info {
        font-size: 12px;
        line-height: 1.5;
        color: var(--secondary-text-color);
        padding: 8px 14px 4px;
      }

      .boost-hint {
        display: flex;
        align-items: flex-start;
        gap: 8px;
        margin-top: 8px;
        padding: 8px 12px;
        background: rgba(var(--rgb-primary-color, 3, 169, 244), 0.08);
        border-radius: 8px;
        font-size: 13px;
        color: var(--primary-text-color);
        line-height: 1.4;
        --mdc-icon-size: 18px;
      }
      .boost-hint ha-icon {
        color: var(--primary-color);
        flex-shrink: 0;
        margin-top: 1px;
      }

      .idle-action-row {
        display: flex;
        gap: 12px;
        padding: 4px 14px 4px 42px;
      }

      .idle-action-row ha-select {
        flex: 1;
        min-width: 0;
      }

      .setpoint-mode-row {
        display: flex;
        gap: 12px;
        padding: 4px 14px 4px 42px;
      }

      .setpoint-mode-row ha-select {
        flex: 1;
        min-width: 0;
      }

      .setpoint-mode-hint {
        font-size: 12px;
        color: var(--secondary-text-color);
        padding: 2px 14px 4px 42px;
      }

      .valve-exclude-row {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 2px 14px 2px 42px;
        font-size: 12px;
        color: var(--secondary-text-color);
      }

      .valve-exclude-row ha-icon {
        --mdc-icon-size: 14px;
        color: var(--secondary-text-color);
      }

      .valve-exclude-row ha-checkbox {
        --mdc-checkbox-unchecked-color: var(--secondary-text-color);
        margin: -8px -4px -8px -8px;
      }

      .valve-exclude-badge {
        display: inline-flex;
        align-items: center;
        gap: 3px;
        font-size: 10px;
        font-weight: 500;
        color: var(--secondary-text-color);
        background: var(--secondary-background-color);
        padding: 2px 6px;
        border-radius: 8px;
        --mdc-icon-size: 12px;
      }

      .detail-section-label {
        font-size: 11px;
        font-weight: 500;
        color: var(--secondary-text-color);
        text-transform: uppercase;
        letter-spacing: 0.4px;
        padding: 10px 0 4px 0;
        border-top: 1px solid var(--divider-color, rgba(0, 0, 0, 0.08));
        margin-top: 4px;
      }

      /* View mode styles */
      .view-row {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 8px 14px;
        font-size: 14px;
        color: var(--primary-text-color);
      }

      .view-name {
        flex: 1;
        min-width: 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .entity-link {
        cursor: pointer;
      }

      .entity-link:hover {
        text-decoration: underline;
      }

      .view-value {
        font-weight: 500;
        flex-shrink: 0;
      }
    `]}render(){return this.editing?this._renderEditMode():this._renderViewMode()}_renderViewMode(){let e=this._selectedThermostats.size>0||this._selectedCoolingDevices.size>0;return m`
      ${e?m`
              <div class="device-group">
                <div class="section-subtitle">
                  ${S(`devices.climate_entities`,this.hass.language)}
                </div>
                ${[...this._selectedThermostats].map(e=>this._renderViewRow(e,`climate`))}
                ${[...this._selectedCoolingDevices].map(e=>this._renderViewRow(e,`climate`))}
              </div>
            `:h}
      ${this._heatingSystemType?m`
              <div class="device-group">
                <div class="section-subtitle">
                  ${S(`devices.heating_system_type`,this.hass.language)}
                </div>
                <div class="view-row">
                  <span class="view-name"
                    >${this._heatingSystemType===`radiator`?S(`devices.system_type_radiator`,this.hass.language):this._heatingSystemType===`underfloor`?S(`devices.system_type_underfloor`,this.hass.language):this._heatingSystemType}</span
                  >
                </div>
              </div>
            `:h}
    `}_renderViewRow(e,t){let n=this.hass.states[e],r=n?.attributes?.friendly_name||e,i=n?.state,a=n?.attributes??{},o=``;if(t===`climate`){let e=a.current_temperature;e!=null&&(o=`${e.toFixed(1)}${C(this.hass)}`)}else if(t===`temp`){let t=e.startsWith(`climate.`)?a.current_temperature:i;t!=null&&t!==``&&t!==`unknown`&&t!==`unavailable`&&(o=`${Number(t).toFixed(1)}${C(this.hass)}`)}else i&&i!==`unknown`&&i!==`unavailable`&&(o=`${Math.round(Number(i))}%`);let s=t===`climate`&&this.valveProtectionEnabled&&this.valveProtectionExclude.has(e),c=t===`climate`?this.devices.find(t=>t.entity_id===e):void 0,l=c?.idle_action===`fan_only`||c?.idle_action===`setback`||c?.idle_action===`low`,u=c?.type===`trv`&&!!c?.valve_opening_entity&&!!c?.valve_closing_entity,d=c?.setpoint_mode===`direct`&&!!this.selectedTempSensor&&!u,f=u&&!!this.selectedTempSensor;return m`
      <div class="view-row">
        <span class="view-name entity-link" @click=${()=>Rt(this,e)}
          >${r}</span
        >
        ${l?m`<span class="valve-exclude-badge">
                ${c.idle_action===`fan_only`?m`${S(`devices.idle_action_fan_only`,this.hass.language)}${c.idle_fan_mode?` (${c.idle_fan_mode})`:h}`:c.idle_action===`low`?S(`devices.idle_action_low`,this.hass.language):S(`devices.idle_action_setback`,this.hass.language)}
              </span>`:h}
        ${d?m`<span class="valve-exclude-badge">
                ${S(`devices.setpoint_mode_direct`,this.hass.language)}
              </span>`:h}
        ${f?m`<span class="valve-exclude-badge">
                <ha-icon icon="mdi:valve"></ha-icon>
                ${S(`devices.valve_direct_badge`,this.hass.language)}
              </span>`:h}
        ${s?m`<span class="valve-exclude-badge">
                <ha-icon icon="mdi:shield-off-outline"></ha-icon>
                ${S(`devices.valve_protection_excluded`,this.hass.language)}
              </span>`:h}
        ${o?m`<span class="view-value">${o}</span>`:h}
      </div>
    `}_renderEditMode(){let e=bt(this.area.area_id,this.hass?.entities,this.hass?.devices).filter(e=>!e.entity_id.substring(e.entity_id.indexOf(`.`)+1).startsWith(`roommind_`)).filter(e=>e.entity_id.startsWith(`climate.`)),t=new Set(e.map(e=>e.entity_id)),n=new Set(this.devices.map(e=>e.entity_id)),r=[...n].filter(e=>!t.has(e)),i=e=>n.has(e),a=this._selectedForEdit;return m`
      <rs-master-detail>
        <div slot="master" class="master">
          <div class="section-subtitle">
            ${S(`devices.climate_entities`,this.hass.language)}
          </div>
          <div class="master-list">
            ${e.length>0?e.map(e=>this._renderMasterRow(e.entity_id,!1)):m`<div class="no-devices">
                    ${S(`devices.no_climate`,this.hass.language)}
                  </div>`}
            ${r.map(e=>this._renderMasterRow(e,!0))}
          </div>
          <div class="entity-picker-wrap">
            <ha-entity-picker
              .hass=${this.hass}
              .includeDomains=${[`climate`]}
              .entityFilter=${this._entityFilter}
              .value=${``}
              label=${S(`devices.add_entity`,this.hass.language)}
              @value-changed=${this._onEntityPicked}
            ></ha-entity-picker>
          </div>
        </div>

        <div slot="detail" class="detail-panel">
          ${a&&i(a)?this._renderDeviceDetail(a):m`<div class="empty-detail">
                  <ha-icon icon="mdi:gesture-tap"></ha-icon>
                  <span>${S(`devices.select_to_configure`,this.hass.language)}</span>
                </div>`}
        </div>
      </rs-master-detail>

      ${this._selectedThermostats.size>0?m`
              <div class="block-divider"></div>
              <div class="block">
                <div class="subtitle-row">
                  <div class="section-subtitle">
                    ${S(`devices.heating_system_type`,this.hass.language)}
                  </div>
                  <ha-icon
                    class="info-icon ${this._systemTypeInfoExpanded?`info-active`:``}"
                    icon="mdi:information-outline"
                    @click=${()=>{this._systemTypeInfoExpanded=!this._systemTypeInfoExpanded}}
                  ></ha-icon>
                </div>
                ${this._systemTypeInfoExpanded?m`
                        <div class="system-type-info">
                          ${S(`devices.heating_system_type_info`,this.hass.language)}
                        </div>
                      `:h}
                <ha-select
                  .value=${this._heatingSystemType||`standard`}
                  .options=${[{value:`standard`,label:S(`devices.system_type_none`,this.hass.language)},{value:`radiator`,label:S(`devices.system_type_radiator`,this.hass.language)},{value:`underfloor`,label:S(`devices.system_type_underfloor`,this.hass.language)}]}
                  @selected=${this._onHeatingSystemTypeChange}
                  @closed=${e=>e.stopPropagation()}
                  fixedMenuPosition
                  style="width: 100%;"
                >
                  <ha-list-item value="standard"
                    >${S(`devices.system_type_none`,this.hass.language)}</ha-list-item
                  >
                  <ha-list-item value="radiator"
                    >${S(`devices.system_type_radiator`,this.hass.language)}</ha-list-item
                  >
                  <ha-list-item value="underfloor"
                    >${S(`devices.system_type_underfloor`,this.hass.language)}</ha-list-item
                  >
                </ha-select>
                ${this._showBoostHint?m`
                        <div class="boost-hint">
                          <ha-icon icon="mdi:information-outline"></ha-icon>
                          <span
                            >${S(`devices.heating_system_type_boost_hint`,this.hass.language)}</span
                          >
                        </div>
                      `:h}
              </div>
            `:h}
    `}_renderMasterRow(e,t){let n=this._selectedThermostats.has(e),r=this._selectedCoolingDevices.has(e),i=n||r,a=this._selectedForEdit===e,o=this.hass.states[e]?.attributes?.friendly_name||e,s=this.devices.find(t=>t.entity_id===e),c=n?S(`devices.type_thermostat`,this.hass.language):r?S(`devices.type_ac`,this.hass.language):``;return m`
      <div
        class="master-row ${a?`focused`:``} ${i?`in-room`:``}"
        @click=${()=>this._onSelectForEdit(e)}
      >
        <ha-checkbox
          .checked=${i}
          @click=${e=>e.stopPropagation()}
          @change=${t=>{let n=t.target;this._onClimateToggle(e,n.checked),n.checked&&(this._selectedForEdit=e)}}
        ></ha-checkbox>
        <div class="master-info">
          <div class="master-name-row">
            <span class="master-name">${o}</span>
            ${t?m`<span class="external-badge"
                    >${S(`devices.other_area`,this.hass.language)}</span
                  >`:h}
          </div>
          <div class="master-meta">
            ${c?m`<span class="type-pill">${c}</span>`:h}
            ${s?.idle_action&&s.idle_action!==`off`?m`<span class="meta-pill"
                    >${S(`devices.idle_action_${s.idle_action}`,this.hass.language)}</span
                  >`:h}
            ${r&&(s?.coil_dry===`on`||s?.coil_dry!==`off`&&this.coilDryEnabledGlobal)?m`<span class="meta-pill"
                    >${S(`devices.coil_dry_summary`,this.hass.language)}</span
                  >`:h}
            ${s?.setpoint_mode===`direct`&&this.selectedTempSensor&&!(s.type===`trv`&&s.valve_opening_entity&&s.valve_closing_entity)?m`<span class="meta-pill"
                    >${S(`devices.setpoint_mode_direct`,this.hass.language)}</span
                  >`:h}
          </div>
        </div>
      </div>
    `}_onSelectForEdit(e){this._selectedForEdit=e}_renderDeviceDetail(e){let t=this.devices.find(t=>t.entity_id===e);if(!t)return h;let n=t.type===`trv`,r=t.type===`ac`,i=this.hass.states[e],a=i?.attributes?.friendly_name||e,o=(i?.attributes?.hvac_modes??[]).includes(`fan_only`),s=this.valveProtectionExclude.has(e),c=this.hass.language,l=n?this._deviceNumberEntities(e):[],u=n&&!!t.valve_opening_entity&&!!t.valve_closing_entity,d=n&&!!this.selectedTempSensor&&(l.length>0||u),f=this._detectValvePair(l),p=!!f&&(!t.valve_opening_entity||t.valve_opening_entity===f[0]&&t.valve_closing_entity===f[1]);return m`
      <div class="detail-head">
        <div class="detail-title">${a}</div>
        <div class="detail-entity-id">${e}</div>
      </div>

      <div class="detail-field">
        <ha-select
          .label=${S(`devices.type_label`,c)||`Type`}
          .value=${this._getDeviceDisplayType(e)}
          .options=${[{value:`thermostat`,label:S(`devices.type_thermostat`,c)},{value:`ac`,label:S(`devices.type_ac`,c)}]}
          @selected=${t=>this._onDeviceTypeChange(e,F(t))}
          @closed=${e=>e.stopPropagation()}
          fixedMenuPosition
        >
          <ha-list-item value="thermostat"
            >${S(`devices.type_thermostat`,c)}</ha-list-item
          >
          <ha-list-item value="ac">${S(`devices.type_ac`,c)}</ha-list-item>
        </ha-select>
      </div>

      ${r?m`
              <div class="detail-field">
                <ha-select
                  .label=${S(`devices.idle_action`,c)}
                  .value=${t.idle_action??`off`}
                  .options=${[{value:`off`,label:S(`devices.idle_action_off`,c)},...o?[{value:`fan_only`,label:S(`devices.idle_action_fan_only`,c)}]:[],{value:`setback`,label:S(`devices.idle_action_setback`,c)}]}
                  @selected=${t=>this._onIdleActionChange(e,F(t))}
                  @closed=${e=>e.stopPropagation()}
                  fixedMenuPosition
                >
                  <ha-list-item value="off"
                    >${S(`devices.idle_action_off`,c)}</ha-list-item
                  >
                  ${o?m`<ha-list-item value="fan_only"
                          >${S(`devices.idle_action_fan_only`,c)}</ha-list-item
                        >`:h}
                  <ha-list-item value="setback"
                    >${S(`devices.idle_action_setback`,c)}</ha-list-item
                  >
                </ha-select>
              </div>
              ${t.idle_action===`fan_only`?m`<div class="detail-field">
                      <ha-select
                        .label=${S(`devices.idle_fan_mode`,c)}
                        .value=${t.idle_fan_mode===``?`__keep__`:t.idle_fan_mode??`low`}
                        .options=${[{value:`__keep__`,label:S(`devices.idle_fan_mode_keep`,c)},...(i?.attributes?.fan_modes??[]).map(e=>({value:e,label:e}))]}
                        @selected=${t=>{let n=F(t);this._onIdleFanModeChange(e,n===`__keep__`?``:n)}}
                        @closed=${e=>e.stopPropagation()}
                        fixedMenuPosition
                      >
                        <ha-list-item value="__keep__"
                          >${S(`devices.idle_fan_mode_keep`,c)}</ha-list-item
                        >
                        ${(i?.attributes?.fan_modes??[]).map(e=>m`<ha-list-item value="${e}">${e}</ha-list-item>`)}
                      </ha-select>
                    </div>`:h}

              <div class="detail-field">
                <ha-select
                  .label=${S(`devices.coil_dry`,c)}
                  .value=${t.coil_dry??`inherit`}
                  .options=${[{value:`inherit`,label:S(`devices.coil_dry_inherit`,c)},{value:`on`,label:S(`devices.coil_dry_on`,c)},{value:`off`,label:S(`devices.coil_dry_off`,c)}]}
                  @selected=${t=>this._onCoilDryChange(e,F(t))}
                  @closed=${e=>e.stopPropagation()}
                  fixedMenuPosition
                >
                  <ha-list-item value="inherit"
                    >${S(`devices.coil_dry_inherit`,c)}</ha-list-item
                  >
                  <ha-list-item value="on">${S(`devices.coil_dry_on`,c)}</ha-list-item>
                  <ha-list-item value="off">${S(`devices.coil_dry_off`,c)}</ha-list-item>
                </ha-select>
              </div>

              ${(t.coil_dry??`inherit`)===`inherit`&&!this.coilDryEnabledGlobal?m`
                      <div class="boost-hint">
                        <ha-icon icon="mdi:information-outline"></ha-icon>
                        <span>${S(`devices.coil_dry_global_off_hint`,c)}</span>
                      </div>
                    `:h}
              ${(t.coil_dry??`inherit`)===`off`?h:m`
                      <div class="detail-field">
                        <ha-textfield
                          .value=${String(t.coil_dry_minutes??0)}
                          .label=${S(`devices.coil_dry_minutes`,c,{minutes:this.coilDryMinutesGlobal})}
                          type="number"
                          step="1"
                          min="0"
                          max="60"
                          @change=${t=>{let n=parseInt(t.target.value,10);!isNaN(n)&&n>=0&&n<=60&&this._onCoilDryMinutesChange(e,n)}}
                        ></ha-textfield>
                      </div>

                      <div class="detail-field with-info">
                        <ha-select
                          .label=${S(`devices.coil_dry_mode`,c)}
                          .value=${t.coil_dry_mode||Jt}
                          .options=${[{value:Jt,label:S(`devices.coil_dry_mode_inherit`,c,{value:this.coilDryModeGlobal})},{value:`fan_only`,label:`fan_only`},{value:`dry`,label:`dry`}]}
                          @selected=${t=>this._onCoilDryModeChange(e,Yt(F(t)))}
                          @closed=${e=>e.stopPropagation()}
                          fixedMenuPosition
                        >
                          <ha-list-item value="${Jt}"
                            >${S(`devices.coil_dry_mode_inherit`,c,{value:this.coilDryModeGlobal})}</ha-list-item
                          >
                          <ha-list-item value="fan_only">fan_only</ha-list-item>
                          <ha-list-item value="dry">dry</ha-list-item>
                        </ha-select>
                        ${t.coil_dry_mode===`dry`?m`<rs-info-icon
                                icon="mdi:alert-outline"
                                .text=${S(`coil_dry.mode_dry_warning`,c)}
                              ></rs-info-icon>`:h}
                      </div>

                      <div class="detail-field">
                        <ha-select
                          .label=${S(`devices.coil_dry_fan_mode`,c)}
                          .value=${t.coil_dry_fan_mode||Jt}
                          .options=${[{value:Jt,label:S(`devices.coil_dry_fan_mode_inherit`,c,{value:this._globalFanModeLabel(c)})},{value:`__keep__`,label:S(`devices.coil_dry_fan_mode_keep`,c)},...(i?.attributes?.fan_modes??[]).map(e=>({value:e,label:e}))]}
                          @selected=${t=>this._onCoilDryFanModeChange(e,Yt(F(t)))}
                          @closed=${e=>e.stopPropagation()}
                          fixedMenuPosition
                        >
                          <ha-list-item value="${Jt}"
                            >${S(`devices.coil_dry_fan_mode_inherit`,c,{value:this._globalFanModeLabel(c)})}</ha-list-item
                          >
                          <ha-list-item value="__keep__"
                            >${S(`devices.coil_dry_fan_mode_keep`,c)}</ha-list-item
                          >
                          ${(i?.attributes?.fan_modes??[]).map(e=>m`<ha-list-item value="${e}">${e}</ha-list-item>`)}
                        </ha-select>
                      </div>
                    `}
            `:h}
      ${n?m`
              <div class="detail-field with-info">
                <ha-select
                  .label=${S(`devices.idle_action`,c)}
                  .value=${t.idle_action??`off`}
                  .options=${[{value:`off`,label:S(`devices.idle_action_off`,c)},{value:`low`,label:S(`devices.idle_action_low`,c)}]}
                  @selected=${t=>this._onIdleActionChange(e,F(t))}
                  @closed=${e=>e.stopPropagation()}
                  fixedMenuPosition
                >
                  <ha-list-item value="off"
                    >${S(`devices.idle_action_off`,c)}</ha-list-item
                  >
                  <ha-list-item value="low"
                    >${S(`devices.idle_action_low`,c)}</ha-list-item
                  >
                </ha-select>
                ${t.idle_action===`low`?m`<rs-info-icon
                        .text=${S(`devices.idle_action_low_hint`,c)}
                      ></rs-info-icon>`:h}
              </div>
            `:h}
      ${this.selectedTempSensor&&!u?m`
              <div class="detail-field with-info">
                <ha-select
                  .label=${S(`devices.setpoint_mode`,c)}
                  .value=${t.setpoint_mode??`proportional`}
                  .options=${[{value:`proportional`,label:S(`devices.setpoint_mode_proportional`,c)},{value:`direct`,label:S(`devices.setpoint_mode_direct`,c)}]}
                  @selected=${t=>this._onSetpointModeChange(e,F(t))}
                  @closed=${e=>e.stopPropagation()}
                  fixedMenuPosition
                >
                  <ha-list-item value="proportional"
                    >${S(`devices.setpoint_mode_proportional`,c)}</ha-list-item
                  >
                  <ha-list-item value="direct"
                    >${S(`devices.setpoint_mode_direct`,c)}</ha-list-item
                  >
                </ha-select>
                <rs-info-icon .text=${S(`devices.setpoint_mode_hint`,c)}></rs-info-icon>
              </div>
              ${t.setpoint_mode===`direct`?m`
                      <div class="detail-field with-info">
                        <ha-textfield
                          .label=${S(`devices.setpoint_offset`,c)}
                          .suffix=${C(this.hass)}
                          .value=${String(Math.round(E(t.setpoint_offset??0,this.hass)*10)/10)}
                          type="number"
                          .step=${Dt(this.hass)?`1`:`0.5`}
                          .min=${String(Math.round(E(-5,this.hass)))}
                          .max=${String(Math.round(E(5,this.hass)))}
                          @change=${t=>{let n=parseFloat(t.target.value);isNaN(n)||this._onSetpointOffsetChange(e,n)}}
                        ></ha-textfield>
                        <rs-info-icon
                          .text=${S(`devices.setpoint_offset_hint`,c)}
                        ></rs-info-icon>
                      </div>
                    `:h}
            `:h}
      ${n&&this.valveProtectionEnabled?m`
              <div class="detail-toggle-row">
                <ha-checkbox
                  .checked=${s}
                  @change=${t=>{let n=t.target;this._onValveProtectionExcludeToggle(e,n.checked)}}
                ></ha-checkbox>
                <div class="detail-toggle-label">
                  <ha-icon icon="mdi:shield-off-outline"></ha-icon>
                  ${S(`devices.valve_protection_excluded`,c)}
                  <rs-info-icon
                    .text=${S(`devices.valve_protection_exclude_hint`,c)}
                  ></rs-info-icon>
                </div>
              </div>
            `:h}
      ${d&&p?m`
              <div class="detail-field">
                <rs-toggle-row
                  .label=${S(`devices.valve_direct_control`,c)}
                  .hint=${S(`devices.valve_direct_control_toggle_hint`,c)}
                  .checked=${u}
                  @toggle-changed=${t=>this._onValveToggle(e,t.detail?f:null)}
                ></rs-toggle-row>
              </div>
            `:h}
      ${d&&!p?m`
              <div class="detail-section-label">
                ${S(`devices.valve_direct_control`,c)}
              </div>
              <div class="detail-field with-info">
                <ha-entity-picker
                  .hass=${this.hass}
                  .includeDomains=${[`number`]}
                  .includeEntities=${l.length?l:void 0}
                  .value=${t.valve_opening_entity??``}
                  .label=${S(`devices.valve_opening_entity`,c)}
                  @value-changed=${t=>this._onValveOpeningChange(e,t.detail.value,l)}
                ></ha-entity-picker>
                <rs-info-icon
                  .text=${S(`devices.valve_direct_control_hint`,c)}
                ></rs-info-icon>
              </div>
              <div class="detail-field with-info">
                <ha-entity-picker
                  .hass=${this.hass}
                  .includeDomains=${[`number`]}
                  .includeEntities=${l.length?l:void 0}
                  .value=${t.valve_closing_entity??``}
                  .label=${S(`devices.valve_closing_entity`,c)}
                  @value-changed=${t=>this._onValveClosingChange(e,t.detail.value)}
                ></ha-entity-picker>
                <rs-info-icon
                  .text=${S(`devices.valve_closing_entity_hint`,c)}
                ></rs-info-icon>
              </div>
            `:h}
    `}_detectClimateType(e){return(this.hass.states[e]?.attributes?.hvac_modes??[]).some(e=>[`cool`,`heat_cool`].includes(e))?`ac`:`thermostat`}_getDeviceDisplayType(e){let t=this.devices.find(t=>t.entity_id===e);return t&&t.type===`ac`?`ac`:`thermostat`}_onClimateToggle(e,t){let n;if(t){let t=this._detectClimateType(e)===`thermostat`?`trv`:`ac`;n=[...this.devices,{entity_id:e,type:t,role:`auto`}]}else n=this.devices.filter(t=>t.entity_id!==e);this._fireDeviceChanged(n)}_onDeviceTypeChange(e,t){let n=t===`thermostat`?`trv`:`ac`,r=this.devices.map(t=>{if(t.entity_id!==e)return t;let r={...t,type:n};return n===`ac`&&r.idle_action===`low`&&(r.idle_action=`off`),n===`trv`&&r.coil_dry===`on`&&(r.coil_dry=`inherit`),n===`ac`&&(delete r.valve_opening_entity,delete r.valve_closing_entity),r});this._fireDeviceChanged(r)}_onValveProtectionExcludeToggle(e,t){this.dispatchEvent(new CustomEvent(`valve-protection-exclude-toggle`,{detail:{entityId:e,excluded:t},bubbles:!0,composed:!0}))}_onIdleActionChange(e,t){let n=this.devices.map(n=>{if(n.entity_id!==e)return n;let r={...n,idle_action:t};return t===`fan_only`&&!n.idle_fan_mode&&(r.idle_fan_mode=`low`),r});this._fireDeviceChanged(n)}_onIdleFanModeChange(e,t){let n=this.devices.map(n=>n.entity_id===e?{...n,idle_fan_mode:t}:n);this._fireDeviceChanged(n)}_onSetpointModeChange(e,t){let n=this.devices.map(n=>n.entity_id===e?{...n,setpoint_mode:t}:n);this._fireDeviceChanged(n)}_onSetpointOffsetChange(e,t){let n=Math.max(-5,Math.min(5,Math.round(Ot(t,this.hass)*100)/100));this._fireDeviceChanged(this.devices.map(t=>t.entity_id===e?{...t,setpoint_offset:n}:t))}_globalFanModeLabel(e){return this.coilDryFanModeGlobal===``?S(`devices.coil_dry_fan_mode_keep`,e):this.coilDryFanModeGlobal}_onCoilDryChange(e,t){this._fireDeviceChanged(this.devices.map(n=>n.entity_id===e?{...n,coil_dry:t}:n))}_onCoilDryMinutesChange(e,t){this._fireDeviceChanged(this.devices.map(n=>n.entity_id===e?{...n,coil_dry_minutes:t}:n))}_onCoilDryModeChange(e,t){this._fireDeviceChanged(this.devices.map(n=>n.entity_id===e?{...n,coil_dry_mode:t}:n))}_onCoilDryFanModeChange(e,t){this._fireDeviceChanged(this.devices.map(n=>n.entity_id===e?{...n,coil_dry_fan_mode:t}:n))}_deviceNumberEntities(e){let t=this.hass.entities?.[e]?.device_id;if(!t)return[];let n=Object.values(this.hass.entities).filter(e=>e.device_id===t&&e.entity_id.startsWith(`number.`)).map(e=>e.entity_id),r=n.filter(e=>/valve|opening|closing|ventil|vanne/.test(e));return r.length?r:n}_detectValvePair(e){for(let t of e){if(!t.includes(`opening`))continue;let n=t.replace(/opening/g,`closing`);if(e.includes(n))return[t,n]}return null}_onValveToggle(e,t){this._fireDeviceChanged(this.devices.map(n=>{if(n.entity_id!==e)return n;let r={...n};return delete r.valve_opening_entity,delete r.valve_closing_entity,t&&([r.valve_opening_entity,r.valve_closing_entity]=t),r}))}_onValveOpeningChange(e,t,n){let r=t.replace(/opening/g,`closing`),i=r!==t&&n.includes(r)?r:``;this._fireDeviceChanged(this.devices.map(n=>{if(n.entity_id!==e)return n;let r={...n};return t?(r.valve_opening_entity=t,!r.valve_closing_entity&&i&&(r.valve_closing_entity=i),r):(delete r.valve_opening_entity,delete r.valve_closing_entity,r)}))}_onValveClosingChange(e,t){this._fireDeviceChanged(this.devices.map(n=>{if(n.entity_id!==e)return n;let r={...n};return t?r.valve_closing_entity=t:delete r.valve_closing_entity,r}))}_onHeatingSystemTypeChange(e){let t=F(e)??``,n=t===`standard`?``:t;this._showBoostHint=!0;let r=this.devices.map(e=>e.type===`trv`?{...e,heating_system_type:n}:e);this._fireDeviceChanged(r)}_fireDeviceChanged(e){this.dispatchEvent(new CustomEvent(`device-changed`,{detail:{devices:e},bubbles:!0,composed:!0}))}_onEntityPicked(e){let t=e.detail?.value,n=e.target;if(n.value=``,!t||!t.startsWith(`climate.`)||this.devices.some(e=>e.entity_id===t))return;let r=this._detectClimateType(t)===`thermostat`?`trv`:`ac`,i=[...this.devices,{entity_id:t,type:r,role:`auto`}];this._fireDeviceChanged(i)}};A([y({attribute:!1})],z.prototype,`hass`,void 0),A([y({attribute:!1})],z.prototype,`area`,void 0),A([y({attribute:!1})],z.prototype,`devices`,void 0),A([y({type:String})],z.prototype,`selectedTempSensor`,void 0),A([y({attribute:!1})],z.prototype,`valveProtectionExclude`,void 0),A([y({type:Boolean})],z.prototype,`valveProtectionEnabled`,void 0),A([y({type:Boolean})],z.prototype,`coilDryEnabledGlobal`,void 0),A([y({type:Number})],z.prototype,`coilDryMinutesGlobal`,void 0),A([y({type:String})],z.prototype,`coilDryModeGlobal`,void 0),A([y({type:String})],z.prototype,`coilDryFanModeGlobal`,void 0),A([y({type:Boolean})],z.prototype,`editing`,void 0),A([b()],z.prototype,`_systemTypeInfoExpanded`,void 0),A([b()],z.prototype,`_showBoostHint`,void 0),A([b()],z.prototype,`_selectedThermostats`,void 0),A([b()],z.prototype,`_selectedCoolingDevices`,void 0),A([b()],z.prototype,`_heatingSystemType`,void 0),A([b()],z.prototype,`_selectedForEdit`,void 0),z=A([v(`rs-device-section`)],z);var Xt=3250368e4;_(),x(),j();var B=class extends g{constructor(...e){super(...e),this.temperatureSensor=``,this.humiditySensor=``,this.occupancySensors=new Set,this.occupancyEcoEnabled=!1,this.occupancyEcoDelay=15,this.windowSensors=new Set,this.windowOpenDelay=0,this.windowCloseDelay=0,this.heatingSystemType=``,this.editing=!1,this.language=`en`,this._pickerOpen=!1,this._collapsed={},this._globalEntityFilter=e=>{let t=e.entity_id;if(t.substring(t.indexOf(`.`)+1).startsWith(`roommind_`)||this.temperatureSensor===t||this.humiditySensor===t||this.occupancySensors.has(t)||this.windowSensors.has(t))return!1;if(t.startsWith(`sensor.`)){let e=this.hass.states[t]?.attributes?.device_class;return e===`temperature`||e===`humidity`}if(t.startsWith(`binary_sensor.`)){let e=this.hass.states[t]?.attributes?.device_class;return e===`occupancy`||e===`motion`||e===`presence`||e===`window`||e===`door`||e===`opening`}return t.startsWith(`climate.`)?this.hass.states[t]?.attributes?.current_temperature!=null:t.startsWith(`input_number.`)||t.startsWith(`input_boolean.`)},this._onGlobalPickerValueChanged=e=>{let t=e.detail?.value,n=e.target;if(n.value=``,t){if(t.startsWith(`binary_sensor.`)){let e=this.hass.states[t]?.attributes?.device_class;e===`window`||e===`door`||e===`opening`?this.windowSensors.has(t)||this._onWindowToggle(t,!0):this.occupancySensors.has(t)||this._onOccupancyToggle(t,!0)}else if(t.startsWith(`input_boolean.`))this.occupancySensors.has(t)||this._onOccupancyToggle(t,!0);else if(t.startsWith(`input_number.`)){let e=this.hass.states[t]?.attributes?.unit_of_measurement;this._onSensorSelected(t,e===`%`?`humidity`:`temp`)}else if(t.startsWith(`climate.`))this._onSensorSelected(t,`temp`);else{let e=this.hass.states[t]?.attributes?.device_class;this._onSensorSelected(t,e===`humidity`?`humidity`:`temp`)}this._pickerOpen=!1}},this._onOccupancyEcoDelayChange=e=>{let t=e.target,n=parseInt(t.value),r=Number.isNaN(n)?15:Math.min(240,Math.max(5,n));t.value=String(r),this._fireSensorChanged(`occupancy_eco_delay`,r)},this._onWindowOpenDelayChange=e=>{let t=Math.max(0,parseInt(e.target.value)||0);this.dispatchEvent(new CustomEvent(`sensor-changed`,{detail:{key:`window_open_delay`,value:t},bubbles:!0,composed:!0}))},this._onWindowCloseDelayChange=e=>{let t=Math.max(0,parseInt(e.target.value)||0);this.dispatchEvent(new CustomEvent(`sensor-changed`,{detail:{key:`window_close_delay`,value:t},bubbles:!0,composed:!0}))}}static{this.styles=[L,l`
      :host {
        display: block;
      }

      .sensor-block {
        display: flex;
        flex-direction: column;
        gap: 6px;
        padding: 12px 14px;
        background: rgba(255, 255, 255, 0.02);
        border: 1px solid var(--divider-color, rgba(255, 255, 255, 0.08));
        border-radius: 12px;
      }

      .sensor-block + .sensor-block {
        margin-top: 12px;
      }

      .block-header {
        display: flex;
        align-items: center;
        gap: 8px;
        padding-bottom: 6px;
        cursor: pointer;
        user-select: none;
      }

      .block-header:hover .block-title {
        color: var(--primary-color);
      }

      .block-header ha-icon {
        --mdc-icon-size: 18px;
        color: var(--secondary-text-color);
      }

      .chevron {
        --mdc-icon-size: 18px;
        color: var(--secondary-text-color);
        transition: transform 0.2s ease;
      }

      .chevron.collapsed {
        transform: rotate(-90deg);
      }

      .block-body {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }

      .sensor-block.collapsed .block-header {
        padding-bottom: 0;
      }

      .block-title {
        font-size: 13px;
        font-weight: 500;
        color: var(--primary-text-color);
        letter-spacing: 0.2px;
        flex: 1;
      }

      .count-chip {
        font-size: 11px;
        font-weight: 500;
        padding: 1px 7px;
        border-radius: 10px;
        background: rgba(255, 255, 255, 0.06);
        color: var(--secondary-text-color);
      }

      .count-chip.has-selection {
        background: rgba(3, 169, 244, 0.15);
        color: var(--primary-color);
      }

      .row-list {
        display: flex;
        flex-direction: column;
        gap: 2px;
        max-height: 168px;
        overflow-y: auto;
        overflow-x: hidden;
        scrollbar-width: thin;
      }

      .row {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 6px 8px;
        border-radius: 8px;
        cursor: pointer;
        border-left: 2px solid transparent;
        transition:
          background 0.15s,
          border-color 0.15s;
        min-width: 0;
      }

      .row:hover {
        background: rgba(255, 255, 255, 0.03);
      }

      .row.selected {
        background: rgba(3, 169, 244, 0.08);
        border-left-color: var(--primary-color);
      }

      .row ha-checkbox,
      .row ha-radio {
        flex-shrink: 0;
        margin: -4px 0;
      }

      .row-info {
        flex: 1;
        min-width: 0;
        display: flex;
        flex-direction: column;
        gap: 1px;
      }

      .row-name-line {
        display: flex;
        align-items: center;
        gap: 6px;
        min-width: 0;
      }

      .row-name {
        font-size: 13px;
        font-weight: 450;
        color: var(--primary-text-color);
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .row-eid {
        font-family: var(--code-font-family, monospace);
        font-size: 10.5px;
        color: var(--secondary-text-color);
        opacity: 0.65;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .external-badge {
        display: inline-flex;
        align-items: center;
        font-size: 9.5px;
        font-weight: 500;
        color: var(--warning-color, #ff9800);
        background: rgba(255, 152, 0, 0.1);
        padding: 1px 6px;
        border-radius: 8px;
        letter-spacing: 0.3px;
        text-transform: uppercase;
        flex-shrink: 0;
      }

      .value-chip {
        flex-shrink: 0;
        font-size: 12px;
        font-weight: 500;
        padding: 3px 9px;
        border-radius: 10px;
        background: rgba(255, 255, 255, 0.05);
        color: var(--primary-text-color);
        font-variant-numeric: tabular-nums;
      }

      .row.selected .value-chip {
        background: rgba(3, 169, 244, 0.15);
        color: var(--primary-color);
      }

      .occupancy-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        flex-shrink: 0;
        transition: background 0.2s;
      }

      .occupancy-dot.on {
        background: var(--success-color, #4caf50);
        box-shadow: 0 0 0 3px rgba(76, 175, 80, 0.18);
      }

      .occupancy-dot.off {
        background: rgba(255, 255, 255, 0.2);
      }

      .window-dot.on {
        background: var(--warning-color, #ff9800);
        box-shadow: 0 0 0 3px rgba(255, 152, 0, 0.18);
      }

      .window-dot.off {
        background: rgba(255, 255, 255, 0.2);
      }

      .delay-fields {
        display: flex;
        gap: 8px;
        margin-top: 8px;
      }

      .occupancy-eco {
        margin-top: 8px;
      }

      .delay-fields ha-textfield {
        flex: 1;
      }

      .delay-hint {
        display: flex;
        align-items: flex-start;
        gap: 6px;
        font-size: 11.5px;
        line-height: 1.5;
        color: var(--warning-color, #ff9800);
        margin-top: 6px;
      }

      .delay-hint ha-icon {
        --mdc-icon-size: 16px;
        flex-shrink: 0;
        margin-top: 1px;
      }

      .delay-view {
        font-size: 12px;
        color: var(--secondary-text-color);
        padding-top: 4px;
      }

      .empty-row {
        color: var(--secondary-text-color);
        font-size: 12.5px;
        font-style: italic;
        padding: 6px 4px;
        opacity: 0.7;
      }

      .add-row,
      .global-add {
        display: flex;
        align-items: center;
        gap: 8px;
      }

      .global-add {
        margin-top: 12px;
      }

      .add-row ha-entity-picker,
      .global-add ha-entity-picker {
        flex: 1;
      }

      .add-button {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 6px 10px;
        margin: 12px 0 0 0;
        background: none;
        border: none;
        cursor: pointer;
        color: var(--secondary-text-color);
        font-size: 12px;
        font-weight: 500;
        border-radius: 6px;
        transition:
          color 0.15s,
          background 0.15s;
      }

      .add-button:hover,
      .add-button:focus-visible {
        color: var(--primary-color);
        background: rgba(3, 169, 244, 0.08);
        outline: none;
      }

      .add-button ha-icon {
        --mdc-icon-size: 16px;
      }

      .picker-close {
        --mdc-icon-button-size: 32px;
        --mdc-icon-size: 18px;
        color: var(--secondary-text-color);
        flex-shrink: 0;
      }

      /* View mode rows */
      .view-row {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 6px 0;
        font-size: 14px;
        color: var(--primary-text-color);
      }

      .view-name {
        flex: 1;
        min-width: 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .entity-link {
        cursor: pointer;
      }

      .entity-link:hover {
        text-decoration: underline;
      }

      .view-value {
        font-weight: 500;
        flex-shrink: 0;
      }

      .section-subtitle {
        font-size: 12px;
        font-weight: 500;
        color: var(--secondary-text-color);
        margin: 12px 0 4px 0;
        text-transform: uppercase;
        letter-spacing: 0.4px;
      }

      .section-subtitle:first-child {
        margin-top: 0;
      }
    `]}render(){return this.editing?this._renderEditMode():this._renderViewMode()}_renderViewMode(){let e=!!this.temperatureSensor,t=!!this.humiditySensor,n=this.occupancySensors.size>0,r=this.windowSensors.size>0;if(!e&&!t&&!n&&!r)return h;let i=this.hass.language;return m`
      ${e?m`
              <div class="section-subtitle">${S(`devices.temp_sensors`,i)}</div>
              ${this._renderSensorViewRow(this.temperatureSensor,`temp`)}
            `:h}
      ${t?m`
              <div class="section-subtitle">${S(`devices.humidity_sensors`,i)}</div>
              ${this._renderSensorViewRow(this.humiditySensor,`humidity`)}
            `:h}
      ${n?m`
              <div class="section-subtitle">${S(`devices.occupancy_sensors`,i)}</div>
              ${[...this.occupancySensors].map(e=>this._renderOccupancyViewRow(e))}
              ${this.occupancyEcoEnabled?m`<div class="delay-view">
                      ${S(`devices.occupancy_eco_view`,i,{minutes:String(this.occupancyEcoDelay)})}
                    </div>`:h}
            `:h}
      ${r?m`
              <div class="section-subtitle">${S(`devices.window_sensors`,i)}</div>
              ${[...this.windowSensors].map(e=>this._renderWindowViewRow(e))}
              ${this.windowOpenDelay||this.windowCloseDelay?m`<div class="delay-view">
                      ${this.windowOpenDelay?m`${S(`devices.window_open_delay`,i)}:
                            ${this.windowOpenDelay}s`:h}
                      ${this.windowOpenDelay&&this.windowCloseDelay?` · `:h}
                      ${this.windowCloseDelay?m`${S(`devices.window_close_delay`,i)}:
                            ${this.windowCloseDelay}s`:h}
                    </div>`:h}
            `:h}
    `}_renderWindowViewRow(e){let t=this.hass.states[e],n=t?.attributes?.friendly_name||e,r=t?.state===`on`;return m`
      <div class="view-row">
        <span class="view-name entity-link" @click=${()=>Rt(this,e)}
          >${n}</span
        >
        <span class="occupancy-dot window-dot ${r?`on`:`off`}"></span>
      </div>
    `}_renderSensorViewRow(e,t){let n=this.hass.states[e],r=n?.attributes?.friendly_name||e,i=n?.state,a=n?.attributes??{},o=``;if(t===`temp`){let t=e.startsWith(`climate.`)?a.current_temperature:i;t!=null&&t!==``&&t!==`unknown`&&t!==`unavailable`&&(o=`${Number(t).toFixed(1)}${C(this.hass)}`)}else i&&i!==`unknown`&&i!==`unavailable`&&(o=`${Math.round(Number(i))}%`);return m`
      <div class="view-row">
        <span class="view-name entity-link" @click=${()=>Rt(this,e)}
          >${r}</span
        >
        ${o?m`<span class="view-value">${o}</span>`:h}
      </div>
    `}_renderOccupancyViewRow(e){let t=this.hass.states[e],n=t?.attributes?.friendly_name||e,r=t?.state===`on`;return m`
      <div class="view-row">
        <span class="view-name entity-link" @click=${()=>Rt(this,e)}
          >${n}</span
        >
        <span class="occupancy-dot ${r?`on`:`off`}"></span>
      </div>
    `}_renderEditMode(){let e=bt(this.area.area_id,this.hass?.entities,this.hass?.devices).filter(e=>!e.entity_id.substring(e.entity_id.indexOf(`.`)+1).startsWith(`roommind_`)),t=this.hass?.states?e.filter(e=>e.entity_id.startsWith(`sensor.`)&&this.hass.states[e.entity_id]?.attributes?.device_class===`temperature`||e.entity_id.startsWith(`climate.`)&&this.hass.states[e.entity_id]?.attributes?.current_temperature!=null):[],n=this.hass?.states?e.filter(e=>e.entity_id.startsWith(`sensor.`)&&this.hass.states[e.entity_id]?.attributes?.device_class===`humidity`):[],r=this.hass?.states?e.filter(e=>e.entity_id.startsWith(`binary_sensor.`)&&[`occupancy`,`motion`,`presence`].includes(this.hass.states[e.entity_id]?.attributes?.device_class)||e.entity_id.startsWith(`input_boolean.`)):[],i=new Set(t.map(e=>e.entity_id)),a=this.temperatureSensor&&!i.has(this.temperatureSensor)?this.temperatureSensor:null,o=new Set(n.map(e=>e.entity_id)),s=this.humiditySensor&&!o.has(this.humiditySensor)?this.humiditySensor:null,c=new Set(r.map(e=>e.entity_id)),l=[...this.occupancySensors].filter(e=>!c.has(e)),u=this.hass?.states?e.filter(e=>e.entity_id.startsWith(`binary_sensor.`)&&[`window`,`door`,`opening`].includes(this.hass.states[e.entity_id]?.attributes?.device_class)):[],d=new Set(u.map(e=>e.entity_id)),f=[...this.windowSensors].filter(e=>!d.has(e)),p=this.hass.language;return m`
      ${this._renderBlock({kind:`temp`,icon:`mdi:thermometer`,title:S(`devices.temp_sensors`,p),emptyText:S(`devices.no_temp_sensors`,p),areaSensors:t,externalSensors:a?[a]:[],selectedCount:+!!this.temperatureSensor})}
      ${this._renderBlock({kind:`humidity`,icon:`mdi:water-percent`,title:S(`devices.humidity_sensors`,p),emptyText:S(`devices.no_humidity_sensors`,p),areaSensors:n,externalSensors:s?[s]:[],selectedCount:+!!this.humiditySensor})}
      ${this._renderBlock({kind:`occupancy`,icon:`mdi:account-eye`,title:S(`devices.occupancy_sensors`,p),emptyText:S(`devices.no_occupancy_sensors`,p),areaSensors:r,externalSensors:l,selectedCount:this.occupancySensors.size,extras:this._renderOccupancyExtras(p)})}
      ${this._renderBlock({kind:`window`,icon:`mdi:window-open-variant`,title:S(`devices.window_sensors`,p),emptyText:S(`devices.no_window_sensors`,p),areaSensors:u,externalSensors:f,selectedCount:this.windowSensors.size,extras:this._renderWindowExtras(p)})}
      ${this._renderGlobalAdd(p)}
    `}_renderOccupancyExtras(e){return this.occupancySensors.size===0?h:m`
      <rs-toggle-row
        class="occupancy-eco"
        .label=${S(`devices.occupancy_eco`,e)}
        .hint=${S(`devices.occupancy_eco_hint`,e)}
        .checked=${this.occupancyEcoEnabled}
        @toggle-changed=${e=>this._fireSensorChanged(`occupancy_eco_enabled`,e.detail)}
      ></rs-toggle-row>
      ${this.occupancyEcoEnabled?m`
              <div class="delay-fields">
                <ha-textfield
                  type="number"
                  min=${5}
                  max="240"
                  suffix="min"
                  .label=${S(`devices.occupancy_eco_delay`,e)}
                  .value=${String(this.occupancyEcoDelay)}
                  @change=${this._onOccupancyEcoDelayChange}
                ></ha-textfield>
              </div>
            `:h}
    `}_renderWindowExtras(e){return this.windowSensors.size===0?h:m`
      <div class="delay-fields">
        <ha-textfield
          type="number"
          min="0"
          suffix="s"
          .label=${S(`devices.window_open_delay`,e)}
          .value=${String(this.windowOpenDelay)}
          @change=${this._onWindowOpenDelayChange}
        ></ha-textfield>
        <ha-textfield
          type="number"
          min="0"
          suffix="s"
          .label=${S(`devices.window_close_delay`,e)}
          .value=${String(this.windowCloseDelay)}
          @change=${this._onWindowCloseDelayChange}
        ></ha-textfield>
      </div>
      ${this.heatingSystemType===`underfloor`&&this.windowOpenDelay<300?m`
              <div class="delay-hint">
                <ha-icon icon="mdi:information-outline"></ha-icon>
                ${S(`devices.underfloor_delay_hint`,e)}
              </div>
            `:h}
    `}_renderGlobalAdd(e){return this._pickerOpen?m`
        <div class="global-add">
          <ha-entity-picker
            .hass=${this.hass}
            .includeDomains=${[`sensor`,`binary_sensor`,`climate`,`input_number`,`input_boolean`]}
            .entityFilter=${this._globalEntityFilter}
            .value=${``}
            .autofocus=${!0}
            label=${S(`devices.add_entity`,e)}
            @value-changed=${this._onGlobalPickerValueChanged}
          ></ha-entity-picker>
          <ha-icon-button
            class="picker-close"
            .path=${`M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z`}
            @click=${()=>this._pickerOpen=!1}
          ></ha-icon-button>
        </div>
      `:m`
      <button type="button" class="add-button global" @click=${()=>this._pickerOpen=!0}>
        <ha-icon icon="mdi:plus"></ha-icon>
        ${S(`devices.add_entity`,e)}
      </button>
    `}_renderBlock(e){let t=e.areaSensors.length+e.externalSensors.length,n=this._collapsed[e.kind]??!0;return m`
      <div class="sensor-block ${n?`collapsed`:``}">
        <div class="block-header" @click=${()=>this._toggleBlock(e.kind)}>
          <ha-icon icon=${e.icon}></ha-icon>
          <div class="block-title">${e.title}</div>
          ${e.selectedCount>0?m`<span class="count-chip has-selection">${e.selectedCount}</span>`:t>0?m`<span class="count-chip">${t}</span>`:h}
          <ha-icon
            class="chevron ${n?`collapsed`:``}"
            icon="mdi:chevron-down"
          ></ha-icon>
        </div>
        ${n?h:m`
                <div class="block-body">
                  <div class="row-list">
                    ${e.areaSensors.length>0||e.externalSensors.length>0?m`
                            ${e.areaSensors.map(t=>this._renderEditRow(t.entity_id,e.kind,!1))}
                            ${e.externalSensors.map(t=>this._renderEditRow(t,e.kind,!0))}
                          `:m`<div class="empty-row">${e.emptyText}</div>`}
                  </div>
                  ${e.extras??h}
                </div>
              `}
      </div>
    `}_toggleBlock(e){let t=this._collapsed[e]??!0;this._collapsed={...this._collapsed,[e]:!t}}_renderEditRow(e,t,n){let r=this.hass.states[e],i=r?.attributes?.friendly_name||e,a=this.hass.language;if(t===`occupancy`||t===`window`){let o=(t===`occupancy`?this.occupancySensors:this.windowSensors).has(e),s=r?.state===`on`,c=t===`window`?`occupancy-dot window-dot`:`occupancy-dot`,l=n=>t===`occupancy`?this._onOccupancyToggle(e,n):this._onWindowToggle(e,n);return m`
        <div
          class="row ${o?`selected`:``}"
          @click=${e=>{e.target.tagName!==`HA-CHECKBOX`&&l(!o)}}
        >
          <ha-checkbox
            .checked=${o}
            @change=${e=>{let t=e.target;l(t.checked)}}
          ></ha-checkbox>
          <div class="row-info">
            <div class="row-name-line">
              <span class="row-name">${i}</span>
              ${n?m`<span class="external-badge"
                      >${S(`devices.other_area`,a)}</span
                    >`:h}
            </div>
            <div class="row-eid">${e}</div>
          </div>
          <span class="${c} ${s?`on`:`off`}"></span>
        </div>
      `}let o=(t===`temp`?this.temperatureSensor:this.humiditySensor)===e,s=t===`temp`?C(this.hass):`%`,c=e.startsWith(`climate.`)?r?.attributes?.current_temperature:r?.state,l=c&&c!==`unknown`&&c!==`unavailable`?`${t===`humidity`?Math.round(Number(c)):Number(c).toFixed(1)}${s}`:``;return m`
      <div
        class="row ${o?`selected`:``}"
        @click=${()=>this._onSensorSelected(o?``:e,t)}
      >
        <ha-radio .checked=${o} name="${t}-sensor"></ha-radio>
        <div class="row-info">
          <div class="row-name-line">
            <span class="row-name">${i}</span>
            ${n?m`<span class="external-badge">${S(`devices.other_area`,a)}</span>`:h}
          </div>
          <div class="row-eid">${e}</div>
        </div>
        ${l?m`<span class="value-chip">${l}</span>`:h}
      </div>
    `}_onSensorSelected(e,t){let n=t===`temp`?`temperature_sensor`:`humidity_sensor`;this.dispatchEvent(new CustomEvent(`sensor-changed`,{detail:{key:n,value:e},bubbles:!0,composed:!0}))}_onOccupancyToggle(e,t){let n=new Set(this.occupancySensors);t?n.add(e):n.delete(e),this.dispatchEvent(new CustomEvent(`sensor-changed`,{detail:{key:`occupancy_sensors`,value:[...n]},bubbles:!0,composed:!0}))}_onWindowToggle(e,t){let n=new Set(this.windowSensors);t?n.add(e):n.delete(e),this.dispatchEvent(new CustomEvent(`sensor-changed`,{detail:{key:`window_sensors`,value:[...n]},bubbles:!0,composed:!0}))}_fireSensorChanged(e,t){this.dispatchEvent(new CustomEvent(`sensor-changed`,{detail:{key:e,value:t},bubbles:!0,composed:!0}))}};A([y({attribute:!1})],B.prototype,`hass`,void 0),A([y({attribute:!1})],B.prototype,`area`,void 0),A([y({type:String})],B.prototype,`temperatureSensor`,void 0),A([y({type:String})],B.prototype,`humiditySensor`,void 0),A([y({attribute:!1})],B.prototype,`occupancySensors`,void 0),A([y({type:Boolean})],B.prototype,`occupancyEcoEnabled`,void 0),A([y({type:Number})],B.prototype,`occupancyEcoDelay`,void 0),A([y({attribute:!1})],B.prototype,`windowSensors`,void 0),A([y({type:Number})],B.prototype,`windowOpenDelay`,void 0),A([y({type:Number})],B.prototype,`windowCloseDelay`,void 0),A([y({type:String})],B.prototype,`heatingSystemType`,void 0),A([y({type:Boolean})],B.prototype,`editing`,void 0),A([y()],B.prototype,`language`,void 0),A([b()],B.prototype,`_pickerOpen`,void 0),A([b()],B.prototype,`_collapsed`,void 0),B=A([v(`rs-sensor-section`)],B),_(),x(),j();var Zt=class extends g{constructor(...e){super(...e),this.label=``,this.hint=``}static{this.styles=l`
    :host {
      display: inline-block;
    }

    .badge {
      font-size: 10px;
      font-weight: 600;
      color: var(--primary-color);
      background: color-mix(in srgb, var(--primary-color) 12%, transparent);
      padding: 2px 6px;
      border-radius: 4px;
      letter-spacing: 0.5px;
      text-transform: uppercase;
      cursor: default;
    }
  `}render(){return m`<span class="badge" title=${this.hint}>${this.label}</span>`}};A([y({type:String})],Zt.prototype,`label`,void 0),A([y({type:String})],Zt.prototype,`hint`,void 0),Zt=A([v(`rs-badge`)],Zt),_(),x(),j();var Qt=`M20.71,7.04C21.1,6.65 21.1,6 20.71,5.63L18.37,3.29C18,2.9 17.35,2.9 16.96,3.29L15.12,5.12L18.87,8.87M3,17.25V21H6.75L17.81,9.93L14.06,6.18L3,17.25Z`,$t=class extends g{constructor(...e){super(...e),this.icon=``,this.heading=``,this.badge=``,this.badgeHint=``,this.editable=!1}static{this.styles=l`
    :host {
      display: block;
    }

    ha-card {
      overflow: hidden;
      min-width: 0;
    }

    .section-header {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 16px 20px 12px;
    }

    .section-icon {
      --mdc-icon-size: 18px;
      opacity: 0.7;
    }

    .section-title {
      font-size: 15px;
      font-weight: 500;
      color: var(--primary-text-color);
      margin: 0;
      flex: 1;
    }

    .edit-btn {
      --mdc-icon-button-size: 32px;
      --mdc-icon-size: 18px;
      color: var(--secondary-text-color);
      margin: -4px -8px -4px 0;
      transition: opacity 0.15s ease;
    }

    @media (hover: hover) {
      .edit-btn {
        opacity: 0;
      }

      ha-card:hover .edit-btn,
      ha-card:focus-within .edit-btn {
        opacity: 1;
      }
    }

    .section-body {
      padding: 0 20px 20px;
    }
  `}render(){return m`
      <ha-card>
        <div class="section-header">
          <ha-icon class="section-icon" icon=${this.icon}></ha-icon>
          <h3 class="section-title">${this.heading}</h3>
          ${this.badge?m`<rs-badge .label=${this.badge} .hint=${this.badgeHint}></rs-badge>`:h}
          <slot name="header-extras"></slot>
          ${this.editable?m`
                  <ha-icon-button
                    class="edit-btn"
                    .path=${Qt}
                    @click=${this._onEditClick}
                  ></ha-icon-button>
                `:h}
        </div>
        <div class="section-body">
          <slot></slot>
        </div>
      </ha-card>
    `}_onEditClick(){this.dispatchEvent(new CustomEvent(`edit-click`,{bubbles:!0,composed:!0}))}};A([y({type:String})],$t.prototype,`icon`,void 0),A([y({type:String})],$t.prototype,`heading`,void 0),A([y({type:String})],$t.prototype,`badge`,void 0),A([y({type:String})],$t.prototype,`badgeHint`,void 0),A([y({type:Boolean})],$t.prototype,`editable`,void 0),$t=A([v(`rs-section-card`)],$t),_(),x(),j();var V=class extends g{constructor(...e){super(...e),this.climateMode=`auto`,this.comfortHeat=21,this.comfortCool=24,this.ecoHeat=17,this.ecoCool=27,this.language=`en`,this._overridePending=null,this._overrideCustomHeat=21,this._overrideCustomCool=24,this._overrideError=``,this._optimisticOverride=null,this._optimisticClear=!1}static{this.styles=[L,l`
      :host {
        display: block;
      }

      .override-divider {
        border: none;
        border-top: 1px solid var(--divider-color, #e0e0e0);
        margin: 16px 0 12px;
      }

      .override-label {
        font-size: 13px;
        font-weight: 500;
        color: var(--secondary-text-color);
        margin-bottom: 10px;
      }

      .override-presets {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
      }

      .override-preset {
        cursor: pointer;
        border: 1px solid var(--divider-color, #e0e0e0);
        border-radius: 8px;
        padding: 6px 12px;
        font-size: 13px;
        background: transparent;
        color: var(--primary-text-color);
        display: flex;
        align-items: center;
        gap: 6px;
        transition:
          background 0.15s,
          border-color 0.15s;
      }

      .override-preset:hover {
        background: rgba(0, 0, 0, 0.04);
      }

      .override-preset.pending {
        border-color: var(--primary-color);
        background: rgba(var(--rgb-primary-color, 33, 150, 243), 0.08);
      }

      .override-preset.active.boost {
        border-color: var(--warning-color, #ff9800);
        background: rgba(255, 152, 0, 0.15);
        color: var(--warning-color, #ff9800);
      }

      .override-preset.active.eco {
        border-color: #4caf50;
        background: rgba(76, 175, 80, 0.15);
        color: #4caf50;
      }

      .override-preset.active.custom {
        border-color: #2196f3;
        background: rgba(33, 150, 243, 0.15);
        color: #2196f3;
      }

      .override-preset:disabled {
        opacity: 0.35;
        cursor: default;
      }

      .override-preset:disabled:hover {
        background: transparent;
      }

      .override-preset ha-icon {
        --mdc-icon-size: 16px;
      }

      .override-target {
        display: block;
        width: 160px;
        margin-top: 12px;
      }

      .override-duration {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        margin-top: 12px;
        align-items: center;
      }

      .override-duration-label {
        font-size: 13px;
        font-weight: 500;
        color: var(--secondary-text-color);
      }

      .override-dur-chips {
        display: flex;
        gap: 6px;
      }

      .override-dur-chip {
        cursor: pointer;
        border: 1px solid var(--divider-color);
        border-radius: 8px;
        padding: 6px 14px;
        font-size: 13px;
        font-weight: 500;
        background: var(--card-background-color);
        color: var(--primary-text-color);
        transition:
          border-color 0.15s ease,
          background 0.15s ease;
      }

      .override-dur-chip:hover {
        background: rgba(255, 255, 255, 0.04);
        border-color: rgba(3, 169, 244, 0.4);
      }

      .override-dur-chip:disabled {
        opacity: 0.5;
        pointer-events: none;
      }

      .override-error {
        color: var(--error-color, #d32f2f);
        font-size: 12px;
        margin-top: 6px;
      }
    `]}updated(e){if(e.has(`config`)&&this.config?.live){let e=this.config.live;this._optimisticOverride&&e.override_active&&(this._optimisticOverride=null),this._optimisticClear&&!e.override_active&&(this._optimisticClear=!1)}}getEffectiveOverride(){if(this._optimisticClear)return{active:!1,type:null,heat:null,cool:null,until:null};if(this._optimisticOverride)return{active:!0,type:this._optimisticOverride.type,heat:this._optimisticOverride.heat,cool:this._optimisticOverride.cool,until:this._optimisticOverride.until};let e=this.config?.live;return e?.override_active&&e.override_type?{active:!0,type:e.override_type,heat:e.override_heat,cool:e.override_cool,until:e.override_until}:{active:!1,type:null,heat:null,cool:null,until:null}}render(){let e=this.getEffectiveOverride();return m`
      <hr class="override-divider" />
      <div class="override-label">${S(`override.label`,this.language)}</div>
      ${this._renderOverrideButtons(e)}
      ${this._overrideError?m`<div class="override-error">${this._overrideError}</div>`:h}
    `}_renderOverrideButtons(e){let t=e.active?e.type:null,n=!t&&this._overridePending;return m`
      <div class="override-presets">
        ${[`boost`,`eco`,`custom`].map(e=>{let n=t===e,r=t!==null&&!n,i=!t&&this._overridePending===e;return m`
            <button
              class="override-preset ${e} ${n?`active`:``} ${i?`pending`:``}"
              ?disabled=${r}
              @click=${()=>n?this._onClearOverride():this._onOverridePreset(e)}
            >
              <ha-icon
                icon=${e===`boost`?`mdi:fire`:e===`eco`?`mdi:leaf`:`mdi:thermometer`}
              ></ha-icon>
              ${S(e===`boost`?`override.comfort`:e===`eco`?`override.eco`:`override.custom`,this.language)}
            </button>
          `})}
      </div>
      ${n?m`
              ${this._overridePending===`custom`?this._renderCustomInputs():h}
              <div class="override-duration">
                <span class="override-duration-label"
                  >${S(`override.activate_for`,this.language)}</span
                >
                <div class="override-dur-chips">
                  ${[{label:`1h`,hours:1},{label:`2h`,hours:2},{label:`4h`,hours:4}].map(e=>m`
                      <button
                        class="override-dur-chip"
                        @click=${()=>this._onOverrideActivate(e.hours)}
                      >
                        ${e.label}
                      </button>
                    `)}
                </div>
              </div>
            `:h}
    `}_renderCustomInputs(){let e=k(5,35,this.hass),t=m`
      <ha-textfield
        class="override-target"
        type="number"
        .label=${S(this.climateMode===`auto`?`override.heat_to`:`override.target`,this.language)}
        .suffix=${C(this.hass)}
        min=${e.min}
        max=${e.max}
        step=${O(this.hass)}
        .value=${String(w(this._overrideCustomHeat,this.hass))}
        @input=${this._onCustomHeatInput}
      ></ha-textfield>
    `,n=m`
      <ha-textfield
        class="override-target"
        type="number"
        .label=${S(this.climateMode===`auto`?`override.cool_above`:`override.target`,this.language)}
        .suffix=${C(this.hass)}
        min=${e.min}
        max=${e.max}
        step=${O(this.hass)}
        .value=${String(w(this._overrideCustomCool,this.hass))}
        @input=${this._onCustomCoolInput}
      ></ha-textfield>
    `;return this.climateMode===`heat_only`?t:this.climateMode===`cool_only`?n:m`${t} ${n}`}_onOverridePreset(e){this._overridePending===e?this._overridePending=null:(this._overridePending=e,e===`custom`&&(this._overrideCustomHeat=this.comfortHeat,this._overrideCustomCool=this.comfortCool)),this._overrideError=``}_onCustomHeatInput(e){this._overrideCustomHeat=T(Number(e.target.value)||w(21,this.hass),this.hass)}_onCustomCoolInput(e){this._overrideCustomCool=T(Number(e.target.value)||w(24,this.hass),this.hass)}async _onOverrideActivate(e){if(!this._overridePending||!this.config)return;let t=this._overridePending,n,r;if(t===`boost`?(n=this.comfortHeat,r=this.comfortCool):t===`eco`?(n=this.ecoHeat,r=this.ecoCool):(n=this._overrideCustomHeat,r=this._overrideCustomCool),this.climateMode===`heat_only`&&(r=null),this.climateMode===`cool_only`&&(n=null),n!=null&&r!=null&&r<n){this._overrideError=S(`override.invalid_band`,this.language);return}this._optimisticOverride={type:t,heat:n,cool:r,until:Date.now()/1e3+e*3600},this._optimisticClear=!1,this._overridePending=null,this._overrideError=``;let i={type:`roommind/override/set`,area_id:this.config.area_id,override_type:t,duration:e};t===`custom`&&(this.climateMode!==`cool_only`&&(i.heat=this._overrideCustomHeat),this.climateMode!==`heat_only`&&(i.cool=this._overrideCustomCool));try{await this.hass.callWS(i),this._fireRoomUpdated()}catch(e){this._optimisticOverride=null,this._overrideError=e instanceof Error?e.message:S(`override.error_set`,this.language),console.error(`Override set failed:`,e)}}async _onClearOverride(){if(this.config){this._optimisticClear=!0,this._optimisticOverride=null,this._overrideError=``;try{await this.hass.callWS({type:`roommind/override/clear`,area_id:this.config.area_id}),this._fireRoomUpdated()}catch(e){this._optimisticClear=!1,this._overrideError=e instanceof Error?e.message:S(`override.error_clear`,this.language),console.error(`Override clear failed:`,e)}}}_fireRoomUpdated(){this.dispatchEvent(new CustomEvent(`room-updated`,{bubbles:!0,composed:!0}))}};A([y({attribute:!1})],V.prototype,`hass`,void 0),A([y({attribute:!1})],V.prototype,`config`,void 0),A([y()],V.prototype,`climateMode`,void 0),A([y({type:Number})],V.prototype,`comfortHeat`,void 0),A([y({type:Number})],V.prototype,`comfortCool`,void 0),A([y({type:Number})],V.prototype,`ecoHeat`,void 0),A([y({type:Number})],V.prototype,`ecoCool`,void 0),A([y()],V.prototype,`language`,void 0),A([b()],V.prototype,`_overridePending`,void 0),A([b()],V.prototype,`_overrideCustomHeat`,void 0),A([b()],V.prototype,`_overrideCustomCool`,void 0),A([b()],V.prototype,`_overrideError`,void 0),A([b()],V.prototype,`_optimisticOverride`,void 0),A([b()],V.prototype,`_optimisticClear`,void 0),V=A([v(`rs-override-section`)],V),_(),x(),j();var en=class extends g{constructor(...e){super(...e),this.presenceEnabled=!1,this.presencePersons=[],this.selectedPresencePersons=[],this.ignorePresence=!1,this.editing=!1,this.language=`en`}static{this.styles=l`
    :host {
      display: block;
    }

    .presence-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
      gap: 8px;
      margin-top: 12px;
    }

    .presence-card {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 8px 12px 8px 6px;
      border: 1px solid var(--divider-color);
      border-radius: 10px;
      background: var(--card-background-color);
      cursor: pointer;
      transition:
        border-color 0.15s ease,
        background 0.15s ease;
      user-select: none;
    }

    .presence-card:hover {
      background: rgba(255, 255, 255, 0.03);
    }

    .presence-card.active {
      border-color: rgba(3, 169, 244, 0.4);
      background: rgba(3, 169, 244, 0.08);
    }

    .presence-card ha-checkbox {
      flex-shrink: 0;
    }

    .person-icon {
      --mdc-icon-size: 18px;
      color: var(--secondary-text-color);
      flex-shrink: 0;
    }

    .presence-card.active .person-icon {
      color: var(--primary-color);
    }

    .person-name {
      flex: 1;
      font-size: 14px;
      font-weight: 450;
      min-width: 0;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .presence-list {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }

    .presence-row {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 10px 14px;
      border-radius: 8px;
      transition: background 0.3s;
    }

    .presence-row.home {
      background: rgba(76, 175, 80, 0.1);
    }

    .presence-row.away {
      background: rgba(0, 0, 0, 0.04);
    }

    .presence-dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      flex-shrink: 0;
    }

    .presence-row.home .presence-dot {
      background: #4caf50;
      box-shadow: 0 0 6px rgba(76, 175, 80, 0.5);
    }

    .presence-row.away .presence-dot {
      background: var(--disabled-text-color, #bdbdbd);
    }

    .presence-name {
      flex: 1;
      font-size: 14px;
      font-weight: 500;
      min-width: 0;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .presence-row.home .presence-name {
      color: var(--primary-text-color);
    }

    .presence-row.away .presence-name {
      color: var(--secondary-text-color);
    }

    .presence-state {
      font-size: 12px;
      white-space: nowrap;
    }

    .presence-row.home .presence-state {
      color: #2e7d32;
    }

    .presence-row.away .presence-state {
      color: var(--secondary-text-color);
    }

    .section-divider {
      border-top: 1px solid var(--divider-color, #e0e0e0);
      margin: 8px 0;
    }

    .field-hint {
      color: var(--secondary-text-color);
      font-size: 12px;
    }

    .presence-card.missing {
      border-color: var(--warning-color, #ff9800);
    }

    .missing-icon {
      --mdc-icon-size: 16px;
      color: var(--warning-color, #ff9800);
      flex-shrink: 0;
    }

    .missing-hint {
      margin-top: 8px;
      color: var(--secondary-text-color);
      font-size: 12px;
    }
  `}get _allPersons(){let e=this.selectedPresencePersons.filter(e=>!this.presencePersons.includes(e));return[...this.presencePersons,...e]}_isMissing(e){return!this.hass.states[e]}render(){return!this.presenceEnabled||!this.editing&&this._allPersons.length===0?h:this.editing?m`
      <rs-toggle-row
        .label=${S(`presence.ignore_toggle`,this.language)}
        .checked=${this.ignorePresence}
        @toggle-changed=${this._onIgnoreToggle}
      ></rs-toggle-row>
      ${this.ignorePresence?h:m`<div class="section-divider"></div>
              ${this._renderEditMode()}`}
    `:this.ignorePresence?m`<span class="field-hint"
          >${S(`presence.tile_ignored`,this.language)}</span
        >`:this._renderViewMode()}_renderEditMode(){let e=this._allPersons,t=e.some(e=>this._isMissing(e));return m`
      <div class="presence-grid">
        ${e.map(e=>{let t=this.selectedPresencePersons.includes(e),n=this._isMissing(e),r=this.hass.states[e]?.attributes?.friendly_name??e.split(`.`).slice(1).join(`.`);return m`
            <div
              class="presence-card ${t?`active`:``} ${n?`missing`:``}"
              role="checkbox"
              tabindex="0"
              aria-checked=${t}
              @click=${()=>this._onTogglePerson(e,t)}
              @keydown=${n=>{(n.key===`Enter`||n.key===` `)&&(n.preventDefault(),this._onTogglePerson(e,t))}}
            >
              <ha-checkbox
                .checked=${t}
                tabindex="-1"
                @click=${e=>e.stopPropagation()}
                @change=${()=>this._onTogglePerson(e,t)}
              ></ha-checkbox>
              <ha-icon class="person-icon" icon="mdi:account"></ha-icon>
              <span class="person-name">${r}</span>
              ${n?this._renderMissingIcon():h}
            </div>
          `})}
      </div>
      ${t?m`<div class="missing-hint">
              ${S(`presence.missing_entity_hint`,this.language)}
            </div>`:h}
    `}_renderMissingIcon(){return m`<ha-icon
      class="missing-icon"
      icon="mdi:alert-circle-outline"
      title=${S(`presence.missing_entity_hint`,this.language)}
    ></ha-icon>`}_renderViewMode(){return this.selectedPresencePersons.length===0?m`<span class="field-hint"
        >${S(`presence.room_none_assigned`,this.language)}</span
      >`:m`
      <div class="presence-list">
        ${this.selectedPresencePersons.map(e=>{let t=this.hass.states[e]?.attributes?.friendly_name??e.split(`.`).slice(1).join(`.`),n=this.hass.states[e]?.state,r=e.startsWith(`person.`)||e.startsWith(`device_tracker.`)?n===`home`:n===`on`;return m`
            <div class="presence-row ${r?`home`:`away`}">
              <span class="presence-dot"></span>
              <span class="presence-name">${t}</span>
              ${this._isMissing(e)?this._renderMissingIcon():h}
              <span class="presence-state"
                >${S(r?`presence.state_home`:`presence.state_away`,this.language)}</span
              >
            </div>
          `})}
      </div>
    `}_onIgnoreToggle(e){this.dispatchEvent(new CustomEvent(`ignore-presence-changed`,{detail:e.detail,bubbles:!0,composed:!0}))}_onTogglePerson(e,t){let n;n=t?this.selectedPresencePersons.filter(t=>t!==e):[...this.selectedPresencePersons,e],this.dispatchEvent(new CustomEvent(`presence-persons-changed`,{detail:n,bubbles:!0,composed:!0}))}};A([y({attribute:!1})],en.prototype,`hass`,void 0),A([y({type:Boolean})],en.prototype,`presenceEnabled`,void 0),A([y({attribute:!1})],en.prototype,`presencePersons`,void 0),A([y({attribute:!1})],en.prototype,`selectedPresencePersons`,void 0),A([y({type:Boolean})],en.prototype,`ignorePresence`,void 0),A([y({type:Boolean})],en.prototype,`editing`,void 0),A([y()],en.prototype,`language`,void 0),en=A([v(`rs-presence-section`)],en),_(),x(),j();var tn=class extends g{constructor(...e){super(...e),this.label=``,this.suffix=``,this.hint=``}static{this.styles=[L,l`
      :host {
        display: block;
      }

      .row {
        display: flex;
        align-items: center;
        gap: 6px;
      }

      ha-textfield {
        display: block;
        flex: 1;
        min-width: 0;
      }

      rs-info-icon {
        flex-shrink: 0;
      }
    `]}render(){return m`
      <div class="row">
        <ha-textfield
          .label=${this.label}
          .suffix=${this.suffix}
          .value=${this.value==null?``:String(this.value)}
          .min=${this.min==null?``:String(this.min)}
          .max=${this.max==null?``:String(this.max)}
          .step=${this.step==null?``:String(this.step)}
          type="number"
          @input=${this._onInput}
        ></ha-textfield>
        ${this.hint?m`<rs-info-icon .text=${this.hint}></rs-info-icon>`:h}
      </div>
    `}_onInput(e){let t=parseFloat(e.target.value);isNaN(t)||this.dispatchEvent(new CustomEvent(`value-changed`,{detail:t,bubbles:!0,composed:!0}))}};A([y({type:String})],tn.prototype,`label`,void 0),A([y({type:String})],tn.prototype,`suffix`,void 0),A([y({type:Number})],tn.prototype,`value`,void 0),A([y({type:Number})],tn.prototype,`min`,void 0),A([y({type:Number})],tn.prototype,`max`,void 0),A([y({type:Number})],tn.prototype,`step`,void 0),A([y({type:String})],tn.prototype,`hint`,void 0),tn=A([v(`rs-threshold-field`)],tn),_(),x(),j();var nn=class extends zt{constructor(...e){super(...e),this.schedules=[]}static{this.styles=[zt.sharedStyles,L,l`
      .pos-badge {
        font-size: 0.8em;
        padding: 1px 6px;
        border-radius: 10px;
        background: var(--primary-color);
        color: var(--text-primary-color);
        flex-shrink: 0;
      }
      .gate-badge {
        font-size: 0.8em;
        padding: 1px 6px;
        border-radius: 10px;
        background: var(--accent-color, var(--primary-color));
        color: var(--text-primary-color);
        opacity: 0.8;
        flex-shrink: 0;
      }
      .mode-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 8px;
        padding: 4px 0 0;
      }
      @media (max-width: 480px) {
        .mode-row {
          grid-template-columns: 1fr;
        }
      }
      .mode-option {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 6px 12px;
        font-size: 13px;
        cursor: pointer;
        color: var(--primary-text-color);
        border: 1px solid var(--divider-color);
        border-radius: 8px;
        background: var(--card-background-color);
        transition:
          border-color 0.15s ease,
          background 0.15s ease;
      }
      .mode-option.active {
        border-color: rgba(3, 169, 244, 0.4);
        background: rgba(3, 169, 244, 0.08);
      }
    `]}render(){return this.editing?this._renderEdit():this._renderView()}_renderView(){let e=this.hass.language;if(this.schedules.length===0)return h;let t=this.schedules.length>=2;return m`
      <div class="schedule-list">
        ${this.schedules.map((n,r)=>{let i=this._getScheduleState(r,this.schedules.length),a=n.mode===`gate`,o=a?null:this._getBlockPosition(n.entity_id);return m`
            <div class="schedule-row ${i}">
              ${t?m`<span class="schedule-number">${r+1}</span>`:h}
              <span class="schedule-status-dot"></span>
              <span
                class="schedule-name schedule-link"
                @click=${()=>this._openEntityInfo(n.entity_id)}
                >${this._getFriendlyName(n.entity_id)}</span
              >
              ${a?m`<span class="gate-badge"
                      >${S(`covers.schedule_mode_gate_short`,e)}</span
                    >`:o===null?h:m`<span class="pos-badge">${o}%</span>`}
              <span class="schedule-status">${this._statusText(i,e)}</span>
            </div>
          `})}
      </div>
    `}_renderEdit(){let e=this.hass.language,t=this.schedules.length,n=new Set(this.schedules.map(e=>e.entity_id));return m`
      ${t>0?m`
              <div class="schedule-list">
                ${this.schedules.map((n,r)=>{let i=this._getScheduleState(r,t);return m`
                    <div class="schedule-row ${i}">
                      ${t>=2?m`<span class="schedule-number">${r+1}</span>`:h}
                      <span class="schedule-status-dot"></span>
                      <span class="schedule-name">${this._getFriendlyName(n.entity_id)}</span>
                      <span class="schedule-status">${this._statusText(i,e)}</span>
                      ${this._renderScheduleControls(r,t,(e,t)=>this._moveSchedule(e,t),e=>this._removeSchedule(e))}
                    </div>
                    <div class="mode-row">
                      <div
                        class="mode-option ${(n.mode??`force`)===`force`?`active`:``}"
                        role="radio"
                        tabindex="0"
                        aria-checked=${(n.mode??`force`)===`force`}
                        @click=${()=>this._updateMode(r,`force`)}
                        @keydown=${e=>{(e.key===`Enter`||e.key===` `)&&(e.preventDefault(),this._updateMode(r,`force`))}}
                      >
                        <ha-radio
                          .checked=${(n.mode??`force`)===`force`}
                          tabindex="-1"
                        ></ha-radio>
                        ${S(`covers.schedule_mode_force`,e)}
                      </div>
                      <div
                        class="mode-option ${n.mode===`gate`?`active`:``}"
                        role="radio"
                        tabindex="0"
                        aria-checked=${n.mode===`gate`}
                        @click=${()=>this._updateMode(r,`gate`)}
                        @keydown=${e=>{(e.key===`Enter`||e.key===` `)&&(e.preventDefault(),this._updateMode(r,`gate`))}}
                      >
                        <ha-radio .checked=${n.mode===`gate`} tabindex="-1"></ha-radio>
                        ${S(`covers.schedule_mode_gate`,e)}
                      </div>
                    </div>
                  `})}
              </div>
            `:h}
      ${this._renderAddRow(S(`covers.add_schedule`,e),this._getAvailableEntities(n),e=>this._addSchedule(e),S(`covers.schedule_create_link`,e))}
      ${this._renderSelectorSection(t,S(`covers.schedule_selector`,e),S(`covers.schedule_selector_hint`,e),S(`covers.schedule_selector_warning`,e),e=>this._emitSelectorChanged(e))}
    `}_getBlockPosition(e){let t=this.hass?.states?.[e];if(!t||t.state!==`on`)return null;let n=t.attributes?.position;return n==null?null:Number(n)}_statusText(e,t){return S(e===`active`?`covers.schedule_state_active`:e===`unreachable`?`covers.schedule_state_unreachable`:`covers.schedule_state_inactive`,t)}_addSchedule(e){this._emitSchedules([...this.schedules,{entity_id:e,mode:`force`}])}_removeSchedule(e){this._emitSchedules(this.schedules.filter((t,n)=>n!==e))}_moveSchedule(e,t){let n=e+t;if(n<0||n>=this.schedules.length)return;let r=[...this.schedules];[r[e],r[n]]=[r[n],r[e]],this._emitSchedules(r)}_updateMode(e,t){let n=this.schedules.map((n,r)=>r===e?{...n,mode:t}:n);this._emitSchedules(n)}_emitSchedules(e){this.dispatchEvent(new CustomEvent(`cover-schedules-changed`,{detail:{value:e},bubbles:!0,composed:!0}))}_emitSelectorChanged(e){this.dispatchEvent(new CustomEvent(`cover-schedule-selector-changed`,{detail:{value:e},bubbles:!0,composed:!0}))}};A([y({attribute:!1})],nn.prototype,`schedules`,void 0),nn=A([v(`rs-cover-schedule`)],nn),_(),x(),j();var rn,H=class extends g{static{rn=this}constructor(...e){super(...e),this.selectedCovers=new Set,this.editing=!1,this.autoEnabled=!1,this.deployThreshold=1.5,this.minPosition=0,this.overrideMinutes=60,this.autoPaused=!1,this.overrideUntil=null,this.coverSchedules=[],this.coverScheduleSelectorEntity=``,this.activeCoverScheduleIndex=-1,this.nightClose=!1,this.nightPosition=0,this.snapDeploy=!1,this.forcedReason=``,this.coverOrientations={},this.nightCloseElevation=0,this.nightCloseOffsetMinutes=0,this.outdoorMinTemp=10,this.coverMinPositions={},this._selectedForEdit=``,this._scheduleCollapsed=!0,this._solarCollapsed=!0,this._entityFilter=e=>{let t=e.entity_id;return!t.startsWith(`cover.roommind_`)&&t.startsWith(`cover.`)&&!this.selectedCovers.has(t)}}willUpdate(e){e.has(`selectedCovers`)&&(this._selectedForEdit&&!this.selectedCovers.has(this._selectedForEdit)&&(this._selectedForEdit=``),!this._selectedForEdit&&this.selectedCovers.size>0&&(this._selectedForEdit=[...this.selectedCovers][0]))}static{this.styles=[Gt,L,l`
      :host {
        display: block;
      }

      /* Tile view rows (match rs-sensor-section visual rhythm) */
      .view-row {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 6px 0;
        font-size: 14px;
        color: var(--primary-text-color);
      }

      .view-name {
        flex: 1;
        min-width: 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .view-pill {
        font-size: 10px;
        font-weight: 500;
        padding: 1px 7px;
        border-radius: 8px;
        background: rgba(255, 255, 255, 0.05);
        color: var(--secondary-text-color);
        letter-spacing: 0.3px;
        text-transform: uppercase;
        flex-shrink: 0;
      }

      .view-value {
        font-weight: 500;
        flex-shrink: 0;
        color: var(--primary-text-color);
      }

      /* Device-row style (matches rs-device-section) */
      .device-list-scroll {
        max-height: 210px;
        overflow-y: auto;
      }
      .device-row {
        display: flex;
        align-items: center;
        padding: 4px 0;
        margin-bottom: 2px;
        border-radius: 8px;
        transition: background 0.15s;
      }
      .device-row:hover {
        background: rgba(0, 0, 0, 0.02);
      }
      .device-row.selected {
        background: rgba(3, 169, 244, 0.035);
      }
      .device-row ha-checkbox {
        flex-shrink: 0;
      }
      .device-info {
        flex: 1;
        min-width: 0;
      }
      .device-name-row {
        display: flex;
        align-items: center;
        gap: 6px;
      }
      .device-name {
        font-size: 14px;
        font-weight: 450;
      }
      .device-value {
        margin-left: auto;
        font-size: 13px;
        font-weight: 500;
        padding-right: 4px;
        white-space: nowrap;
      }
      .device-entity {
        font-family: var(--code-font-family, monospace);
        font-size: 11px;
        color: var(--secondary-text-color);
        opacity: 0.7;
      }
      .external-badge {
        display: inline-flex;
        align-items: center;
        font-size: 10px;
        font-weight: 500;
        color: var(--secondary-text-color);
        background: var(--divider-color, rgba(0, 0, 0, 0.06));
        padding: 1px 6px;
        border-radius: 4px;
        white-space: nowrap;
      }
      .no-devices {
        color: var(--secondary-text-color);
        font-size: 13px;
        padding: 8px 0;
      }

      .entity-picker-wrap {
        margin-top: 8px;
      }
      ha-entity-picker {
        width: 100%;
      }
      .settings-group {
        margin-top: 16px;
        display: flex;
        flex-direction: column;
        gap: 12px;
      }
      .sub-section {
        margin-top: 20px;
        display: flex;
        flex-direction: column;
        gap: 12px;
      }
      .sub-section:first-child {
        margin-top: 8px;
      }
      .sub-section-header {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 13px;
        font-weight: 500;
        color: var(--secondary-text-color);
        text-transform: uppercase;
        letter-spacing: 0.3px;
        padding-bottom: 4px;
        border-bottom: 1px solid var(--divider-color, rgba(0, 0, 0, 0.12));
      }
      .sub-section-header ha-icon {
        --mdc-icon-size: 18px;
      }
      .field-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 12px;
      }
      @media (max-width: 450px) {
        .field-row {
          grid-template-columns: 1fr;
        }
      }
      .no-items {
        color: var(--secondary-text-color);
        font-size: 0.9em;
        margin: 0;
      }
      .status-hint {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 6px;
        color: var(--secondary-text-color);
        font-size: 0.85em;
      }
      .status-hint.paused {
        color: var(--warning-color, #ff9800);
      }
      .pill {
        font-size: 10px;
        font-weight: 500;
        padding: 1px 6px;
        border-radius: 10px;
        background: var(--divider-color, rgba(0, 0, 0, 0.08));
        color: var(--secondary-text-color);
        white-space: nowrap;
      }

      /* Editing layout — feature card + grouped sections */
      .feature-card {
        display: flex;
        align-items: center;
        gap: 14px;
        padding: 14px 16px;
        border: 1px solid var(--divider-color);
        border-radius: 12px;
        background: var(--card-background-color);
        transition:
          border-color 0.2s ease,
          background 0.2s ease;
      }

      .feature-card.enabled {
        border-color: rgba(3, 169, 244, 0.4);
        background: rgba(3, 169, 244, 0.06);
      }

      .feature-text {
        flex: 1;
        min-width: 0;
      }

      .feature-title {
        font-size: 14px;
        font-weight: 500;
        margin: 0 0 4px;
      }

      .feature-description {
        font-size: 12px;
        color: var(--secondary-text-color);
        line-height: 1.5;
        margin: 0;
      }

      .feature-card ha-switch {
        flex-shrink: 0;
      }

      .group-card {
        margin-top: 16px;
        border: 1px solid var(--divider-color);
        border-radius: 12px;
        background: var(--card-background-color);
        padding: 14px 16px;
        display: flex;
        flex-direction: column;
        gap: 12px;
      }

      .group-header {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 12px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.4px;
        color: var(--secondary-text-color);
        cursor: pointer;
        user-select: none;
      }

      .group-header > span:first-of-type {
        flex: 1;
        min-width: 0;
      }

      .group-header ha-icon {
        --mdc-icon-size: 18px;
        color: var(--secondary-text-color);
      }

      .group-header .chevron {
        transition: transform 0.2s ease;
        margin-left: auto;
      }

      .group-header .chevron.collapsed {
        transform: rotate(-90deg);
      }

      .group-card.collapsed {
        gap: 0;
        padding-bottom: 14px;
      }

      .group-divider {
        height: 1px;
        background: var(--divider-color);
        margin: 4px -16px;
      }
    `]}render(){let e=this.hass.language;return this.editing?this._renderEdit(e):this._renderView(e)}_renderView(e){let t=[...this.selectedCovers];return t.length===0?m`<p class="no-items">${S(`covers.no_covers`,e)}</p>`:m`
      ${t.map(t=>{let n=this.hass.states[t],r=n?.attributes?.friendly_name??t,i=n?.attributes?.current_position,a=this.coverOrientations[t],o=a===void 0?void 0:rn._DIRECTIONS.find(e=>e.deg===a),s=o?S(o.shortLabel,e):void 0,c=this.coverMinPositions[t];return m`
          <div class="view-row">
            <span class="view-name">${r}</span>
            ${s?m`<span class="view-pill">${s}</span>`:h}
            ${c!==void 0&&c>0?m`<span class="view-pill"
                    >${S(`covers.per_cover_min_short`,e)} ${c}%</span
                  >`:h}
            ${i===void 0?h:m`<span class="view-value">${i}%</span>`}
          </div>
        `})}
      ${this.autoPaused?m`
              <div class="status-hint paused">
                <ha-icon icon="mdi:hand-back-right"></ha-icon>
                <span>
                  ${this.overrideUntil?`${S(`covers.auto_paused_until`,e)} ${new Date(this.overrideUntil*1e3).toLocaleTimeString(e,{hour:`2-digit`,minute:`2-digit`})}`:S(`covers.auto_paused`,e)}
                </span>
                <ha-button @click=${this._onResumeAuto}
                  >${S(`covers.resume_auto`,e)}</ha-button
                >
              </div>
            `:this.autoEnabled?m`
                <div class="status-hint">
                  <ha-icon icon="mdi:sun-angle-outline"></ha-icon>
                  <span>${S(`covers.shading_active`,e)}</span>
                </div>
              `:h}
      ${this.forcedReason===`schedule_active`?m`
              <div class="status-hint">
                <ha-icon icon="mdi:calendar-clock"></ha-icon>
                <span>${S(`covers.schedule_active`,e)}</span>
              </div>
            `:this.forcedReason===`night_close`?m`
                <div class="status-hint">
                  <ha-icon icon="mdi:weather-night"></ha-icon>
                  <span>${S(`covers.night_close_active`,e)}</span>
                </div>
              `:h}
    `}_renderMasterRow(e,t){let n=this.selectedCovers.has(e),r=this._selectedForEdit===e,i=this.hass.states[e],a=i?.attributes?.friendly_name||e,o=i?.attributes?.current_position,s=this.hass.language,c=this.coverOrientations[e],l=c===void 0?void 0:rn._DIRECTIONS.find(e=>e.deg===c),u=l?S(l.shortLabel,s):``,d=this.coverMinPositions[e];return m`
      <div
        class="master-row ${r?`focused`:``}"
        @click=${()=>this._selectedForEdit=e}
      >
        <ha-checkbox
          .checked=${n}
          @click=${e=>e.stopPropagation()}
          @change=${t=>{let n=t.target;this._onToggle(e,n.checked),n.checked&&(this._selectedForEdit=e)}}
        ></ha-checkbox>
        <div class="master-info">
          <div class="master-name-row">
            <span class="master-name">${a}</span>
            ${t?m`<span class="external-badge">${S(`devices.other_area`,s)}</span>`:h}
          </div>
          <div class="master-meta">
            ${u?m`<span class="meta-pill">${u}</span>`:h}
            ${d!==void 0&&d>0?m`<span class="meta-pill">min ${d}%</span>`:h}
            ${o===void 0?h:m`<span class="meta-pill" style="color: var(--primary-color);">${o}%</span>`}
          </div>
        </div>
      </div>
    `}_renderCoverDetail(e){let t=this.hass.language,n=this.hass.states[e]?.attributes?.friendly_name||e,r=this.coverOrientations[e],i=this.coverMinPositions[e];return m`
      <div class="detail-head">
        <div class="detail-title">${n}</div>
        <div class="detail-entity-id">${e}</div>
      </div>
      <div class="detail-field">
        <ha-select
          .label=${S(`covers.orientation_group_title`,t)}
          .value=${r===void 0?``:String(r)}
          .options=${[{value:``,label:S(`covers.orientation_none`,t)},...rn._DIRECTIONS.map(e=>({value:String(e.deg),label:S(e.longLabel,t)}))]}
          fixedMenuPosition
          @selected=${t=>{let n=F(t);this._setOrientation(e,n===``?void 0:Number(n))}}
          @closed=${e=>e.stopPropagation()}
        >
          <ha-list-item value="">${S(`covers.orientation_none`,t)}</ha-list-item>
          ${rn._DIRECTIONS.map(e=>m`
              <ha-list-item value=${String(e.deg)}>${S(e.longLabel,t)}</ha-list-item>
            `)}
        </ha-select>
      </div>
      <div class="detail-field">
        <rs-threshold-field
          .label=${S(`covers.per_cover_min_position`,t)}
          .value=${i??0}
          .min=${0}
          .max=${99}
          .step=${1}
          suffix="%"
          @value-changed=${t=>this._setMinPosition(e,t.detail)}
        ></rs-threshold-field>
      </div>
    `}_renderEdit(e){let t=bt(this.area.area_id,this.hass?.entities,this.hass?.devices).filter(e=>!e.entity_id.substring(e.entity_id.indexOf(`.`)+1).startsWith(`roommind_`)).filter(e=>e.entity_id.startsWith(`cover.`)),n=new Set(t.map(e=>e.entity_id)),r=[...this.selectedCovers].filter(e=>!n.has(e)),i=this.selectedCovers.size>0,a=this._selectedForEdit,o=a&&this.selectedCovers.has(a);return m`
      <rs-master-detail>
        <div slot="master" class="master">
          <div class="block-title">${S(`covers.add_cover`,e)}</div>
          <div class="master-list">
            ${t.length>0?t.map(e=>this._renderMasterRow(e.entity_id,!1)):m`<div class="empty-list">${S(`covers.no_covers_in_area`,e)}</div>`}
            ${r.map(e=>this._renderMasterRow(e,!0))}
          </div>
          <div class="picker-wrap">
            <ha-entity-picker
              .hass=${this.hass}
              .includeDomains=${[`cover`]}
              .entityFilter=${this._entityFilter}
              .value=${``}
              .label=${S(`covers.add_cover`,e)}
              @value-changed=${this._onEntityPicked}
            ></ha-entity-picker>
          </div>
        </div>
        <div slot="detail">
          ${o?m`<div class="detail-panel">${this._renderCoverDetail(a)}</div>`:m`<div class="detail-panel">
                  <div class="empty-detail">
                    <ha-icon icon="mdi:gesture-tap"></ha-icon>
                    <span>${S(`devices.select_to_configure`,e)}</span>
                  </div>
                </div>`}
        </div>
      </rs-master-detail>

      ${i?m`
              <div class="block-divider"></div>
              <div class="feature-card ${this.autoEnabled?`enabled`:``}">
                <div class="feature-text">
                  <div class="feature-title">${S(`covers.auto_control`,e)}</div>
                  <div class="feature-description">${S(`covers.auto_control_hint`,e)}</div>
                </div>
                <ha-switch
                  .checked=${this.autoEnabled}
                  @change=${e=>this._emit(`covers_auto_enabled`,e.target.checked)}
                ></ha-switch>
              </div>

              ${this.autoEnabled?m`
                      <div class="group-card ${this._scheduleCollapsed?`collapsed`:``}">
                        <div
                          class="group-header"
                          @click=${()=>this._scheduleCollapsed=!this._scheduleCollapsed}
                        >
                          <ha-icon icon="mdi:calendar-clock"></ha-icon>
                          <span>${S(`covers.schedule_group_title`,e)}</span>
                          <rs-info-icon
                            .text=${S(`covers.schedule_section_hint`,e)}
                          ></rs-info-icon>
                          <ha-icon
                            class="chevron ${this._scheduleCollapsed?`collapsed`:``}"
                            icon="mdi:chevron-down"
                          ></ha-icon>
                        </div>
                        ${this._scheduleCollapsed?h:m`<rs-cover-schedule
                                  .hass=${this.hass}
                                  .schedules=${this.coverSchedules}
                                  .selectorEntity=${this.coverScheduleSelectorEntity}
                                  .activeIndex=${this.activeCoverScheduleIndex}
                                  .editing=${!0}
                                  @cover-schedules-changed=${e=>this._emit(`cover_schedules`,e.detail.value)}
                                  @cover-schedule-selector-changed=${e=>this._emit(`cover_schedule_selector_entity`,e.detail.value)}
                                ></rs-cover-schedule>
                                <div class="group-divider"></div>
                                <rs-toggle-row
                                  .label=${S(`covers.night_close`,e)}
                                  .hint=${S(`covers.night_close_hint`,e)}
                                  .checked=${this.nightClose}
                                  @toggle-changed=${e=>this._emit(`covers_night_close`,e.detail)}
                                ></rs-toggle-row>
                                ${this.nightClose?m`
                                        <rs-threshold-field
                                          .label=${S(`covers.night_position`,e)}
                                          .hint=${S(`covers.night_position_hint`,e)}
                                          .value=${this.nightPosition}
                                          .min=${0}
                                          .max=${100}
                                          .step=${5}
                                          suffix="%"
                                          @value-changed=${e=>this._emit(`covers_night_position`,e.detail)}
                                        ></rs-threshold-field>
                                        <ha-expansion-panel
                                          .header=${S(`covers.night_close_advanced`,e)}
                                          outlined
                                        >
                                          <div class="field-row" style="padding:8px 0;">
                                            <rs-threshold-field
                                              .label=${S(`covers.night_close_elevation`,e)}
                                              .hint=${S(`covers.night_close_elevation_hint`,e)}
                                              .value=${this.nightCloseElevation}
                                              .min=${-18}
                                              .max=${10}
                                              .step=${1}
                                              suffix="°"
                                              @value-changed=${e=>this._emit(`covers_night_close_elevation`,e.detail)}
                                            ></rs-threshold-field>
                                            <rs-threshold-field
                                              .label=${S(`covers.night_close_offset`,e)}
                                              .hint=${S(`covers.night_close_offset_hint`,e)}
                                              .value=${this.nightCloseOffsetMinutes}
                                              .min=${-120}
                                              .max=${120}
                                              .step=${5}
                                              suffix="min"
                                              @value-changed=${e=>this._emit(`covers_night_close_offset_minutes`,e.detail)}
                                            ></rs-threshold-field>
                                          </div>
                                        </ha-expansion-panel>
                                      `:h}`}
                      </div>

                      <div class="group-card ${this._solarCollapsed?`collapsed`:``}">
                        <div
                          class="group-header"
                          @click=${()=>this._solarCollapsed=!this._solarCollapsed}
                        >
                          <ha-icon icon="mdi:white-balance-sunny"></ha-icon>
                          <span>${S(`covers.solar_group_title`,e)}</span>
                          <ha-icon
                            class="chevron ${this._solarCollapsed?`collapsed`:``}"
                            icon="mdi:chevron-down"
                          ></ha-icon>
                        </div>
                        ${this._solarCollapsed?h:m`<div class="field-row">
                                  <rs-threshold-field
                                    .label=${S(`covers.deploy_threshold`,e)}
                                    .hint=${S(`covers.deploy_threshold_hint`,e)}
                                    .value=${this.deployThreshold}
                                    .min=${.5}
                                    .max=${5}
                                    .step=${.5}
                                    suffix="°C"
                                    @value-changed=${e=>this._emit(`covers_deploy_threshold`,e.detail)}
                                  ></rs-threshold-field>
                                  <rs-threshold-field
                                    .label=${S(`covers.min_position`,e)}
                                    .hint=${S(`covers.min_position_hint`,e)}
                                    .value=${this.minPosition}
                                    .min=${0}
                                    .max=${80}
                                    .step=${5}
                                    suffix="%"
                                    @value-changed=${e=>this._emit(`covers_min_position`,e.detail)}
                                  ></rs-threshold-field>
                                </div>
                                <div class="field-row">
                                  <rs-threshold-field
                                    .label=${S(`covers.override_minutes`,e)}
                                    .hint=${S(`covers.override_minutes_hint`,e)}
                                    .value=${this.overrideMinutes}
                                    .min=${0}
                                    .max=${480}
                                    .step=${15}
                                    suffix="min"
                                    @value-changed=${e=>this._emit(`covers_override_minutes`,e.detail)}
                                  ></rs-threshold-field>
                                  <rs-threshold-field
                                    .label=${S(`covers.outdoor_min_temp`,e)}
                                    .hint=${S(`covers.outdoor_min_temp_hint`,e)}
                                    .value=${this.outdoorMinTemp??10}
                                    .min=${0}
                                    .max=${35}
                                    .step=${1}
                                    suffix="°C"
                                    @value-changed=${e=>this._emit(`covers_outdoor_min_temp`,e.detail)}
                                  ></rs-threshold-field>
                                </div>
                                <div class="group-divider"></div>
                                <rs-toggle-row
                                  .label=${S(`covers.snap_deploy`,e)}
                                  .hint=${S(`covers.snap_deploy_hint`,e)}
                                  .checked=${this.snapDeploy}
                                  @toggle-changed=${e=>this._emit(`covers_snap_deploy`,e.detail)}
                                ></rs-toggle-row>`}
                      </div>
                    `:h}
            `:h}
    `}static{this._DIRECTIONS=[{shortLabel:`covers.orientation_N`,longLabel:`covers.orientation_N_full`,deg:0},{shortLabel:`covers.orientation_NE`,longLabel:`covers.orientation_NE_full`,deg:45},{shortLabel:`covers.orientation_E`,longLabel:`covers.orientation_E_full`,deg:90},{shortLabel:`covers.orientation_SE`,longLabel:`covers.orientation_SE_full`,deg:135},{shortLabel:`covers.orientation_S`,longLabel:`covers.orientation_S_full`,deg:180},{shortLabel:`covers.orientation_SW`,longLabel:`covers.orientation_SW_full`,deg:225},{shortLabel:`covers.orientation_W`,longLabel:`covers.orientation_W_full`,deg:270},{shortLabel:`covers.orientation_NW`,longLabel:`covers.orientation_NW_full`,deg:315}]}_setMinPosition(e,t){let n={...this.coverMinPositions};n[e]=t,this._emit(`cover_min_positions`,n)}_setOrientation(e,t){let n={...this.coverOrientations};t===void 0?delete n[e]:n[e]=t,this._emit(`cover_orientations`,n)}_onEntityPicked(e){e.stopPropagation();let t=e.detail.value;if(!t)return;this._onToggle(t,!0);let n=e.target;n.value=``}_onToggle(e,t){this.dispatchEvent(new CustomEvent(`covers-toggle`,{detail:{entityId:e,checked:t},bubbles:!0,composed:!0}))}_onResumeAuto(){this.dispatchEvent(new CustomEvent(`cover-resume-auto`,{bubbles:!0,composed:!0}))}_emit(e,t){this.dispatchEvent(new CustomEvent(`setting-changed`,{detail:{key:e,value:t},bubbles:!0,composed:!0}))}};A([y({attribute:!1})],H.prototype,`hass`,void 0),A([y({attribute:!1})],H.prototype,`area`,void 0),A([y({attribute:!1})],H.prototype,`selectedCovers`,void 0),A([y({type:Boolean})],H.prototype,`editing`,void 0),A([y({type:Boolean})],H.prototype,`autoEnabled`,void 0),A([y({type:Number})],H.prototype,`deployThreshold`,void 0),A([y({type:Number})],H.prototype,`minPosition`,void 0),A([y({type:Number})],H.prototype,`overrideMinutes`,void 0),A([y({type:Boolean})],H.prototype,`autoPaused`,void 0),A([y({type:Number})],H.prototype,`overrideUntil`,void 0),A([y({attribute:!1})],H.prototype,`coverSchedules`,void 0),A([y({type:String})],H.prototype,`coverScheduleSelectorEntity`,void 0),A([y({type:Number})],H.prototype,`activeCoverScheduleIndex`,void 0),A([y({type:Boolean})],H.prototype,`nightClose`,void 0),A([y({type:Number})],H.prototype,`nightPosition`,void 0),A([y({type:Boolean})],H.prototype,`snapDeploy`,void 0),A([y({type:String})],H.prototype,`forcedReason`,void 0),A([y({attribute:!1})],H.prototype,`coverOrientations`,void 0),A([y({type:Number})],H.prototype,`nightCloseElevation`,void 0),A([y({type:Number})],H.prototype,`nightCloseOffsetMinutes`,void 0),A([y({type:Number})],H.prototype,`outdoorMinTemp`,void 0),A([y({attribute:!1})],H.prototype,`coverMinPositions`,void 0),A([b()],H.prototype,`_selectedForEdit`,void 0),A([b()],H.prototype,`_scheduleCollapsed`,void 0),A([b()],H.prototype,`_solarCollapsed`,void 0),H=rn=A([v(`rs-covers-section`)],H),_(),x(),j();var an=class extends g{constructor(...e){super(...e),this.enabled=!1,this.primaryDelta=1.5,this.outdoorThreshold=5,this.acMinOutdoor=-15,this.editing=!1}static{this.styles=[L,l`
      :host {
        display: block;
      }

      /* Read-only summary (tile) */
      .summary {
        padding: 0 16px 16px;
        font-size: 13px;
        color: var(--secondary-text-color);
        line-height: 1.6;
      }

      .summary.disabled {
        font-style: italic;
        opacity: 0.75;
      }

      /* Editing layout */
      .feature-card {
        display: flex;
        align-items: center;
        gap: 14px;
        padding: 14px 16px;
        border: 1px solid var(--divider-color);
        border-radius: 12px;
        background: var(--card-background-color);
        transition:
          border-color 0.2s ease,
          background 0.2s ease;
      }

      .feature-card.enabled {
        border-color: rgba(3, 169, 244, 0.4);
        background: rgba(3, 169, 244, 0.06);
      }

      .feature-text {
        flex: 1;
        min-width: 0;
      }

      .feature-title {
        font-size: 14px;
        font-weight: 500;
        margin: 0 0 4px;
      }

      .feature-description {
        font-size: 12px;
        color: var(--secondary-text-color);
        line-height: 1.5;
        margin: 0;
      }

      ha-switch {
        flex-shrink: 0;
      }

      .thresholds {
        margin-top: 16px;
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 12px;
      }

      @media (max-width: 600px) {
        .thresholds {
          grid-template-columns: 1fr;
        }
      }

      .threshold-cell {
        display: flex;
        flex-direction: column;
        gap: 8px;
        padding: 12px 14px;
        border: 1px solid var(--divider-color);
        border-radius: 10px;
        background: var(--card-background-color);
      }

      .threshold-label {
        font-size: 12px;
        font-weight: 500;
        color: var(--secondary-text-color);
        display: flex;
        align-items: center;
        gap: 4px;
        line-height: 1.3;
      }

      .threshold-label > span {
        flex: 1;
        min-width: 0;
      }

      .threshold-cell ha-textfield {
        width: 100%;
      }
    `]}render(){let e=this.hass.language;return this.editing?m`
      <div class="feature-card ${this.enabled?`enabled`:``}">
        <div class="feature-text">
          <div class="feature-title">${S(`heat_source.toggle`,e)}</div>
          <div class="feature-description">${S(`heat_source.toggle_hint`,e)}</div>
        </div>
        <ha-switch .checked=${this.enabled} @change=${this._onSwitchChange}></ha-switch>
      </div>

      ${this.enabled?m`
              <div class="thresholds">
                ${this._renderThresholdCell({label:S(`heat_source.primary_delta`,e),hint:S(`heat_source.primary_delta_hint`,e),suffix:S(`heat_source.primary_delta_suffix`,e),value:this.primaryDelta,min:.5,max:5,step:.1,key:`heat_source_primary_delta`})}
                ${this._renderThresholdCell({label:S(`heat_source.outdoor_threshold`,e),hint:S(`heat_source.outdoor_threshold_hint`,e),suffix:S(`heat_source.outdoor_threshold_suffix`,e),value:this.outdoorThreshold,min:-20,max:25,step:1,key:`heat_source_outdoor_threshold`})}
                ${this._renderThresholdCell({label:S(`heat_source.ac_min_outdoor`,e),hint:S(`heat_source.ac_min_outdoor_hint`,e),suffix:S(`heat_source.ac_min_outdoor_suffix`,e),value:this.acMinOutdoor,min:-30,max:5,step:1,key:`heat_source_ac_min_outdoor`})}
              </div>
            `:h}
    `:this.enabled?m`<div class="summary">
        ${S(`heat_source.primary_delta`,e)}:
        <strong>${this.primaryDelta}${S(`heat_source.primary_delta_suffix`,e)}</strong>
        · ${S(`heat_source.outdoor_threshold`,e)}:
        <strong
          >${this.outdoorThreshold}${S(`heat_source.outdoor_threshold_suffix`,e)}</strong
        >
        · ${S(`heat_source.ac_min_outdoor`,e)}:
        <strong>${this.acMinOutdoor}${S(`heat_source.ac_min_outdoor_suffix`,e)}</strong>
      </div>`:m`<div class="summary disabled">
          ${S(`heat_source.summary_disabled`,e)}
        </div>`}_renderThresholdCell(e){return m`
      <div class="threshold-cell">
        <div class="threshold-label">
          <span>${e.label}</span>
          <rs-info-icon .text=${e.hint}></rs-info-icon>
        </div>
        <ha-textfield
          .value=${String(e.value)}
          .min=${String(e.min)}
          .max=${String(e.max)}
          .step=${String(e.step)}
          .suffix=${e.suffix}
          type="number"
          @input=${t=>this._onNumberInput(e.key,t)}
        ></ha-textfield>
      </div>
    `}_onSwitchChange(e){this._emit(`heat_source_orchestration`,e.target.checked)}_onNumberInput(e,t){let n=parseFloat(t.target.value);isNaN(n)||this._emit(e,n)}_emit(e,t){this.dispatchEvent(new CustomEvent(`setting-changed`,{detail:{key:e,value:t},bubbles:!0,composed:!0}))}};A([y({attribute:!1})],an.prototype,`hass`,void 0),A([y({type:Boolean})],an.prototype,`enabled`,void 0),A([y({type:Number})],an.prototype,`primaryDelta`,void 0),A([y({type:Number})],an.prototype,`outdoorThreshold`,void 0),A([y({type:Number})],an.prototype,`acMinOutdoor`,void 0),A([y({type:Boolean})],an.prototype,`editing`,void 0),an=A([v(`rs-heat-source-section`)],an),_(),x(),j();function on(e,t){let n=`climate.roommind_${t}`;if(e.states[n])return n;for(let n of Object.values(e.entities??{}))if(n.platform===`roommind`&&n.entity_id.startsWith(`climate.`)&&n.area_id===t&&!n.entity_id.endsWith(`_override`))return n.entity_id;return null}var sn=class extends g{constructor(...e){super(...e),this.areaId=``,this._entityId=null,this._failed=!1,this._cardKey=``}static{this.styles=l`
    :host {
      display: block;
    }
    .card-host {
      display: block;
    }
    /* The embedded card brings its own ha-card; drop its frame inside our section. */
    .card-host > * {
      --ha-card-box-shadow: none;
      --ha-card-border-width: 0;
      --ha-card-background: transparent;
    }
    .hint {
      font-size: 13px;
      color: var(--secondary-text-color);
      padding: 0 20px 16px;
    }
  `}willUpdate(e){(e.has(`hass`)||e.has(`areaId`))&&(this._entityId=this.hass?on(this.hass,this.areaId):null)}updated(e){this._entityId&&this.hass.states[this._entityId]&&(this._entityId===this._cardKey?e.has(`hass`)&&this._card&&(this._card.hass=this._wrapHass()):(this._cardKey=this._entityId,this._createCard()))}_wrapHass(){let e=this.hass,t=this.setTemperature;if(!t)return e;let n=this._entityId,r=Object.create(e);return r.callService=async(r,i,a,...o)=>{let s=a?.entity_id??o[0]?.entity_id,c=s===n||Array.isArray(s)&&s.includes(n);if(r===`climate`&&i===`set_temperature`&&c&&a)try{if(await t(a))return}catch{}return e.callService(r,i,a,...o)},r}async _createCard(){let e=this._cardKey;try{let t=await(await window.loadCardHelpers()).createCardElement({type:`thermostat`,entity:this._entityId,features:[]});if(e!==this._cardKey)return;t.hass=this._wrapHass(),this._card=t,this._failed=!1,(this.shadowRoot?.querySelector(`.card-host`))?.replaceChildren(t)}catch{this._failed=!0}}render(){return this.hass?this._entityId?this._failed?m`<div class="hint">
        ${S(`thermostat.load_failed`,this.hass.language)}
      </div>`:m`<div class="card-host"></div>`:m`<div class="hint">
        ${S(`thermostat.not_available`,this.hass.language)}
      </div>`:h}};A([y({attribute:!1})],sn.prototype,`hass`,void 0),A([y({type:String})],sn.prototype,`areaId`,void 0),A([y({attribute:!1})],sn.prototype,`setTemperature`,void 0),A([b()],sn.prototype,`_entityId`,void 0),A([b()],sn.prototype,`_failed`,void 0),sn=A([v(`rs-thermostat-card`)],sn);var U=[`monday`,`tuesday`,`wednesday`,`thursday`,`friday`,`saturday`,`sunday`];async function cn(e,t){let[n,r]=await Promise.all([e.callWS({type:`config/entity_registry/get`,entity_id:t}),e.callWS({type:`schedule/list`})]);return r.find(e=>e.id===n.unique_id)??null}async function ln(e,t){let n=(await e.callWS({type:`call_service`,domain:`schedule`,service:`get_schedule`,target:{entity_id:t},return_response:!0})).response?.[t]??{};return Object.fromEntries(U.map(e=>[e,n[e]??[]]))}function un(e,t){let n=e=>typeof e==`number`&&Number.isFinite(e)?e:void 0,r=n(e.target_temp_low),i=n(e.target_temp_high),a=n(e.temperature);return r!==void 0||i!==void 0?{heat:r,cool:i}:a===void 0?null:t===`cool_only`?{cool:a}:{heat:a}}function dn(e,t,n){let r={};for(let i of U)r[i]=(e[i]??[]).map(e=>{let r={...e.data??{}};if(t===`auto`)n.heat!==void 0&&(r.heat_temperature=n.heat),n.cool!==void 0&&(r.cool_temperature=n.cool),delete r.temperature;else{let e=t===`cool_only`?n.cool:n.heat;e!==void 0&&(r.temperature=e)}return{from:e.from,to:e.to,data:r}});return r}async function fn(e,t,n,r){let i=await cn(e,t);if(!i)return!1;let a=dn(i,n,r);return await e.callWS({type:`schedule/update`,schedule_id:i.id,name:i.name,...i.icon?{icon:i.icon}:{},...a}),!0}_(),x(),j();var pn=`M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z`,mn=`M11,9H13V7H11M12,20C7.59,20 4,16.41 4,12C4,7.59 7.59,4 12,4C16.41,4 20,7.59 20,12C20,16.41 16.41,20 12,20M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M11,17H13V11H11V17Z`,hn=class extends g{constructor(...e){super(...e),this.open=!1,this.heading=``,this.icon=``,this.hasInfo=!1,this._infoExpanded=!1,this._onKeyDown=e=>{e.key===`Escape`&&this.open&&(e.stopPropagation(),this._close())}}connectedCallback(){super.connectedCallback(),window.addEventListener(`keydown`,this._onKeyDown)}disconnectedCallback(){super.disconnectedCallback(),window.removeEventListener(`keydown`,this._onKeyDown)}static{this.styles=l`
    :host {
      display: contents;
    }

    .backdrop {
      position: fixed;
      inset: 0;
      z-index: 1000;
      background: rgba(0, 0, 0, 0.55);
      backdrop-filter: blur(2px);
      display: flex;
      align-items: flex-start;
      justify-content: center;
      padding: 32px 16px;
      box-sizing: border-box;
      overflow-y: auto;
      animation: fade-in 0.18s ease-out;
    }

    @media (max-width: 600px) {
      .backdrop {
        padding: 0;
        align-items: stretch;
      }
    }

    .dialog {
      background: var(--card-background-color, #1c1c1c);
      color: var(--primary-text-color);
      border-radius: 14px;
      box-shadow: 0 24px 48px rgba(0, 0, 0, 0.5);
      width: 100%;
      max-width: 760px;
      display: flex;
      flex-direction: column;
      max-height: calc(100vh - 64px);
      animation: pop-in 0.18s ease-out;
    }

    @media (min-width: 1400px) {
      .dialog {
        max-width: 880px;
      }
    }

    @media (max-width: 600px) {
      .dialog {
        max-width: 100%;
        max-height: 100vh;
        border-radius: 0;
      }
    }

    .dialog-header {
      display: flex;
      align-items: center;
      gap: 4px;
      padding: 18px 24px;
      border-bottom: 1px solid var(--divider-color, rgba(255, 255, 255, 0.08));
    }

    .dialog-icon {
      --mdc-icon-size: 20px;
      opacity: 0.7;
      flex-shrink: 0;
      margin-right: 8px;
    }

    .dialog-title {
      flex: 1;
      font-size: 16px;
      font-weight: 500;
      margin: 0;
      min-width: 0;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .info-btn {
      --mdc-icon-button-size: 36px;
      --mdc-icon-size: 20px;
      color: var(--secondary-text-color);
      transition:
        color 0.15s,
        background 0.15s;
      border-radius: 50%;
    }

    .info-btn.active {
      color: var(--primary-color);
      background: rgba(3, 169, 244, 0.12);
    }

    .close-btn {
      --mdc-icon-button-size: 36px;
      --mdc-icon-size: 20px;
      color: var(--secondary-text-color);
      margin: -6px -10px -6px 0;
    }

    .dialog-body {
      flex: 1;
      overflow-y: auto;
      padding: 20px 24px 24px;
    }

    .dialog-body ::slotted(*) {
      display: block;
    }

    .info-panel {
      margin-bottom: 16px;
      padding: 12px 14px;
      background: rgba(3, 169, 244, 0.06);
      border: 1px solid rgba(3, 169, 244, 0.18);
      border-radius: 10px;
      font-size: 13px;
      line-height: 1.6;
      color: var(--primary-text-color);
      animation: info-fade 0.18s ease-out;
    }

    .info-panel ::slotted(*) {
      display: block;
    }

    @keyframes fade-in {
      from {
        opacity: 0;
      }
      to {
        opacity: 1;
      }
    }

    @keyframes pop-in {
      from {
        opacity: 0;
        transform: scale(0.97);
      }
      to {
        opacity: 1;
        transform: scale(1);
      }
    }

    @keyframes info-fade {
      from {
        opacity: 0;
        transform: translateY(-4px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
  `}render(){return this.open?m`
      <div class="backdrop" @click=${this._onBackdropClick} role="dialog" aria-modal="true">
        <div class="dialog" @click=${e=>e.stopPropagation()}>
          <div class="dialog-header">
            ${this.icon?m`<ha-icon class="dialog-icon" icon=${this.icon}></ha-icon>`:h}
            <h3 class="dialog-title">${this.heading}</h3>
            ${this.hasInfo?m`<ha-icon-button
                    class="info-btn ${this._infoExpanded?`active`:``}"
                    .path=${mn}
                    @click=${this._toggleInfo}
                  ></ha-icon-button>`:h}
            <ha-icon-button
              class="close-btn"
              .path=${pn}
              @click=${this._close}
            ></ha-icon-button>
          </div>
          <div class="dialog-body">
            ${this.hasInfo&&this._infoExpanded?m`<div class="info-panel"><slot name="info"></slot></div>`:h}
            <slot></slot>
          </div>
        </div>
      </div>
    `:h}_onBackdropClick(e){e.target===e.currentTarget&&this._close()}_toggleInfo(){this._infoExpanded=!this._infoExpanded}_close(){this._infoExpanded=!1,this.dispatchEvent(new CustomEvent(`rs-dialog-closed`,{bubbles:!0,composed:!0}))}};A([y({type:Boolean,reflect:!0})],hn.prototype,`open`,void 0),A([y({type:String})],hn.prototype,`heading`,void 0),A([y({type:String})],hn.prototype,`icon`,void 0),A([y({type:Boolean})],hn.prototype,`hasInfo`,void 0),A([b()],hn.prototype,`_infoExpanded`,void 0),hn=A([v(`rs-edit-dialog`)],hn),_(),x(),j();var gn=`M19,4H15.5L14.5,3H9.5L8.5,4H5V6H19M6,19A2,2 0 0,0 8,21H16A2,2 0 0,0 18,19V7H6V19Z`,_n=`M19,21H8V7H19M19,5H8A2,2 0 0,0 6,7V21A2,2 0 0,0 8,23H19A2,2 0 0,0 21,21V7A2,2 0 0,0 19,5M16,1H4A2,2 0 0,0 2,3V17H4V3H16V1Z`,vn=()=>Object.fromEntries(U.map(e=>[e,[]]));function yn(e,t=!1){let n=(e??``).slice(0,5);return t&&(n===`00:00`||n===`24:00`)?`24:00`:n}function W(e){let[t,n]=e.split(`:`).map(Number);return t*60+n}var bn=e=>e==null||e===``?``:String(e);function xn(e){return(e??[]).map(e=>({from:yn(e.from),to:yn(e.to,!0),temp:bn(e.data?.temperature),heat:bn(e.data?.heat_temperature),cool:bn(e.data?.cool_temperature)}))}function Sn(e,t){return[...e].sort((e,t)=>W(e.from)-W(t.from)).map(e=>{let n={};t===`auto`?(e.heat!==``&&(n.heat_temperature=Number(e.heat)),e.cool!==``&&(n.cool_temperature=Number(e.cool))):e.temp!==``&&(n.temperature=Number(e.temp));let r={from:`${e.from}:00`,to:`${e.to}:00`};return Object.keys(n).length&&(r.data=n),r})}function Cn(e){let t=[...e].sort((e,t)=>W(e.from)-W(t.from)),n=-1;for(let e of t){if(!/^\d\d:\d\d$/.test(e.from)||!/^\d\d:\d\d$/.test(e.to))return`schedule_editor.err_time`;let t=W(e.from),r=W(e.to);if(r<=t)return`schedule_editor.err_order`;if(t<n)return`schedule_editor.err_overlap`;for(let t of[e.temp,e.heat,e.cool])if(t!==``&&!Number.isFinite(Number(t)))return`schedule_editor.err_temp`;if(e.heat!==``&&e.cool!==``&&Number(e.cool)<Number(e.heat))return`schedule_editor.err_band`;n=r}return null}var G=class extends g{constructor(...e){super(...e),this.open=!1,this.entityId=``,this.climateMode=`auto`,this.defaultName=``,this.nightTemp=17,this._loading=!1,this._saving=!1,this._error=``,this._readOnly=!1,this._name=``,this._week=vn(),this._scheduleId=null,this._day=`monday`,this._copyFrom=null,this._icon=``,this._dayTemp=``,this._nightTempText=``,this._addBlock=()=>{let e=[...this._week[this._day]].sort((e,t)=>W(e.from)-W(t.from)),t=e[e.length-1],n=`06:00`,r=`22:00`;if(t&&/^\d\d:\d\d$/.test(t.to)){let e=Math.min(W(t.to),1380),i=Math.min(e+60,1440),a=e=>`${String(Math.floor(e/60)).padStart(2,`0`)}:${String(e%60).padStart(2,`0`)}`;n=a(e),r=a(i)}this._updateDay(this._day,[...e,{from:n,to:r,temp:``,heat:``,cool:``}])},this._save=async()=>{let e=this.hass.language;for(let t of U){let n=Cn(this._week[t]);if(n){this._day=t,this._error=S(n,e);return}}let t=Number(this._nightTempText);if(this._nightTempText!==``&&!Number.isFinite(t)){this._error=S(`schedule_editor.err_temp`,e);return}this._error=``,this._saving=!0;let n=Object.fromEntries(U.map(e=>[e,Sn(this._week[e],this.climateMode)]));try{let e=this.entityId;if(this._scheduleId)await this.hass.callWS({type:`schedule/update`,schedule_id:this._scheduleId,name:this._name.trim(),...this._icon?{icon:this._icon}:{},...n});else{let t=await this.hass.callWS({type:`schedule/create`,name:this._name.trim(),icon:`mdi:calendar-clock`,...n});e=await this._entityIdFor(t.id)}this.dispatchEvent(new CustomEvent(`schedule-saved`,{detail:{entityId:e,created:!this._scheduleId,replaces:this._copyFrom,nightTemp:this._nightTempText===``?null:T(t,this.hass)},bubbles:!0,composed:!0})),this._close()}catch(e){this._error=e instanceof Error?e.message:String(e?.message??e)}finally{this._saving=!1}},this._onClosed=e=>{e?.stopPropagation(),this._close()}}static{this.styles=[L,l`
      :host {
        display: contents;
      }
      .body {
        display: flex;
        flex-direction: column;
        gap: 16px;
      }
      .week-preview {
        display: flex;
        flex-direction: column;
        gap: 4px;
      }
      .preview-row {
        display: grid;
        grid-template-columns: 34px 1fr;
        align-items: center;
        gap: 8px;
        cursor: pointer;
        border-radius: 6px;
        padding: 2px 4px;
      }
      .preview-row.selected {
        background: rgba(var(--rgb-primary-color, 3, 169, 244), 0.12);
      }
      .preview-label {
        font-size: 12px;
        font-weight: 500;
        color: var(--secondary-text-color);
      }
      .preview-row.selected .preview-label {
        color: var(--primary-color);
      }
      .bar {
        position: relative;
        height: 14px;
        border-radius: 4px;
        background: var(--divider-color, rgba(127, 127, 127, 0.2));
        overflow: hidden;
      }
      .bar-block {
        position: absolute;
        top: 0;
        bottom: 0;
        background: var(--state-climate-heat-color, #ff8100);
        opacity: 0.85;
      }
      .bar-block.cool {
        background: var(--state-climate-cool-color, #2b9af9);
      }
      .hours {
        display: grid;
        grid-template-columns: 34px 1fr;
        gap: 8px;
        padding: 0 4px;
        font-size: 10px;
        color: var(--secondary-text-color);
      }
      .hours div {
        display: flex;
        justify-content: space-between;
      }
      .day-tabs {
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
      }
      .day-tab {
        border: 1px solid var(--divider-color, #ccc);
        background: none;
        color: var(--primary-text-color);
        border-radius: 16px;
        padding: 4px 12px;
        font: inherit;
        font-size: 13px;
        cursor: pointer;
      }
      .day-tab.selected {
        background: var(--primary-color);
        border-color: var(--primary-color);
        color: var(--text-primary-color, #fff);
      }
      .day-tab.invalid {
        border-color: var(--error-color, #d32f2f);
      }
      .block-row {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 8px;
        padding: 8px 10px;
        border-radius: 8px;
        background: rgba(127, 127, 127, 0.08);
      }
      .block-row label {
        display: flex;
        flex-direction: column;
        gap: 2px;
        font-size: 11px;
        color: var(--secondary-text-color);
      }
      .block-row input {
        font: inherit;
        font-size: 14px;
        padding: 6px 8px;
        border-radius: 6px;
        border: 1px solid var(--divider-color, #ccc);
        background: var(--card-background-color, transparent);
        color: var(--primary-text-color);
        color-scheme: light dark;
      }
      .block-row input.temp {
        width: 70px;
      }
      .block-row .spacer {
        flex: 1;
      }
      .blocks {
        display: flex;
        flex-direction: column;
        gap: 8px;
      }
      .actions-row {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        align-items: center;
      }
      .link-btn {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        background: none;
        border: none;
        padding: 4px 0;
        cursor: pointer;
        color: var(--primary-color);
        font: inherit;
        font-size: 13px;
      }
      .link-btn ha-svg-icon {
        --mdc-icon-size: 16px;
      }
      .hint {
        font-size: 12px;
        color: var(--secondary-text-color);
        line-height: 1.5;
      }
      .error {
        color: var(--error-color, #d32f2f);
        font-size: 13px;
      }
      .footer {
        display: flex;
        justify-content: flex-end;
        gap: 8px;
      }
      .copy-banner {
        padding: 10px 14px;
        border-radius: 8px;
        background: rgba(var(--rgb-primary-color, 3, 169, 244), 0.1);
        font-size: 13px;
        line-height: 1.5;
      }
      .day-night {
        display: flex;
        flex-wrap: wrap;
        gap: 12px;
        align-items: flex-end;
      }
      .day-night label {
        display: flex;
        flex-direction: column;
        gap: 4px;
        font-size: 12px;
        color: var(--secondary-text-color);
      }
      .day-night input {
        font: inherit;
        font-size: 15px;
        width: 110px;
        padding: 8px 10px;
        border-radius: 8px;
        border: 1px solid var(--divider-color, #ccc);
        background: var(--card-background-color, transparent);
        color: var(--primary-text-color);
      }
      .day-night .hint {
        flex-basis: 100%;
      }
      .empty {
        font-size: 13px;
        color: var(--secondary-text-color);
        padding: 8px 0;
      }
    `]}updated(e){(e.has(`open`)||e.has(`entityId`))&&this.open&&this._load()}async _load(){if(this._error=``,this._readOnly=!1,this._day=`monday`,this._scheduleId=null,this._copyFrom=null,this._icon=``,this._nightTempText=String(Math.round(w(this.nightTemp,this.hass)*10)/10),!this.entityId)this._name=this.defaultName,this._week=vn(),this._dayTemp=``;else{this._loading=!0;try{let e=await cn(this.hass,this.entityId),t=vn();if(e){this._scheduleId=e.id,this._name=e.name,this._icon=e.icon??``;for(let n of U)t[n]=xn(e[n])}else{let e=await ln(this.hass,this.entityId),n=this.hass.states[this.entityId]?.attributes?.friendly_name||this.entityId;this._copyFrom=this.entityId,this._name=`${n} (RoomMind)`;for(let n of U)t[n]=xn(e[n])}this._week=t,this._dayTemp=this._commonDayTemp(t)}catch(e){this._readOnly=!0,this._error=e instanceof Error?e.message:String(e)}finally{this._loading=!1}}}render(){let e=this.hass?.language??`en`;return m`
      <rs-edit-dialog
        .open=${this.open}
        .heading=${S(this.entityId?`schedule_editor.title_edit`:`schedule_editor.title_new`,e)}
        icon="mdi:calendar-edit"
        @rs-dialog-closed=${this._onClosed}
      >
        ${this.open?this._renderBody(e):h}
      </rs-edit-dialog>
    `}_renderBody(e){if(this._loading)return m`<div class="hint">${S(`panel.loading`,e)}</div>`;if(this._readOnly)return m`<div class="body">
        <div class="hint">${S(`schedule_editor.read_only`,e)}</div>
        ${this._error?m`<div class="error">${this._error}</div>`:h}
      </div>`;let t=this._week[this._day];return m`
      <div class="body">
        ${this._copyFrom?m`<div class="copy-banner">${S(`schedule_editor.copy_hint`,e)}</div>`:h}
        <ha-textfield
          .label=${S(`schedule_editor.name`,e)}
          .value=${this._name}
          @input=${e=>this._name=e.target.value}
        ></ha-textfield>

        ${this._renderDayNight(e)} ${this._renderPreview(e)}

        <div class="day-tabs">
          ${U.map(t=>m`<button
                class="day-tab ${t===this._day?`selected`:``} ${Cn(this._week[t])?`invalid`:``}"
                @click=${()=>this._day=t}
              >
                ${S(`schedule_editor.day_short.${t}`,e)}
              </button>`)}
        </div>

        <div class="blocks">
          ${t.length===0?m`<div class="empty">${S(`schedule_editor.no_blocks`,e)}</div>`:t.map((t,n)=>this._renderBlock(t,n,e))}
        </div>
        ${this._renderDayError(e)}

        <div class="actions-row">
          <button class="link-btn" @click=${this._addBlock}>
            + ${S(`schedule_editor.add_block`,e)}
          </button>
          <span class="spacer" style="flex:1"></span>
          <button class="link-btn" @click=${()=>this._copyDay(`weekdays`)}>
            <ha-svg-icon .path=${_n}></ha-svg-icon>
            ${S(`schedule_editor.copy_weekdays`,e)}
          </button>
          <button class="link-btn" @click=${()=>this._copyDay(`all`)}>
            <ha-svg-icon .path=${_n}></ha-svg-icon>
            ${S(`schedule_editor.copy_all`,e)}
          </button>
        </div>

        <div class="hint">
          ${S(this.climateMode===`auto`?`schedule_editor.hint_auto`:`schedule_editor.hint`,e)}
        </div>

        ${this._error?m`<div class="error">${this._error}</div>`:h}

        <div class="footer">
          <ha-button @click=${this._onClosed}>${S(`schedule_editor.cancel`,e)}</ha-button>
          <ha-button raised .disabled=${this._saving||!this._name.trim()} @click=${this._save}>
            ${S(this._saving?`settings.saving`:`schedule_editor.save`,e)}
          </ha-button>
        </div>
      </div>
    `}get _dayField(){return this.climateMode===`auto`?`heat`:`temp`}_commonDayTemp(e){let t=new Set(U.flatMap(t=>e[t].map(e=>e[this._dayField])));return t.size===1?[...t][0]:``}_renderDayNight(e){let t=C(this.hass);return m`
      <div class="day-night">
        <label
          >${S(`schedule_editor.day_temp`,e)} (${t})
          <input
            type="number"
            step="0.5"
            inputmode="decimal"
            placeholder=${S(`schedule_editor.comfort_placeholder`,e)}
            .value=${this._dayTemp}
            @change=${e=>this._setDayTemp(e.target.value)}
          />
        </label>
        <label
          >${S(`schedule_editor.night_temp`,e)} (${t})
          <input
            type="number"
            step="0.5"
            inputmode="decimal"
            .value=${this._nightTempText}
            @change=${e=>this._nightTempText=e.target.value}
          />
        </label>
        <div class="hint">${S(`schedule_editor.day_night_hint`,e)}</div>
      </div>
    `}_setDayTemp(e){this._dayTemp=e;let t=this._dayField,n={...this._week};for(let r of U)n[r]=n[r].map(n=>({...n,[t]:e}));this._week=n}_renderPreview(e){return m`
      <div class="week-preview">
        ${U.map(t=>m`
            <div
              class="preview-row ${t===this._day?`selected`:``}"
              @click=${()=>this._day=t}
            >
              <span class="preview-label"
                >${S(`schedule_editor.day_short.${t}`,e)}</span
              >
              <div class="bar">
                ${this._week[t].map(e=>{if(!/^\d\d:\d\d$/.test(e.from)||!/^\d\d:\d\d$/.test(e.to))return h;let t=W(e.from)/1440*100,n=Math.max(0,(W(e.to)-W(e.from))/1440*100),r=this.climateMode===`cool_only`;return m`<div
                    class="bar-block ${r?`cool`:``}"
                    style="left:${t}%;width:${n}%"
                    title="${e.from}–${e.to}"
                  ></div>`})}
              </div>
            </div>
          `)}
        <div class="hours">
          <span></span>
          <div><span>0</span><span>6</span><span>12</span><span>18</span><span>24</span></div>
        </div>
      </div>
    `}_renderBlock(e,t,n){let r=C(this.hass),i=(i,a)=>m`
      <label
        >${a} (${r})
        <input
          class="temp"
          type="number"
          step="0.5"
          inputmode="decimal"
          placeholder=${S(`schedule_editor.comfort_placeholder`,n)}
          .value=${e[i]}
          @change=${e=>this._setBlock(t,i,e.target.value)}
        />
      </label>
    `;return m`
      <div class="block-row">
        <label
          >${S(`schedule_editor.from`,n)}
          <input
            type="time"
            .value=${e.from}
            @change=${e=>this._setBlock(t,`from`,e.target.value)}
          />
        </label>
        <label
          >${S(`schedule_editor.to`,n)}
          <input
            type="time"
            .value=${e.to===`24:00`?`00:00`:e.to}
            @change=${e=>{let n=e.target.value;this._setBlock(t,`to`,n===`00:00`?`24:00`:n)}}
          />
        </label>
        ${this.climateMode===`auto`?m`${i(`heat`,S(`schedule_editor.heat`,n))}
              ${i(`cool`,S(`schedule_editor.cool`,n))}`:i(`temp`,S(`schedule_editor.temperature`,n))}
        <span class="spacer"></span>
        <ha-icon-button
          .path=${gn}
          .label=${S(`schedule_editor.remove_block`,n)}
          @click=${()=>this._removeBlock(t)}
        ></ha-icon-button>
      </div>
    `}_renderDayError(e){let t=Cn(this._week[this._day]);return t?m`<div class="error">${S(t,e)}</div>`:h}_updateDay(e,t){this._week={...this._week,[e]:t}}_setBlock(e,t,n){let r=this._week[this._day].map((r,i)=>i===e?{...r,[t]:n}:r);this._updateDay(this._day,r)}_removeBlock(e){this._updateDay(this._day,this._week[this._day].filter((t,n)=>n!==e))}_copyDay(e){let t=this._week[this._day],n=e===`all`?U:U.slice(0,5),r={...this._week};for(let e of n)r[e]=t.map(e=>({...e}));this._week=r}async _entityIdFor(e){for(let t=0;t<20;t++){let t=(await this.hass.callWS({type:`config/entity_registry/list`})).find(t=>t.platform===`schedule`&&t.unique_id===e);if(t)return t.entity_id;await new Promise(e=>setTimeout(e,250))}throw Error(S(`schedule_editor.err_entity`,this.hass.language))}_close(){this.dispatchEvent(new CustomEvent(`schedule-editor-closed`,{bubbles:!0,composed:!0}))}};A([y({attribute:!1})],G.prototype,`hass`,void 0),A([y({type:Boolean})],G.prototype,`open`,void 0),A([y({type:String})],G.prototype,`entityId`,void 0),A([y({type:String})],G.prototype,`climateMode`,void 0),A([y({type:String})],G.prototype,`defaultName`,void 0),A([y({type:Number})],G.prototype,`nightTemp`,void 0),A([b()],G.prototype,`_loading`,void 0),A([b()],G.prototype,`_saving`,void 0),A([b()],G.prototype,`_error`,void 0),A([b()],G.prototype,`_readOnly`,void 0),A([b()],G.prototype,`_name`,void 0),A([b()],G.prototype,`_week`,void 0),A([b()],G.prototype,`_scheduleId`,void 0),A([b()],G.prototype,`_day`,void 0),A([b()],G.prototype,`_copyFrom`,void 0),A([b()],G.prototype,`_icon`,void 0),A([b()],G.prototype,`_dayTemp`,void 0),A([b()],G.prototype,`_nightTempText`,void 0),G=A([v(`rs-schedule-editor`)],G),_(),x(),j();var K=class extends g{constructor(...e){super(...e),this.climateMode=`auto`,this.comfortHeat=21,this.ecoHeat=17,this.awayHeat=null,this.scheduleEntity=``,this.presenceEnabled=!1,this.predictedArrival=null,this.preheatActive=!1,this._scheduleDay=null,this._scheduleEditable=!0,this._loadedFor=``,this._takeOver=()=>{this.dispatchEvent(new CustomEvent(`schedule-edit-request`,{detail:{entityId:this.scheduleEntity},bubbles:!0,composed:!0}))}}refresh(){this._loadedFor=``,this.requestUpdate()}updated(){this.scheduleEntity!==this._loadedFor&&this.hass&&(this._loadedFor=this.scheduleEntity,this._loadSchedule())}async _loadSchedule(){let e=this.scheduleEntity;if(!e)this._scheduleDay=null,this._scheduleEditable=!0;else try{let[t,n]=await Promise.all([ln(this.hass,e),cn(this.hass,e).catch(()=>null)]);if(e!==this.scheduleEntity)return;let r=this.climateMode===`auto`?`heat_temperature`:`temperature`,i=new Set(U.flatMap(e=>t[e].map(e=>e.data?.[r]??e.data?.temperature))),a=i.size===1?[...i][0]:void 0;this._scheduleDay=typeof a==`number`?Math.round(T(a,this.hass)*10)/10:null,this._scheduleEditable=n!==null}catch{this._scheduleDay=null}}get _dayValue(){return this._scheduleDay??this.comfortHeat}_fire(e,t){this.dispatchEvent(new CustomEvent(`quick-temp-changed`,{detail:{field:e,value:t},bubbles:!0,composed:!0})),e===`day`&&t!==null&&this._scheduleEditable&&(this._scheduleDay=t)}_step(e,t,n){let r=Number(O(this.hass))||.5,i=Math.round((w(t,this.hass)+n*r)/r)*r,a=Math.round(T(i,this.hass)*10)/10;a<5||a>30||this._fire(e,a)}_renderRow(e,t,n,r,i,a=!1){return m`<div class="row">
      <ha-icon .icon=${t}></ha-icon>
      <div class="text">
        <div class="label">${n}</div>
        ${i?m`<div class="hint">${i}</div>`:h}
      </div>
      <button class="step" @click=${()=>this._step(e,r,-1)}>−</button>
      <span class="value ${a?`inherited`:``}"
        >${D(r,this.hass)}<small>${C(this.hass)}</small></span
      >
      <button class="step" @click=${()=>this._step(e,r,1)}>+</button>
    </div>`}render(){if(!this.hass||this.climateMode===`cool_only`)return h;let e=this.hass.language,t=this.awayHeat,n=this.predictedArrival==null?``:new Date(this.predictedArrival*1e3).toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`});return m`
      ${this._renderRow(`day`,`mdi:white-balance-sunny`,S(`quick.day`,e),this._dayValue,this.scheduleEntity?this._scheduleEditable?S(`quick.day_hint_schedule`,e):S(`quick.day_hint_yaml`,e):S(`quick.day_hint`,e))}
      ${this.scheduleEntity&&!this._scheduleEditable?m`<button class="link" @click=${this._takeOver}>
              ${S(`quick.take_over`,e)}
            </button>`:h}
      ${this._renderRow(`night`,`mdi:weather-night`,S(`quick.night`,e),this.ecoHeat,S(`quick.night_hint`,e))}
      ${this.presenceEnabled?m`${this._renderRow(`away`,`mdi:home-export-outline`,S(`quick.away`,e),t??this.ecoHeat,S(t===null?`quick.away_hint_same`:`quick.away_hint`,e),t===null)}
            ${t===null?h:m`<button class="link" @click=${()=>this._fire(`away`,null)}>
                    ${S(`quick.away_reset`,e)}
                  </button>`}
            ${n?m`<div class="arrival ${this.preheatActive?`active`:``}">
                    <ha-icon icon="mdi:home-clock-outline"></ha-icon>
                    ${S(this.preheatActive?`quick.arrival_heating`:`quick.arrival`,e,{time:n})}
                  </div>`:h}`:h}
    `}static{this.styles=l`
    :host {
      display: flex;
      flex-direction: column;
      gap: 6px;
      margin: 12px 0;
      padding-top: 12px;
      border-top: 1px solid var(--divider-color, #eee);
    }
    .row {
      display: grid;
      grid-template-columns: 24px 1fr 34px auto 34px;
      align-items: center;
      gap: 8px;
    }
    .row ha-icon {
      --mdc-icon-size: 20px;
      color: var(--secondary-text-color);
    }
    .label {
      font-size: 14px;
      font-weight: 500;
    }
    .hint {
      font-size: 11px;
      color: var(--secondary-text-color);
      line-height: 1.3;
    }
    .step {
      width: 34px;
      height: 34px;
      border-radius: 50%;
      border: 1px solid var(--divider-color, #ccc);
      background: none;
      color: var(--primary-text-color);
      font-size: 18px;
      cursor: pointer;
    }
    .step:hover {
      background: rgba(127, 127, 127, 0.12);
    }
    .value {
      min-width: 62px;
      text-align: center;
      font-size: 20px;
      font-weight: 500;
    }
    .value small {
      font-size: 12px;
      margin-left: 2px;
      color: var(--secondary-text-color);
    }
    .value.inherited {
      color: var(--secondary-text-color);
    }
    .link {
      align-self: flex-start;
      margin-left: 32px;
      background: none;
      border: none;
      padding: 0;
      color: var(--primary-color);
      font: inherit;
      font-size: 12px;
      cursor: pointer;
    }
    .arrival {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 12px;
      color: var(--secondary-text-color);
      margin-left: 32px;
    }
    .arrival ha-icon {
      --mdc-icon-size: 16px;
    }
    .arrival.active {
      color: var(--state-climate-heat-color, #ff8100);
    }
  `}};A([y({attribute:!1})],K.prototype,`hass`,void 0),A([y({type:String})],K.prototype,`climateMode`,void 0),A([y({type:Number})],K.prototype,`comfortHeat`,void 0),A([y({type:Number})],K.prototype,`ecoHeat`,void 0),A([y({attribute:!1})],K.prototype,`awayHeat`,void 0),A([y({type:String})],K.prototype,`scheduleEntity`,void 0),A([y({type:Boolean})],K.prototype,`presenceEnabled`,void 0),A([y({attribute:!1})],K.prototype,`predictedArrival`,void 0),A([y({type:Boolean})],K.prototype,`preheatActive`,void 0),A([b()],K.prototype,`_scheduleDay`,void 0),A([b()],K.prototype,`_scheduleEditable`,void 0),K=A([v(`rs-quick-temps`)],K),_(),x(),j();var wn=class extends g{constructor(...e){super(...e),this.icon=``,this.label=``,this.hint=``,this.checked=!1,this.disabled=!1}static{this.styles=l`
    :host {
      display: block;
    }

    ha-card {
      padding: 16px 20px;
      min-width: 0;
    }

    .row {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .icon {
      --mdc-icon-size: 18px;
      color: var(--secondary-text-color);
      opacity: 0.7;
      flex-shrink: 0;
    }

    rs-toggle-row {
      flex: 1;
      min-width: 0;
    }
  `}render(){return m`
      <ha-card>
        <div class="row">
          ${this.icon?m`<ha-icon class="icon" icon=${this.icon}></ha-icon>`:h}
          <rs-toggle-row
            .label=${this.label}
            .hint=${this.hint}
            .checked=${this.checked}
            .disabled=${this.disabled}
            @toggle-changed=${this._onToggle}
          ></rs-toggle-row>
        </div>
      </ha-card>
    `}_onToggle(e){e.stopPropagation(),this.dispatchEvent(new CustomEvent(`toggle-changed`,{detail:e.detail,bubbles:!0,composed:!0}))}};A([y({type:String})],wn.prototype,`icon`,void 0),A([y({type:String})],wn.prototype,`label`,void 0),A([y({type:String})],wn.prototype,`hint`,void 0),A([y({type:Boolean})],wn.prototype,`checked`,void 0),A([y({type:Boolean})],wn.prototype,`disabled`,void 0),wn=A([v(`rs-toggle-card`)],wn),_(),x(),j();var Tn=`https://github.com/snazzybean/roommind/blob/main/docs/control-and-devices.md`,En=500,Dn=2e3,On=3,q=class extends g{constructor(...e){super(...e),this.config=null,this.presenceEnabled=!1,this.presencePersons=[],this.climateControlActive=!0,this.valveProtectionEnabled=!1,this.coilDryEnabled=!1,this.coilDryMinutes=20,this.coilDryMode=`fan_only`,this.coilDryFanMode=`low`,this._devices=[],this._selectedTempSensor=``,this._selectedHumiditySensor=``,this._selectedOccupancySensors=new Set,this._occupancyEcoEnabled=!1,this._occupancyEcoDelay=15,this._selectedWindowSensors=new Set,this._windowOpenDelay=0,this._windowCloseDelay=0,this._climateMode=`auto`,this._schedules=[],this._scheduleSelectorEntity=``,this._comfortHeat=21,this._comfortCool=24,this._ecoHeat=17,this._ecoCool=27,this._error=``,this._dirty=!1,this._editing=null,this._selectedPresencePersons=[],this._displayName=``,this._selectedCovers=new Set,this._coversAutoEnabled=!1,this._coversDeployThreshold=1.5,this._coversMinPosition=0,this._coversOverrideMinutes=60,this._coverSchedules=[],this._coverScheduleSelectorEntity=``,this._coversNightClose=!1,this._coversNightPosition=0,this._coversSnapDeploy=!1,this._coverOrientations={},this._coversNightCloseElevation=0,this._coversNightCloseOffsetMinutes=0,this._coversOutdoorMinTemp=10,this._coverMinPositions={},this._ignorePresence=!1,this._isOutdoor=!1,this._valveProtectionExclude=new Set,this._climateControlEnabled=!0,this._showThermostat=!0,this._thermostatWritesSchedule=!0,this._awayHeat=null,this._scheduleEditorEntity=null,this._heatSourceOrchestration=!1,this._heatSourcePrimaryDelta=1.5,this._heatSourceOutdoorThreshold=5,this._heatSourceAcMinOutdoor=-15,this._optimisticCoverResume=!1,this._prevAreaId=null,this._saveInFlight=null,this._editSeq=0,this._saveRetries=0,this._openEdit=e=>()=>{this._editing=e},this._closeEdit=()=>{this._editing=null},this._onScheduleEditRequest=e=>{e.stopPropagation(),this._scheduleEditorEntity=e.detail.entityId},this._onScheduleEditorClosed=e=>{e.stopPropagation(),this._scheduleEditorEntity=null},this._onScheduleSaved=e=>{e.stopPropagation();let{entityId:t,created:n,replaces:r,nightTemp:i}=e.detail,a=!1;if(n&&t&&!this._schedules.some(e=>e.entity_id===t)){let e=r?this._schedules.findIndex(e=>e.entity_id===r):-1;this._schedules=e>=0?this._schedules.map((n,r)=>r===e?{entity_id:t}:n):[...this._schedules,{entity_id:t}],a=!0}i!==null&&this._setNightTemp(i)&&(a=!0),a&&this._autoSave(),this._quickTemps()?.refresh()},this._onQuickTempChanged=async e=>{e.stopPropagation();let{field:t,value:n}=e.detail;if(t===`night`&&n!==null)this._setNightTemp(n)&&this._autoSave();else if(t===`away`)this._awayHeat=n,this._autoSave();else if(t===`day`&&n!==null){this._comfortHeat=n,this._comfortCool<n&&(this._comfortCool=n),this._autoSave();let e=this._activeScheduleEntity();if(e)try{let t=Math.round(w(n,this.hass)*10)/10;await fn(this.hass,e,this._climateMode,{heat:t})}catch(e){this._error=e instanceof Error?e.message:String(e)}}},this._onThermostatSetTemperature=async e=>{if(!this._thermostatWritesSchedule||this._schedules.length===0)return!1;let t=un(e,this._climateMode);if(!t)return!1;let n=this.config?.live?.active_schedule_index??-1,r=this._schedules[n>=0?n:0]?.entity_id,i=r?this.hass.states[r]:void 0;if(!r||!i)return!1;if(i.state===`on`){if(!await fn(this.hass,r,this._climateMode,t))return!1;this._quickTemps()?.refresh()}else{let e=this._climateMode===`cool_only`?t.cool:t.heat;if(e===void 0)return!1;this._setNightTemp(T(e,this.hass))&&(this._autoSave(),await this._flushPending())}let a=e.entity_id;return this.config?.live?.override_active?await this.hass.callService(`climate`,`set_preset_mode`,{entity_id:a,preset_mode:`none`}):await this.hass.callService(`homeassistant`,`update_entity`,{entity_id:a}),!0}}static{this.styles=l`
    :host {
      display: block;
      max-width: 2400px;
      margin: 0 auto;
    }

    .detail-layout {
      display: flex;
      flex-direction: column;
      gap: 16px;
    }

    .detail-grid {
      column-count: 3;
      column-width: 360px;
      column-gap: 16px;
      column-fill: balance;
    }

    .detail-grid > * {
      display: block;
      width: 100%;
      break-inside: avoid;
      page-break-inside: avoid;
      margin-bottom: 16px;
    }

    @media (min-width: 1900px) {
      .detail-grid {
        column-count: 4;
      }
    }

    /* Section cards handled by rs-section-card */

    /* YAML code block for info panels (slotted into edit dialogs) */
    .yaml-block {
      background: var(--code-editor-background-color, rgba(0, 0, 0, 0.35));
      border: 1px solid var(--divider-color, rgba(255, 255, 255, 0.12));
      border-radius: 6px;
      padding: 10px 14px;
      margin: 8px 0;
      font-family: var(--code-font-family, monospace);
      font-size: 12px;
      line-height: 1.6;
      white-space: pre;
      overflow-x: auto;
      color: var(--primary-text-color);
    }
    .yaml-key {
      color: #82aaff;
    }
    .yaml-value {
      color: #e2a76a;
    }

    /* Actions */
    .actions {
      display: flex;
      align-items: center;
      gap: 12px;
      margin-top: 8px;
      margin-bottom: 24px;
    }

    .error {
      color: var(--error-color, #d32f2f);
      font-size: 13px;
      margin-top: 8px;
    }

    .field-hint {
      color: var(--secondary-text-color);
      font-size: 12px;
    }

    .exceptions-link {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      background: none;
      border: none;
      padding: 8px 0 0;
      margin: 0;
      cursor: pointer;
      font-size: 13px;
      color: var(--primary-color);
      font-family: inherit;
    }

    .exceptions-link:hover {
      text-decoration: underline;
    }

    .helper-link {
      display: inline-block;
      margin-top: 12px;
      color: var(--primary-color);
      font-size: 12px;
      text-decoration: none;
    }

    .helper-link:hover {
      text-decoration: underline;
    }
  `}connectedCallback(){super.connectedCallback(),this._initFromConfig()}disconnectedCallback(){super.disconnectedCallback(),this._flushSave()}willUpdate(e){if(e.has(`area`)||e.has(`config`)){let e=this.config?.area_id??this.area?.area_id??null;this._prevAreaId!==null&&e!==this._prevAreaId&&this._flushSave(this._prevAreaId)}}updated(e){let t=this.config?.area_id??this.area?.area_id??null;t===this._prevAreaId?e.has(`config`)&&!this._dirty&&(e.get(`config`)??this._initFromConfig()):(this._initFromConfig(),this._prevAreaId=t),e.has(`config`)&&this._optimisticCoverResume&&!this.config?.live?.cover_auto_paused&&(this._optimisticCoverResume=!1)}_initFromConfig(){this.config?(this._devices=this.config.devices?.length?[...this.config.devices]:[...(this.config.thermostats??[]).map(e=>({entity_id:e,type:`trv`,role:`auto`,heating_system_type:this.config.heating_system_type??``})),...(this.config.acs??[]).map(e=>({entity_id:e,type:`ac`,role:`auto`}))],this._selectedTempSensor=this.config.temperature_sensor,this._selectedHumiditySensor=this.config.humidity_sensor??``,this._selectedOccupancySensors=new Set(this.config.occupancy_sensors??[]),this._occupancyEcoEnabled=this.config.occupancy_eco_enabled??!1,this._occupancyEcoDelay=this.config.occupancy_eco_delay??15,this._selectedWindowSensors=new Set(this.config.window_sensors??[]),this._windowOpenDelay=this.config.window_open_delay??0,this._windowCloseDelay=this.config.window_close_delay??0,this._climateMode=this.config.climate_mode,this._schedules=this.config.schedules??[],this._scheduleSelectorEntity=this.config.schedule_selector_entity??``,this._comfortHeat=this.config.comfort_heat??this.config.comfort_temp??21,this._comfortCool=this.config.comfort_cool??24,this._ecoHeat=this.config.eco_heat??this.config.eco_temp??17,this._ecoCool=this.config.eco_cool??27,this._selectedPresencePersons=this.config.presence_persons??[],this._displayName=this.config.display_name??``,this._selectedCovers=new Set(this.config.covers??[]),this._coversAutoEnabled=this.config.covers_auto_enabled??!1,this._coversDeployThreshold=this.config.covers_deploy_threshold??1.5,this._coversMinPosition=this.config.covers_min_position??0,this._coversOverrideMinutes=this.config.covers_override_minutes??60,this._coverSchedules=this.config.cover_schedules??[],this._coverScheduleSelectorEntity=this.config.cover_schedule_selector_entity??``,this._coversNightClose=this.config.covers_night_close??!1,this._coversNightPosition=this.config.covers_night_position??0,this._coversSnapDeploy=this.config.covers_snap_deploy??!1,this._coverOrientations=this.config.cover_orientations??{},this._coversNightCloseElevation=this.config.covers_night_close_elevation??0,this._coversNightCloseOffsetMinutes=this.config.covers_night_close_offset_minutes??0,this._coversOutdoorMinTemp=this.config.covers_outdoor_min_temp??10,this._coverMinPositions=this.config.cover_min_positions??{},this._ignorePresence=this.config.ignore_presence??!1,this._isOutdoor=this.config.is_outdoor??!1,this._valveProtectionExclude=new Set(this.config.valve_protection_exclude??[]),this._climateControlEnabled=this.config.climate_control_enabled??!0,this._showThermostat=this.config.show_thermostat??!0,this._thermostatWritesSchedule=this.config.thermostat_writes_schedule??!0,this._awayHeat=this.config.away_heat??null,this._heatSourceOrchestration=this.config.heat_source_orchestration??!1,this._heatSourcePrimaryDelta=this.config.heat_source_primary_delta??1.5,this._heatSourceOutdoorThreshold=this.config.heat_source_outdoor_threshold??5,this._heatSourceAcMinOutdoor=this.config.heat_source_ac_min_outdoor??-15):(this._devices=[],this._selectedTempSensor=``,this._selectedHumiditySensor=``,this._selectedOccupancySensors=new Set,this._occupancyEcoEnabled=!1,this._occupancyEcoDelay=15,this._selectedWindowSensors=new Set,this._windowOpenDelay=0,this._windowCloseDelay=0,this._climateMode=`auto`,this._schedules=[],this._scheduleSelectorEntity=``,this._comfortHeat=21,this._comfortCool=24,this._ecoHeat=17,this._ecoCool=27,this._selectedPresencePersons=[],this._displayName=``,this._selectedCovers=new Set,this._coversAutoEnabled=!1,this._coversDeployThreshold=1.5,this._coversMinPosition=0,this._coversOverrideMinutes=60,this._coverSchedules=[],this._coverScheduleSelectorEntity=``,this._coversNightClose=!1,this._coversNightPosition=0,this._coversSnapDeploy=!1,this._coverOrientations={},this._coversNightCloseElevation=0,this._coversNightCloseOffsetMinutes=0,this._coversOutdoorMinTemp=10,this._coverMinPositions={},this._ignorePresence=!1,this._isOutdoor=!1,this._valveProtectionExclude=new Set,this._climateControlEnabled=!0,this._showThermostat=!0,this._thermostatWritesSchedule=!0,this._awayHeat=null,this._heatSourceOrchestration=!1,this._heatSourcePrimaryDelta=1.5,this._heatSourceOutdoorThreshold=5,this._heatSourceAcMinOutdoor=-15),this._dirty=!1,this._devices.length===0&&this._editing===null&&(this._editing=`devices`)}_getEffectiveOverride(){let e=this.shadowRoot?.querySelector(`rs-override-section`);if(e)return e.getEffectiveOverride();let t=this.config?.live;return t?.override_active&&t.override_type?{active:!0,type:t.override_type,heat:t.override_heat,cool:t.override_cool,until:t.override_until}:{active:!1,type:null,heat:null,cool:null,until:null}}render(){return this.area?m`
      <div class="detail-layout" @schedule-edit-request=${this._onScheduleEditRequest}>
        <rs-hero-status
          .hass=${this.hass}
          .area=${this.area}
          .config=${this.config}
          .isOutdoor=${this._isOutdoor}
          .overrideInfo=${this._getEffectiveOverride()}
          .climateControlActive=${this.climateControlActive&&this._climateControlEnabled}
          @display-name-changed=${this._onDisplayNameChanged}
        ></rs-hero-status>

        <div class="detail-grid">
          ${this._isOutdoor?h:m`
                  <rs-toggle-card
                    icon="mdi:power"
                    .label=${S(`room.climate_control_toggle`,this.hass.language)}
                    .hint=${S(`room.climate_control_hint`,this.hass.language)}
                    .checked=${this._climateControlEnabled}
                    @toggle-changed=${this._onClimateControlToggle}
                  ></rs-toggle-card>
                  ${this._showThermostat&&this.config?m`
                          <rs-section-card
                            icon="mdi:thermostat"
                            .heading=${S(`room.section.thermostat`,this.hass.language)}
                          >
                            <rs-info-icon slot="header-extras">
                              ${S(`thermostat.info`,this.hass.language)}
                            </rs-info-icon>
                            <rs-thermostat-card
                              .hass=${this.hass}
                              .areaId=${this.area.area_id}
                              .setTemperature=${this._onThermostatSetTemperature}
                            ></rs-thermostat-card>
                            <rs-toggle-row
                              .label=${S(`thermostat.writes_schedule`,this.hass.language)}
                              .hint=${S(`thermostat.writes_schedule_hint`,this.hass.language)}
                              .checked=${this._thermostatWritesSchedule}
                              @toggle-changed=${this._onThermostatWritesScheduleToggle}
                            ></rs-toggle-row>
                          </rs-section-card>
                        `:h}

                  <rs-section-card
                    icon="mdi:cog"
                    .heading=${S(`room.section.climate_mode`,this.hass.language)}
                  >
                    <rs-info-icon slot="header-extras">
                      <b>${S(`mode.auto`,this.hass.language)}</b> —
                      ${S(`mode.auto_desc`,this.hass.language)}<br />
                      <b>${S(`mode.heat_only`,this.hass.language)}</b> —
                      ${S(`mode.heat_only_desc`,this.hass.language)}<br />
                      <b>${S(`mode.cool_only`,this.hass.language)}</b> —
                      ${S(`mode.cool_only_desc`,this.hass.language)}
                    </rs-info-icon>
                    <rs-climate-mode-selector
                      .climateMode=${this._climateMode}
                      .language=${this.hass.language}
                      @mode-changed=${this._onModeChanged}
                    ></rs-climate-mode-selector>
                  </rs-section-card>

                  <rs-section-card
                    icon="mdi:calendar"
                    .heading=${S(`room.section.schedule`,this.hass.language)}
                    editable
                    @edit-click=${this._openEdit(`schedule`)}
                  >
                    <rs-schedule-settings
                      .hass=${this.hass}
                      .schedules=${this._schedules}
                      .scheduleSelectorEntity=${this._scheduleSelectorEntity}
                      .activeScheduleIndex=${this.config?.live?.active_schedule_index??-1}
                      .comfortHeat=${this._comfortHeat}
                      .comfortCool=${this._comfortCool}
                      .ecoHeat=${this._ecoHeat}
                      .ecoCool=${this._ecoCool}
                      .climateMode=${this._climateMode}
                      .scheduleTempWarnings=${this.config?.live?.schedule_temp_warnings??[]}
                      .editing=${!1}
                      .hideHeatTemps=${!0}
                      @schedules-changed=${this._onSchedulesChanged}
                      @schedule-selector-changed=${this._onScheduleSelectorChanged}
                      @comfort-heat-changed=${this._onComfortHeatChanged}
                      @comfort-cool-changed=${this._onComfortCoolChanged}
                      @eco-heat-changed=${this._onEcoHeatChanged}
                      @eco-cool-changed=${this._onEcoCoolChanged}
                    ></rs-schedule-settings>
                    <rs-quick-temps
                      .hass=${this.hass}
                      .climateMode=${this._climateMode}
                      .comfortHeat=${this._comfortHeat}
                      .ecoHeat=${this._ecoHeat}
                      .awayHeat=${this._awayHeat}
                      .scheduleEntity=${this._activeScheduleEntity()}
                      .presenceEnabled=${this.presenceEnabled&&!this._ignorePresence}
                      .predictedArrival=${this.config?.live?.predicted_arrival??null}
                      .preheatActive=${this.config?.live?.presence_preheat_active??!1}
                      @quick-temp-changed=${this._onQuickTempChanged}
                    ></rs-quick-temps>
                    ${this.config?m`
                            <rs-override-section
                              .hass=${this.hass}
                              .config=${this.config}
                              .climateMode=${this._climateMode}
                              .comfortHeat=${this._comfortHeat}
                              .comfortCool=${this._comfortCool}
                              .ecoHeat=${this._ecoHeat}
                              .ecoCool=${this._ecoCool}
                              .language=${this.hass.language}
                            ></rs-override-section>
                          `:h}
                  </rs-section-card>
                `}
          ${this._isOutdoor?h:m`
                  <rs-section-card
                    icon="mdi:power-plug"
                    .heading=${S(`room.section.devices`,this.hass.language)}
                    editable
                    @edit-click=${this._openEdit(`devices`)}
                  >
                    <rs-device-section
                      .hass=${this.hass}
                      .area=${this.area}
                      .editing=${!1}
                      .devices=${this._devices}
                      .selectedTempSensor=${this._selectedTempSensor}
                      .valveProtectionExclude=${this._valveProtectionExclude}
                      .valveProtectionEnabled=${this.valveProtectionEnabled}
                      .coilDryEnabledGlobal=${this.coilDryEnabled}
                      .coilDryMinutesGlobal=${this.coilDryMinutes}
                      .coilDryModeGlobal=${this.coilDryMode}
                      .coilDryFanModeGlobal=${this.coilDryFanMode}
                      @device-changed=${this._onDeviceChanged}
                      @valve-protection-exclude-toggle=${this._onValveProtectionExcludeToggle}
                    ></rs-device-section>
                  </rs-section-card>

                  <rs-section-card
                    icon="mdi:thermometer"
                    .heading=${S(`room.section.sensors`,this.hass.language)}
                    editable
                    @edit-click=${this._openEdit(`sensors`)}
                  >
                    <rs-sensor-section
                      .hass=${this.hass}
                      .area=${this.area}
                      .editing=${!1}
                      .temperatureSensor=${this._selectedTempSensor}
                      .humiditySensor=${this._selectedHumiditySensor}
                      .occupancySensors=${this._selectedOccupancySensors}
                      .occupancyEcoEnabled=${this._occupancyEcoEnabled}
                      .occupancyEcoDelay=${this._occupancyEcoDelay}
                      .windowSensors=${this._selectedWindowSensors}
                      .windowOpenDelay=${this._windowOpenDelay}
                      .windowCloseDelay=${this._windowCloseDelay}
                      .heatingSystemType=${Wt(this._devices)}
                      .language=${this.hass.language}
                      @sensor-changed=${this._onSensorChanged}
                    ></rs-sensor-section>
                  </rs-section-card>

                  ${this.presenceEnabled&&(this.presencePersons.length>0||this._selectedPresencePersons.length>0)?m`<rs-section-card
                          icon="mdi:home-account"
                          .heading=${S(`room.section.presence`,this.hass.language)}
                          editable
                          @edit-click=${this._openEdit(`presence`)}
                        >
                          <rs-info-icon
                            slot="header-extras"
                            .text=${S(`presence.ignore_hint`,this.hass.language)}
                          ></rs-info-icon>
                          <rs-presence-section
                            .hass=${this.hass}
                            .presenceEnabled=${this.presenceEnabled}
                            .presencePersons=${this.presencePersons}
                            .selectedPresencePersons=${this._selectedPresencePersons}
                            .ignorePresence=${this._ignorePresence}
                            .editing=${!1}
                            .language=${this.hass.language}
                            @presence-persons-changed=${this._onPresencePersonsChanged}
                            @ignore-presence-changed=${this._onIgnorePresenceChanged}
                          ></rs-presence-section>
                        </rs-section-card>`:h}
                `}
          ${this._isOutdoor?h:m`<rs-section-card
                  icon="mdi:blinds-horizontal"
                  .heading=${S(`room.section.covers`,this.hass.language)}
                  .badge=${S(`badge.beta`,this.hass.language)}
                  .badgeHint=${S(`badge.beta_hint`,this.hass.language)}
                  editable
                  @edit-click=${this._openEdit(`covers`)}
                >
                  <rs-covers-section
                    .hass=${this.hass}
                    .area=${this.area}
                    .editing=${!1}
                    .selectedCovers=${this._selectedCovers}
                    .autoEnabled=${this._coversAutoEnabled}
                    .deployThreshold=${this._coversDeployThreshold}
                    .minPosition=${this._coversMinPosition}
                    .overrideMinutes=${this._coversOverrideMinutes}
                    .coverSchedules=${this._coverSchedules}
                    .coverScheduleSelectorEntity=${this._coverScheduleSelectorEntity}
                    .activeCoverScheduleIndex=${this.config?.live?.active_cover_schedule_index??-1}
                    .nightClose=${this._coversNightClose}
                    .nightPosition=${this._coversNightPosition}
                    .snapDeploy=${this._coversSnapDeploy}
                    .forcedReason=${this.config?.live?.cover_forced_reason??``}
                    .autoPaused=${this._optimisticCoverResume?!1:this.config?.live?.cover_auto_paused??!1}
                    .overrideUntil=${this.config?.live?.cover_override_until??null}
                    .coverOrientations=${this._coverOrientations}
                    .nightCloseElevation=${this._coversNightCloseElevation}
                    .nightCloseOffsetMinutes=${this._coversNightCloseOffsetMinutes}
                    .outdoorMinTemp=${this._coversOutdoorMinTemp}
                    .coverMinPositions=${this._coverMinPositions}
                    @covers-toggle=${this._onCoversToggle}
                    @setting-changed=${this._onCoverSettingChanged}
                    @cover-resume-auto=${this._onCoverResumeAuto}
                  ></rs-covers-section>
                </rs-section-card>`}
          ${!this._isOutdoor&&this._selectedTempSensor&&this._devices.some(e=>e.type===`trv`)&&this._devices.some(e=>e.type===`ac`)?m`<rs-section-card
                  icon="mdi:swap-horizontal"
                  .heading=${S(`room.section.heat_source`,this.hass.language)}
                  editable
                  @edit-click=${this._openEdit(`heatSource`)}
                >
                  <rs-heat-source-section
                    .hass=${this.hass}
                    .editing=${!1}
                    .enabled=${this._heatSourceOrchestration}
                    .primaryDelta=${this._heatSourcePrimaryDelta}
                    .outdoorThreshold=${this._heatSourceOutdoorThreshold}
                    .acMinOutdoor=${this._heatSourceAcMinOutdoor}
                    @setting-changed=${this._onHeatSourceSettingChanged}
                  ></rs-heat-source-section>
                </rs-section-card>`:h}
          ${this._isOutdoor?h:m`<rs-toggle-card
                  icon="mdi:thermostat"
                  .label=${S(`room.thermostat_toggle`,this.hass.language)}
                  .hint=${S(`room.thermostat_hint`,this.hass.language)}
                  .checked=${this._showThermostat}
                  @toggle-changed=${this._onShowThermostatToggle}
                ></rs-toggle-card>`}

          <rs-toggle-card
            icon="mdi:tree"
            .label=${S(`room.outdoor_toggle`,this.hass.language)}
            .hint=${S(`room.outdoor_hint`,this.hass.language)}
            .checked=${this._isOutdoor}
            @toggle-changed=${this._onOutdoorToggle}
          ></rs-toggle-card>
        </div>
        ${this._error?m`<div class="error">${this._error}</div>`:h}
        ${this._renderEditDialog()}
        <rs-schedule-editor
          .hass=${this.hass}
          .open=${this._scheduleEditorEntity!==null}
          .entityId=${this._scheduleEditorEntity??``}
          .climateMode=${this._climateMode}
          .defaultName=${this._displayName||this.area.name}
          .nightTemp=${this._climateMode===`cool_only`?this._ecoCool:this._ecoHeat}
          @schedule-editor-closed=${this._onScheduleEditorClosed}
          @schedule-saved=${this._onScheduleSaved}
        ></rs-schedule-editor>
      </div>
    `:h}_renderEditDialog(){if(this._editing===null)return h;let e=this.hass.language;switch(this._editing){case`schedule`:return m`<rs-edit-dialog
          open
          icon="mdi:calendar"
          .heading=${S(`room.section.schedule`,e)}
          hasInfo
          @rs-dialog-closed=${this._closeEdit}
        >
          <div slot="info">
            <p><strong>${S(`schedule.help_temps_title`,e)}</strong></p>
            <p>${S(`schedule.help_temps`,e)}</p>
            <ol style="margin: 4px 0 0 0; padding-left: 20px; line-height: 1.8">
              <li>${N(S(`schedule.help_temps_1`,e))}</li>
              <li>${N(S(`schedule.help_temps_2`,e))}</li>
              <li>${N(S(`schedule.help_temps_3`,e))}</li>
              <li>${N(S(`schedule.help_temps_4`,e))}</li>
            </ol>
            <p style="margin-top: 12px">
              <strong>${S(`schedule.help_block_title`,e)}</strong>
            </p>
            <p>${N(S(`schedule.help_block`,e))}</p>
            <div class="yaml-block">
              ${N(`<span class="yaml-key">schedule</span>:
  <span class="yaml-key">living_room_heating</span>:
    <span class="yaml-key">name</span>: <span class="yaml-value">Living Room Heating</span>
    <span class="yaml-key">monday</span>:
      - <span class="yaml-key">from</span>: <span class="yaml-value">"06:00:00"</span>
        <span class="yaml-key">to</span>: <span class="yaml-value">"08:00:00"</span>
        <span class="yaml-key">data</span>:
          <span class="yaml-key">temperature</span>: <span class="yaml-value">23</span>
      - <span class="yaml-key">from</span>: <span class="yaml-value">"17:00:00"</span>
        <span class="yaml-key">to</span>: <span class="yaml-value">"22:00:00"</span>
        <span class="yaml-key">data</span>:
          <span class="yaml-key">temperature</span>: <span class="yaml-value">21.5</span>`)}
            </div>
            <p style="margin-top: 8px">${N(S(`schedule.help_block_note`,e))}</p>
            <p style="margin-top: 12px">
              <strong>${S(`schedule.help_split_title`,e)}</strong>
            </p>
            <p>${N(S(`schedule.help_split`,e))}</p>
            <div class="yaml-block">
              ${N(`- <span class="yaml-key">from</span>: <span class="yaml-value">"06:00:00"</span>
  <span class="yaml-key">to</span>: <span class="yaml-value">"08:00:00"</span>
  <span class="yaml-key">data</span>:
    <span class="yaml-key">heat_temperature</span>: <span class="yaml-value">21</span>
    <span class="yaml-key">cool_temperature</span>: <span class="yaml-value">24</span>`)}
            </div>
            <p style="margin-top: 8px">${N(S(`schedule.help_split_note`,e))}</p>
            <p style="margin-top: 12px">
              <strong>${S(`schedule.help_multi_title`,e)}</strong>
            </p>
            <p>${N(S(`schedule.help_multi`,e))}</p>
          </div>
          <rs-schedule-settings
            .hass=${this.hass}
            .schedules=${this._schedules}
            .scheduleSelectorEntity=${this._scheduleSelectorEntity}
            .activeScheduleIndex=${this.config?.live?.active_schedule_index??-1}
            .comfortHeat=${this._comfortHeat}
            .comfortCool=${this._comfortCool}
            .ecoHeat=${this._ecoHeat}
            .ecoCool=${this._ecoCool}
            .climateMode=${this._climateMode}
            .scheduleTempWarnings=${this.config?.live?.schedule_temp_warnings??[]}
            .editing=${!0}
            @schedules-changed=${this._onSchedulesChanged}
            @schedule-selector-changed=${this._onScheduleSelectorChanged}
            @comfort-heat-changed=${this._onComfortHeatChanged}
            @comfort-cool-changed=${this._onComfortCoolChanged}
            @eco-heat-changed=${this._onEcoHeatChanged}
            @eco-cool-changed=${this._onEcoCoolChanged}
          ></rs-schedule-settings>
        </rs-edit-dialog>`;case`devices`:return m`<rs-edit-dialog
          open
          icon="mdi:power-plug"
          .heading=${S(`room.section.devices`,e)}
          hasInfo
          @rs-dialog-closed=${this._closeEdit}
        >
          <div slot="info">
            <b>${S(`devices.info.types_title`,e)}</b><br />
            ${S(`devices.info.types_body`,e)}
            <br /><br />
            <b>${S(`devices.info.control_title`,e)}</b><br />
            ${S(`devices.info.control_body`,e)}
            <br /><br />
            <b>${S(`devices.info.modes_title`,e)}</b><br />
            ${S(`devices.info.modes_body`,e)}
            <br /><br />
            <b>${S(`devices.info.heat_source_title`,e)}</b><br />
            ${S(`devices.info.heat_source_body`,e)}
            <br />
            <a class="helper-link" href=${Tn} target="_blank" rel="noreferrer">
              ${S(`common.learn_more`,e)}
            </a>
          </div>
          <rs-device-section
            .hass=${this.hass}
            .area=${this.area}
            .editing=${!0}
            .devices=${this._devices}
            .selectedTempSensor=${this._selectedTempSensor}
            .valveProtectionExclude=${this._valveProtectionExclude}
            .valveProtectionEnabled=${this.valveProtectionEnabled}
            .coilDryEnabledGlobal=${this.coilDryEnabled}
            .coilDryMinutesGlobal=${this.coilDryMinutes}
            .coilDryModeGlobal=${this.coilDryMode}
            .coilDryFanModeGlobal=${this.coilDryFanMode}
            @device-changed=${this._onDeviceChanged}
            @valve-protection-exclude-toggle=${this._onValveProtectionExcludeToggle}
          ></rs-device-section>
        </rs-edit-dialog>`;case`sensors`:return m`<rs-edit-dialog
          open
          icon="mdi:thermometer"
          .heading=${S(`room.section.sensors`,e)}
          @rs-dialog-closed=${this._closeEdit}
        >
          <rs-sensor-section
            .hass=${this.hass}
            .area=${this.area}
            .editing=${!0}
            .temperatureSensor=${this._selectedTempSensor}
            .humiditySensor=${this._selectedHumiditySensor}
            .occupancySensors=${this._selectedOccupancySensors}
            .occupancyEcoEnabled=${this._occupancyEcoEnabled}
            .occupancyEcoDelay=${this._occupancyEcoDelay}
            .windowSensors=${this._selectedWindowSensors}
            .windowOpenDelay=${this._windowOpenDelay}
            .windowCloseDelay=${this._windowCloseDelay}
            .heatingSystemType=${Wt(this._devices)}
            .language=${this.hass.language}
            @sensor-changed=${this._onSensorChanged}
          ></rs-sensor-section>
        </rs-edit-dialog>`;case`presence`:return m`<rs-edit-dialog
          open
          icon="mdi:home-account"
          .heading=${S(`room.section.presence`,e)}
          hasInfo
          @rs-dialog-closed=${this._closeEdit}
        >
          <div slot="info">
            <b>${S(`presence.room_help_header`,e)}</b><br />
            ${S(`presence.room_help_body`,e)}
            <br /><br />
            <b>${S(`presence.help_ignore_title`,e)}</b><br />
            ${S(`presence.help_ignore_body`,e)}
          </div>
          <rs-presence-section
            .hass=${this.hass}
            .presenceEnabled=${this.presenceEnabled}
            .presencePersons=${this.presencePersons}
            .selectedPresencePersons=${this._selectedPresencePersons}
            .ignorePresence=${this._ignorePresence}
            .editing=${!0}
            .language=${this.hass.language}
            @presence-persons-changed=${this._onPresencePersonsChanged}
            @ignore-presence-changed=${this._onIgnorePresenceChanged}
          ></rs-presence-section>
        </rs-edit-dialog>`;case`covers`:return m`<rs-edit-dialog
          open
          icon="mdi:blinds-horizontal"
          .heading=${S(`room.section.covers`,e)}
          hasInfo
          @rs-dialog-closed=${this._closeEdit}
        >
          <div slot="info">
            <b>${S(`covers.info.selection_title`,e)}</b><br />
            ${S(`covers.info.selection_body`,e)}
            <br /><br />
            <b>${S(`covers.info.schedule_title`,e)}</b><br />
            ${S(`covers.info.schedule_body`,e)}
            <div class="yaml-block">
              ${N(`<span class="yaml-key">schedule</span>:
  <span class="yaml-key">cover_evening</span>:
    <span class="yaml-key">name</span>: <span class="yaml-value">Cover Evening</span>
    <span class="yaml-key">monday</span>:
      - <span class="yaml-key">from</span>: <span class="yaml-value">"20:00:00"</span>
        <span class="yaml-key">to</span>: <span class="yaml-value">"06:00:00"</span>
        <span class="yaml-key">data</span>:
          <span class="yaml-key">position</span>: <span class="yaml-value">10</span>`)}
            </div>
            <b>${S(`covers.info.solar_title`,e)}</b><br />
            ${S(`covers.info.solar_body`,e)}
            <br /><br />
            <b>${S(`covers.info.night_title`,e)}</b><br />
            ${S(`covers.info.night_body`,e)}
            <br /><br />
            <b>${S(`covers.info.override_title`,e)}</b><br />
            ${S(`covers.info.override_body`,e)}
            <br /><br />
            <b>${S(`covers.info.priority_title`,e)}</b><br />
            ${S(`covers.info.priority_body`,e)}
            <br /><br />
            <b>${S(`covers.info.entities_title`,e)}</b><br />
            ${S(`covers.info.entities_body`,e)}
          </div>
          <rs-covers-section
            .hass=${this.hass}
            .area=${this.area}
            .editing=${!0}
            .selectedCovers=${this._selectedCovers}
            .autoEnabled=${this._coversAutoEnabled}
            .deployThreshold=${this._coversDeployThreshold}
            .minPosition=${this._coversMinPosition}
            .overrideMinutes=${this._coversOverrideMinutes}
            .coverSchedules=${this._coverSchedules}
            .coverScheduleSelectorEntity=${this._coverScheduleSelectorEntity}
            .activeCoverScheduleIndex=${this.config?.live?.active_cover_schedule_index??-1}
            .nightClose=${this._coversNightClose}
            .nightPosition=${this._coversNightPosition}
            .snapDeploy=${this._coversSnapDeploy}
            .forcedReason=${this.config?.live?.cover_forced_reason??``}
            .autoPaused=${this._optimisticCoverResume?!1:this.config?.live?.cover_auto_paused??!1}
            .overrideUntil=${this.config?.live?.cover_override_until??null}
            .coverOrientations=${this._coverOrientations}
            .nightCloseElevation=${this._coversNightCloseElevation}
            .nightCloseOffsetMinutes=${this._coversNightCloseOffsetMinutes}
            .outdoorMinTemp=${this._coversOutdoorMinTemp}
            .coverMinPositions=${this._coverMinPositions}
            @covers-toggle=${this._onCoversToggle}
            @setting-changed=${this._onCoverSettingChanged}
            @cover-resume-auto=${this._onCoverResumeAuto}
          ></rs-covers-section>
        </rs-edit-dialog>`;case`heatSource`:return m`<rs-edit-dialog
          open
          icon="mdi:swap-horizontal"
          .heading=${S(`room.section.heat_source`,e)}
          @rs-dialog-closed=${this._closeEdit}
        >
          <rs-heat-source-section
            .hass=${this.hass}
            .editing=${!0}
            .enabled=${this._heatSourceOrchestration}
            .primaryDelta=${this._heatSourcePrimaryDelta}
            .outdoorThreshold=${this._heatSourceOutdoorThreshold}
            .acMinOutdoor=${this._heatSourceAcMinOutdoor}
            @setting-changed=${this._onHeatSourceSettingChanged}
          ></rs-heat-source-section>
        </rs-edit-dialog>`}}_onModeChanged(e){this._climateMode=e.detail.mode,this._autoSave()}_onSchedulesChanged(e){this._schedules=e.detail.value,this._autoSave()}_onScheduleSelectorChanged(e){this._scheduleSelectorEntity=e.detail.value,this._autoSave()}_onComfortHeatChanged(e){this._comfortHeat=e.detail.value,this._comfortCool<this._comfortHeat&&(this._comfortCool=this._comfortHeat),this._autoSave()}_onComfortCoolChanged(e){this._comfortCool=e.detail.value,this._comfortHeat>this._comfortCool&&(this._comfortHeat=this._comfortCool),this._autoSave()}_onEcoHeatChanged(e){this._ecoHeat=e.detail.value,this._ecoCool<this._ecoHeat&&(this._ecoCool=this._ecoHeat),this._autoSave()}_onEcoCoolChanged(e){this._ecoCool=e.detail.value,this._ecoHeat>this._ecoCool&&(this._ecoHeat=this._ecoCool),this._autoSave()}_onDeviceChanged(e){let t=new Set(this._devices.map(e=>e.entity_id));this._devices=e.detail.devices;let n=new Set(this._devices.map(e=>e.entity_id));for(let e of t)if(!n.has(e)&&this._valveProtectionExclude.has(e)){let t=new Set(this._valveProtectionExclude);t.delete(e),this._valveProtectionExclude=t}for(let e of this._devices)if(e.type!==`trv`&&this._valveProtectionExclude.has(e.entity_id)){let t=new Set(this._valveProtectionExclude);t.delete(e.entity_id),this._valveProtectionExclude=t}this._autoSave()}_onSensorChanged(e){let{key:t,value:n}=e.detail;t===`temperature_sensor`?this._selectedTempSensor=n:t===`humidity_sensor`?this._selectedHumiditySensor=n:t===`occupancy_sensors`?this._selectedOccupancySensors=new Set(n):t===`occupancy_eco_enabled`?this._occupancyEcoEnabled=n:t===`occupancy_eco_delay`?this._occupancyEcoDelay=n:t===`window_sensors`?this._selectedWindowSensors=new Set(n):t===`window_open_delay`?this._windowOpenDelay=n:t===`window_close_delay`&&(this._windowCloseDelay=n),this._autoSave()}_onValveProtectionExcludeToggle(e){let{entityId:t,excluded:n}=e.detail,r=new Set(this._valveProtectionExclude);n?r.add(t):r.delete(t),this._valveProtectionExclude=r,this._autoSave()}_onPresencePersonsChanged(e){this._selectedPresencePersons=e.detail,this._autoSave()}_onIgnorePresenceChanged(e){this._ignorePresence=e.detail,this._autoSave()}_onCoversToggle(e){let{entityId:t,checked:n}=e.detail,r=new Set(this._selectedCovers);if(n)r.add(t);else{if(r.delete(t),t in this._coverOrientations){let e={...this._coverOrientations};delete e[t],this._coverOrientations=e}if(t in this._coverMinPositions){let e={...this._coverMinPositions};delete e[t],this._coverMinPositions=e}}this._selectedCovers=r,this._autoSave()}_onCoverSettingChanged(e){let{key:t,value:n}=e.detail;e.stopPropagation(),t===`covers_auto_enabled`?this._coversAutoEnabled=n:t===`covers_deploy_threshold`?this._coversDeployThreshold=n:t===`covers_min_position`?this._coversMinPosition=n:t===`covers_override_minutes`?this._coversOverrideMinutes=n:t===`cover_schedules`?this._coverSchedules=n:t===`cover_schedule_selector_entity`?this._coverScheduleSelectorEntity=n:t===`covers_night_close`?this._coversNightClose=n:t===`covers_night_position`?this._coversNightPosition=n:t===`covers_snap_deploy`?this._coversSnapDeploy=n:t===`cover_orientations`?this._coverOrientations=n:t===`covers_night_close_elevation`?this._coversNightCloseElevation=n:t===`covers_night_close_offset_minutes`?this._coversNightCloseOffsetMinutes=n:t===`covers_outdoor_min_temp`?this._coversOutdoorMinTemp=n:t===`cover_min_positions`&&(this._coverMinPositions=n),this._autoSave()}async _onCoverResumeAuto(){this._optimisticCoverResume=!0;try{await this.hass.callWS({type:`roommind/covers/clear_override`,area_id:this.area.area_id})}catch{this._optimisticCoverResume=!1}}_onHeatSourceSettingChanged(e){let{key:t,value:n}=e.detail;e.stopPropagation(),t===`heat_source_orchestration`?this._heatSourceOrchestration=n:t===`heat_source_primary_delta`?this._heatSourcePrimaryDelta=n:t===`heat_source_outdoor_threshold`?this._heatSourceOutdoorThreshold=n:t===`heat_source_ac_min_outdoor`&&(this._heatSourceAcMinOutdoor=n),this._autoSave()}_onClimateControlToggle(e){this._climateControlEnabled=e.detail,this._autoSave()}_quickTemps(){return this.shadowRoot?.querySelector(`rs-quick-temps`)??null}_activeScheduleEntity(){let e=this.config?.live?.active_schedule_index??-1;return this._schedules[e>=0?e:0]?.entity_id??``}_setNightTemp(e){let t=Math.round(e*10)/10;if(this._climateMode===`cool_only`){if(t===this._ecoCool)return!1;this._ecoCool=t}else{if(t===this._ecoHeat)return!1;this._ecoHeat=t,this._ecoCool<t&&(this._ecoCool=t)}return!0}async _flushPending(){this._flushSave(),this._saveInFlight&&await this._saveInFlight.catch(()=>void 0)}_onThermostatWritesScheduleToggle(e){this._thermostatWritesSchedule=e.detail,this._autoSave()}_onShowThermostatToggle(e){this._showThermostat=e.detail,this._autoSave()}_onOutdoorToggle(e){this._isOutdoor=e.detail,this._autoSave()}_onDisplayNameChanged(e){this._displayName=e.detail.value,this._autoSave()}_autoSave(){this._dirty=!0,this._editSeq++,this._saveDebounce&&clearTimeout(this._saveDebounce),this._saveDebounce=setTimeout(()=>{this._saveDebounce=void 0,this._doSave()},En)}_flushSave(e){this._saveDebounce&&(clearTimeout(this._saveDebounce),this._saveDebounce=void 0,this._doSave(e))}_buildSavePayload(e){return{type:`roommind/rooms/save`,area_id:e,devices:this._devices,temperature_sensor:this._selectedTempSensor,humidity_sensor:this._selectedHumiditySensor,occupancy_sensors:[...this._selectedOccupancySensors],occupancy_eco_enabled:this._occupancyEcoEnabled,occupancy_eco_delay:this._occupancyEcoDelay,window_sensors:[...this._selectedWindowSensors],window_open_delay:this._windowOpenDelay,window_close_delay:this._windowCloseDelay,climate_mode:this._climateMode,schedules:this._schedules,schedule_selector_entity:this._scheduleSelectorEntity,comfort_heat:this._comfortHeat,comfort_cool:this._comfortCool,eco_heat:this._ecoHeat,eco_cool:this._ecoCool,presence_persons:this._selectedPresencePersons.filter(e=>e),display_name:this._displayName,covers:[...this._selectedCovers],climate_control_enabled:this._climateControlEnabled,show_thermostat:this._showThermostat,thermostat_writes_schedule:this._thermostatWritesSchedule,away_heat:this._awayHeat,covers_auto_enabled:this._coversAutoEnabled,covers_deploy_threshold:this._coversDeployThreshold,covers_min_position:this._coversMinPosition,covers_override_minutes:this._coversOverrideMinutes,cover_schedules:this._coverSchedules,cover_schedule_selector_entity:this._coverScheduleSelectorEntity,covers_night_close:this._coversNightClose,covers_night_position:this._coversNightPosition,covers_snap_deploy:this._coversSnapDeploy,cover_orientations:this._coverOrientations,covers_night_close_elevation:this._coversNightCloseElevation,covers_night_close_offset_minutes:this._coversNightCloseOffsetMinutes,covers_outdoor_min_temp:this._coversOutdoorMinTemp,cover_min_positions:this._coverMinPositions,ignore_presence:this._ignorePresence,is_outdoor:this._isOutdoor,valve_protection_exclude:[...this._valveProtectionExclude],heat_source_orchestration:this._heatSourceOrchestration,heat_source_primary_delta:this._heatSourcePrimaryDelta,heat_source_outdoor_threshold:this._heatSourceOutdoorThreshold,heat_source_ac_min_outdoor:this._heatSourceAcMinOutdoor}}async _doSave(e=this.area.area_id){let t=this._buildSavePayload(e),n=this._editSeq,r=this._saveInFlight,i=(async()=>{r&&await r.catch(()=>void 0),await this._sendSave(t,n)})();this._saveInFlight=i;try{await i}finally{this._saveInFlight===i&&(this._saveInFlight=null)}}async _sendSave(e,t){I(this,`saving`),this._error=``;try{await this.hass.callWS(e),t===this._editSeq&&!this._saveDebounce&&(this._dirty=!1),this._saveRetries=0,I(this,`saved`),this.dispatchEvent(new CustomEvent(`room-updated`,{bubbles:!0,composed:!0}))}catch(n){let r=n instanceof Error?n.message:S(`room.error_save_fallback`,this.hass.language);this._error=r,I(this,`error`),this.isConnected&&e.area_id===this.area?.area_id&&t===this._editSeq&&!this._saveDebounce&&this._saveRetries<On&&(this._saveRetries++,this._saveDebounce=setTimeout(()=>{this._saveDebounce=void 0,this._doSave(e.area_id)},Dn*this._saveRetries))}}};A([y({attribute:!1})],q.prototype,`area`,void 0),A([y({attribute:!1})],q.prototype,`config`,void 0),A([y({attribute:!1})],q.prototype,`hass`,void 0),A([y({type:Boolean})],q.prototype,`presenceEnabled`,void 0),A([y({attribute:!1})],q.prototype,`presencePersons`,void 0),A([y({type:Boolean})],q.prototype,`climateControlActive`,void 0),A([y({type:Boolean})],q.prototype,`valveProtectionEnabled`,void 0),A([y({type:Boolean})],q.prototype,`coilDryEnabled`,void 0),A([y({type:Number})],q.prototype,`coilDryMinutes`,void 0),A([y({type:String})],q.prototype,`coilDryMode`,void 0),A([y({type:String})],q.prototype,`coilDryFanMode`,void 0),A([b()],q.prototype,`_devices`,void 0),A([b()],q.prototype,`_selectedTempSensor`,void 0),A([b()],q.prototype,`_selectedHumiditySensor`,void 0),A([b()],q.prototype,`_selectedOccupancySensors`,void 0),A([b()],q.prototype,`_occupancyEcoEnabled`,void 0),A([b()],q.prototype,`_occupancyEcoDelay`,void 0),A([b()],q.prototype,`_selectedWindowSensors`,void 0),A([b()],q.prototype,`_windowOpenDelay`,void 0),A([b()],q.prototype,`_windowCloseDelay`,void 0),A([b()],q.prototype,`_climateMode`,void 0),A([b()],q.prototype,`_schedules`,void 0),A([b()],q.prototype,`_scheduleSelectorEntity`,void 0),A([b()],q.prototype,`_comfortHeat`,void 0),A([b()],q.prototype,`_comfortCool`,void 0),A([b()],q.prototype,`_ecoHeat`,void 0),A([b()],q.prototype,`_ecoCool`,void 0),A([b()],q.prototype,`_error`,void 0),A([b()],q.prototype,`_dirty`,void 0),A([b()],q.prototype,`_editing`,void 0),A([b()],q.prototype,`_selectedPresencePersons`,void 0),A([b()],q.prototype,`_displayName`,void 0),A([b()],q.prototype,`_selectedCovers`,void 0),A([b()],q.prototype,`_coversAutoEnabled`,void 0),A([b()],q.prototype,`_coversDeployThreshold`,void 0),A([b()],q.prototype,`_coversMinPosition`,void 0),A([b()],q.prototype,`_coversOverrideMinutes`,void 0),A([b()],q.prototype,`_coverSchedules`,void 0),A([b()],q.prototype,`_coverScheduleSelectorEntity`,void 0),A([b()],q.prototype,`_coversNightClose`,void 0),A([b()],q.prototype,`_coversNightPosition`,void 0),A([b()],q.prototype,`_coversSnapDeploy`,void 0),A([b()],q.prototype,`_coverOrientations`,void 0),A([b()],q.prototype,`_coversNightCloseElevation`,void 0),A([b()],q.prototype,`_coversNightCloseOffsetMinutes`,void 0),A([b()],q.prototype,`_coversOutdoorMinTemp`,void 0),A([b()],q.prototype,`_coverMinPositions`,void 0),A([b()],q.prototype,`_ignorePresence`,void 0),A([b()],q.prototype,`_isOutdoor`,void 0),A([b()],q.prototype,`_valveProtectionExclude`,void 0),A([b()],q.prototype,`_climateControlEnabled`,void 0),A([b()],q.prototype,`_showThermostat`,void 0),A([b()],q.prototype,`_thermostatWritesSchedule`,void 0),A([b()],q.prototype,`_awayHeat`,void 0),A([b()],q.prototype,`_scheduleEditorEntity`,void 0),A([b()],q.prototype,`_heatSourceOrchestration`,void 0),A([b()],q.prototype,`_heatSourcePrimaryDelta`,void 0),A([b()],q.prototype,`_heatSourceOutdoorThreshold`,void 0),A([b()],q.prototype,`_heatSourceAcMinOutdoor`,void 0),A([b()],q.prototype,`_optimisticCoverResume`,void 0),q=A([v(`rs-room-detail`)],q);var kn=n({HaRadioPolyfill:()=>An}),An,jn=t((()=>{_(),x(),j(),An=class extends g{constructor(...e){super(...e),this.checked=!1,this.disabled=!1,this.name=``,this.value=``}static{this.shadowRootOptions={mode:`open`,delegatesFocus:!0}}static{this.styles=l`
    :host {
      display: inline-flex;
      align-items: center;
    }
    input {
      width: 18px;
      height: 18px;
      margin: 0;
      accent-color: var(--primary-color, #03a9f4);
      cursor: pointer;
    }
    input:disabled {
      cursor: default;
      opacity: 0.5;
    }
  `}render(){return m`
      <input
        type="radio"
        .checked=${this.checked}
        .value=${this.value}
        name=${this.name||void 0}
        ?disabled=${this.disabled}
        @change=${this._onChange}
      />
    `}_onChange(e){this.checked=e.target.checked,this.dispatchEvent(new Event(`change`,{bubbles:!0,composed:!0}))}},A([y({type:Boolean,reflect:!0})],An.prototype,`checked`,void 0),A([y({type:Boolean,reflect:!0})],An.prototype,`disabled`,void 0),A([y({type:String})],An.prototype,`name`,void 0),A([y({type:String})],An.prototype,`value`,void 0)})),Mn=n({HaTextfieldPolyfill:()=>J}),J,Nn=t((()=>{_(),x(),j(),J=class extends g{constructor(...e){super(...e),this.value=``,this.type=`text`,this.label=``,this.placeholder=``,this.suffix=``,this.prefix=``,this.helper=``,this.disabled=!1,this.required=!1,this.readOnly=!1,this.min=``,this.max=``,this.step=null,this.name=``}static{this.shadowRootOptions={mode:`open`,delegatesFocus:!0}}static{this.styles=l`
    :host {
      display: inline-flex;
      flex-direction: column;
      outline: none;
      width: 100%;
    }
    ha-input {
      --ha-input-padding-bottom: 0;
      width: 100%;
    }
    .prefix,
    .suffix {
      color: var(--secondary-text-color);
    }
  `}render(){return m`
      <ha-input
        .type=${this.type}
        .value=${this.value||``}
        .label=${this.label}
        .placeholder=${this.placeholder}
        .disabled=${this.disabled}
        .required=${this.required}
        .readonly=${this.readOnly}
        .min=${this.min===``?void 0:this.min}
        .max=${this.max===``?void 0:this.max}
        .step=${this.step??void 0}
        .name=${this.name||void 0}
        .hint=${this.helper}
        .withoutSpinButtons=${this.type===`number`}
        @input=${this._sync}
        @change=${this._sync}
      >
        ${this.prefix?m`<span class="prefix" slot="start">${this.prefix}</span>`:h}
        ${this.suffix?m`<span class="suffix" slot="end">${this.suffix}</span>`:h}
      </ha-input>
    `}_sync(){this.value=this._haInput?.value??``}},A([y({type:String})],J.prototype,`value`,void 0),A([y({type:String})],J.prototype,`type`,void 0),A([y({type:String})],J.prototype,`label`,void 0),A([y({type:String})],J.prototype,`placeholder`,void 0),A([y({type:String})],J.prototype,`suffix`,void 0),A([y({type:String})],J.prototype,`prefix`,void 0),A([y({type:String})],J.prototype,`helper`,void 0),A([y({type:Boolean})],J.prototype,`disabled`,void 0),A([y({type:Boolean})],J.prototype,`required`,void 0),A([y({type:Boolean,reflect:!0,attribute:`readonly`})],J.prototype,`readOnly`,void 0),A([y()],J.prototype,`min`,void 0),A([y()],J.prototype,`max`,void 0),A([y()],J.prototype,`step`,void 0),A([y({type:String})],J.prototype,`name`,void 0),A([ft(`ha-input`)],J.prototype,`_haInput`,void 0)})),Pn=async()=>{if(!customElements.get(`ha-radio`))try{let{HaRadioPolyfill:e}=await Promise.resolve().then(()=>(jn(),kn));customElements.get(`ha-radio`)||customElements.define(`ha-radio`,e)}catch(e){console.warn(`RoomMind: ha-radio polyfill failed to load`,e)}if(!customElements.get(`ha-textfield`))try{let{HaTextfieldPolyfill:e}=await Promise.resolve().then(()=>(Nn(),Mn));customElements.get(`ha-textfield`)||customElements.define(`ha-textfield`,e)}catch(e){console.warn(`RoomMind: ha-textfield polyfill failed to load`,e)}if(!customElements.get(`ha-entity-picker`)){if(!customElements.get(`ha-selector`)){await customElements.whenDefined(`partial-panel-resolver`);let e=document.createElement(`partial-panel-resolver`);e.hass={panels:[{url_path:`tmp`,component_name:`config`}]},e._updateRoutes(),await e.routerOptions.routes.tmp.load(),await customElements.whenDefined(`ha-panel-config`),await document.createElement(`ha-panel-config`).routerOptions.routes.automation.load()}if(!customElements.get(`ha-entity-picker`))try{await(await(await window.loadCardHelpers()).createCardElement({type:`entities`,entities:[]})).constructor.getConfigElement()}catch{}if(!customElements.get(`ha-entity-picker`))try{await Promise.race([customElements.whenDefined(`ha-selector`),new Promise((e,t)=>setTimeout(()=>t(Error(`timeout`)),1e4))]);let e=document.querySelector(`home-assistant`)?.hass,t=document.createElement(`div`);t.style.cssText=`position:fixed;left:-9999px;opacity:0;pointer-events:none`,document.body.appendChild(t);try{let n=document.createElement(`ha-selector`);n.hass=e,n.selector={entity:{}},t.appendChild(n),await Promise.race([customElements.whenDefined(`ha-entity-picker`),new Promise(e=>setTimeout(e,5e3))])}finally{t.remove()}}catch{}if(await customElements.whenDefined(`ha-card`),!customElements.get(`ha-date-range-picker`))try{await(await window.loadCardHelpers()).createCardElement({type:`energy-date-selection`,entities:[]}),await Promise.race([customElements.whenDefined(`ha-date-range-picker`),new Promise((e,t)=>setTimeout(t,5e3))])}catch{}if(!customElements.get(`ha-chart-base`))try{await(await window.loadCardHelpers()).createCardElement({type:`statistics-graph`,entities:[]}),await Promise.race([customElements.whenDefined(`ha-chart-base`),new Promise((e,t)=>setTimeout(t,5e3))])}catch{}}};_(),x(),j();var Fn=class extends g{constructor(...e){super(...e),this.icon=``,this.heading=``,this.intro=``,this.badge=``,this.badgeHint=``}render(){return m`
      <ha-expansion-panel outlined>
        <div slot="header" class="panel-header">
          <ha-icon .icon=${this.icon}></ha-icon>
          <span>${this.heading}</span>
          ${this.badge?m`<rs-badge .label=${this.badge} .hint=${this.badgeHint}></rs-badge>`:h}
        </div>
        <div class="panel-content">
          ${this.intro?m`<p class="section-intro">${this.intro}</p>`:h}
          <slot></slot>
        </div>
      </ha-expansion-panel>
    `}static{this.styles=l`
    :host {
      display: block;
    }

    .panel-header {
      display: flex;
      align-items: center;
      gap: 10px;
      --mdc-icon-size: 20px;
      color: var(--secondary-text-color);
    }

    .panel-header span {
      color: var(--primary-text-color);
      font-weight: 500;
    }

    .panel-content {
      padding: 16px 16px 16px;
    }

    .section-intro {
      color: var(--secondary-text-color);
      font-size: 13px;
      line-height: 1.5;
      margin: 0 0 16px;
      padding: 2px 0 2px 12px;
      border-left: 3px solid var(--divider-color);
    }
  `}};A([y({type:String})],Fn.prototype,`icon`,void 0),A([y({type:String})],Fn.prototype,`heading`,void 0),A([y({type:String})],Fn.prototype,`intro`,void 0),A([y({type:String})],Fn.prototype,`badge`,void 0),A([y({type:String})],Fn.prototype,`badgeHint`,void 0),Fn=A([v(`rs-settings-panel`)],Fn),_();var Y=class extends g{_fire(e,t){this.dispatchEvent(new CustomEvent(`setting-changed`,{detail:{key:e,value:t},bubbles:!0,composed:!0}))}static{this.settingsBaseStyles=l`
    :host {
      display: block;
    }

    /* Round HA's MDC-based inputs to match the rest of the design */
    ha-textfield,
    ha-select,
    ha-entity-picker,
    ha-combo-box {
      --mdc-shape-small: 8px;
      --mdc-shape-medium: 8px;
      --md-filled-text-field-container-shape: 8px;
      --md-outlined-text-field-container-shape: 8px;
      display: block;
      border-radius: 8px;
      overflow: hidden;
      isolation: isolate;
      clip-path: inset(0 round 8px);
    }

    ha-entity-picker {
      clip-path: inset(0 round 8px 8px 4px 4px);
    }

    .settings-section {
      padding: 16px 0;
      border-top: 1px solid var(--divider-color);
    }
    .settings-section:first-child,
    .settings-section.first {
      border-top: none;
      padding-top: 0;
    }

    .toggle-row {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 16px;
    }
    .toggle-text {
      display: flex;
      flex-direction: column;
      gap: 4px;
      flex: 1;
    }
    .toggle-label {
      font-size: 14px;
      font-weight: 500;
      color: var(--primary-text-color);
    }
    .toggle-hint {
      font-size: 13px;
      color: var(--secondary-text-color);
      line-height: 1.4;
    }

    .threshold-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
    }
    .threshold-field {
      display: flex;
      flex-direction: column;
      gap: 4px;
    }
    .threshold-field ha-textfield {
      width: 100%;
    }
    .field-hint {
      color: var(--secondary-text-color);
      font-size: 12px;
    }

    @media (max-width: 600px) {
      .threshold-grid {
        grid-template-columns: 1fr;
      }
    }
  `}};_(),x(),j();var In=class extends Y{constructor(...e){super(...e),this.groupByFloor=!1,this.climateControlActive=!0}render(){let e=this.hass.language;return m`
      ${this.hass.floors&&Object.keys(this.hass.floors).length>0?m`<div class="settings-section first">
              <div class="toggle-row">
                <div class="toggle-text">
                  <span class="toggle-label">${S(`settings.group_by_floor`,e)}</span>
                </div>
                <ha-switch
                  .checked=${this.groupByFloor}
                  @change=${e=>this._fire(`groupByFloor`,e.target.checked)}
                ></ha-switch>
              </div>
            </div>`:h}

      <div
        class="settings-section ${this.hass.floors&&Object.keys(this.hass.floors).length>0?``:`first`}"
      >
        <div class="toggle-row">
          <div class="toggle-text">
            <span class="toggle-label">${S(`settings.climate_control_active`,e)}</span>
            <span class="toggle-hint">${S(`settings.climate_control_hint`,e)}</span>
          </div>
          <ha-switch
            .checked=${this.climateControlActive}
            @change=${e=>this._fire(`climateControlActive`,e.target.checked)}
          ></ha-switch>
        </div>
      </div>
    `}static{this.styles=[Y.settingsBaseStyles]}};A([y({attribute:!1})],In.prototype,`hass`,void 0),A([y({type:Boolean})],In.prototype,`groupByFloor`,void 0),A([y({type:Boolean})],In.prototype,`climateControlActive`,void 0),In=A([v(`rs-settings-general`)],In),_(),x(),j();var Ln=class extends Y{constructor(...e){super(...e),this.outdoorTempSensor=``,this.outdoorHumiditySensor=``,this.weatherEntity=``,this.outdoorUnavailableNotify=!0,this._filterTemperature=e=>e.attributes?.device_class===`temperature`,this._filterHumidity=e=>e.attributes?.device_class===`humidity`}_getSensorValue(e){let t=this.hass.states[e];if(!t||t.state===`unavailable`||t.state===`unknown`)return null;let n=parseFloat(t.state);return isNaN(n)?null:Math.round(n*10)/10}render(){let e=this.hass.language,t=this.outdoorTempSensor?this._getSensorValue(this.outdoorTempSensor):null,n=this.outdoorHumiditySensor?this._getSensorValue(this.outdoorHumiditySensor):null;return m`
      <div class="settings-section first">
        <div class="sensor-grid">
          <div class="sensor-field">
            <ha-entity-picker
              .hass=${this.hass}
              .value=${this.outdoorTempSensor}
              .includeDomains=${[`sensor`]}
              .entityFilter=${this._filterTemperature}
              .label=${S(`settings.outdoor_sensor_label`,e)}
              allow-custom-entity
              @value-changed=${e=>{let t=e.detail?.value??``;t!==this.outdoorTempSensor&&this._fire(`outdoorTempSensor`,t)}}
            ></ha-entity-picker>
            ${t===null?this.outdoorTempSensor?m`<div class="current-value muted">
                      ${S(`settings.outdoor_waiting`,e)}
                    </div>`:h:m`<div class="current-value">
                    ${S(`settings.outdoor_current`,e,{temp:t.toFixed(1),unit:C(this.hass)})}
                  </div>`}
          </div>
          <div class="sensor-field">
            <ha-entity-picker
              .hass=${this.hass}
              .value=${this.outdoorHumiditySensor}
              .includeDomains=${[`sensor`]}
              .entityFilter=${this._filterHumidity}
              .label=${S(`settings.outdoor_humidity_label`,e)}
              allow-custom-entity
              @value-changed=${e=>{let t=e.detail?.value??``;t!==this.outdoorHumiditySensor&&this._fire(`outdoorHumiditySensor`,t)}}
            ></ha-entity-picker>
            ${n===null?this.outdoorHumiditySensor?m`<div class="current-value muted">
                      ${S(`settings.outdoor_waiting`,e)}
                    </div>`:h:m`<div class="current-value">
                    ${S(`settings.outdoor_humidity_current`,e,{value:String(n)})}
                  </div>`}
          </div>
        </div>
      </div>

      <div class="settings-section">
        <ha-entity-picker
          .hass=${this.hass}
          .value=${this.weatherEntity}
          .includeDomains=${[`weather`]}
          .label=${S(`settings.weather_entity`,e)}
          allow-custom-entity
          @value-changed=${e=>{let t=e.detail?.value??``;t!==this.weatherEntity&&this._fire(`weatherEntity`,t)}}
        ></ha-entity-picker>
        <span class="field-hint">${S(`settings.weather_entity_hint`,e)}</span>
      </div>

      <div class="settings-section">
        <rs-toggle-row
          .label=${S(`settings.outdoor_unavailable_notify`,e)}
          .hint=${S(`settings.outdoor_unavailable_notify_hint`,e)}
          .checked=${this.outdoorUnavailableNotify}
          @toggle-changed=${e=>this._fire(`outdoorUnavailableNotify`,e.detail)}
        ></rs-toggle-row>
      </div>
    `}static{this.styles=[Y.settingsBaseStyles,l`
      .sensor-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 16px;
      }
      .current-value {
        margin-top: 8px;
        font-size: 14px;
        color: var(--primary-text-color);
      }
      .current-value.muted {
        color: var(--secondary-text-color);
      }

      @media (max-width: 600px) {
        .sensor-grid {
          grid-template-columns: 1fr;
        }
      }
    `]}};A([y({attribute:!1})],Ln.prototype,`hass`,void 0),A([y({type:String})],Ln.prototype,`outdoorTempSensor`,void 0),A([y({type:String})],Ln.prototype,`outdoorHumiditySensor`,void 0),A([y({type:String})],Ln.prototype,`weatherEntity`,void 0),A([y({type:Boolean})],Ln.prototype,`outdoorUnavailableNotify`,void 0),Ln=A([v(`rs-settings-sensors`)],Ln),_(),x(),j();var Rn=`https://github.com/snazzybean/roommind/blob/main/docs/control-and-devices.md`,zn=class extends Y{constructor(...e){super(...e),this.controlMode=`mpc`,this.comfortWeight=70,this.outdoorCoolingMin=16,this.outdoorHeatingMax=22,this.predictionEnabled=!0,this.scheduleOffAction=`eco`}render(){let e=this.hass.language;return m`
      <div class="settings-section first">
        <p class="hint">${S(`settings.control_mode_hint`,e)}</p>
        <div class="radio-group">
          <label class="radio-option" @click=${()=>this._setControlMode(`mpc`)}>
            <ha-radio name="control_mode" .checked=${this.controlMode===`mpc`}></ha-radio>
            <span>${S(`settings.control_mode_mpc`,e)}</span>
          </label>
          <label class="radio-option" @click=${()=>this._setControlMode(`bangbang`)}>
            <ha-radio name="control_mode" .checked=${this.controlMode===`bangbang`}></ha-radio>
            <span>${S(`settings.control_mode_simple`,e)}</span>
          </label>
        </div>
      </div>

      <div class="settings-section">
        <label class="section-label">${S(`settings.comfort_weight`,e)}</label>
        <div class="slider-row">
          <span class="slider-label">${S(`settings.comfort_weight_efficiency`,e)}</span>
          <input
            type="range"
            min="0"
            max="100"
            step="5"
            .value=${String(this.comfortWeight)}
            @change=${e=>{let t=parseInt(e.target.value,10);!isNaN(t)&&t!==this.comfortWeight&&this._fire(`comfortWeight`,t)}}
          />
          <span class="slider-label">${S(`settings.comfort_weight_comfort`,e)}</span>
        </div>
        <p class="hint helper-text">${S(`settings.comfort_weight_hint`,e)}</p>
        <a class="helper-link" href=${Rn} target="_blank" rel="noreferrer">
          ${S(`common.learn_more`,e)}
        </a>
      </div>

      <div class="settings-section">
        <p class="hint">${S(`settings.smart_control_hint`,e)}</p>
        <div class="threshold-grid">
          <div class="threshold-field">
            <ha-textfield
              .value=${String(w(this.outdoorCoolingMin,this.hass))}
              .label=${S(`settings.outdoor_cooling_min`,e)}
              .suffix=${C(this.hass)}
              type="number"
              step=${O(this.hass)}
              min=${k(-10,40,this.hass).min}
              max=${k(-10,40,this.hass).max}
              @change=${e=>{let t=parseFloat(e.target.value);isNaN(t)||this._fire(`outdoorCoolingMin`,T(t,this.hass))}}
            ></ha-textfield>
            <span class="field-hint">${S(`settings.outdoor_cooling_min_hint`,e)}</span>
          </div>
          <div class="threshold-field">
            <ha-textfield
              .value=${String(w(this.outdoorHeatingMax,this.hass))}
              .label=${S(`settings.outdoor_heating_max`,e)}
              .suffix=${C(this.hass)}
              type="number"
              step=${O(this.hass)}
              min=${k(0,40,this.hass).min}
              max=${k(0,40,this.hass).max}
              @change=${e=>{let t=parseFloat(e.target.value);isNaN(t)||this._fire(`outdoorHeatingMax`,T(t,this.hass))}}
            ></ha-textfield>
            <span class="field-hint">${S(`settings.outdoor_heating_max_hint`,e)}</span>
          </div>
        </div>
      </div>

      <div class="settings-section">
        <div class="toggle-row">
          <div class="toggle-text">
            <span class="toggle-label">${S(`settings.prediction_enabled`,e)}</span>
            <span class="toggle-hint">${S(`settings.prediction_enabled_hint`,e)}</span>
          </div>
          <ha-switch
            .checked=${this.predictionEnabled}
            @change=${e=>this._fire(`predictionEnabled`,e.target.checked)}
          ></ha-switch>
        </div>
      </div>

      <div class="settings-section">
        <ha-select
          .label=${S(`schedule.off_action_label`,e)}
          .value=${this.scheduleOffAction}
          .options=${[{value:`eco`,label:S(`schedule.off_action_eco`,e)},{value:`off`,label:S(`schedule.off_action_off`,e)}]}
          fixedMenuPosition
          @selected=${e=>{let t=F(e);t&&t!==this.scheduleOffAction&&this._fire(`scheduleOffAction`,t)}}
          @closed=${e=>e.stopPropagation()}
        >
          <ha-list-item value="eco">${S(`schedule.off_action_eco`,e)}</ha-list-item>
          <ha-list-item value="off">${S(`schedule.off_action_off`,e)}</ha-list-item>
        </ha-select>
      </div>
    `}_setControlMode(e){this.controlMode!==e&&this._fire(`controlMode`,e)}static{this.styles=[Y.settingsBaseStyles,l`
      .hint {
        color: var(--secondary-text-color);
        font-size: 13px;
        margin: 0 0 12px;
      }
      .helper-text {
        margin: 10px 0 0;
      }
      .section-label {
        display: block;
        margin-bottom: 8px;
        font-size: 14px;
        color: var(--primary-text-color);
      }

      .radio-group {
        display: flex;
        flex-direction: column;
        gap: 8px;
      }
      .radio-option {
        display: flex;
        align-items: center;
        gap: 8px;
        cursor: pointer;
      }

      .slider-row {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .slider-row input[type="range"] {
        flex: 1;
        accent-color: var(--primary-color);
      }
      .slider-label {
        font-size: 12px;
        color: var(--secondary-text-color);
        white-space: nowrap;
      }
      .helper-link {
        display: inline-block;
        margin-top: 6px;
        font-size: 12px;
        color: var(--primary-color);
        text-decoration: none;
      }
      .helper-link:hover {
        text-decoration: underline;
      }
    `]}};A([y({attribute:!1})],zn.prototype,`hass`,void 0),A([y({type:String})],zn.prototype,`controlMode`,void 0),A([y({type:Number})],zn.prototype,`comfortWeight`,void 0),A([y({type:Number})],zn.prototype,`outdoorCoolingMin`,void 0),A([y({type:Number})],zn.prototype,`outdoorHeatingMax`,void 0),A([y({type:Boolean})],zn.prototype,`predictionEnabled`,void 0),A([y({type:String})],zn.prototype,`scheduleOffAction`,void 0),zn=A([v(`rs-settings-control`)],zn),_(),x(),j();var Bn=class extends Y{constructor(...e){super(...e),this.presenceEnabled=!1,this.presencePersons=[],this.presenceAwayAction=`eco`,this.presenceClearsOverride=!1,this.presencePreheat=!1,this.presencePreheatMinutes=60,this._arrivals={}}connectedCallback(){super.connectedCallback(),this._loadArrivals()}async _loadArrivals(){try{let e=await this.hass.callWS({type:`roommind/presence/arrivals`});this._arrivals=e.arrivals??{}}catch{this._arrivals={}}}_renderPreheat(){let e=this.hass.language,t=[0,1,2,3,4,5,6];return m`
      <div class="toggle-row">
        <div class="toggle-text">
          <span class="toggle-label">${S(`presence.preheat_label`,e)}</span>
          <span class="toggle-hint">${S(`presence.preheat_hint`,e)}</span>
        </div>
        <ha-switch
          .checked=${this.presencePreheat}
          @change=${e=>this._fire(`presencePreheat`,e.target.checked)}
        ></ha-switch>
      </div>
      ${this.presencePreheat?m`
              <ha-textfield
                type="number"
                .value=${String(this.presencePreheatMinutes)}
                .label=${S(`presence.preheat_minutes`,e)}
                .suffix=${`min`}
                min="10"
                max="240"
                step="5"
                @change=${e=>{let t=parseInt(e.target.value,10);t>=10&&t<=240&&this._fire(`presencePreheatMinutes`,t)}}
              ></ha-textfield>
              <span class="field-hint">${S(`presence.preheat_minutes_hint`,e)}</span>
              <span class="toggle-label">${S(`presence.learned_title`,e)}</span>
              <div class="arrivals">
                <div class="arrival-row head">
                  <span></span>
                  ${t.map(t=>m`<span
                        >${S(`schedule_editor.day_short.${[`monday`,`tuesday`,`wednesday`,`thursday`,`friday`,`saturday`,`sunday`][t]}`,e)}</span
                      >`)}
                </div>
                ${this.presencePersons.map(n=>{let r=this._arrivals[n],i=this.hass.states[n]?.attributes?.friendly_name??n.split(`.`).slice(1).join(`.`);return m`<div class="arrival-row">
                    <span class="person-name"
                      >${i}
                      <small
                        >${S(`presence.learned_count`,e,{count:r?.arrivals??0})}${r?.next?m` ·
                              ${S(`presence.learned_next`,e,{time:new Date(r.next*1e3).toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`})})}`:h}</small
                      ></span
                    >
                    ${t.map(e=>m`<span>${r?.typical?.[e]??`–`}</span>`)}
                  </div>`})}
              </div>
              <span class="field-hint">${S(`presence.learned_hint`,e)}</span>
            `:h}
    `}render(){let e=this.hass.language;return m`
      <div class="toggle-row">
        <div class="toggle-text">
          <span class="toggle-label">${S(`presence.title`,e)}</span>
          <span class="toggle-hint">${S(`presence.hint`,e)}</span>
        </div>
        <ha-switch
          .checked=${this.presenceEnabled}
          @change=${e=>this._fire(`presenceEnabled`,e.target.checked)}
        ></ha-switch>
      </div>

      ${this.presenceEnabled?m`
              <div class="detail-section">
                <span class="field-hint">${S(`presence.hint_detail`,e)}</span>
                ${this.presencePersons.length>0?m`
                        <div class="person-list">
                          ${this.presencePersons.map(e=>{let t=this.hass.states[e]?.attributes?.friendly_name??e.split(`.`).slice(1).join(`.`);return m`
                              <div class="person-row">
                                <ha-icon
                                  icon="mdi:account"
                                  style="--mdc-icon-size: 18px; color: var(--secondary-text-color)"
                                ></ha-icon>
                                <span class="person-name">${t}</span>
                                <ha-icon-button
                                  .path=${`M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z`}
                                  @click=${()=>this._fire(`presencePersons`,this.presencePersons.filter(t=>t!==e))}
                                ></ha-icon-button>
                              </div>
                            `})}
                        </div>
                      `:h}
                <ha-entity-picker
                  .hass=${this.hass}
                  .includeDomains=${[`person`,`device_tracker`,`binary_sensor`,`input_boolean`]}
                  .entityFilter=${e=>!this.presencePersons.includes(e.entity_id)}
                  .label=${S(`presence.add_entity`,e)}
                  @value-changed=${e=>{let t=e.detail?.value;t&&!this.presencePersons.includes(t)&&this._fire(`presencePersons`,[...this.presencePersons,t]);let n=e.target;n.value=``}}
                ></ha-entity-picker>
                <ha-select
                  .label=${S(`presence.away_action_label`,e)}
                  .value=${this.presenceAwayAction}
                  .options=${[{value:`eco`,label:S(`presence.away_action_eco`,e)},{value:`off`,label:S(`presence.away_action_off`,e)}]}
                  fixedMenuPosition
                  @selected=${e=>{let t=F(e);t&&t!==this.presenceAwayAction&&this._fire(`presenceAwayAction`,t)}}
                  @closed=${e=>e.stopPropagation()}
                  style="margin-top: 8px"
                >
                  <ha-list-item value="eco"
                    >${S(`presence.away_action_eco`,e)}</ha-list-item
                  >
                  <ha-list-item value="off"
                    >${S(`presence.away_action_off`,e)}</ha-list-item
                  >
                </ha-select>
                <div class="toggle-row">
                  <div class="toggle-text">
                    <span class="toggle-label"
                      >${S(`presence.clears_override_label`,e)}</span
                    >
                    <span class="toggle-hint">${S(`presence.clears_override_hint`,e)}</span>
                  </div>
                  <ha-switch
                    .checked=${this.presenceClearsOverride}
                    @change=${e=>this._fire(`presenceClearsOverride`,e.target.checked)}
                  ></ha-switch>
                </div>
                ${this._renderPreheat()}
              </div>
            `:h}
    `}static{this.styles=[Y.settingsBaseStyles,l`
      .detail-section {
        display: flex;
        flex-direction: column;
        gap: 8px;
        margin-top: 12px;
      }

      .person-list {
        display: flex;
        flex-direction: column;
        gap: 2px;
      }
      .person-row {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 4px 8px 4px 12px;
        border-radius: 8px;
        background: rgba(0, 0, 0, 0.04);
      }
      .person-name {
        flex: 1;
        font-size: 14px;
        font-weight: 500;
      }
      .person-name small {
        display: block;
        font-weight: 400;
        font-size: 11px;
        color: var(--secondary-text-color);
      }
      .arrivals {
        display: flex;
        flex-direction: column;
        gap: 4px;
        overflow-x: auto;
      }
      .arrival-row {
        display: grid;
        grid-template-columns: minmax(120px, 1.5fr) repeat(7, minmax(44px, 1fr));
        gap: 6px;
        align-items: center;
        font-size: 13px;
        text-align: center;
      }
      .arrival-row .person-name {
        text-align: left;
      }
      .arrival-row.head {
        font-size: 11px;
        color: var(--secondary-text-color);
      }
    `]}};A([y({attribute:!1})],Bn.prototype,`hass`,void 0),A([y({type:Boolean})],Bn.prototype,`presenceEnabled`,void 0),A([y({type:Array})],Bn.prototype,`presencePersons`,void 0),A([y({type:String})],Bn.prototype,`presenceAwayAction`,void 0),A([y({type:Boolean})],Bn.prototype,`presenceClearsOverride`,void 0),A([y({type:Boolean})],Bn.prototype,`presencePreheat`,void 0),A([y({type:Number})],Bn.prototype,`presencePreheatMinutes`,void 0),A([b()],Bn.prototype,`_arrivals`,void 0),Bn=A([v(`rs-settings-presence`)],Bn),_(),x(),j();var Vn=class extends Y{constructor(...e){super(...e),this.vacationActive=!1,this.vacationTemp=15,this.vacationUntil=``}render(){let e=this.hass.language;return m`
      <div class="toggle-row">
        <div class="toggle-text">
          <span class="toggle-label">${S(`vacation.title`,e)}</span>
          <span class="toggle-hint">${S(`vacation.hint`,e)}</span>
        </div>
        <ha-switch
          .checked=${this.vacationActive}
          @change=${e=>{let t=e.target.checked;this._fire(`vacationActive`,t),t||this._fire(`vacationUntil`,``)}}
        ></ha-switch>
      </div>

      ${this.vacationActive?m`
              <div class="threshold-grid" style="margin-top: 12px; align-items: end">
                <div class="threshold-field">
                  <label class="field-label" for="vacation-until"
                    >${S(`vacation.end_date`,e)}</label
                  >
                  <ha-textfield
                    id="vacation-until"
                    .value=${this.vacationUntil}
                    aria-label=${S(`vacation.end_date`,e)}
                    type="datetime-local"
                    @change=${e=>this._fire(`vacationUntil`,e.target.value)}
                  ></ha-textfield>
                </div>
                <div class="threshold-field">
                  <ha-textfield
                    .value=${String(w(this.vacationTemp,this.hass))}
                    .label=${S(`vacation.setback_temp`,e)}
                    .suffix=${C(this.hass)}
                    type="number"
                    step=${O(this.hass)}
                    min=${k(5,25,this.hass).min}
                    max=${k(5,25,this.hass).max}
                    @change=${e=>{let t=parseFloat(e.target.value);isNaN(t)||this._fire(`vacationTemp`,T(t,this.hass))}}
                  ></ha-textfield>
                </div>
              </div>
            `:h}
    `}static{this.styles=[Y.settingsBaseStyles,l`
      .field-label {
        color: var(--secondary-text-color);
        font-size: 12px;
      }
    `]}};A([y({attribute:!1})],Vn.prototype,`hass`,void 0),A([y({type:Boolean})],Vn.prototype,`vacationActive`,void 0),A([y({type:Number})],Vn.prototype,`vacationTemp`,void 0),A([y({type:String})],Vn.prototype,`vacationUntil`,void 0),Vn=A([v(`rs-settings-vacation`)],Vn),_(),x(),j();var Hn=class extends Y{constructor(...e){super(...e),this.valveProtectionEnabled=!1,this.valveProtectionInterval=7}render(){let e=this.hass.language;return m`
      <div class="toggle-row">
        <div class="toggle-text">
          <span class="toggle-label">${S(`valve_protection.title`,e)}</span>
          <span class="toggle-hint">${S(`valve_protection.hint`,e)}</span>
        </div>
        <ha-switch
          .checked=${this.valveProtectionEnabled}
          @change=${e=>this._fire(`valveProtectionEnabled`,e.target.checked)}
        ></ha-switch>
      </div>

      ${this.valveProtectionEnabled?m`
              <div class="threshold-grid" style="margin-top: 12px">
                <div class="threshold-field">
                  <ha-textfield
                    .value=${String(this.valveProtectionInterval)}
                    .label=${S(`valve_protection.interval_label`,e)}
                    .suffix=${S(`valve_protection.interval_suffix`,e)}
                    type="number"
                    step="1"
                    min="1"
                    max="90"
                    @change=${e=>{let t=parseInt(e.target.value,10);!isNaN(t)&&t>=1&&t<=90&&this._fire(`valveProtectionInterval`,t)}}
                  ></ha-textfield>
                  <span class="field-hint">${S(`valve_protection.interval_hint`,e)}</span>
                </div>
              </div>
            `:h}
    `}static{this.styles=[Y.settingsBaseStyles]}};A([y({attribute:!1})],Hn.prototype,`hass`,void 0),A([y({type:Boolean})],Hn.prototype,`valveProtectionEnabled`,void 0),A([y({type:Number})],Hn.prototype,`valveProtectionInterval`,void 0),Hn=A([v(`rs-settings-valve`)],Hn),_(),x(),j();var Un=class extends g{constructor(...e){super(...e),this.label=``,this.confirmMessage=``,this.disabled=!1,this.destructive=!1}static{this.styles=l`
    :host {
      display: block;
    }

    .confirm-btn {
      background: transparent;
      border: 1px solid var(--divider-color);
      border-radius: 8px;
      padding: 8px 16px;
      font-size: 14px;
      font-family: inherit;
      cursor: pointer;
      color: var(--primary-text-color);
      transition: all 0.2s;
    }

    .confirm-btn.destructive {
      border-color: var(--error-color);
      color: var(--error-color);
    }

    .confirm-btn.destructive:hover:not([disabled]) {
      background: var(--error-color);
      color: #fff;
    }

    .confirm-btn[disabled] {
      opacity: 0.5;
      cursor: not-allowed;
    }
  `}render(){return m`
      <button
        class="confirm-btn ${this.destructive?`destructive`:``}"
        ?disabled=${this.disabled}
        @click=${this._onClick}
      >
        ${this.label}
      </button>
    `}_onClick(){this.disabled||(!this.confirmMessage||confirm(this.confirmMessage))&&this.dispatchEvent(new CustomEvent(`confirmed`,{bubbles:!0,composed:!0}))}};A([y({type:String})],Un.prototype,`label`,void 0),A([y({type:String})],Un.prototype,`confirmMessage`,void 0),A([y({type:Boolean})],Un.prototype,`disabled`,void 0),A([y({type:Boolean})],Un.prototype,`destructive`,void 0),Un=A([v(`rs-confirm-button`)],Un),_(),x(),j();var Wn=class extends g{constructor(...e){super(...e),this.compressorGroups=[],this.releaseStatus={},this._goHeating=e=>{e.preventDefault(),history.replaceState(null,``,`/roommind/heating`),window.dispatchEvent(new Event(`location-changed`))},this._memberFilter=e=>{let t=e.entity_id;if(t.substring(t.indexOf(`.`)+1).startsWith(`roommind_`))return!1;for(let e of this.compressorGroups)if(e.members.includes(t)||e.master_entity===t)return!1;return!0},this._masterFilter=e=>{let t=e.entity_id;if(t.substring(t.indexOf(`.`)+1).startsWith(`roommind_`))return!1;for(let e of this.compressorGroups)if(e.members.includes(t)||e.master_entity===t)return!1;return!0}}static{this.styles=[L,l`
      :host {
        display: block;
      }
      .group-card {
        border: 1px solid var(--divider-color);
        border-radius: 8px;
        padding: 16px;
        margin-bottom: 16px;
      }
      .member-list {
        display: flex;
        flex-direction: column;
        gap: 4px;
        margin: 8px 0;
      }
      .member-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 4px 8px;
        background: var(--card-background-color);
        border-radius: 4px;
      }
      .member-name {
        font-size: 14px;
        flex: 1;
      }
      .member-area {
        font-size: 12px;
        color: var(--secondary-text-color);
        margin-left: 4px;
      }
      .member-missing {
        color: var(--error-color);
      }
      .field-row {
        margin-top: 12px;
      }
      .field-hint {
        font-size: 12px;
        color: var(--secondary-text-color);
        margin-top: 4px;
      }
      .section-label {
        font-size: 14px;
        font-weight: 500;
        margin-top: 12px;
        margin-bottom: 4px;
      }
      .add-button {
        margin-top: 12px;
      }
      .delete-row {
        margin-top: 16px;
        display: flex;
        justify-content: flex-end;
      }
      .release-status {
        display: flex;
        align-items: center;
        gap: 6px;
        margin-top: 8px;
        padding: 8px 12px;
        border-radius: 8px;
        font-size: 13px;
        background: rgba(127, 127, 127, 0.08);
        color: var(--secondary-text-color);
      }
      .release-status.on {
        background: rgba(255, 129, 0, 0.12);
        color: var(--state-climate-heat-color, #ff8100);
      }
      .heating-link {
        margin-left: auto;
        color: var(--primary-color);
        text-decoration: none;
        white-space: nowrap;
      }
      .release-status ha-icon {
        --mdc-icon-size: 18px;
      }
      .no-groups {
        color: var(--secondary-text-color);
        font-size: 14px;
        padding: 8px 0;
      }
      ha-textfield {
        width: 100%;
      }
      ha-entity-picker {
        width: 100%;
      }
      .number-fields {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 12px;
        margin-top: 12px;
      }
      @media (max-width: 500px) {
        .number-fields {
          grid-template-columns: 1fr;
        }
      }
    `]}render(){let e=this.hass.language;return m`
      ${this.compressorGroups.length===0?m`<div class="no-groups">${S(`compressor.no_groups`,e)}</div>`:this.compressorGroups.map((e,t)=>this._renderGroup(e,t))}
      <ha-button class="add-button" @click=${this._addGroup}>
        <ha-icon icon="mdi:plus" slot="icon"></ha-icon>
        ${S(`compressor.add_group`,e)}
      </ha-button>
    `}_renderGroup(e,t){let n=this.hass.language;return m`
      <div class="group-card">
        <ha-textfield
          .value=${e.name}
          .label=${S(`compressor.group_name`,n)}
          @change=${e=>{let n=e.target.value;this._updateGroup(t,`name`,n)}}
        ></ha-textfield>

        <div class="section-label">${S(`compressor.members`,n)}</div>
        ${e.members.length>0?m`
                <div class="member-list">
                  ${e.members.map(e=>this._renderMember(e,t))}
                </div>
              `:h}
        <ha-entity-picker
          .hass=${this.hass}
          .value=${``}
          .includeDomains=${[`climate`]}
          .entityFilter=${this._memberFilter}
          @value-changed=${e=>{let n=e.detail?.value??``;if(!n)return;let r=[...this.compressorGroups];r[t]={...r[t],members:[...r[t].members,n]},this._fire(r);let i=e.target;i&&(i.value=``)}}
        ></ha-entity-picker>
        <div class="field-hint">${S(`compressor.members_hint`,n)}</div>

        <div class="number-fields">
          <div>
            <ha-textfield
              type="number"
              .value=${String(e.min_run_minutes)}
              .label=${S(`compressor.min_run`,n)}
              .suffix=${S(`compressor.min_run_suffix`,n)}
              min="1"
              max="120"
              step="1"
              @change=${e=>{let n=parseInt(e.target.value,10);!isNaN(n)&&n>=1&&n<=120&&this._updateGroup(t,`min_run_minutes`,n)}}
            ></ha-textfield>
            <div class="field-hint">${S(`compressor.min_run_hint`,n)}</div>
          </div>
          <div>
            <ha-textfield
              type="number"
              .value=${String(e.min_off_minutes)}
              .label=${S(`compressor.min_off`,n)}
              .suffix=${S(`compressor.min_off_suffix`,n)}
              min="1"
              max="60"
              step="1"
              @change=${e=>{let n=parseInt(e.target.value,10);!isNaN(n)&&n>=1&&n<=60&&this._updateGroup(t,`min_off_minutes`,n)}}
            ></ha-textfield>
            <div class="field-hint">${S(`compressor.min_off_hint`,n)}</div>
          </div>
        </div>

        <div class="section-label">${S(`compressor.master_entity`,n)}</div>
        <ha-entity-picker
          .hass=${this.hass}
          .value=${e.master_entity||``}
          .includeDomains=${[`climate`]}
          .entityFilter=${this._masterFilter}
          @value-changed=${e=>{this._updateGroup(t,`master_entity`,e.detail?.value??``)}}
        ></ha-entity-picker>
        <div class="field-hint">${S(`compressor.master_entity_hint`,n)}</div>

        <div class="field-row">
          <ha-formfield .label=${S(`compressor.enforce_uniform_mode`,n)}>
            <ha-switch
              .checked=${e.enforce_uniform_mode||!1}
              @change=${e=>{this._updateGroup(t,`enforce_uniform_mode`,e.target.checked)}}
            ></ha-switch>
          </ha-formfield>
          <div class="field-hint">${S(`compressor.enforce_uniform_mode_hint`,n)}</div>
        </div>

        ${e.master_entity||e.enforce_uniform_mode?m`
                <div class="field-row">
                  <ha-select
                    .label=${S(`compressor.conflict_resolution`,n)}
                    .value=${e.conflict_resolution||`heating_priority`}
                    .options=${[{value:`heating_priority`,label:S(`compressor.conflict_heating_priority`,n)},{value:`cooling_priority`,label:S(`compressor.conflict_cooling_priority`,n)},{value:`majority`,label:S(`compressor.conflict_majority`,n)},{value:`outdoor_temp`,label:S(`compressor.conflict_outdoor_temp`,n)}]}
                    @selected=${e=>{let n=F(e);n&&this._updateGroup(t,`conflict_resolution`,n)}}
                    @closed=${e=>e.stopPropagation()}
                    fixedMenuPosition
                    style="width: 100%;"
                  >
                  </ha-select>
                  <div class="field-hint">
                    ${S(`compressor.conflict_resolution_hint`,n)}
                  </div>
                </div>
              `:h}
        ${this._renderRelease(e)}

        <div class="field-row">
          <ha-entity-picker
            .hass=${this.hass}
            .value=${e.action_script||``}
            .includeDomains=${[`script`]}
            .label=${S(`compressor.action_script`,n)}
            @value-changed=${e=>{this._updateGroup(t,`action_script`,e.detail?.value??``)}}
          ></ha-entity-picker>
          <div class="field-hint">${S(`compressor.action_script_hint`,n)}</div>
        </div>

        <div class="delete-row">
          <rs-confirm-button
            .label=${S(`compressor.delete`,n)}
            .confirmMessage=${S(`compressor.delete_confirm`,n).replace(`{name}`,e.name||`#${t+1}`)}
            destructive
            @confirmed=${()=>{this._fire(this.compressorGroups.filter((e,n)=>n!==t))}}
          ></rs-confirm-button>
        </div>
      </div>
    `}_renderRelease(e){let t=this.hass.language,n=this.releaseStatus[e.id];return m`
      <div class="section-label">${S(`compressor.release_title`,t)}</div>
      <div class="release-status ${n?.on?`on`:``}">
        <ha-icon
          icon=${e.release_entity?`mdi:water-boiler`:`mdi:water-boiler-off`}
        ></ha-icon>
        ${e.release_entity?m`${S(n?.on?`compressor.release_on`:`compressor.release_off`,t)} ·
              ${e.release_entity}`:S(`compressor.release_moved`,t)}
        <a class="heating-link" href="/roommind/heating" @click=${this._goHeating}
          >${S(`compressor.release_open_tab`,t)}</a
        >
      </div>
    `}_renderMember(e,t){let n=this.hass.states[e],r=!n,i=n?.attributes?.friendly_name||e,a=this.hass.entities[e]?.area_id,o=a?this.hass.areas[a]?.name:void 0;return m`
      <div class="member-row">
        <span class="member-name ${r?`member-missing`:``}"
          >${i}${o?m`<span class="member-area">(${o})</span>`:h}</span
        >
        <ha-icon-button
          .path=${`M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z`}
          @click=${()=>{let n=[...this.compressorGroups];n[t]={...n[t],members:n[t].members.filter(t=>t!==e)},this._fire(n)}}
        ></ha-icon-button>
      </div>
    `}_updateGroup(e,t,n){let r=[...this.compressorGroups];r[e]={...r[e],[t]:n},this._fire(r)}_addGroup(){this._fire([...this.compressorGroups,{id:self.crypto?.randomUUID?.()??`${Date.now()}-${Math.random().toString(36).slice(2)}`,name:``,members:[],min_run_minutes:15,min_off_minutes:5,master_entity:``,conflict_resolution:`heating_priority`,action_script:``,enforce_uniform_mode:!1}])}_fire(e){this.dispatchEvent(new CustomEvent(`setting-changed`,{detail:{key:`compressorGroups`,value:e},bubbles:!0,composed:!0}))}};A([y({attribute:!1})],Wn.prototype,`hass`,void 0),A([y({type:Array})],Wn.prototype,`compressorGroups`,void 0),A([y({attribute:!1})],Wn.prototype,`releaseStatus`,void 0),Wn=A([v(`rs-settings-compressor`)],Wn),_(),x(),j();var Gn=`__keep__`,Kn=class extends Y{constructor(...e){super(...e),this.coilDryEnabled=!1,this.coilDryMinutes=20,this.coilDryMode=`fan_only`,this.coilDryFanMode=`low`,this.coilDryMinCoolingMinutes=10,this.coilDryDrainMinutes=0,this.availableFanModes=[]}_numberField(e,t,n,r,i,a,o){let s=this.hass.language;return m`
      <div class="threshold-field">
        <ha-textfield
          .value=${String(t)}
          .label=${S(n,s)}
          .suffix=${S(r,s)}
          type="number"
          step="1"
          min="${a}"
          max="${o}"
          @change=${t=>{let n=parseInt(t.target.value,10);!isNaN(n)&&n>=a&&n<=o&&this._fire(e,n)}}
        ></ha-textfield>
        <span class="field-hint">${S(i,s)}</span>
      </div>
    `}render(){let e=this.hass.language,t=this.availableFanModes.length?this.availableFanModes:[`low`,`medium`,`high`];return m`
      <div class="toggle-row">
        <div class="toggle-text">
          <span class="toggle-label">${S(`coil_dry.title`,e)}</span>
          <span class="toggle-hint">${S(`coil_dry.hint`,e)}</span>
        </div>
        <ha-switch
          .checked=${this.coilDryEnabled}
          @change=${e=>this._fire(`coilDryEnabled`,e.target.checked)}
        ></ha-switch>
      </div>

      ${this.coilDryEnabled?m`
              <div class="threshold-grid" style="margin-top: 12px">
                ${this._numberField(`coilDryMinutes`,this.coilDryMinutes,`coil_dry.duration_label`,`coil_dry.duration_suffix`,`coil_dry.duration_hint`,1,60)}
                ${this._numberField(`coilDryMinCoolingMinutes`,this.coilDryMinCoolingMinutes,`coil_dry.min_cooling_label`,`coil_dry.min_cooling_suffix`,`coil_dry.min_cooling_hint`,1,240)}
                ${this._numberField(`coilDryDrainMinutes`,this.coilDryDrainMinutes,`coil_dry.drain_label`,`coil_dry.drain_suffix`,`coil_dry.drain_hint`,0,15)}
              </div>

              <div class="threshold-grid" style="margin-top: 12px">
                <div class="threshold-field">
                  <ha-select
                    .label=${S(`coil_dry.fan_mode_label`,e)}
                    .value=${this.coilDryFanMode===``?Gn:this.coilDryFanMode}
                    .options=${[{value:Gn,label:S(`coil_dry.fan_mode_keep`,e)},...t.map(e=>({value:e,label:e}))]}
                    @selected=${e=>{let t=F(e),n=this.coilDryFanMode===``?Gn:this.coilDryFanMode;t&&t!==n&&this._fire(`coilDryFanMode`,t===Gn?``:t)}}
                    @closed=${e=>e.stopPropagation()}
                    fixedMenuPosition
                  >
                    <ha-list-item value="${Gn}"
                      >${S(`coil_dry.fan_mode_keep`,e)}</ha-list-item
                    >
                    ${t.map(e=>m`<ha-list-item value="${e}">${e}</ha-list-item>`)}
                  </ha-select>
                  <span class="field-hint">${S(`coil_dry.fan_mode_hint`,e)}</span>
                </div>

                <div class="threshold-field">
                  <ha-select
                    .label=${S(`coil_dry.mode_label`,e)}
                    .value=${this.coilDryMode}
                    .options=${[{value:`fan_only`,label:S(`coil_dry.mode_fan_only`,e)},{value:`dry`,label:S(`coil_dry.mode_dry`,e)}]}
                    @selected=${e=>{let t=F(e);t&&t!==this.coilDryMode&&this._fire(`coilDryMode`,t)}}
                    @closed=${e=>e.stopPropagation()}
                    fixedMenuPosition
                  >
                    <ha-list-item value="fan_only"
                      >${S(`coil_dry.mode_fan_only`,e)}</ha-list-item
                    >
                    <ha-list-item value="dry">${S(`coil_dry.mode_dry`,e)}</ha-list-item>
                  </ha-select>
                  ${this.coilDryMode===`dry`?m`<span class="field-hint warning"
                          >${S(`coil_dry.mode_dry_warning`,e)}</span
                        >`:h}
                </div>
              </div>
            `:h}
    `}static{this.styles=[Y.settingsBaseStyles,l`
      .field-hint.warning {
        color: var(--warning-color);
      }
    `]}};A([y({attribute:!1})],Kn.prototype,`hass`,void 0),A([y({type:Boolean})],Kn.prototype,`coilDryEnabled`,void 0),A([y({type:Number})],Kn.prototype,`coilDryMinutes`,void 0),A([y({type:String})],Kn.prototype,`coilDryMode`,void 0),A([y({type:String})],Kn.prototype,`coilDryFanMode`,void 0),A([y({type:Number})],Kn.prototype,`coilDryMinCoolingMinutes`,void 0),A([y({type:Number})],Kn.prototype,`coilDryDrainMinutes`,void 0),A([y({attribute:!1})],Kn.prototype,`availableFanModes`,void 0),Kn=A([v(`rs-settings-coil-dry`)],Kn),_(),x(),j();var qn=[{f_rsi:.65,key:`mold.insulation_poor`},{f_rsi:.8,key:`mold.insulation_standard`},{f_rsi:.9,key:`mold.insulation_good`}],Jn=class extends Y{constructor(...e){super(...e),this.moldDetectionEnabled=!1,this.moldHumidityThreshold=70,this.moldFRsi=.8,this.moldSustainedMinutes=30,this.moldPreventionEnabled=!1,this.moldPreventionIntensity=`medium`}render(){let e=this.hass.language;return m`
      <!-- Detection section -->
      <div class="settings-section first">
        <div class="toggle-row">
          <div class="toggle-text">
            <span class="toggle-label">
              <ha-icon
                icon="mdi:bell-alert"
                style="--mdc-icon-size: 18px; vertical-align: middle; margin-right: 4px"
              ></ha-icon>
              ${S(`mold.detection`,e)}
            </span>
            <span class="toggle-hint">${S(`mold.detection_desc`,e)}</span>
          </div>
          <ha-switch
            .checked=${this.moldDetectionEnabled}
            @change=${e=>this._fire(`moldDetectionEnabled`,e.target.checked)}
          ></ha-switch>
        </div>
        ${this.moldDetectionEnabled?m`
                <div class="threshold-grid" style="margin-top: 12px">
                  <div class="threshold-field">
                    <ha-textfield
                      .value=${String(this.moldHumidityThreshold)}
                      .label=${S(`mold.threshold`,e)}
                      .suffix=${`%`}
                      type="number"
                      step="1"
                      min="50"
                      max="90"
                      @change=${e=>{let t=parseFloat(e.target.value);!isNaN(t)&&t>=50&&t<=90&&this._fire(`moldHumidityThreshold`,t)}}
                    ></ha-textfield>
                    <span class="field-hint">${S(`mold.threshold_hint`,e)}</span>
                  </div>
                  <div class="threshold-field">
                    <ha-textfield
                      .value=${String(this.moldSustainedMinutes)}
                      .label=${S(`mold.sustained`,e)}
                      .suffix=${`min`}
                      type="number"
                      step="5"
                      min="5"
                      max="120"
                      @change=${e=>{let t=parseInt(e.target.value,10);!isNaN(t)&&t>=5&&t<=120&&this._fire(`moldSustainedMinutes`,t)}}
                    ></ha-textfield>
                    <span class="field-hint">${S(`mold.sustained_hint`,e)}</span>
                  </div>
                </div>
              `:h}
      </div>

      <!-- Prevention section -->
      <div class="settings-section">
        <div class="toggle-row">
          <div class="toggle-text">
            <span class="toggle-label">
              <ha-icon
                icon="mdi:shield-check"
                style="--mdc-icon-size: 18px; vertical-align: middle; margin-right: 4px"
              ></ha-icon>
              ${S(`mold.prevention`,e)}
            </span>
            <span class="toggle-hint">${S(`mold.prevention_desc`,e)}</span>
          </div>
          <ha-switch
            .checked=${this.moldPreventionEnabled}
            @change=${e=>this._fire(`moldPreventionEnabled`,e.target.checked)}
          ></ha-switch>
        </div>
        ${this.moldPreventionEnabled?m`
                <div style="margin-top: 12px; display: flex; flex-direction: column; gap: 4px;">
                  <ha-select
                    style="width: 100%;"
                    .value=${this.moldPreventionIntensity}
                    .label=${S(`mold.intensity`,e)}
                    .options=${[{value:`light`,label:S(`mold.intensity_light`,e,{delta:String(E(1,this.hass)),unit:C(this.hass)})},{value:`medium`,label:S(`mold.intensity_medium`,e,{delta:String(E(2,this.hass)),unit:C(this.hass)})},{value:`strong`,label:S(`mold.intensity_strong`,e,{delta:String(E(3,this.hass)),unit:C(this.hass)})}]}
                    fixedMenuPosition
                    @selected=${e=>{let t=F(e);t&&t!==this.moldPreventionIntensity&&this._fire(`moldPreventionIntensity`,t)}}
                    @closed=${e=>e.stopPropagation()}
                  >
                    <ha-list-item value="light"
                      >${S(`mold.intensity_light`,e,{delta:String(E(1,this.hass)),unit:C(this.hass)})}</ha-list-item
                    >
                    <ha-list-item value="medium"
                      >${S(`mold.intensity_medium`,e,{delta:String(E(2,this.hass)),unit:C(this.hass)})}</ha-list-item
                    >
                    <ha-list-item value="strong"
                      >${S(`mold.intensity_strong`,e,{delta:String(E(3,this.hass)),unit:C(this.hass)})}</ha-list-item
                    >
                  </ha-select>
                  <span class="field-hint">${S(`mold.intensity_hint`,e)}</span>
                </div>
              `:h}
      </div>

      ${this.moldDetectionEnabled||this.moldPreventionEnabled?m`
              <div class="settings-section">
                <div style="display: flex; flex-direction: column; gap: 4px;">
                  <ha-select
                    style="width: 100%;"
                    .value=${this._insulationValue()}
                    .label=${S(`mold.insulation`,e)}
                    .options=${qn.map(t=>({value:String(t.f_rsi),label:S(t.key,e)}))}
                    fixedMenuPosition
                    @selected=${e=>{let t=parseFloat(F(e));!isNaN(t)&&t!==this.moldFRsi&&this._fire(`moldFRsi`,t)}}
                    @closed=${e=>e.stopPropagation()}
                  >
                    ${qn.map(t=>m`<ha-list-item value=${String(t.f_rsi)}
                          >${S(t.key,e)}</ha-list-item
                        >`)}
                  </ha-select>
                  <span class="field-hint">${S(`mold.insulation_hint`,e)}</span>
                </div>
              </div>
            `:h}
    `}_insulationValue(){let e=qn.reduce((e,t)=>Math.abs(t.f_rsi-this.moldFRsi)<Math.abs(e.f_rsi-this.moldFRsi)?t:e);return String(e.f_rsi)}static{this.styles=[Y.settingsBaseStyles]}};A([y({attribute:!1})],Jn.prototype,`hass`,void 0),A([y({type:Boolean})],Jn.prototype,`moldDetectionEnabled`,void 0),A([y({type:Number})],Jn.prototype,`moldHumidityThreshold`,void 0),A([y({type:Number})],Jn.prototype,`moldFRsi`,void 0),A([y({type:Number})],Jn.prototype,`moldSustainedMinutes`,void 0),A([y({type:Boolean})],Jn.prototype,`moldPreventionEnabled`,void 0),A([y({type:String})],Jn.prototype,`moldPreventionIntensity`,void 0),Jn=A([v(`rs-settings-mold`)],Jn),_(),x(),j();var Yn=class extends Y{constructor(...e){super(...e),this.notificationsEnabled=!0,this.notificationTargets=[],this.notificationCooldown=60,this.moldPreventionEnabled=!1,this.moldPreventionNotify=!1}render(){let e=this.hass.language;return m`
      <div class="toggle-row">
        <div class="toggle-text">
          <span class="toggle-label">${S(`notifications.enabled`,e)}</span>
          <span class="toggle-hint">${S(`notifications.enabled_hint`,e)}</span>
        </div>
        <ha-switch
          .checked=${this.notificationsEnabled}
          @change=${e=>this._fire(`moldNotificationsEnabled`,e.target.checked)}
        ></ha-switch>
      </div>

      ${this.notificationsEnabled?m`
              <div class="detail-section">
                <p class="hint">${S(`notifications.desc`,e)}</p>

                <div class="target-list">
                  ${this.notificationTargets.map((t,n)=>{let r=t.entity_id?this.hass.states[t.entity_id]?.attributes?.friendly_name??t.entity_id.replace(`notify.`,``):S(`notifications.target_unnamed`,e);return m`
                      <div class="target-card">
                        <div class="target-header">
                          <ha-icon
                            icon="mdi:bell"
                            style="--mdc-icon-size: 18px; color: var(--secondary-text-color)"
                          ></ha-icon>
                          <span>${r}</span>
                          <ha-icon-button
                            .path=${`M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z`}
                            @click=${()=>{this._fire(`moldNotificationTargets`,this.notificationTargets.filter((e,t)=>t!==n))}}
                          ></ha-icon-button>
                        </div>
                        <div class="target-detail">
                          <ha-entity-picker
                            .hass=${this.hass}
                            .value=${t.person_entity}
                            .includeDomains=${[`person`]}
                            .label=${S(`notifications.target_person`,e)}
                            allow-custom-entity
                            @value-changed=${e=>{let t=[...this.notificationTargets];t[n]={...t[n],person_entity:e.detail?.value??``},this._fire(`moldNotificationTargets`,t)}}
                          ></ha-entity-picker>
                          <ha-select
                            .value=${t.notify_when}
                            .options=${[{value:`always`,label:S(`notifications.target_when_always`,e)},{value:`home_only`,label:S(`notifications.target_when_home`,e)}]}
                            fixedMenuPosition
                            @selected=${e=>{let t=F(e);if(!t)return;let r=[...this.notificationTargets];r[n]={...r[n],notify_when:t},this._fire(`moldNotificationTargets`,r)}}
                            @closed=${e=>e.stopPropagation()}
                          >
                            <ha-list-item value="always"
                              >${S(`notifications.target_when_always`,e)}</ha-list-item
                            >
                            <ha-list-item value="home_only"
                              >${S(`notifications.target_when_home`,e)}</ha-list-item
                            >
                          </ha-select>
                        </div>
                      </div>
                    `})}
                </div>

                <div style="margin-top: 8px">
                  <ha-entity-picker
                    .hass=${this.hass}
                    .value=${``}
                    .includeDomains=${[`notify`]}
                    .label=${S(`notifications.add_target_label`,e)}
                    allow-custom-entity
                    @value-changed=${e=>{let t=e.detail?.value??``;if(!t)return;this._fire(`moldNotificationTargets`,[...this.notificationTargets,{entity_id:t,person_entity:``,notify_when:`always`}]);let n=e.target;n&&(n.value=``)}}
                  ></ha-entity-picker>
                  <span class="field-hint">${S(`notifications.add_target_hint`,e)}</span>
                </div>

                <div class="threshold-grid" style="margin-top: 12px">
                  <div class="threshold-field">
                    <ha-textfield
                      .value=${String(this.notificationCooldown)}
                      .label=${S(`notifications.cooldown`,e)}
                      .suffix=${`min`}
                      type="number"
                      step="5"
                      min="10"
                      max="1440"
                      @change=${e=>{let t=parseInt(e.target.value,10);!isNaN(t)&&t>=10&&t<=1440&&this._fire(`moldNotificationCooldown`,t)}}
                    ></ha-textfield>
                    <span class="field-hint">${S(`notifications.cooldown_hint`,e)}</span>
                  </div>
                </div>

                ${this.moldPreventionEnabled?m`
                        <div class="toggle-row" style="margin-top: 12px">
                          <div class="toggle-text">
                            <span class="toggle-label"
                              >${S(`notifications.mold_prevention_notify`,e)}</span
                            >
                            <span class="toggle-hint"
                              >${S(`notifications.mold_prevention_notify_hint`,e)}</span
                            >
                          </div>
                          <ha-switch
                            .checked=${this.moldPreventionNotify}
                            @change=${e=>this._fire(`moldPreventionNotify`,e.target.checked)}
                          ></ha-switch>
                        </div>
                      `:h}
              </div>
            `:h}
    `}static{this.styles=[Y.settingsBaseStyles,l`
      .hint {
        color: var(--secondary-text-color);
        font-size: 13px;
        margin: 12px 0;
        line-height: 1.4;
      }
      .detail-section {
        margin-top: 4px;
      }
      .field-hint {
        color: var(--secondary-text-color);
        font-size: 12px;
      }

      .target-list {
        display: flex;
        flex-direction: column;
        gap: 2px;
      }
      .target-card {
        display: flex;
        flex-direction: column;
        gap: 4px;
        padding: 8px 8px 8px 12px;
        border-radius: 8px;
        background: rgba(0, 0, 0, 0.04);
      }
      .target-header {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .target-header span {
        flex: 1;
        font-size: 14px;
        font-weight: 500;
      }
      .target-detail {
        display: flex;
        gap: 8px;
        align-items: center;
        padding-left: 26px;
      }
      .target-detail ha-entity-picker {
        flex: 1;
      }
      .target-detail ha-select {
        min-width: 120px;
      }

      @media (max-width: 600px) {
        .target-detail {
          flex-direction: column;
          padding-left: 0;
        }
      }
    `]}};A([y({attribute:!1})],Yn.prototype,`hass`,void 0),A([y({type:Boolean})],Yn.prototype,`notificationsEnabled`,void 0),A([y({type:Array})],Yn.prototype,`notificationTargets`,void 0),A([y({type:Number})],Yn.prototype,`notificationCooldown`,void 0),A([y({type:Boolean})],Yn.prototype,`moldPreventionEnabled`,void 0),A([y({type:Boolean})],Yn.prototype,`moldPreventionNotify`,void 0),Yn=A([v(`rs-settings-notifications`)],Yn),_(),x(),j();var Xn=250,Zn=class extends Y{constructor(...e){super(...e),this.rooms={},this.learningDisabledRooms=[],this.boostAppliedAt={},this.roomsLive={},this._showLearningExceptions=!1,this._boostSelectedRoom=``}render(){let e=this.hass.language,t=Object.entries(this.rooms).map(([e])=>({areaId:e,name:this.hass.areas?.[e]?.name??e})).sort((e,t)=>e.name.localeCompare(t.name)),n=Object.keys(this.rooms),r=n.length===0||this.learningDisabledRooms.length<n.length,i=this.learningDisabledRooms.filter(e=>n.includes(e)).length;return m`
      <!-- Learning toggle -->
      <div class="settings-section first">
        <div class="toggle-row">
          <div class="toggle-text">
            <span class="toggle-label">${S(`settings.learning_title`,e)}</span>
            <span class="toggle-hint">${S(`settings.learning_hint`,e)}</span>
          </div>
          <ha-switch
            .checked=${r}
            @change=${e=>{let t=e.target.checked;this._fire(`learningDisabledRooms`,t?[]:Object.keys(this.rooms)),t||(this._showLearningExceptions=!1)}}
          ></ha-switch>
        </div>
        ${r&&t.length>0?m`
                <button
                  class="exceptions-link"
                  @click=${()=>{this._showLearningExceptions=!this._showLearningExceptions}}
                >
                  <span
                    >${i>0?`${i} ${S(i===1?`settings.learning_room_paused`:`settings.learning_rooms_paused`,e)}`:S(`settings.learning_exceptions`,e)}</span
                  >
                  <ha-icon
                    icon=${this._showLearningExceptions?`mdi:chevron-up`:`mdi:chevron-down`}
                    style="--mdc-icon-size: 16px"
                  ></ha-icon>
                </button>
                ${this._showLearningExceptions?m`
                        <div class="room-toggles">
                          ${t.map(e=>m`
                              <div class="room-toggle-row">
                                <span class="room-toggle-name">${e.name}</span>
                                <ha-switch
                                  .checked=${!this.learningDisabledRooms.includes(e.areaId)}
                                  @change=${t=>{let n=!t.target.checked,r=new Set(this.learningDisabledRooms);n?r.add(e.areaId):r.delete(e.areaId),this._fire(`learningDisabledRooms`,[...r])}}
                                ></ha-switch>
                              </div>
                            `)}
                        </div>
                      `:h}
              `:h}
      </div>

      <!-- Boost learning -->
      <div class="settings-section">
        <span class="toggle-label">${S(`settings.boost_title`,e)}</span>
        <p class="hint">${S(`settings.boost_hint`,e)}</p>

        ${t.length>0?m`
                <div class="room-select-row">
                  <ha-select
                    .value=${this._boostSelectedRoom}
                    .label=${S(`settings.boost_room_select`,e)}
                    .options=${t.map(e=>({value:e.areaId,label:e.name}))}
                    fixedMenuPosition
                    @selected=${e=>{this._boostSelectedRoom=F(e)}}
                    @closed=${e=>e.stopPropagation()}
                  >
                    ${t.map(e=>m`<ha-list-item value=${e.areaId}>${e.name}</ha-list-item>`)}
                  </ha-select>
                  ${this._boostSelectedRoom?m`<ha-icon-button
                          .path=${`M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z`}
                          @click=${()=>{this._boostSelectedRoom=``}}
                        ></ha-icon-button>`:h}
                  ${this._boostSelectedRoom&&this._isCooldown(this._boostSelectedRoom)?m`<span class="boost-status">
                          <ha-icon icon="mdi:check-circle-outline"></ha-icon>
                          ${S(`settings.boost_cooldown`,e)}
                        </span>`:m`<button
                          class="boost-btn"
                          ?disabled=${!this._boostSelectedRoom||this._isCooldown(this._boostSelectedRoom)}
                          @click=${()=>this._boostSelectedRoom&&this._boostLearning(this._boostSelectedRoom)}
                        >
                          <ha-icon icon="mdi:lightning-bolt"></ha-icon>
                          ${S(`settings.boost_btn`,e)}
                        </button>`}
                </div>
              `:m`<p class="hint">${S(`settings.boost_no_rooms`,e)}</p>`}
      </div>
    `}_isCooldown(e){let t=this.roomsLive?.[e]?.n_observations??0,n=this.boostAppliedAt[e];return n!==void 0&&t-n<Xn}async _boostLearning(e){try{I(this,`saving`);let t=await this.hass.callWS({type:`roommind/model/boost_learning`,area_id:e});I(this,`saved`),this.dispatchEvent(new CustomEvent(`boost-applied`,{detail:{area_id:e,n_observations:t.n_observations},bubbles:!0,composed:!0}))}catch{I(this,`error`)}}static{this.styles=[Y.settingsBaseStyles,l`
      .hint {
        color: var(--secondary-text-color);
        font-size: 13px;
        margin: 4px 0 12px;
        line-height: 1.4;
      }

      .exceptions-link {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        background: none;
        border: none;
        padding: 8px 0 0;
        margin: 0;
        cursor: pointer;
        font-size: 13px;
        color: var(--primary-color);
        font-family: inherit;
      }
      .exceptions-link:hover {
        text-decoration: underline;
      }

      .room-toggles {
        display: flex;
        flex-direction: column;
        gap: 4px;
        margin-top: 12px;
      }
      .room-toggle-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 4px 0;
      }
      .room-toggle-name {
        font-size: 14px;
        color: var(--primary-text-color);
      }

      .room-select-row {
        display: flex;
        align-items: center;
        gap: 12px;
      }
      .room-select-row ha-select {
        flex: 1;
      }

      .boost-btn {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 8px 14px;
        border: 1px solid var(--primary-color);
        border-radius: 8px;
        background: transparent;
        color: var(--primary-color);
        font-size: 13px;
        font-family: inherit;
        cursor: pointer;
        transition: background 0.15s;
        --mdc-icon-size: 16px;
        white-space: nowrap;
      }
      .boost-btn:hover {
        background: rgba(var(--rgb-primary-color), 0.08);
      }
      .boost-btn:disabled {
        opacity: 0.4;
        cursor: not-allowed;
      }
      .boost-btn:disabled:hover {
        background: transparent;
      }

      .boost-status {
        display: flex;
        align-items: center;
        gap: 6px;
        color: var(--success-color, #4caf50);
        font-size: 13px;
        --mdc-icon-size: 16px;
        white-space: nowrap;
      }
    `]}};A([y({attribute:!1})],Zn.prototype,`hass`,void 0),A([y({attribute:!1})],Zn.prototype,`rooms`,void 0),A([y({type:Array})],Zn.prototype,`learningDisabledRooms`,void 0),A([y({attribute:!1})],Zn.prototype,`boostAppliedAt`,void 0),A([y({attribute:!1})],Zn.prototype,`roomsLive`,void 0),A([b()],Zn.prototype,`_showLearningExceptions`,void 0),A([b()],Zn.prototype,`_boostSelectedRoom`,void 0),Zn=A([v(`rs-settings-learning`)],Zn),_(),x(),j();var Qn=class extends Y{constructor(...e){super(...e),this.rooms={},this._resetSelectedRoom=``}render(){let e=this.hass.language,t=Object.entries(this.rooms).map(([e])=>({areaId:e,name:this.hass.areas?.[e]?.name??e})).sort((e,t)=>e.name.localeCompare(t.name));return m`
      <div class="settings-section first">
        <div class="reset-row">
          <div class="reset-text">
            <span class="toggle-label">${S(`settings.reset_all_label`,e)}</span>
            <span class="toggle-hint">${S(`settings.reset_all_hint`,e)}</span>
          </div>
          <button class="reset-btn" @click=${this._resetAllModels}>
            <ha-icon icon="mdi:restart-alert"></ha-icon>
            ${S(`settings.reset_all_btn`,e)}
          </button>
        </div>
      </div>

      <div class="settings-section">
        <div class="reset-text" style="margin-bottom: 12px">
          <span class="toggle-label">${S(`settings.reset_room_label`,e)}</span>
          <span class="toggle-hint">${S(`settings.reset_room_hint`,e)}</span>
        </div>
        ${t.length>0?m`
                <div class="reset-room-row">
                  <ha-select
                    .value=${this._resetSelectedRoom}
                    .label=${S(`settings.reset_room_select`,e)}
                    .options=${t.map(e=>({value:e.areaId,label:e.name}))}
                    fixedMenuPosition
                    @selected=${e=>{this._resetSelectedRoom=F(e)}}
                    @closed=${e=>e.stopPropagation()}
                  >
                    ${t.map(e=>m`<ha-list-item value=${e.areaId}>${e.name}</ha-list-item>`)}
                  </ha-select>
                  ${this._resetSelectedRoom?m`<ha-icon-button
                          .path=${`M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z`}
                          @click=${()=>{this._resetSelectedRoom=``}}
                        ></ha-icon-button>`:h}
                  <button
                    class="reset-btn"
                    ?disabled=${!this._resetSelectedRoom}
                    @click=${()=>this._resetSelectedRoom&&this._resetRoomModel(this._resetSelectedRoom)}
                  >
                    <ha-icon icon="mdi:restart"></ha-icon>
                    ${S(`settings.reset_btn`,e)}
                  </button>
                </div>
              `:m`<p class="hint">${S(`settings.reset_no_rooms`,e)}</p>`}
      </div>
    `}async _resetRoomModel(e){let t=this.hass.language;if(confirm(S(`settings.reset_room_confirm`,t)))try{I(this,`saving`),await this.hass.callWS({type:`roommind/thermal/reset`,area_id:e}),I(this,`saved`)}catch{I(this,`error`)}}async _resetAllModels(){let e=this.hass.language;if(confirm(S(`settings.reset_all_confirm`,e)))try{I(this,`saving`),await this.hass.callWS({type:`roommind/thermal/reset_all`}),I(this,`saved`)}catch{I(this,`error`)}}static{this.styles=[Y.settingsBaseStyles,l`
      .hint {
        color: var(--secondary-text-color);
        font-size: 13px;
        margin: 0;
      }

      .reset-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 16px;
      }
      .reset-text {
        display: flex;
        flex-direction: column;
        gap: 4px;
        flex: 1;
      }

      .reset-btn {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 8px 14px;
        border: 1px solid var(--error-color, #d32f2f);
        border-radius: 8px;
        background: transparent;
        color: var(--error-color, #d32f2f);
        font-size: 13px;
        font-family: inherit;
        cursor: pointer;
        transition: background 0.15s;
        --mdc-icon-size: 16px;
        white-space: nowrap;
      }
      .reset-btn:hover {
        background: rgba(211, 47, 47, 0.08);
      }
      .reset-btn:disabled {
        opacity: 0.4;
        cursor: not-allowed;
      }
      .reset-btn:disabled:hover {
        background: transparent;
      }

      .reset-room-row {
        display: flex;
        align-items: center;
        gap: 12px;
      }
      .reset-room-row ha-select {
        flex: 1;
      }

      @media (max-width: 600px) {
        .reset-row {
          flex-direction: column;
          align-items: flex-start;
          gap: 12px;
        }
      }
    `]}};A([y({attribute:!1})],Qn.prototype,`hass`,void 0),A([y({attribute:!1})],Qn.prototype,`rooms`,void 0),A([b()],Qn.prototype,`_resetSelectedRoom`,void 0),Qn=A([v(`rs-settings-reset`)],Qn),_(),x(),j();var X=class extends g{constructor(...e){super(...e),this.rooms={},this.compressorRelease={},this._groupByFloor=!1,this._climateControlActive=!0,this._learningDisabledRooms=[],this._outdoorTempSensor=``,this._outdoorHumiditySensor=``,this._outdoorCoolingMin=16,this._outdoorHeatingMax=22,this._controlMode=`mpc`,this._comfortWeight=70,this._weatherEntity=``,this._outdoorUnavailableNotify=!0,this._predictionEnabled=!0,this._vacationActive=!1,this._vacationTemp=15,this._vacationUntil=``,this._presenceEnabled=!1,this._presencePersons=[],this._presenceAwayAction=`eco`,this._presenceClearsOverride=!1,this._presencePreheat=!1,this._presencePreheatMinutes=60,this._scheduleOffAction=`eco`,this._valveProtectionEnabled=!1,this._valveProtectionInterval=7,this._moldDetectionEnabled=!1,this._moldHumidityThreshold=70,this._moldFRsi=.8,this._moldSustainedMinutes=30,this._moldNotificationCooldown=60,this._moldNotificationsEnabled=!0,this._moldNotificationTargets=[],this._moldPreventionEnabled=!1,this._moldPreventionIntensity=`medium`,this._moldPreventionNotify=!1,this._compressorGroups=[],this._coilDryEnabled=!1,this._coilDryMinutes=20,this._coilDryMode=`fan_only`,this._coilDryFanMode=`low`,this._coilDryMinCoolingMinutes=10,this._coilDryDrainMinutes=0,this._boostAppliedAt={},this._loaded=!1,this._saveChain=Promise.resolve()}connectedCallback(){super.connectedCallback(),this._loadSettings()}disconnectedCallback(){super.disconnectedCallback(),this._saveDebounce&&(clearTimeout(this._saveDebounce),this._saveDebounce=void 0,this._doSave())}async _loadSettings(){try{let e=(await this.hass.callWS({type:`roommind/settings/get`})).settings;this._groupByFloor=e.group_by_floor??!1,this._climateControlActive=e.climate_control_active??!0,this._learningDisabledRooms=e.learning_disabled_rooms??[],this._outdoorTempSensor=e.outdoor_temp_sensor??``,this._outdoorHumiditySensor=e.outdoor_humidity_sensor??``,this._outdoorCoolingMin=e.outdoor_cooling_min??16,this._outdoorHeatingMax=e.outdoor_heating_max??22,this._controlMode=e.control_mode??`mpc`,this._comfortWeight=e.comfort_weight??70,this._weatherEntity=e.weather_entity??``,this._outdoorUnavailableNotify=e.outdoor_unavailable_notify??!0,this._predictionEnabled=e.prediction_enabled??!0;let t=e.vacation_until;this._vacationActive=!!(t&&t>Date.now()/1e3),this._vacationTemp=e.vacation_temp??15,this._vacationUntil=t&&t>Date.now()/1e3&&t<3250368e4?this._tsToDatetimeLocal(t):``,this._presenceEnabled=e.presence_enabled??!1,this._presencePersons=e.presence_persons??[],this._presenceAwayAction=e.presence_away_action??`eco`,this._presenceClearsOverride=e.presence_clears_override??!1,this._presencePreheat=e.presence_preheat??!1,this._presencePreheatMinutes=e.presence_preheat_minutes??60,this._scheduleOffAction=e.schedule_off_action??`eco`,this._valveProtectionEnabled=e.valve_protection_enabled??!1,this._valveProtectionInterval=e.valve_protection_interval_days??7,this._moldDetectionEnabled=e.mold_detection_enabled??!1,this._moldHumidityThreshold=e.mold_humidity_threshold??70,this._moldFRsi=e.mold_f_rsi??.8,this._moldSustainedMinutes=e.mold_sustained_minutes??30,this._moldNotificationCooldown=e.mold_notification_cooldown??60,this._moldNotificationsEnabled=e.mold_notifications_enabled??!0,this._moldNotificationTargets=e.mold_notification_targets??[],this._moldPreventionEnabled=e.mold_prevention_enabled??!1,this._moldPreventionIntensity=e.mold_prevention_intensity??`medium`,this._moldPreventionNotify=e.mold_prevention_notify_enabled??!1,this._compressorGroups=e.compressor_groups??[],this._coilDryEnabled=e.coil_dry_enabled??!1,this._coilDryMinutes=e.coil_dry_minutes??20,this._coilDryMode=e.coil_dry_mode??`fan_only`,this._coilDryFanMode=e.coil_dry_fan_mode??`low`,this._coilDryMinCoolingMinutes=e.coil_dry_min_cooling_minutes??10,this._coilDryDrainMinutes=e.coil_dry_drain_minutes??0,this._boostAppliedAt=e.boost_applied_at??{}}catch(e){console.debug(`[RoomMind] loadSettings:`,e)}finally{this._loaded=!0}}render(){if(!this._loaded)return m`<div class="loading">${S(`panel.loading`,this.hass.language)}</div>`;let e=this.hass.language;return m`
      <rs-settings-panel
        icon="mdi:power"
        .heading=${S(`settings.general_title`,e)}
        .intro=${S(`settings.intro.general`,e)}
      >
        <rs-settings-general
          .hass=${this.hass}
          .groupByFloor=${this._groupByFloor}
          .climateControlActive=${this._climateControlActive}
          @setting-changed=${this._onSettingChanged}
        ></rs-settings-general>
      </rs-settings-panel>

      <rs-settings-panel
        icon="mdi:thermometer"
        .heading=${S(`settings.sensors_title`,e)}
        .intro=${S(`settings.intro.sensors`,e)}
      >
        <rs-settings-sensors
          .hass=${this.hass}
          .outdoorTempSensor=${this._outdoorTempSensor}
          .outdoorHumiditySensor=${this._outdoorHumiditySensor}
          .weatherEntity=${this._weatherEntity}
          .outdoorUnavailableNotify=${this._outdoorUnavailableNotify}
          @setting-changed=${this._onSettingChanged}
        ></rs-settings-sensors>
      </rs-settings-panel>

      <rs-settings-panel
        icon="mdi:tune-variant"
        .heading=${S(`settings.control_title`,e)}
        .intro=${S(`settings.intro.control`,e)}
      >
        <rs-settings-control
          .hass=${this.hass}
          .controlMode=${this._controlMode}
          .comfortWeight=${this._comfortWeight}
          .outdoorCoolingMin=${this._outdoorCoolingMin}
          .outdoorHeatingMax=${this._outdoorHeatingMax}
          .predictionEnabled=${this._predictionEnabled}
          .scheduleOffAction=${this._scheduleOffAction}
          @setting-changed=${this._onSettingChanged}
        ></rs-settings-control>
      </rs-settings-panel>

      <rs-settings-panel
        icon="mdi:home-account"
        .heading=${S(`presence.title`,e)}
        .intro=${S(`settings.intro.presence`,e)}
      >
        <rs-settings-presence
          .hass=${this.hass}
          .presenceEnabled=${this._presenceEnabled}
          .presencePersons=${this._presencePersons}
          .presenceAwayAction=${this._presenceAwayAction}
          .presenceClearsOverride=${this._presenceClearsOverride}
          .presencePreheat=${this._presencePreheat}
          .presencePreheatMinutes=${this._presencePreheatMinutes}
          @setting-changed=${this._onSettingChanged}
        ></rs-settings-presence>
      </rs-settings-panel>

      <rs-settings-panel
        icon="mdi:airplane"
        .heading=${S(`vacation.title`,e)}
        .intro=${S(`settings.intro.vacation`,e)}
      >
        <rs-settings-vacation
          .hass=${this.hass}
          .vacationActive=${this._vacationActive}
          .vacationTemp=${this._vacationTemp}
          .vacationUntil=${this._vacationUntil}
          @setting-changed=${this._onSettingChanged}
        ></rs-settings-vacation>
      </rs-settings-panel>

      <rs-settings-panel
        icon="mdi:shield-refresh"
        .heading=${S(`valve_protection.title`,e)}
        .intro=${S(`settings.intro.valve`,e)}
      >
        <rs-settings-valve
          .hass=${this.hass}
          .valveProtectionEnabled=${this._valveProtectionEnabled}
          .valveProtectionInterval=${this._valveProtectionInterval}
          @setting-changed=${this._onSettingChanged}
        ></rs-settings-valve>
      </rs-settings-panel>

      <rs-settings-panel
        icon="mdi:heat-pump-outline"
        .heading=${S(`compressor.title`,e)}
        .intro=${S(`settings.intro.compressor`,e)}
      >
        <rs-settings-compressor
          .hass=${this.hass}
          .compressorGroups=${this._compressorGroups}
          .releaseStatus=${this.compressorRelease}
          @setting-changed=${this._onSettingChanged}
        ></rs-settings-compressor>
      </rs-settings-panel>

      <rs-settings-panel .heading=${S(`coil_dry.title`,e)} icon="mdi:air-filter">
        <rs-settings-coil-dry
          .hass=${this.hass}
          .coilDryEnabled=${this._coilDryEnabled}
          .coilDryMinutes=${this._coilDryMinutes}
          .coilDryMode=${this._coilDryMode}
          .coilDryFanMode=${this._coilDryFanMode}
          .coilDryMinCoolingMinutes=${this._coilDryMinCoolingMinutes}
          .coilDryDrainMinutes=${this._coilDryDrainMinutes}
          .availableFanModes=${this._availableAcFanModes()}
          @setting-changed=${this._onSettingChanged}
        ></rs-settings-coil-dry>
      </rs-settings-panel>

      <rs-settings-panel
        icon="mdi:water-alert"
        .heading=${S(`mold.title`,e)}
        .intro=${S(`settings.intro.mold`,e)}
      >
        <rs-settings-mold
          .hass=${this.hass}
          .moldDetectionEnabled=${this._moldDetectionEnabled}
          .moldHumidityThreshold=${this._moldHumidityThreshold}
          .moldFRsi=${this._moldFRsi}
          .moldSustainedMinutes=${this._moldSustainedMinutes}
          .moldPreventionEnabled=${this._moldPreventionEnabled}
          .moldPreventionIntensity=${this._moldPreventionIntensity}
          @setting-changed=${this._onSettingChanged}
        ></rs-settings-mold>
      </rs-settings-panel>

      <rs-settings-panel
        icon="mdi:bell-outline"
        .heading=${S(`notifications.title`,e)}
        .intro=${S(`settings.intro.notifications`,e)}
        .badge=${S(`badge.beta`,e)}
        .badgeHint=${S(`badge.beta_hint`,e)}
      >
        <rs-settings-notifications
          .hass=${this.hass}
          .notificationsEnabled=${this._moldNotificationsEnabled}
          .notificationTargets=${this._moldNotificationTargets}
          .notificationCooldown=${this._moldNotificationCooldown}
          .moldPreventionEnabled=${this._moldPreventionEnabled}
          .moldPreventionNotify=${this._moldPreventionNotify}
          @setting-changed=${this._onSettingChanged}
        ></rs-settings-notifications>
      </rs-settings-panel>

      <rs-settings-panel
        icon="mdi:brain"
        .heading=${S(`settings.learning_title`,e)}
        .intro=${S(`settings.intro.learning`,e)}
      >
        <rs-settings-learning
          .hass=${this.hass}
          .rooms=${this.rooms}
          .learningDisabledRooms=${this._learningDisabledRooms}
          .boostAppliedAt=${this._boostAppliedAt}
          .roomsLive=${Object.fromEntries(Object.entries(this.rooms).map(([e,t])=>[e,t.live??{}]))}
          @setting-changed=${this._onSettingChanged}
          @boost-applied=${this._onBoostApplied}
        ></rs-settings-learning>
      </rs-settings-panel>

      <rs-settings-panel
        icon="mdi:restart"
        .heading=${S(`settings.reset_title`,e)}
        .intro=${S(`settings.intro.reset`,e)}
      >
        <rs-settings-reset .hass=${this.hass} .rooms=${this.rooms}></rs-settings-reset>
      </rs-settings-panel>
    `}_onBoostApplied(e){let{area_id:t,n_observations:n}=e.detail;this._boostAppliedAt={...this._boostAppliedAt,[t]:n}}_onSettingChanged(e){let{key:t,value:n}=e.detail;this[`_${t}`]=n,this._autoSave()}_availableAcFanModes(){let e=new Set;for(let t of Object.values(this.rooms??{}))for(let n of t.devices??[]){if(n.type!==`ac`)continue;let t=this.hass?.states?.[n.entity_id];for(let n of t?.attributes?.fan_modes??[])e.add(n)}return[...e].sort()}_tsToDatetimeLocal(e){let t=new Date(e*1e3),n=e=>String(e).padStart(2,`0`);return`${t.getFullYear()}-${n(t.getMonth()+1)}-${n(t.getDate())}T${n(t.getHours())}:${n(t.getMinutes())}`}_autoSave(){this._saveDebounce&&clearTimeout(this._saveDebounce),this._saveDebounce=setTimeout(()=>{this._saveDebounce=void 0,this._doSave()},500)}_doSave(){let e=this._buildSavePayload();return this._saveChain=this._saveChain.then(()=>this._sendSave(e)),this._saveChain}async _sendSave(e){I(this,`saving`);try{await this.hass.callWS(e),I(this,`saved`)}catch{I(this,`error`)}}_buildSavePayload(){return{type:`roommind/settings/save`,group_by_floor:this._groupByFloor,climate_control_active:this._climateControlActive,learning_disabled_rooms:this._learningDisabledRooms,outdoor_temp_sensor:this._outdoorTempSensor,outdoor_humidity_sensor:this._outdoorHumiditySensor,outdoor_cooling_min:this._outdoorCoolingMin,outdoor_heating_max:this._outdoorHeatingMax,control_mode:this._controlMode,comfort_weight:this._comfortWeight,weather_entity:this._weatherEntity,outdoor_unavailable_notify:this._outdoorUnavailableNotify,prediction_enabled:this._predictionEnabled,vacation_temp:this._vacationTemp,vacation_until:this._vacationActive?this._vacationUntil?new Date(this._vacationUntil).getTime()/1e3:Xt:null,presence_enabled:this._presenceEnabled,presence_persons:this._presencePersons.filter(e=>e),presence_away_action:this._presenceAwayAction,presence_clears_override:this._presenceClearsOverride,presence_preheat:this._presencePreheat,presence_preheat_minutes:this._presencePreheatMinutes,schedule_off_action:this._scheduleOffAction,valve_protection_enabled:this._valveProtectionEnabled,valve_protection_interval_days:this._valveProtectionInterval,compressor_groups:this._compressorGroups.filter(e=>e.members.length>0),coil_dry_enabled:this._coilDryEnabled,coil_dry_minutes:this._coilDryMinutes,coil_dry_mode:this._coilDryMode,coil_dry_fan_mode:this._coilDryFanMode,coil_dry_min_cooling_minutes:this._coilDryMinCoolingMinutes,coil_dry_drain_minutes:this._coilDryDrainMinutes,mold_detection_enabled:this._moldDetectionEnabled,mold_humidity_threshold:this._moldHumidityThreshold,mold_f_rsi:this._moldFRsi,mold_sustained_minutes:this._moldSustainedMinutes,mold_notification_cooldown:this._moldNotificationCooldown,mold_notifications_enabled:this._moldNotificationsEnabled,mold_notification_targets:this._moldNotificationTargets.filter(e=>e.entity_id),mold_prevention_enabled:this._moldPreventionEnabled,mold_prevention_intensity:this._moldPreventionIntensity,mold_prevention_notify_enabled:this._moldPreventionNotify,mold_prevention_notify_targets:this._moldPreventionNotify?this._moldNotificationTargets.filter(e=>e.entity_id):[]}}static{this.styles=l`
    :host {
      display: flex;
      flex-direction: column;
      gap: 12px;
      padding: 0 16px;
    }

    .loading {
      padding: 80px 16px;
      text-align: center;
      color: var(--secondary-text-color);
    }
  `}};A([y({attribute:!1})],X.prototype,`hass`,void 0),A([y({attribute:!1})],X.prototype,`rooms`,void 0),A([y({attribute:!1})],X.prototype,`compressorRelease`,void 0),A([b()],X.prototype,`_groupByFloor`,void 0),A([b()],X.prototype,`_climateControlActive`,void 0),A([b()],X.prototype,`_learningDisabledRooms`,void 0),A([b()],X.prototype,`_outdoorTempSensor`,void 0),A([b()],X.prototype,`_outdoorHumiditySensor`,void 0),A([b()],X.prototype,`_outdoorCoolingMin`,void 0),A([b()],X.prototype,`_outdoorHeatingMax`,void 0),A([b()],X.prototype,`_controlMode`,void 0),A([b()],X.prototype,`_comfortWeight`,void 0),A([b()],X.prototype,`_weatherEntity`,void 0),A([b()],X.prototype,`_outdoorUnavailableNotify`,void 0),A([b()],X.prototype,`_predictionEnabled`,void 0),A([b()],X.prototype,`_vacationActive`,void 0),A([b()],X.prototype,`_vacationTemp`,void 0),A([b()],X.prototype,`_vacationUntil`,void 0),A([b()],X.prototype,`_presenceEnabled`,void 0),A([b()],X.prototype,`_presencePersons`,void 0),A([b()],X.prototype,`_presenceAwayAction`,void 0),A([b()],X.prototype,`_presenceClearsOverride`,void 0),A([b()],X.prototype,`_presencePreheat`,void 0),A([b()],X.prototype,`_presencePreheatMinutes`,void 0),A([b()],X.prototype,`_scheduleOffAction`,void 0),A([b()],X.prototype,`_valveProtectionEnabled`,void 0),A([b()],X.prototype,`_valveProtectionInterval`,void 0),A([b()],X.prototype,`_moldDetectionEnabled`,void 0),A([b()],X.prototype,`_moldHumidityThreshold`,void 0),A([b()],X.prototype,`_moldFRsi`,void 0),A([b()],X.prototype,`_moldSustainedMinutes`,void 0),A([b()],X.prototype,`_moldNotificationCooldown`,void 0),A([b()],X.prototype,`_moldNotificationsEnabled`,void 0),A([b()],X.prototype,`_moldNotificationTargets`,void 0),A([b()],X.prototype,`_moldPreventionEnabled`,void 0),A([b()],X.prototype,`_moldPreventionIntensity`,void 0),A([b()],X.prototype,`_moldPreventionNotify`,void 0),A([b()],X.prototype,`_compressorGroups`,void 0),A([b()],X.prototype,`_coilDryEnabled`,void 0),A([b()],X.prototype,`_coilDryMinutes`,void 0),A([b()],X.prototype,`_coilDryMode`,void 0),A([b()],X.prototype,`_coilDryFanMode`,void 0),A([b()],X.prototype,`_coilDryMinCoolingMinutes`,void 0),A([b()],X.prototype,`_coilDryDrainMinutes`,void 0),A([b()],X.prototype,`_boostAppliedAt`,void 0),A([b()],X.prototype,`_loaded`,void 0),X=A([v(`rs-settings`)],X);async function $n(e,t,n,r,i=!1){let a=[...new Set(t.filter(Boolean))];if(a.length===0)return{};let o=await e.callWS({type:`history/history_during_period`,start_time:new Date(n).toISOString(),end_time:new Date(r).toISOString(),entity_ids:a,minimal_response:!i,no_attributes:!i,significant_changes_only:!1}),s={};for(let[e,t]of Object.entries(o??{}))s[e]=t.map(e=>({ts:(e.lu??e.lc??n/1e3)*1e3,state:e.s,attributes:e.a}));return s}function er(e){if(e===void 0||e===`unavailable`||e===`unknown`||e===``)return null;let t=e.toLowerCase();if([`on`,`heat`,`heating`,`true`,`running`].includes(t))return!0;let n=Number(t);return Number.isFinite(n)?n>0:!1}function tr(e,t,n){let r=[],i=null;for(let a of e){let e=Math.max(t,Math.min(n,a.ts)),o=er(a.state)===!0;o&&i===null?i=e:!o&&i!==null&&(e>i&&r.push({start:i,end:e}),i=null)}return i!==null&&n>i&&r.push({start:i,end:n}),r}function nr(e,t,n){let r=tr(e,t,n),i=r.filter(e=>e.start>t).length,a=r.reduce((e,t)=>e+(t.end-t.start),0);return{starts:i,onHours:a/36e5,avgRunMinutes:r.length?a/r.length/6e4:null}}function rr(e){let t=0,n=null,r=!1;for(let i of e){let e=Number(i.state);Number.isFinite(e)&&(n!==null&&e>n&&(t+=e-n),n=e,r=!0)}return r?t:null}function ir(e,t,n,r){let i={};for(let a=0;a<e.length;a++){let o=e[a].attributes?.[t];if(typeof o!=`string`)continue;let s=Math.max(n,e[a].ts),c=Math.min(r,a+1<e.length?e[a+1].ts:r);c>s&&(i[o]=(i[o]??0)+(c-s)/36e5)}return i}function ar(e){let t=[];for(let n of e){let e=Number(n.state);Number.isFinite(e)&&t.push([n.ts,e])}return t}_(),x(),j();var or={"24h":864e5,"7d":6048e5,"30d":2592e6};function sr(e){return`sensor.roommind_heating_${e.replace(/-/g,``).slice(0,8).toLowerCase()}`}var cr=[{key:`release`,color:`rgba(255, 152, 0, 0.55)`},{key:`burner`,color:`rgba(244, 67, 54, 0.6)`},{key:`pump`,color:`rgba(33, 150, 243, 0.55)`},{key:`dhw`,color:`rgba(156, 39, 176, 0.55)`}],lr=class extends g{constructor(...e){super(...e),this.releaseStatus={},this._groups=[],this._loaded=!1,this._selected=``,this._range=`24h`,this._history={},this._historyLoading=!1,this._historyKey=``,this._saveChain=Promise.resolve()}connectedCallback(){super.connectedCallback(),this._loadSettings()}disconnectedCallback(){super.disconnectedCallback(),this._saveDebounce&&(clearTimeout(this._saveDebounce),this._saveDebounce=void 0,this._save())}async _loadSettings(){try{let e=await this.hass.callWS({type:`roommind/settings/get`});this._groups=e.settings.compressor_groups??[];let t=this._groups.find(e=>e.release_entity);this._groups.some(e=>e.id===this._selected)||(this._selected=(t??this._groups[0])?.id??``)}catch(e){console.debug(`[RoomMind] heating settings:`,e)}finally{this._loaded=!0}}get _group(){return this._groups.find(e=>e.id===this._selected)}updated(){let e=this._group;if(!e?.release_entity)return;let t=[e.id,this._range,e.release_entity,e.burner_entity,e.pump_entity,e.dhw_entity,e.boiler_temp_sensor,e.oil_sensor].join(`|`);t!==this._historyKey&&(this._historyKey=t,this._loadHistory(e))}async _loadHistory(e){let t=this._historyKey,n=Date.now(),r=n-or[this._range];this._historyLoading=!0;try{let i=await $n(this.hass,[e.release_entity??``,e.burner_entity??``,e.pump_entity??``,e.dhw_entity??``,e.boiler_temp_sensor??``,e.oil_sensor??``],r,n),a={};try{a=await $n(this.hass,[sr(e.id)],r,n,!0)}catch{}t===this._historyKey&&(this._history={...i,...a})}catch(e){console.debug(`[RoomMind] heating history:`,e),t===this._historyKey&&(this._history={})}finally{t===this._historyKey&&(this._historyLoading=!1)}}render(){let e=this.hass.language;if(!this._loaded)return m`<div class="empty">${S(`panel.loading`,e)}</div>`;if(this._groups.length===0)return m`<div class="empty">
        <ha-icon icon="mdi:water-boiler" class="big-icon"></ha-icon>
        <p>${S(`heating.no_groups`,e)}</p>
      </div>`;let t=this._group;return m`
      ${this._groups.length>1?m`<div class="chips">
              ${this._groups.map(t=>m`<button
                    class="chip ${t.id===this._selected?`selected`:``}"
                    @click=${()=>this._selected=t.id}
                  >
                    ${t.name||S(`heating.unnamed`,e)}
                  </button>`)}
            </div>`:h}
      ${t?t.release_entity?m`${this._renderStatus(t)} ${this._renderAnalysis(t)} ${this._renderSettings(t)}`:this._renderSettings(t):h}
    `}_card(e,t,n,r){return m`<ha-card>
      <div class="card-header">
        <ha-icon .icon=${e}></ha-icon>
        <span class="card-title">${t}</span>
        ${r??h}
      </div>
      <div class="card-body">${n}</div>
    </ha-card>`}_renderStatus(e){let t=this.hass.language,n=this.releaseStatus[e.id],r=e=>S(e==null?`heating.unknown`:e?`heating.on`:`heating.off`,t),i=(e,t,n,r=!1,i=``)=>m`<div class="tile ${r?`active`:``}">
        <ha-icon .icon=${e}></ha-icon>
        <div>
          <div class="tile-label">${t}</div>
          <div class="tile-value">${n}</div>
          ${i?m`<div class="tile-hint">${i}</div>`:h}
        </div>
      </div>`,a=S(`compressor.boiler_learning`,t),o=n?m`
          <div class="tiles">
            ${i(n.on?`mdi:fire`:`mdi:fire-off`,S(`heating.release`,t),r(n.on),n.on,S(`compressor.release_reason.${n.reason}`,t))}
            ${i(`mdi:home-thermometer`,S(`heating.demand`,t),S(`heating.demand_value`,t,{count:n.demand_count,weighted:n.weighted_demand.toFixed(1)}))}
            ${e.boiler_temp_sensor?i(`mdi:thermometer-water`,S(`heating.boiler_temp`,t),n.boiler_temp==null?`–`:`${n.boiler_temp.toFixed(1)} °C`,!1,n.lead_minutes?S(`compressor.boiler_lead`,t,{min:n.lead_minutes}):n.warm_minutes?S(`compressor.boiler_warm`,t,{min:n.warm_minutes}):``):h}
            ${e.burner_entity?i(`mdi:fire-circle`,S(`heating.burner`,t),r(n.burner_on),!!n.burner_on):h}
            ${e.pump_entity?i(`mdi:pump`,S(`heating.pump`,t),r(n.pump_on),!!n.pump_on):h}
            ${e.dhw_entity?i(`mdi:water-thermometer`,S(`heating.dhw`,t),r(n.dhw_on),!!n.dhw_on):h}
          </div>
          ${e.boiler_temp_sensor?m`<div class="learned">
                  <div class="section-label">${S(`heating.learned`,t)}</div>
                  <div class="learned-row">
                    <span
                      >${S(`heating.heat_rate`,t)}:
                      <b>${n.heat_rate?`${n.heat_rate.toFixed(2)} K/min`:a}</b></span
                    >
                    <span
                      >${S(`heating.cool_rate`,t)}:
                      <b>${n.cool_rate?`${n.cool_rate.toFixed(2)} K/min`:a}</b></span
                    >
                    <ha-button @click=${()=>this._resetLearning(e)}>
                      ${S(`heating.reset_learning`,t)}
                    </ha-button>
                  </div>
                  <div class="hint">${S(`heating.learned_hint`,t)}</div>
                </div>`:h}
        `:m`<div class="hint">${S(`heating.waiting_status`,t)}</div>`;return this._card(`mdi:water-boiler`,S(`heating.status`,t),o)}_figures(e,t,n){let r=this._history,i=e=>e&&r[e]?nr(r[e],t,n):null,a=i(e.burner_entity),o=e.boiler_temp_sensor?ar(r[e.boiler_temp_sensor]??[]):[],s=e.oil_sensor?r[e.oil_sensor]??[]:[],c=e.oil_nozzle_lph??0;return{release:i(e.release_entity),burner:a,pump:i(e.pump_entity),dhw:i(e.dhw_entity),oilMeasured:e.oil_sensor?rr(s):null,oilUnit:this.hass.states[e.oil_sensor??``]?.attributes?.unit_of_measurement||`L`,oilEstimated:a&&c>0?a.onHours*c:null,boilerAvg:o.length?o.reduce((e,[,t])=>e+t,0)/o.length:null,boilerMax:o.length?Math.max(...o.map(([,e])=>e)):null,reasons:ir(r[sr(e.id)]??[],`reason`,t,n)}}_renderAnalysis(e){let t=this.hass.language,n=Date.now(),r=n-or[this._range],i=this._figures(e,r,n),a=e=>`${e.toFixed(1)} h`,o=(e,t,n=``)=>m`<div class="kpi">
        <div class="kpi-value">${t}</div>
        <div class="kpi-label">${e}</div>
        ${n?m`<div class="kpi-hint">${n}</div>`:h}
      </div>`,s=i.burner??i.release,c=i.burner?`heating.burner`:`heating.release`,l=Object.values(i.reasons).reduce((e,t)=>e+t,0),u=m`<div class="range">
      ${Object.keys(or).map(e=>m`<button
            class="chip small ${e===this._range?`selected`:``}"
            @click=${()=>this._range=e}
          >
            ${S(`heating.range.${e}`,t)}
          </button>`)}
    </div>`,d=m`
      ${this._historyLoading?m`<div class="hint">${S(`panel.loading`,t)}</div>`:h}
      <div class="kpis">
        ${s?m`${o(S(`heating.kpi_starts`,t,{what:S(c,t)}),String(s.starts),s.avgRunMinutes==null?``:S(`heating.kpi_avg_run`,t,{min:Math.round(s.avgRunMinutes)}))}
              ${o(S(`heating.kpi_runtime`,t,{what:S(c,t)}),a(s.onHours))}`:h}
        ${i.burner&&i.release?o(S(`heating.kpi_release_time`,t),a(i.release.onHours)):h}
        ${i.oilMeasured==null?i.oilEstimated==null?h:o(S(`heating.kpi_oil`,t),`≈ ${i.oilEstimated.toFixed(1)} L`,S(`heating.kpi_oil_estimated`,t)):o(S(`heating.kpi_oil`,t),`${i.oilMeasured.toFixed(1)} ${i.oilUnit}`)}
        ${i.pump?o(S(`heating.kpi_pump`,t),a(i.pump.onHours)):h}
        ${i.dhw?o(S(`heating.kpi_dhw`,t),a(i.dhw.onHours),S(`heating.kpi_dhw_count`,t,{count:i.dhw.starts})):h}
        ${i.boilerAvg==null?h:o(S(`heating.kpi_boiler`,t),`${i.boilerAvg.toFixed(0)} °C`,S(`heating.kpi_boiler_max`,t,{max:(i.boilerMax??0).toFixed(0)}))}
      </div>
      ${this._renderChart(e,r,n)}
      ${l>0?m`<div class="section-label">${S(`heating.reasons`,t)}</div>
              <div class="reasons">
                ${Object.entries(i.reasons).sort((e,t)=>t[1]-e[1]).map(([e,n])=>m`<div class="reason-row">
                        <span>${S(`compressor.release_reason.${e}`,t)}</span>
                        <div class="reason-bar">
                          <div style="width:${n/l*100}%"></div>
                        </div>
                        <span class="reason-val">${a(n)}</span>
                      </div>`)}
              </div>`:h}
      ${!e.oil_sensor&&!(e.oil_nozzle_lph&&e.burner_entity)?m`<div class="hint">${S(`heating.oil_hint`,t)}</div>`:h}
    `;return this._card(`mdi:chart-timeline-variant`,S(`heating.analysis`,t),d,u)}_renderChart(e,t,n){let r=this.hass.language,i=this._history,a={release:e.release_entity,burner:e.burner_entity,pump:e.pump_entity,dhw:e.dhw_entity},o=cr.filter(e=>a[e.key]&&i[a[e.key]]),s=[];if(e.boiler_temp_sensor&&i[e.boiler_temp_sensor]&&s.push({id:`boiler`,type:`line`,name:S(`heating.boiler_temp`,r),color:`rgb(255, 87, 34)`,data:ar(i[e.boiler_temp_sensor]),showSymbol:!1,step:`end`,yAxisIndex:0}),o.forEach((e,o)=>{let c=tr(i[a[e.key]],t,n);s.push({id:`lane_${e.key}`,type:`line`,name:S(`heating.${e.key}`,r),color:e.color,data:[],yAxisIndex:1,markArea:{silent:!0,itemStyle:{color:e.color},data:c.map(e=>[{xAxis:e.start,yAxis:o+.1},{xAxis:e.end,yAxis:o+.9}])}})}),s.length===0)return h;let c={xAxis:{type:`time`,min:t,max:n},yAxis:[{type:`value`,name:`°C`,scale:!0},{type:`value`,min:0,max:Math.max(o.length,1),show:!1}],legend:{show:!0},dataZoom:[{type:`inside`,xAxisIndex:0,filterMode:`none`}],tooltip:{trigger:`axis`},grid:{top:40,left:40,right:16,bottom:30,containLabel:!0}};return m`<ha-chart-base
        .hass=${this.hass}
        .data=${s}
        .options=${c}
        .height=${`280px`}
        style="height: 280px"
      ></ha-chart-base>
      <div class="lane-legend">
        ${o.map((e,t)=>m`<span
              ><i style="background:${e.color}"></i>${t+1}.
              ${S(`heating.${e.key}`,r)}</span
            >`)}
      </div>`}_renderSettings(e){let t=this.hass.language,n=(t,n,r,i)=>m`
      <div class="field">
        <ha-entity-picker
          .hass=${this.hass}
          .value=${e[t]||``}
          .includeDomains=${i}
          .label=${n}
          @value-changed=${n=>this._update(e.id,{[t]:n.detail?.value??``})}
        ></ha-entity-picker>
        <div class="hint">${r}</div>
      </div>
    `,r=(t,n,r,i,a,o,s,c=``)=>m`
      <div class="field">
        <ha-textfield
          type="number"
          .value=${String(n)}
          .label=${r}
          .suffix=${c}
          min=${a}
          max=${o}
          step=${s}
          @change=${n=>{let r=Number(n.target.value);Number.isFinite(r)&&r>=a&&r<=o&&this._update(e.id,{[t]:r})}}
        ></ha-textfield>
        <div class="hint">${i}</div>
      </div>
    `,i=[`binary_sensor`,`switch`,`input_boolean`,`sensor`],a=m`
      <div class="hint">${S(`heating.settings_intro`,t)}</div>
      ${n(`release_entity`,S(`compressor.release_entity`,t),S(`compressor.release_entity_hint`,t),[`input_boolean`,`switch`])}
      ${e.release_entity?m`
              <div class="section-label">${S(`heating.section_release`,t)}</div>
              <div class="grid">
                ${r(`release_min_demand`,e.release_min_demand??1,S(`compressor.release_min_demand`,t),S(`compressor.release_min_demand_hint`,t),1,50,1)}
              </div>
              <div class="field">
                <ha-formfield .label=${S(`compressor.release_smart`,t)}>
                  <ha-switch
                    .checked=${e.release_smart??!1}
                    @change=${t=>this._update(e.id,{release_smart:t.target.checked})}
                  ></ha-switch>
                </ha-formfield>
                <div class="hint">${S(`compressor.release_smart_hint`,t)}</div>
              </div>
              ${e.release_smart?m`<div class="grid">
                      ${r(`release_urgent_delta`,e.release_urgent_delta??1.5,S(`compressor.release_urgent_delta`,t),S(`compressor.release_urgent_delta_hint`,t),.3,5,.1,`K`)}
                      ${r(`release_max_wait_minutes`,e.release_max_wait_minutes??45,S(`compressor.release_max_wait`,t),S(`compressor.release_max_wait_hint`,t),5,240,5,`min`)}
                    </div>`:h}

              <div class="section-label">${S(`heating.section_boiler`,t)}</div>
              ${n(`boiler_temp_sensor`,S(`compressor.boiler_temp_sensor`,t),S(`compressor.boiler_temp_sensor_hint`,t),[`sensor`,`input_number`,`number`])}
              ${e.boiler_temp_sensor?m`<div class="grid">
                      ${r(`boiler_usable_temp`,e.boiler_usable_temp??45,S(`compressor.boiler_usable_temp`,t),S(`compressor.boiler_usable_temp_hint`,t),20,90,1,`°C`)}
                    </div>`:h}
              ${n(`burner_entity`,S(`heating.burner_entity`,t),S(`heating.burner_entity_hint`,t),i)}
              ${n(`pump_entity`,S(`heating.pump_entity`,t),S(`heating.pump_entity_hint`,t),i)}
              ${n(`dhw_entity`,S(`heating.dhw_entity`,t),S(`heating.dhw_entity_hint`,t),[...i,`water_heater`])}

              <div class="section-label">${S(`heating.section_oil`,t)}</div>
              ${n(`oil_sensor`,S(`heating.oil_sensor`,t),S(`heating.oil_sensor_hint`,t),[`sensor`,`input_number`,`counter`])}
              <div class="grid">
                ${r(`oil_nozzle_lph`,e.oil_nozzle_lph??0,S(`heating.oil_nozzle`,t),S(`heating.oil_nozzle_hint`,t),0,50,.05,`L/h`)}
              </div>
            `:h}
      <div class="hint">${S(`heating.members_hint`,t)}</div>
    `;return this._card(`mdi:cog`,S(`heating.settings`,t),a)}_update(e,t){this._groups=this._groups.map(n=>n.id===e?{...n,...t}:n),this._saveDebounce&&clearTimeout(this._saveDebounce),this._saveDebounce=setTimeout(()=>{this._saveDebounce=void 0,this._save()},500)}_save(){let e=this._groups;return this._saveChain=this._saveChain.then(async()=>{I(this,`saving`);try{await this.hass.callWS({type:`roommind/settings/save`,compressor_groups:e}),I(this,`saved`)}catch(e){console.debug(`[RoomMind] heating save:`,e),I(this,`error`)}}),this._saveChain}async _resetLearning(e){if(confirm(S(`heating.reset_confirm`,this.hass.language)))try{await this.hass.callWS({type:`roommind/heating/reset_learning`,group_id:e.id})}catch(e){console.debug(`[RoomMind] reset learning:`,e)}}static{this.styles=[L,l`
      :host {
        display: flex;
        flex-direction: column;
        gap: 16px;
        padding: 0 16px 24px;
        max-width: 1200px;
        margin: 0 auto;
      }
      ha-card {
        overflow: hidden;
      }
      .card-header {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 16px 20px 8px;
      }
      .card-header ha-icon {
        --mdc-icon-size: 20px;
        opacity: 0.75;
      }
      .card-title {
        flex: 1;
        font-size: 16px;
        font-weight: 500;
      }
      .card-body {
        padding: 8px 20px 20px;
        display: flex;
        flex-direction: column;
        gap: 12px;
      }
      .empty {
        padding: 80px 16px;
        text-align: center;
        color: var(--secondary-text-color);
      }
      .empty p {
        max-width: 460px;
        margin: 16px auto 0;
        line-height: 1.5;
      }
      .big-icon {
        --mdc-icon-size: 48px;
        opacity: 0.4;
      }
      .chips,
      .range {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
      }
      .chip {
        border: 1px solid var(--divider-color, #ccc);
        background: none;
        color: var(--primary-text-color);
        border-radius: 16px;
        padding: 6px 14px;
        font: inherit;
        font-size: 14px;
        cursor: pointer;
      }
      .chip.small {
        padding: 3px 10px;
        font-size: 12px;
      }
      .chip.selected {
        background: var(--primary-color);
        border-color: var(--primary-color);
        color: var(--text-primary-color, #fff);
      }
      .tiles {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
        gap: 10px;
      }
      .tile {
        display: flex;
        gap: 10px;
        align-items: flex-start;
        padding: 12px;
        border-radius: 10px;
        background: rgba(127, 127, 127, 0.08);
      }
      .tile.active {
        background: rgba(255, 129, 0, 0.14);
      }
      .tile.active ha-icon {
        color: var(--state-climate-heat-color, #ff8100);
      }
      .tile-label {
        font-size: 12px;
        color: var(--secondary-text-color);
      }
      .tile-value {
        font-size: 18px;
        font-weight: 500;
      }
      .tile-hint {
        font-size: 12px;
        color: var(--secondary-text-color);
        margin-top: 2px;
      }
      .learned-row {
        display: flex;
        flex-wrap: wrap;
        gap: 16px;
        align-items: center;
        font-size: 14px;
      }
      .kpis {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
        gap: 10px;
      }
      .kpi {
        padding: 12px;
        border-radius: 10px;
        background: rgba(127, 127, 127, 0.08);
      }
      .kpi-value {
        font-size: 22px;
        font-weight: 500;
      }
      .kpi-label {
        font-size: 12px;
        color: var(--secondary-text-color);
      }
      .kpi-hint {
        font-size: 11px;
        color: var(--secondary-text-color);
        margin-top: 2px;
      }
      .lane-legend {
        display: flex;
        flex-wrap: wrap;
        gap: 14px;
        font-size: 12px;
        color: var(--secondary-text-color);
      }
      .lane-legend i {
        display: inline-block;
        width: 12px;
        height: 12px;
        border-radius: 3px;
        margin-right: 4px;
        vertical-align: -2px;
      }
      .reasons {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }
      .reason-row {
        display: grid;
        grid-template-columns: minmax(140px, 220px) 1fr 60px;
        gap: 10px;
        align-items: center;
        font-size: 13px;
      }
      .reason-bar {
        height: 8px;
        border-radius: 4px;
        background: rgba(127, 127, 127, 0.15);
        overflow: hidden;
      }
      .reason-bar div {
        height: 100%;
        background: var(--primary-color);
      }
      .reason-val {
        text-align: right;
        color: var(--secondary-text-color);
      }
      .section-label {
        font-size: 14px;
        font-weight: 500;
        margin-top: 8px;
      }
      .grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 12px;
      }
      @media (max-width: 600px) {
        .grid {
          grid-template-columns: 1fr;
        }
      }
      .field ha-entity-picker,
      .field ha-textfield {
        width: 100%;
      }
      .hint {
        font-size: 12px;
        color: var(--secondary-text-color);
        line-height: 1.5;
        margin-top: 4px;
      }
    `]}};A([y({attribute:!1})],lr.prototype,`hass`,void 0),A([y({attribute:!1})],lr.prototype,`releaseStatus`,void 0),A([b()],lr.prototype,`_groups`,void 0),A([b()],lr.prototype,`_loaded`,void 0),A([b()],lr.prototype,`_selected`,void 0),A([b()],lr.prototype,`_range`,void 0),A([b()],lr.prototype,`_history`,void 0),A([b()],lr.prototype,`_historyLoading`,void 0),A([b()],lr.prototype,`_historyKey`,void 0),lr=A([v(`rs-heating`)],lr);function ur(e){let t=[...e.history,...e.detail];return t.length===0?null:[`timestamp,datetime,room_temp,outdoor_temp,target_temp,mode,predicted_temp,window_open,heating_power,solar_irradiance,blind_position,cover_reason,device_setpoint`,...t.map(e=>{let t=new Date(e.ts*1e3).toISOString(),n=e.room_temp??``,r=e.outdoor_temp??``,i=e.target_temp??``,a=e.predicted_temp??``,o=e.heating_power??``,s=e.solar_irradiance??``,c=e.blind_position??``,l=e.cover_reason??``,u=e.device_setpoint??``;return`${e.ts},${t},${n},${r},${i},${e.mode},${a},${e.window_open},${o},${s},${c},${l},${u}`})].join(`
`)}function dr(e,t,n){let r=new Blob([e],{type:`${n};charset=utf-8`}),i=URL.createObjectURL(r),a=document.createElement(`a`);a.href=i,a.download=t,a.click(),URL.revokeObjectURL(i)}function fr(e,t,n,r,i,a,o){let s=e?.areas?.[n],c=(t[n]?.display_name||s?.name||n).replace(/\s+/g,`_`).toLowerCase();return a?`roommind_${a}_${c}.${o}`:`roommind_${c}_${new Date(r).toISOString().slice(0,10)}_${new Date(i).toISOString().slice(0,10)}.${o}`}function pr(e){return navigator.clipboard?.writeText?(navigator.clipboard.writeText(e).catch(()=>{mr(e)}),!0):mr(e)}function mr(e){let t=document.createElement(`textarea`);t.value=e,t.style.position=`fixed`,t.style.opacity=`0`,document.body.appendChild(t),t.select();let n=!1;try{n=document.execCommand(`copy`)}catch(e){console.debug(`[RoomMind] clipboard fallback:`,e)}return document.body.removeChild(t),n}_(),x(),j();var Z=class extends g{constructor(...e){super(...e),this.rooms={},this.selectedRoom=``,this.rangeStart=0,this.rangeEnd=0,this.activeQuick=`24h`,this.data=null,this.language=`en`,this._openDropdown=null,this._diagLoading=!1,this._boundCloseDropdowns=this._closeDropdowns.bind(this)}connectedCallback(){super.connectedCallback(),document.addEventListener(`click`,this._boundCloseDropdowns)}disconnectedCallback(){super.disconnectedCallback(),document.removeEventListener(`click`,this._boundCloseDropdowns)}updated(e){(e.has(`rooms`)||e.has(`selectedRoom`))&&this.selectedRoom&&this.updateComplete.then(()=>{let e=this.renderRoot?.querySelector(`ha-select`);e&&e.value!==this.selectedRoom&&(e.value=this.selectedRoom)})}render(){let e=this.language,t=this._getConfiguredRooms();return m`
      ${this._renderRoomSelector(t,e)}
      ${this.selectedRoom?this._renderRangeButtons(e):h}
    `}_getConfiguredRooms(){return Object.entries(this.rooms).map(([e,t])=>{let n=this.hass?.areas?.[e];return{area_id:e,name:t.display_name||n?.name||e}})}_renderRoomSelector(e,t){return m`
      <div class="selector-row">
        <ha-select
          .value=${this.selectedRoom}
          .label=${S(`analytics.select_room`,t)}
          .options=${e.map(e=>({value:e.area_id,label:e.name}))}
          naturalMenuWidth
          fixedMenuPosition
          @selected=${this._onRoomSelected}
          @closed=${e=>e.stopPropagation()}
        >
          ${e.map(e=>m` <ha-list-item value=${e.area_id}>${e.name}</ha-list-item> `)}
        </ha-select>
      </div>
    `}_renderRangeButtons(e){let t=[{key:`24h`,label:S(`analytics.range_1d`,e),days:1},{key:`2d`,label:S(`analytics.range_2d`,e),days:2},{key:`7d`,label:S(`analytics.range_7d`,e),days:7},{key:`30d`,label:S(`analytics.range_30d`,e),days:30}],n=this.data&&(this.data.history.length>0||this.data.detail.length>0),r=e=>new Date(e).toLocaleString(this.hass.language,{month:`2-digit`,day:`2-digit`,hour:`2-digit`,minute:`2-digit`});return m`
      <div class="range-row">
        <div class="range-controls">
          <div class="range-bar">
            ${t.map(e=>m`
                <button
                  class="range-chip"
                  ?active=${this.activeQuick===e.key}
                  @click=${()=>this._onQuickRange(e.key,e.days)}
                >
                  ${e.label}
                </button>
              `)}
            <div class="range-chip picker-chip ${this.activeQuick===null?`picker-active`:``}">
              <ha-date-range-picker
                .hass=${this.hass}
                .startDate=${new Date(this.rangeStart)}
                .endDate=${new Date(this.rangeEnd)}
                .ranges=${!1}
                time-picker
                auto-apply
                minimal
                @value-changed=${this._onDateRangeChanged}
              ></ha-date-range-picker>
            </div>
          </div>
          <span class="date-label ${this.activeQuick===null?`custom-active`:``}"
            >${r(this.rangeStart)} – ${r(this.rangeEnd)}</span
          >
        </div>
        <div class="action-buttons">
          <div class="export-split">
            <button
              class="export-btn"
              ?disabled=${!n}
              @click=${e=>{e.stopPropagation(),this._toggleDropdown(`csv`)}}
            >
              <ha-icon icon="mdi:download"></ha-icon>
              ${S(`analytics.export`,e)}
              <ha-icon class="arrow-icon" icon="mdi:chevron-down"></ha-icon>
            </button>
            ${this._openDropdown===`csv`?m`<div class="export-dropdown" @click=${e=>e.stopPropagation()}>
                    <button @click=${this._exportCsv}>
                      <ha-icon icon="mdi:download"></ha-icon>
                      ${S(`analytics.export_download`,e)}
                    </button>
                    <button @click=${this._copyCsvToClipboard}>
                      <ha-icon icon="mdi:content-copy"></ha-icon>
                      ${S(`analytics.export_clipboard`,e)}
                    </button>
                  </div>`:h}
          </div>
          <div class="export-split">
            <button
              class="export-btn"
              ?disabled=${this._diagLoading}
              @click=${e=>{e.stopPropagation(),this._toggleDropdown(`diag`)}}
            >
              <ha-icon icon=${this._diagLoading?`mdi:loading`:`mdi:bug-outline`}></ha-icon>
              ${S(`analytics.copy_diagnostics`,e)}
              <ha-icon class="arrow-icon" icon="mdi:chevron-down"></ha-icon>
            </button>
            ${this._openDropdown===`diag`?m`<div class="export-dropdown" @click=${e=>e.stopPropagation()}>
                    <button @click=${this._exportDiagnostics}>
                      <ha-icon icon="mdi:download"></ha-icon>
                      ${S(`analytics.export_download`,e)}
                    </button>
                    <button @click=${this._copyDiagnosticsToClipboard}>
                      <ha-icon icon="mdi:content-copy"></ha-icon>
                      ${S(`analytics.export_clipboard`,e)}
                    </button>
                  </div>`:h}
          </div>
        </div>
      </div>
    `}_onRoomSelected(e){let t=F(e);t&&t!==this.selectedRoom&&this.dispatchEvent(new CustomEvent(`room-selected`,{detail:{areaId:t},bubbles:!0,composed:!0}))}_onQuickRange(e,t){let n=new Date,r=new Date(n);r.setDate(r.getDate()-(t-1)),r.setHours(0,0,0,0),this.dispatchEvent(new CustomEvent(`range-changed`,{detail:{activeQuick:e,rangeStart:r.getTime(),rangeEnd:n.getTime(),chartAnchor:n.getTime()},bubbles:!0,composed:!0}))}_onDateRangeChanged(e){let{startDate:t,endDate:n}=e.detail.value;t&&n&&this.dispatchEvent(new CustomEvent(`range-changed`,{detail:{activeQuick:null,rangeStart:t.getTime(),rangeEnd:n.getTime(),chartAnchor:n.getTime()},bubbles:!0,composed:!0}))}_exportCsv(){if(!this.data)return;let e=ur(this.data);e&&(dr(e,fr(this.hass,this.rooms,this.selectedRoom,this.rangeStart,this.rangeEnd,``,`csv`),`text/csv`),this._openDropdown=null)}async _exportDiagnostics(){if(!this._diagLoading){this._diagLoading=!0,this._openDropdown=null;try{let e=await this.hass.callWS({type:`roommind/diagnostics/get`});dr(JSON.stringify(e,null,2),`roommind_diagnostics.json`,`application/json`)}catch(e){console.warn(`[RoomMind] diagnostics export failed:`,e)}finally{this._diagLoading=!1}}}_copyCsvToClipboard(){if(!this.data)return;let e=ur(this.data);e&&(pr(e),this._openDropdown=null)}async _copyDiagnosticsToClipboard(){if(!this._diagLoading){this._diagLoading=!0,this._openDropdown=null;try{let e=await this.hass.callWS({type:`roommind/diagnostics/get`});pr(JSON.stringify(e,null,2))}catch(e){console.warn(`[RoomMind] diagnostics clipboard failed:`,e)}finally{this._diagLoading=!1}}}_toggleDropdown(e){this._openDropdown=this._openDropdown===e?null:e}_closeDropdowns(){this._openDropdown&&=null}static{this.styles=[L,l`
      :host {
        display: block;
      }

      .selector-row {
        margin-bottom: 16px;
      }

      .selector-row ha-select {
        width: 100%;
      }

      .range-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 16px;
        gap: 12px;
      }

      .range-controls {
        display: flex;
        align-items: center;
        gap: 8px;
        position: relative;
      }

      .range-bar {
        display: inline-flex;
        border-radius: 12px;
        border: 1px solid var(--divider-color);
        background: var(--card-background-color);
      }

      .range-bar > :first-child {
        border-radius: 12px 0 0 12px;
      }

      .range-bar > :last-child {
        border-radius: 0 12px 12px 0;
      }

      .range-chip {
        padding: 7px 14px;
        border: none;
        border-right: 1px solid var(--divider-color);
        background: transparent;
        color: var(--secondary-text-color);
        font-size: 12px;
        font-weight: 500;
        cursor: pointer;
        transition:
          background 0.15s ease,
          color 0.15s ease;
        font-family: inherit;
        white-space: nowrap;
      }

      .range-chip:last-child {
        border-right: none;
      }

      .range-chip:hover:not([active]) {
        background: rgba(var(--rgb-primary-color, 3, 169, 244), 0.08);
        color: var(--primary-text-color);
      }

      .range-chip[active] {
        background: var(--primary-color);
        color: var(--text-primary-color, #fff);
      }

      .picker-chip {
        display: flex;
        align-items: center;
        padding: 0;
        cursor: pointer;
      }

      .picker-chip ha-date-range-picker {
        --mdc-icon-size: 18px;
        --mdc-icon-button-size: 32px;
      }

      .picker-chip.picker-active {
        background: var(--primary-color);
        color: var(--text-primary-color, #fff);
      }

      .date-label {
        font-size: 12px;
        color: var(--secondary-text-color);
        white-space: nowrap;
      }

      .date-label.custom-active {
        color: var(--primary-color);
      }

      .action-buttons {
        display: flex;
        gap: 8px;
      }

      .export-split {
        position: relative;
        display: inline-flex;
      }

      .export-btn {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 7px 14px;
        border: 1px solid var(--divider-color);
        border-radius: 12px;
        background: var(--card-background-color);
        color: var(--secondary-text-color);
        font-size: 12px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.15s ease;
        font-family: inherit;
        white-space: nowrap;
        --mdc-icon-size: 14px;
      }

      .export-btn:hover {
        color: var(--primary-text-color);
        border-color: var(--primary-color);
      }

      .export-btn[disabled] {
        opacity: 0.4;
        cursor: default;
      }

      .arrow-icon {
        --mdc-icon-size: 14px;
        margin-left: 2px;
        margin-right: -4px;
      }

      .export-dropdown {
        position: absolute;
        top: 100%;
        right: 0;
        margin-top: 4px;
        min-width: 100%;
        background: var(--card-background-color);
        border: 1px solid var(--divider-color);
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        z-index: 10;
        overflow: hidden;
      }

      .export-dropdown button {
        display: flex;
        align-items: center;
        gap: 8px;
        width: 100%;
        padding: 10px 14px;
        border: none;
        background: transparent;
        color: var(--primary-text-color);
        font-size: 12px;
        font-family: inherit;
        cursor: pointer;
        white-space: nowrap;
        --mdc-icon-size: 14px;
      }

      .export-dropdown button:hover {
        background: rgba(var(--rgb-primary-color, 3, 169, 244), 0.08);
      }

      .export-dropdown button + button {
        border-top: 1px solid var(--divider-color);
      }

      @media (max-width: 600px) {
        .range-row {
          flex-wrap: wrap;
        }
        .range-controls {
          flex-wrap: wrap;
        }
        .range-chip {
          padding: 6px 10px;
          font-size: 11px;
        }
      }
    `]}};A([y({attribute:!1})],Z.prototype,`hass`,void 0),A([y({attribute:!1})],Z.prototype,`rooms`,void 0),A([y({type:String})],Z.prototype,`selectedRoom`,void 0),A([y({type:Number})],Z.prototype,`rangeStart`,void 0),A([y({type:Number})],Z.prototype,`rangeEnd`,void 0),A([y({type:String})],Z.prototype,`activeQuick`,void 0),A([y({attribute:!1})],Z.prototype,`data`,void 0),A([y({type:String})],Z.prototype,`language`,void 0),A([b()],Z.prototype,`_openDropdown`,void 0),A([b()],Z.prototype,`_diagLoading`,void 0),Z=A([v(`rs-analytics-toolbar`)],Z),_();var hr=l`
  .info-icon {
    --mdc-icon-size: 16px;
    color: var(--secondary-text-color);
    opacity: 0.3;
    cursor: pointer;
    flex-shrink: 0;
    transition:
      opacity 0.15s,
      color 0.15s;
  }

  .info-icon:hover {
    opacity: 0.7;
  }

  .info-icon.info-active {
    opacity: 1;
    color: var(--primary-color);
  }

  .info-panel {
    padding: 12px;
    border-radius: 8px;
    background: var(--secondary-background-color, rgba(128, 128, 128, 0.06));
    font-size: 13px;
    line-height: 1.6;
    color: var(--secondary-text-color);
  }

  .info-panel strong {
    display: block;
    margin-bottom: 4px;
    color: var(--primary-text-color);
    font-size: 13px;
  }

  .info-panel .yaml-block {
    background: var(--primary-background-color, #f5f5f5);
    border: 1px solid var(--divider-color, #e0e0e0);
    border-radius: 6px;
    padding: 10px 14px;
    margin: 8px 0;
    font-family: var(--code-font-family, monospace);
    font-size: 12px;
    line-height: 1.6;
    white-space: pre;
    overflow-x: auto;
    color: var(--primary-text-color);
  }
  .info-panel .yaml-key {
    color: #0550ae;
  }
  .info-panel .yaml-value {
    color: #0a3069;
  }
`,gr=108e5;function _r(e,t){let{hass:n,language:r,chartAnchor:i,forecast:a,isOutdoor:o}=t,s=e=>w(e,n),c=[],l=[],u=[],d=[],f=[];for(let t of e){let e=t.ts*1e3;t.room_temp!==null&&c.push([e,s(t.room_temp)]),!o&&t.target_temp!==null&&l.push([e,s(t.target_temp)]),!o&&t.predicted_temp!==null&&u.push([e,s(t.predicted_temp)]),t.outdoor_temp!==null&&d.push([e,s(t.outdoor_temp)]),!o&&t.device_setpoint!=null&&f.push([e,s(t.device_setpoint)])}for(let e of a??[]){let t=e.ts*1e3;!o&&e.target_temp!==null&&l.push([t,s(e.target_temp)]),!o&&e.predicted_temp!==null&&u.push([t,s(e.predicted_temp)])}let p=[{id:`room_temp`,type:`line`,name:S(`analytics.temperature`,r),color:`rgb(255, 152, 0)`,data:c,showSymbol:!1,smooth:!0,lineStyle:{width:2},yAxisIndex:0}];o||p.push({id:`target_temp`,type:`line`,name:S(`analytics.target`,r),color:`rgb(76, 175, 80)`,data:l,showSymbol:!1,smooth:!1,lineStyle:{width:2,type:`dashed`},yAxisIndex:0}),u.length>0&&p.push({id:`predicted_temp`,type:`line`,name:S(`analytics.prediction`,r),color:`rgb(33, 150, 243)`,data:u,showSymbol:!1,smooth:!0,lineStyle:{width:2,type:`dotted`},yAxisIndex:0}),f.length>0&&p.push({id:`device_target`,type:`line`,name:`TRV / AC`,color:`rgb(156, 39, 176)`,data:f,showSymbol:!1,smooth:!1,step:`end`,lineStyle:{width:1,type:`dashed`},yAxisIndex:0}),d.length>0&&p.push({id:`outdoor_temp`,type:`line`,name:S(`analytics.outdoor`,r),color:`rgb(158, 158, 158)`,data:d,showSymbol:!1,smooth:!0,lineStyle:{width:1},yAxisIndex:0});let ee=[],te=[],ne=[],re=!1,ie=!1,ae=!1;for(let t of e){let e=t.ts*1e3;t.mode===`heating`?(ee.push([e,999]),re=!0):ee.push([e,null]),t.mode===`cooling`?(te.push([e,999]),ie=!0):te.push([e,null]),t.window_open?(ne.push([e,999]),ae=!0):ne.push([e,null])}return re&&p.push({id:`heating_events`,type:`line`,name:S(`analytics.heating_period`,r),color:`rgb(244, 67, 54)`,data:ee,showSymbol:!1,lineStyle:{width:0},areaStyle:{color:`rgba(244, 67, 54, 0.08)`,origin:`start`},tooltip:{show:!1},yAxisIndex:0,z:-1,connectNulls:!1}),ie&&p.push({id:`cooling_events`,type:`line`,name:S(`analytics.cooling_period`,r),color:`rgb(63, 81, 181)`,data:te,showSymbol:!1,lineStyle:{width:0},areaStyle:{color:`rgba(63, 81, 181, 0.08)`,origin:`start`},tooltip:{show:!1},yAxisIndex:0,z:-1,connectNulls:!1}),ae&&p.push({id:`window_events`,type:`line`,name:S(`analytics.window_open_period`,r),color:`rgb(0, 150, 136)`,data:ne,showSymbol:!1,lineStyle:{width:0},areaStyle:{color:`rgba(0, 150, 136, 0.1)`,origin:`start`},tooltip:{show:!1},yAxisIndex:0,z:-1,connectNulls:!1}),p.push({id:`now_marker`,type:`line`,name:``,color:`rgba(255,255,255,0.3)`,data:[[i,-999],[i,999]],showSymbol:!1,lineStyle:{width:1,type:`dashed`},yAxisIndex:0,tooltip:{show:!1},z:-2}),p}function vr(e,t,n){let{hass:r,language:i,chartAnchor:a,rangeStart:o,rangeEnd:s}=n,c=C(r),l={type:`value`,name:c};if(e.length>0){let t=1/0,n=-1/0;for(let r of e)r<t&&(t=r),r>n&&(n=r);let r=n-t,i=Math.max(r*.1,.5);l.min=Math.floor((t-i)*2)/2,l.max=Math.ceil((n+i)*2)/2}return{xAxis:{type:`time`,min:o,max:Math.abs(s-Date.now())<36e5?a+gr:s},yAxis:l,dataZoom:[{type:`inside`,xAxisIndex:0,filterMode:`none`}],tooltip:{trigger:`axis`,axisPointer:{snap:!1},valueFormatter:e=>e.toFixed(1)+`\xA0`+c,formatter:e=>{if(!Array.isArray(e)||e.length===0)return``;let n=`<div style="font-weight:500;margin-bottom:4px">${new Date(e[0].value[0]).toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`})}</div>`,a=null,o=null;for(let t of e){if(t.seriesId?.endsWith(`_events`))continue;let e=t.value?.[1];e!=null&&(n+=`<div>${t.color?`<span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:${t.color};margin-right:6px"></span>`:``}${t.seriesName}: ${e.toFixed(1)}\u00A0${c}</div>`,t.seriesId===`room_temp`&&(a=e),t.seriesId===`predicted_temp`&&(o=e))}if(a!==null&&o!==null){let e=a-o;n+=`<div style="border-top:1px solid rgba(128,128,128,0.3);margin-top:4px;padding-top:4px">Delta: ${e>=0?`+`:``}${e.toFixed(2)}\u00A0${c}</div>`}if(t.length>0){let a=e[0].value[0]/1e3,o=null,s=1/0;for(let e of t){let t=Math.abs(e.ts-a);t<s&&(s=t,o=e)}if(o){let e=[];if(o.mode===`heating`){let t=o.heating_power;t!=null&&t>0&&t<100?e.push(`${S(`analytics.heating_period`,i)} ${t}%`):e.push(S(`analytics.heating_period`,i)),o.device_setpoint!=null&&e.push(`TRV ${D(o.device_setpoint,r)}\u00A0${c}`)}else o.mode===`cooling`&&(e.push(S(`analytics.cooling_period`,i)),o.device_setpoint!=null&&e.push(`AC ${D(o.device_setpoint,r)}\u00A0${c}`));o.window_open&&e.push(S(`analytics.window_open_period`,i)),e.length>0&&(n+=`<div style="border-top:1px solid rgba(128,128,128,0.3);margin-top:4px;padding-top:4px;color:rgba(255,255,255,0.7)">${e.join(` · `)}</div>`),o.blind_position!=null&&(n+=`<div style="color:rgba(255,255,255,0.7)">${S(`analytics.blind_position`,i)} ${100-o.blind_position}%</div>`)}}let s=document.createElement(`div`);return s.innerHTML=n,s}},grid:{top:15,left:10,right:10,bottom:5,containLabel:!0}}}_(),x(),j();var yr=class extends g{constructor(...e){super(...e),this.data=null,this.rangeStart=0,this.rangeEnd=0,this.chartAnchor=0,this.language=`en`,this.isOutdoor=!1,this._hiddenSeries=new Set([`outdoor_temp`,`device_target`]),this._chartInfoExpanded=!1}render(){let e=this.language,t=this.data?[...this.data.history,...this.data.detail]:[],n=[...t,...this.data?.forecast??[]],r={hass:this.hass,language:e,chartAnchor:this.chartAnchor,rangeStart:this.rangeStart,rangeEnd:this.rangeEnd,forecast:this.data?.forecast,isOutdoor:this.isOutdoor},i=t.length>0?_r(t,r):[],a=[],o=i.map(e=>{let t=e.id,n=e.lineStyle||{},r=t.endsWith(`_events`);if(this._hiddenSeries.has(t)){let t={...e,lineStyle:{...n,width:0,opacity:0}};return e.areaStyle&&(t.areaStyle={...e.areaStyle,opacity:0}),t}if(!r&&t!==`now_marker`)for(let t of e.data)t&&t[1]!=null&&a.push(t[1]);let i={...e,lineStyle:{...n,opacity:1}};return e.areaStyle&&(i.areaStyle={...e.areaStyle,opacity:1}),i}),s=vr(a,n,r);return m`
      <ha-card>
        <div class="card-header">
          <span>${S(`analytics.temperature`,e)}</span>
          <ha-icon
            class="info-icon chart-info-toggle ${this._chartInfoExpanded?`info-active`:``}"
            icon="mdi:information-outline"
            @click=${()=>{this._chartInfoExpanded=!this._chartInfoExpanded}}
          ></ha-icon>
        </div>
        ${this._chartInfoExpanded?m`<div class="chart-info-panel">
                ${this._renderMarkdown(S(`analytics.chart_info_body`,e))}
              </div>`:h}
        ${t.length>0?m`
                <ha-chart-base
                  .hass=${this.hass}
                  .data=${o}
                  .options=${s}
                  .height=${`300px`}
                  style="height: 300px"
                ></ha-chart-base>
                ${this._renderSeriesLegend(i)}
              `:m`<div class="chart-empty">
                <ha-icon icon="mdi:chart-line"></ha-icon>
                <span>${S(`analytics.no_data`,e)}</span>
              </div>`}
      </ha-card>
    `}_renderSeriesLegend(e){let t=e.filter(e=>e.id!==`now_marker`);return m`
      <div class="series-legend">
        ${t.map(e=>{let t=e.id,n=this._hiddenSeries.has(t);return m`
            <button
              class="legend-item ${n?`legend-hidden`:``}"
              @click=${()=>this._toggleSeries(t)}
            >
              <span class="legend-dot" style="background: ${e.color}"></span>
              ${e.name}
            </button>
          `})}
      </div>
    `}_renderMarkdown(e){return e.split(`

`).map(e=>m`<p>
          ${e.split(/(\*\*.*?\*\*)/).map(e=>e.startsWith(`**`)&&e.endsWith(`**`)?m`<strong>${e.slice(2,-2)}</strong>`:e)}
        </p>`)}_toggleSeries(e){let t=new Set(this._hiddenSeries);t.has(e)?t.delete(e):t.add(e),this._hiddenSeries=t}static{this.styles=[hr,l`
      :host {
        display: block;
      }

      ha-card {
        margin-bottom: 16px;
      }

      .card-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 16px 16px 0;
        font-size: 16px;
        font-weight: 500;
      }

      .chart-info-toggle {
        --mdc-icon-size: 20px;
      }

      .chart-info-panel {
        margin: 8px 16px 4px;
        padding: 12px 14px;
        border-radius: 8px;
        background: var(--secondary-background-color, rgba(128, 128, 128, 0.06));
        font-size: 13px;
        line-height: 1.6;
        color: var(--secondary-text-color);
      }

      .chart-info-panel p {
        margin: 0 0 8px;
      }

      .chart-info-panel p:last-child {
        margin-bottom: 0;
      }

      .chart-info-panel strong {
        color: var(--primary-text-color);
      }

      .series-legend {
        display: flex;
        justify-content: center;
        gap: 6px;
        padding: 8px 16px 12px;
        flex-wrap: wrap;
      }

      .legend-item {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 4px 10px;
        border: none;
        border-radius: 12px;
        background: transparent;
        color: var(--primary-text-color);
        font-size: 12px;
        font-family: inherit;
        cursor: pointer;
        transition: opacity 0.2s;
      }

      .legend-item:hover {
        background: var(--secondary-background-color, rgba(128, 128, 128, 0.1));
      }

      .legend-item.legend-hidden {
        opacity: 0.35;
      }

      .legend-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        flex-shrink: 0;
      }

      .chart-empty {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 200px;
        gap: 8px;
        color: var(--secondary-text-color);
        opacity: 0.5;
        --mdc-icon-size: 40px;
        font-size: 13px;
      }
    `]}};A([y({attribute:!1})],yr.prototype,`hass`,void 0),A([y({attribute:!1})],yr.prototype,`data`,void 0),A([y({type:Number})],yr.prototype,`rangeStart`,void 0),A([y({type:Number})],yr.prototype,`rangeEnd`,void 0),A([y({type:Number})],yr.prototype,`chartAnchor`,void 0),A([y({type:String})],yr.prototype,`language`,void 0),A([y({type:Boolean})],yr.prototype,`isOutdoor`,void 0),A([b()],yr.prototype,`_hiddenSeries`,void 0),A([b()],yr.prototype,`_chartInfoExpanded`,void 0),yr=A([v(`rs-analytics-chart`)],yr),_(),x(),j();var br=class extends g{constructor(...e){super(...e),this.data=null,this.language=`en`,this.controlMode=`mpc`,this.managed=!1,this._expandedStat=null}render(){let e=this.language,t=!!this.data?.model?.model,n=this.data?.model,r=n?.model,i=n?.confidence??0,a=n?.n_samples??0,o=n?.n_heating??0,s=n?.n_cooling??0,c=n?.applicable_modes??[],l=n?.prediction_std_idle,u=n?.prediction_std_heating,d=n?.mpc_active??!1,f=Math.round(i*100),p=new Set(c),ee=p.has(`heating`),te=p.has(`cooling`),ne=o>=10,re=s>=10,ie=a-o-s>=10,ae=n?.n_observations??a,oe=[],se=(t,n,r,i,a,o)=>{oe.push({id:t,labelKey:r,infoKey:a});let s=this._expandedStat===t;return m`
        <div class="model-stat ${s?`active`:``}" @click=${()=>this._toggleStat(t)}>
          <div class="stat-content">
            <span class="model-value ${n===`—`?`pending`:``}">${n}</span>
            <span class="model-label">${S(r,e)}${i?` (${i})`:``}</span>
            ${o?m`<span class="model-sub">${o}</span>`:h}
          </div>
          <ha-icon
            class="info-icon ${s?`info-active`:``}"
            icon="mdi:information-outline"
          ></ha-icon>
        </div>
      `};return m`
      <ha-card>
        <div class="card-header">
          <span>${S(`analytics.model_status`,e)}</span>
        </div>
        <div class="card-content">
          <div class="confidence-hero">
            <div class="confidence-top">
              <div class="confidence-main">
                <span class="confidence-value">${t?f+`%`:`0%`}</span>
                <span class="confidence-label">
                  ${S(`analytics.confidence`,e)}
                  <ha-icon
                    class="info-icon ${this._expandedStat===`confidence`?`info-active`:``}"
                    icon="mdi:information-outline"
                    @click=${()=>this._toggleStat(`confidence`)}
                  ></ha-icon>
                </span>
              </div>
              <div class="confidence-meta">
                <span class="meta-value">${t?ae:0}</span>
                <span class="meta-label">
                  ${S(`analytics.data_points`,e)}
                  <ha-icon
                    class="info-icon ${this._expandedStat===`data_points`?`info-active`:``}"
                    icon="mdi:information-outline"
                    @click=${()=>this._toggleStat(`data_points`)}
                  ></ha-icon>
                </span>
              </div>
            </div>
            <div class="confidence-bar">
              <div class="confidence-fill" style="width: ${t?f:0}%"></div>
            </div>
            ${this.managed?h:this.controlMode===`bangbang`?m`<div class="control-mode-badge bangbang">
                      <ha-icon icon="mdi:power"></ha-icon>
                      ${S(`settings.control_mode_simple`,e)}
                    </div>`:m`<div class="control-mode-badge ${d?`mpc`:`bangbang`}">
                      <ha-icon icon=${d?`mdi:brain`:`mdi:school-outline`}></ha-icon>
                      ${S(d?`analytics.control_mode_mpc`:`analytics.control_mode_bangbang`,e)}
                    </div>`}
            ${this._expandedStat===`confidence`?m`<div class="info-panel stat-info-panel">
                    <strong>${S(`analytics.confidence`,e)}</strong>
                    ${S(`analytics.info.confidence`,e)}
                  </div>`:h}
            ${this._expandedStat===`data_points`?m`<div class="info-panel stat-info-panel">
                    <strong>${S(`analytics.data_points`,e)}</strong>
                    ${S(`analytics.info.data_points`,e)}
                  </div>`:h}
          </div>

          <div class="model-grid">
            ${se(`time_constant`,ie&&r&&r.U>0?(1/r.U).toFixed(1)+`h`:`—`,`analytics.time_constant`,``,`analytics.info.time_constant`)}
            ${ee?se(`heating_rate`,ne&&r?E(r.Q_heat,this.hass).toFixed(1)+C(this.hass)+`/h`:`—`,`analytics.heating_rate`,``,`analytics.info.heating_rate`):h}
            ${te?se(`cooling_rate`,re&&r?E(r.Q_cool,this.hass).toFixed(1)+C(this.hass)+`/h`:`—`,`analytics.cooling_rate`,``,`analytics.info.cooling_rate`):h}
            ${r&&r.Q_solar>.1?se(`solar_gain`,E(r.Q_solar,this.hass).toFixed(1)+C(this.hass)+`/h`,`analytics.solar_gain`,``,`analytics.info.solar_gain`,this._solarSub(n)):h}
            ${r&&n?.has_occupancy_sensors?se(`occupancy_gain`,E(r.Q_occupancy,this.hass).toFixed(1)+C(this.hass)+`/h`,`analytics.occupancy_gain`,``,`analytics.info.occupancy_gain`):h}
            ${se(`accuracy_idle`,ie&&l!=null?`±`+E(l,this.hass).toFixed(2)+C(this.hass):`—`,`analytics.accuracy_idle`,``,`analytics.info.accuracy_idle`)}
            ${ee?se(`accuracy_heating`,ne&&u!=null?`±`+E(u,this.hass).toFixed(2)+C(this.hass):`—`,`analytics.accuracy_heating`,``,`analytics.info.accuracy_heating`):h}
          </div>
          ${this._expandedStat&&oe.find(e=>e.id===this._expandedStat)?m`<div class="info-panel stat-info-panel">
                  <strong
                    >${S(oe.find(e=>e.id===this._expandedStat).labelKey,e)}</strong
                  >
                  ${S(oe.find(e=>e.id===this._expandedStat).infoKey,e)}
                </div>`:h}
        </div>
      </ha-card>
    `}_solarSub(e){if(e?.solar_gain_now==null||e.solar_gain_today_max==null)return;let t=e=>E(e,this.hass).toFixed(1)+C(this.hass)+`/h`;return S(`analytics.solar_gain_sub`,this.language).replace(`{now}`,t(e.solar_gain_now)).replace(`{today}`,t(e.solar_gain_today_max))}_toggleStat(e){this._expandedStat=this._expandedStat===e?null:e}static{this.styles=[hr,l`
      :host {
        display: block;
      }

      ha-card {
        margin-bottom: 16px;
      }

      .card-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 16px 16px 0;
        font-size: 16px;
        font-weight: 500;
      }

      .card-content {
        padding: 16px;
      }

      .confidence-hero {
        margin-bottom: 16px;
      }

      .confidence-top {
        display: flex;
        justify-content: space-between;
        align-items: flex-end;
        margin-bottom: 8px;
      }

      .confidence-main {
        display: flex;
        align-items: baseline;
        gap: 8px;
      }

      .confidence-value {
        font-size: 28px;
        font-weight: 600;
        color: var(--primary-text-color);
      }

      .confidence-label {
        font-size: 13px;
        color: var(--secondary-text-color);
      }

      .confidence-meta {
        display: flex;
        align-items: baseline;
        gap: 6px;
      }

      .meta-value {
        font-size: 16px;
        font-weight: 500;
        color: var(--primary-text-color);
      }

      .meta-label {
        font-size: 12px;
        color: var(--secondary-text-color);
      }

      .control-mode-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        margin-top: 8px;
        padding: 4px 12px;
        border-radius: 12px;
        font-size: 12px;
        font-weight: 500;
        --mdc-icon-size: 14px;
      }

      .control-mode-badge.mpc {
        background: rgba(76, 175, 80, 0.12);
        color: var(--success-color, #4caf50);
      }

      .control-mode-badge.bangbang {
        background: rgba(158, 158, 158, 0.12);
        color: var(--secondary-text-color);
      }

      .confidence-bar {
        height: 4px;
        border-radius: 2px;
        background: var(--divider-color);
        overflow: hidden;
      }

      .confidence-fill {
        height: 100%;
        border-radius: 2px;
        background: var(--primary-color);
        transition: width 0.6s ease;
      }

      .model-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
        gap: 12px;
      }

      .model-stat {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 10px 12px;
        border-radius: 8px;
        border: 1px solid var(--divider-color);
        cursor: pointer;
        transition: border-color 0.2s;
      }

      .model-stat.active {
        border-color: var(--primary-color);
      }

      .stat-content {
        display: flex;
        flex-direction: column;
        gap: 2px;
      }

      .model-value {
        font-size: 18px;
        font-weight: 500;
        color: var(--primary-text-color);
      }

      .model-value.pending {
        opacity: 0.2;
      }

      .model-label {
        font-size: 12px;
        color: var(--secondary-text-color);
      }

      .model-sub {
        font-size: 11px;
        color: var(--secondary-text-color);
      }

      .info-panel.stat-info-panel {
        margin-top: 12px;
      }

      @media (max-width: 600px) {
        .model-grid {
          grid-template-columns: repeat(2, 1fr);
          gap: 8px;
        }
      }
    `]}};A([y({attribute:!1})],br.prototype,`hass`,void 0),A([y({attribute:!1})],br.prototype,`data`,void 0),A([y({type:String})],br.prototype,`language`,void 0),A([y({type:String})],br.prototype,`controlMode`,void 0),A([y({type:Boolean})],br.prototype,`managed`,void 0),A([b()],br.prototype,`_expandedStat`,void 0),br=A([v(`rs-analytics-model`)],br),_(),x(),j();var Q=class extends g{constructor(...e){super(...e),this.rooms={},this.initialRoom=``,this.controlMode=`mpc`,this._selectedRoom=``,this._rangeStart=new Date(new Date().setHours(0,0,0,0)).getTime(),this._rangeEnd=Date.now(),this._data=null,this._chartAnchor=Date.now(),this._loading=!1,this._activeQuick=`24h`}connectedCallback(){super.connectedCallback(),this._refreshInterval=setInterval(()=>this._silentRefresh(),6e4)}disconnectedCallback(){super.disconnectedCallback(),this._refreshInterval&&=(clearInterval(this._refreshInterval),void 0)}willUpdate(e){e.has(`initialRoom`)&&this.initialRoom&&(this._selectedRoom=this.initialRoom);let t=!1;if(e.has(`rooms`)&&!this._selectedRoom){let e=Object.keys(this.rooms);e.length>0&&(this._selectedRoom=e[0],t=!0,this.dispatchEvent(new CustomEvent(`room-selected`,{detail:{areaId:e[0]},bubbles:!0,composed:!0})))}(t||e.has(`_selectedRoom`)||e.has(`_rangeStart`)||e.has(`_rangeEnd`))&&this._selectedRoom&&this._fetchData()}render(){let e=this.hass.language;return m`
      <rs-analytics-toolbar
        .hass=${this.hass}
        .rooms=${this.rooms}
        .selectedRoom=${this._selectedRoom}
        .rangeStart=${this._rangeStart}
        .rangeEnd=${this._rangeEnd}
        .activeQuick=${this._activeQuick}
        .data=${this._data}
        .language=${e}
        @room-selected=${this._onRoomSelected}
        @range-changed=${this._onRangeChanged}
      ></rs-analytics-toolbar>
      ${this._selectedRoom?this._loading?m`<div class="loading">${S(`panel.loading`,e)}</div>`:m`
                <rs-analytics-chart
                  .hass=${this.hass}
                  .data=${this._data}
                  .rangeStart=${this._rangeStart}
                  .rangeEnd=${this._rangeEnd}
                  .chartAnchor=${this._chartAnchor}
                  .language=${e}
                  .isOutdoor=${this.rooms[this._selectedRoom]?.is_outdoor??!1}
                ></rs-analytics-chart>
                ${this.rooms[this._selectedRoom]?.is_outdoor?h:m` <rs-analytics-model
                        .hass=${this.hass}
                        .data=${this._data}
                        .language=${e}
                        .controlMode=${this.controlMode}
                        .managed=${!this.rooms[this._selectedRoom]?.temperature_sensor}
                      ></rs-analytics-model>`}
              `:m`
              <div class="no-data">
                <ha-icon
                  icon="mdi:chart-line"
                  style="--mdc-icon-size: 48px; opacity: 0.4"
                ></ha-icon>
                <p>${S(`analytics.select_room`,e)}</p>
              </div>
            `}
    `}_onRoomSelected(e){let t=e.detail.areaId;t&&t!==this._selectedRoom&&(this._selectedRoom=t,this.dispatchEvent(new CustomEvent(`room-selected`,{detail:{areaId:t},bubbles:!0,composed:!0})))}_onRangeChanged(e){let{activeQuick:t,rangeStart:n,rangeEnd:r,chartAnchor:i}=e.detail;this._activeQuick=t,this._rangeStart=n,this._rangeEnd=r,this._chartAnchor=i}_buildWsParams(){return{type:`roommind/analytics/get`,area_id:this._selectedRoom,start_ts:this._rangeStart/1e3,end_ts:this._rangeEnd/1e3}}async _fetchData(){if(this._selectedRoom){this._loading=!0,this._data=null,this._chartAnchor=this._rangeEnd;try{let e=await this.hass.callWS(this._buildWsParams());this._data=e}catch(e){console.debug(`[RoomMind] fetchData:`,e),this._data=null}finally{this._loading=!1}}}async _silentRefresh(){if(this._selectedRoom&&!this._loading)try{let e=await this.hass.callWS(this._buildWsParams());this._data=e,this._chartAnchor=Date.now()}catch(e){console.debug(`[RoomMind] silentRefresh:`,e)}}static{this.styles=l`
    :host {
      display: block;
    }

    .no-data {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 80px 16px;
      text-align: center;
      color: var(--secondary-text-color);
    }

    .no-data p {
      font-size: 15px;
      max-width: 400px;
      line-height: 1.5;
      margin-top: 16px;
    }

    .loading {
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 80px 16px;
      color: var(--secondary-text-color);
      font-size: 14px;
    }
  `}};A([y({attribute:!1})],Q.prototype,`hass`,void 0),A([y({type:Object})],Q.prototype,`rooms`,void 0),A([y()],Q.prototype,`initialRoom`,void 0),A([y()],Q.prototype,`controlMode`,void 0),A([b()],Q.prototype,`_selectedRoom`,void 0),A([b()],Q.prototype,`_rangeStart`,void 0),A([b()],Q.prototype,`_rangeEnd`,void 0),A([b()],Q.prototype,`_data`,void 0),A([b()],Q.prototype,`_chartAnchor`,void 0),A([b()],Q.prototype,`_loading`,void 0),A([b()],Q.prototype,`_activeQuick`,void 0),Q=A([v(`rs-analytics`)],Q),_(),x(),j();var xr=`M20,11V13H8L13.5,18.5L12.08,19.92L4.16,12L12.08,4.08L13.5,5.5L8,11H20Z`,Sr=`M19,4H15.5L14.5,3H9.5L8.5,4H5V6H19M6,19A2,2 0 0,0 8,21H16A2,2 0 0,0 18,19V7H6V19Z`,Cr=`M16,11.78L20.24,4.45L21.97,5.45L16.74,14.5L10.23,10.75L5.46,19H22V21H2V3H4V17.54L9.5,8L16,11.78Z`,wr=`M15 13V5A3 3 0 0 0 9 5V13A5 5 0 1 0 15 13M12 4A1 1 0 0 1 13 5V8H11V5A1 1 0 0 1 12 4Z`;function Tr(e,t){return JSON.stringify(e)===JSON.stringify(t)?e:t}function Er(e,t){let n={},r=Object.keys(e).length!==Object.keys(t).length;for(let[i,a]of Object.entries(t)){let t=e[i];t&&JSON.stringify(t)===JSON.stringify(a)?n[i]=t:(n[i]=a,r=!0)}return r?n:e}var $=class extends g{constructor(...e){super(...e),this.narrow=!1,this.route={path:``},this.panel={},this._activeTab=`areas`,this._rooms={},this._roomsLoaded=!1,this._selectedAreaId=null,this._analyticsRoom=``,this._vacationActive=!1,this._vacationTemp=null,this._vacationUntil=null,this._hiddenRooms=[],this._showHiddenRooms=!1,this._controlMode=`mpc`,this._climateControlActive=!0,this._presenceEnabled=!1,this._valveProtectionEnabled=!1,this._coilDryEnabled=!1,this._coilDryMinutes=20,this._coilDryMode=`fan_only`,this._coilDryFanMode=`low`,this._anyoneHome=!0,this._presencePersons=[],this._presenceAwayAction=`eco`,this._saveStatus=`idle`,this._roomOrder=[],this._groupByFloor=!1,this._reorderMode=!1,this._elementsLoaded=!1,this._compressorRelease={},this._routeApplied=!1,this._areaInfosCache=[],this._areaInfosKey=[],this._loadRoomsInFlight=!1,this._onSaveStatus=e=>{e.stopPropagation(),this._saveStatusTimeout&&clearTimeout(this._saveStatusTimeout),this._saveStatus=e.detail.status,e.detail.status===`saved`&&(this._saveStatusTimeout=setTimeout(()=>{this._saveStatus=`idle`},2e3))}}static{this.styles=l`
    :host {
      display: block;
      font-family: var(--primary-font-family, Roboto, sans-serif);
      color: var(--primary-text-color);
      background: var(--primary-background-color);
      min-height: 100vh;

      /* Round the corners of all MDC-based inputs (ha-textfield, ha-select,
         ha-entity-picker, ha-combo-box) to match the rest of the design.
         The bottom corners are rounded via inputStyles in each component. */
      --mdc-shape-small: 8px;
      --mdc-shape-medium: 8px;
      --md-filled-text-field-container-shape: 8px;
      --md-outlined-text-field-container-shape: 8px;
    }

    .toolbar {
      display: flex;
      align-items: center;
      height: 56px;
      padding: 0 12px;
      font-size: 20px;
      background-color: var(--app-header-background-color, var(--primary-background-color));
      color: var(--app-header-text-color, var(--primary-text-color));
      border-bottom: 1px solid var(--divider-color);
      box-sizing: border-box;
      position: sticky;
      top: 0;
      z-index: 4;
    }

    .toolbar .title {
      margin-left: 4px;
      font-weight: 400;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      flex: 1;
    }

    .toolbar ha-icon-button {
      color: var(--app-header-text-color, var(--primary-text-color));
    }

    .save-indicator {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      font-size: 13px;
      font-weight: 400;
      margin-right: 8px;
      opacity: 1;
      transition: opacity 0.3s ease;
    }

    .save-indicator.fade-out {
      opacity: 0;
    }

    .save-indicator ha-icon {
      --mdc-icon-size: 18px;
    }

    .save-indicator.saving {
      color: var(--primary-color, #03a9f4);
    }

    .save-indicator.saved {
      color: var(--success-color, #4caf50);
    }

    .save-indicator.error {
      color: var(--error-color, #d32f2f);
    }

    .tabs {
      display: flex;
      gap: 0;
      border-bottom: 1px solid var(--divider-color);
      padding: 0 16px;
      background: var(--primary-background-color);
      position: sticky;
      top: 56px;
      z-index: 3;
    }

    .tab {
      padding: 12px 24px;
      cursor: pointer;
      border: none;
      background: none;
      color: var(--secondary-text-color);
      font-size: 14px;
      font-weight: 500;
      border-bottom: 2px solid transparent;
      transition: all 0.2s ease;
      font-family: inherit;
    }

    .tab:hover {
      color: var(--primary-text-color);
    }

    .tab[active] {
      color: var(--primary-color);
      border-bottom-color: var(--primary-color);
    }

    .content {
      padding: 24px;
      max-width: 1200px;
      margin: 0 auto;
      box-sizing: border-box;
    }

    @media (max-width: 600px) {
      .content {
        padding: 16px;
      }
    }

    .placeholder {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 80px 16px;
      text-align: center;
      color: var(--secondary-text-color);
    }

    .placeholder ha-icon {
      margin-bottom: 16px;
    }

    .placeholder p {
      font-size: 15px;
      max-width: 400px;
      line-height: 1.5;
    }

    .area-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(min(360px, 100%), 1fr));
      gap: 16px;
    }

    .loading {
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 80px 16px;
      color: var(--secondary-text-color);
      font-size: 14px;
    }

    .stats-separator {
      width: 1px;
      height: 28px;
      background: var(--divider-color, #444);
      margin: 0 4px;
      flex-shrink: 0;
    }

    .stats-bar {
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      gap: 12px 24px;
      margin-bottom: 20px;
      padding: 12px 16px;
    }

    .stats-actions {
      display: flex;
      align-items: center;
      margin-left: auto;
      gap: 0;
    }

    .hidden-rooms-toggle {
      --mdc-icon-button-size: 36px;
      --mdc-icon-size: 20px;
      color: var(--secondary-text-color);
    }

    .hidden-rooms-panel {
      margin-bottom: 20px;
      padding: 12px 16px;
    }

    .hidden-rooms-header {
      font-size: 13px;
      font-weight: 500;
      color: var(--secondary-text-color);
      margin-bottom: 8px;
    }

    .hidden-room-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 6px 0;
    }

    .hidden-room-name {
      font-size: 14px;
      color: var(--primary-text-color);
    }

    .stat {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }

    .stat-value {
      font-size: 20px;
      font-weight: 500;
      color: var(--primary-text-color);
      --mdc-icon-size: 22px;
      line-height: 1;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-height: 24px;
    }

    .stat-label {
      font-size: 12px;
      color: var(--secondary-text-color);
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .floor-heading {
      font-size: 14px;
      font-weight: 500;
      color: var(--secondary-text-color);
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin: 20px 0 8px 0;
    }

    .floor-heading:first-of-type {
      margin-top: 0;
    }

    .reorder-btn {
      --mdc-icon-button-size: 36px;
      --mdc-icon-size: 20px;
      color: var(--secondary-text-color);
    }

    .reorder-done {
      font-size: 14px;
      margin-left: auto;
    }
  `}connectedCallback(){super.connectedCallback(),Pn().then(()=>{this._elementsLoaded=!0}),this._loadRooms(),this._refreshInterval=setInterval(()=>this._pollRooms(),5e3),this.addEventListener(`save-status`,this._onSaveStatus),this._routeApplied||=(this._applyRoute(),!0),this._boundVisibilityHandler||(this._boundVisibilityHandler=()=>{document.hidden||(this.isConnected?(this._loadRooms(),this.requestUpdate()):window.location.reload())},document.addEventListener(`visibilitychange`,this._boundVisibilityHandler))}disconnectedCallback(){super.disconnectedCallback(),this._refreshInterval&&=(clearInterval(this._refreshInterval),void 0),this._saveStatusTimeout&&clearTimeout(this._saveStatusTimeout),this.removeEventListener(`save-status`,this._onSaveStatus),this._boundConnectionReady&&=(this.hass?.connection?.removeEventListener(`ready`,this._boundConnectionReady),void 0)}render(){if(!this._elementsLoaded||!this.hass)return m``;let e=this.hass.language,t=!!this._selectedAreaId,n=t?this.hass?.areas?.[this._selectedAreaId]:null,r={areas:S(`panel.tab.rooms`,e),heating:S(`panel.tab.heating`,e),analytics:S(`tabs.analytics`,e),settings:S(`panel.tab.settings`,e)};return m`
      <div class="toolbar">
        ${t?m`<ha-icon-button
                .path=${xr}
                @click=${this._onBackFromDetail}
              ></ha-icon-button>`:m`<ha-menu-button .hass=${this.hass} .narrow=${this.narrow}></ha-menu-button>`}
        <div class="title">
          ${t?this._rooms[this._selectedAreaId]?.display_name||n?.name||``:S(`panel.title`,e)}
        </div>
        ${this._renderSaveIndicator()}
        ${t&&this._rooms[this._selectedAreaId]?m`<ha-icon-button
                  .path=${Cr}
                  @click=${this._onGoToAnalytics}
                ></ha-icon-button
                ><ha-icon-button
                  .path=${Sr}
                  @click=${this._onDeleteRoom}
                ></ha-icon-button>`:h}
        ${!t&&this._activeTab===`analytics`&&this._analyticsRoom?m`<ha-icon-button
                .path=${wr}
                @click=${this._onGoToRoomFromAnalytics}
              ></ha-icon-button>`:h}
      </div>

      ${t?h:m`
              <div class="tabs">
                ${Object.keys(r).map(e=>m`
                    <button
                      class="tab"
                      ?active=${this._activeTab===e}
                      @click=${()=>this._onTabClicked(e)}
                    >
                      ${r[e]}
                    </button>
                  `)}
              </div>
            `}

      <div class="content">${this._renderTab()}</div>
    `}_renderTab(){switch(this._activeTab){case`areas`:return this._renderAreas();case`analytics`:return m`<rs-analytics
          .hass=${this.hass}
          .rooms=${this._rooms}
          .initialRoom=${this._analyticsRoom}
          .controlMode=${this._controlMode}
          @room-selected=${this._onAnalyticsRoomSelected}
        ></rs-analytics>`;case`heating`:return m`<rs-heating
          .hass=${this.hass}
          .releaseStatus=${this._compressorRelease}
        ></rs-heating>`;case`settings`:return this._renderSettings();default:return h}}_renderAreas(){if(!this._roomsLoaded)return m`<div class="loading">${S(`panel.loading`,this.hass.language)}</div>`;if(this._selectedAreaId){let e=this.hass?.areas?.[this._selectedAreaId];if(e){let t=this._rooms[this._selectedAreaId]??null;return m`
          <rs-room-detail
            .area=${e}
            .config=${t}
            .hass=${this.hass}
            .presenceEnabled=${this._presenceEnabled}
            .presencePersons=${this._presencePersons}
            .climateControlActive=${this._climateControlActive}
            .valveProtectionEnabled=${this._valveProtectionEnabled}
            .coilDryEnabled=${this._coilDryEnabled}
            .coilDryMinutes=${this._coilDryMinutes}
            .coilDryMode=${this._coilDryMode}
            .coilDryFanMode=${this._coilDryFanMode}
            @back-clicked=${this._onBackFromDetail}
            @room-updated=${this._onRoomUpdated}
          ></rs-room-detail>
        `}this._selectedAreaId=null}let e=this._areaInfosCache,t=e.filter(e=>!this._hiddenRooms.includes(e.area.area_id)),n=e.filter(e=>this._hiddenRooms.includes(e.area.area_id));if(e.length===0)return m`
        <div class="placeholder">
          <ha-icon icon="mdi:home" style="--mdc-icon-size: 56px; opacity: 0.4"></ha-icon>
          <p>
            ${S(`panel.no_areas`,this.hass.language)}<br />${S(`panel.no_areas_hint`,this.hass.language)}
          </p>
        </div>
      `;let r=t.filter(e=>e.config).length,i=t.filter(e=>e.config?.live?.mode===`heating`).length,a=t.filter(e=>e.config?.live?.mode===`cooling`).length,o=t.filter(e=>e.config?.live?.mold_risk_level===`warning`||e.config?.live?.mold_risk_level===`critical`).length,s=this._vacationActive||this._presenceEnabled&&!this._anyoneHome||o>0,c=this.hass.language;return m`
      ${r>0||n.length>0?m`
              <ha-card class="stats-bar">
                ${r>0?m`
                        <div class="stat">
                          <span class="stat-value">${r}</span>
                          <span class="stat-label">${S(`panel.stat.rooms`,c)}</span>
                        </div>
                        <div class="stat">
                          <span class="stat-value" style="color: var(--warning-color, #ff9800)"
                            >${i}</span
                          >
                          <span class="stat-label">${S(`panel.stat.heating`,c)}</span>
                        </div>
                        <div class="stat">
                          <span class="stat-value" style="color: var(--info-color, #2196f3)"
                            >${a}</span
                          >
                          <span class="stat-label">${S(`panel.stat.cooling`,c)}</span>
                        </div>
                      `:h}
                ${s?m`<div class="stats-separator"></div>`:h}
                ${this._vacationActive?m`
                        <div class="stat">
                          <span class="stat-value" style="color: var(--success-color, #4caf50)">
                            <ha-icon icon="mdi:airplane"></ha-icon>
                          </span>
                          <span class="stat-label">${S(`panel.stat.vacation`,c)}</span>
                        </div>
                      `:h}
                ${this._presenceEnabled&&!this._anyoneHome?m`
                        <div class="stat">
                          <span class="stat-value" style="color: var(--secondary-text-color)">
                            <ha-icon icon="mdi:power"></ha-icon>
                          </span>
                          <span class="stat-label">${S(`panel.stat.away`,c)}</span>
                        </div>
                      `:h}
                ${o>0?m`
                        <div class="stat">
                          <span class="stat-value" style="color: var(--error-color, #f44336)"
                            >${o}</span
                          >
                          <span class="stat-label">${S(`panel.stat.mold`,c)}</span>
                        </div>
                      `:h}
                <span class="stats-actions">
                  ${n.length>0?m`<ha-icon-button
                          class="hidden-rooms-toggle"
                          .path=${Et}
                          @click=${()=>{this._showHiddenRooms=!this._showHiddenRooms}}
                        ></ha-icon-button>`:h}
                  ${this._reorderMode?m`<ha-button class="reorder-done" @click=${this._onReorderDone}>
                          ${S(`panel.reorder_done`,c)}
                        </ha-button>`:m`<ha-icon-button
                          class="reorder-btn"
                          .path=${`M9,3L5,7H8V14H10V7H13M16,17V10H14V17H11L15,21L19,17H16Z`}
                          @click=${()=>{this._reorderMode=!0}}
                          title=${S(`panel.reorder`,c)}
                        ></ha-icon-button>`}
                </span>
              </ha-card>
            `:h}
      ${this._showHiddenRooms&&n.length>0?m`
              <ha-card class="hidden-rooms-panel">
                <div class="hidden-rooms-header">
                  <span>${S(`panel.hidden_rooms`,c)} (${n.length})</span>
                </div>
                ${n.map(e=>m`
                    <div class="hidden-room-row">
                      <span class="hidden-room-name">${e.area.name}</span>
                      <ha-button @click=${()=>this._unhideRoom(e.area.area_id)}>
                        ${S(`panel.unhide`,c)}
                      </ha-button>
                    </div>
                  `)}
              </ha-card>
            `:h}
      ${this._getFloorGroups(t).map(e=>m`
          ${e.name?m`<h4 class="floor-heading">${e.name}</h4>`:h}
          <div class="area-grid">
            ${e.items.map((t,n)=>m`
                <rs-area-card
                  .area=${t.area}
                  .config=${t.config}
                  .climateEntityCount=${t.climateEntityCount}
                  .tempSensorCount=${t.tempSensorCount}
                  .hass=${this.hass}
                  .controlMode=${this._controlMode}
                  .climateControlActive=${this._climateControlActive}
                  .reordering=${this._reorderMode}
                  .canMoveUp=${n>0}
                  .canMoveDown=${n<e.items.length-1}
                  @area-selected=${this._onAreaSelected}
                  @hide-room=${this._onHideRoom}
                  @move-room-up=${this._onMoveRoomUp}
                  @move-room-down=${this._onMoveRoomDown}
                ></rs-area-card>
              `)}
          </div>
        `)}
    `}_renderSettings(){return m`<rs-settings
      .hass=${this.hass}
      .rooms=${this._rooms}
      .compressorRelease=${this._compressorRelease}
    ></rs-settings>`}_computeAreaInfos(){if(!this.hass?.areas)return[];let e=Object.values(this.hass.areas).map(e=>{let t=bt(e.area_id,this.hass.entities,this.hass.devices).filter(e=>!e.entity_id.substring(e.entity_id.indexOf(`.`)+1).startsWith(`roommind_`)),n=t.filter(e=>e.entity_id.startsWith(`climate.`)).length,r=t.filter(e=>e.entity_id.startsWith(`sensor.`)&&this.hass.states[e.entity_id]?.attributes?.device_class===`temperature`).length;return{area:e,config:this._rooms[e.area_id]??null,climateEntityCount:n,tempSensorCount:r}}),t=new Map(this._roomOrder.map((e,t)=>[e,t]));return e.sort((e,n)=>{let r=t.get(e.area.area_id),i=t.get(n.area.area_id);if(r!==void 0&&i!==void 0)return r-i;if(r!==void 0)return-1;if(i!==void 0)return 1;let a=e.config?2:+(e.climateEntityCount>0),o=n.config?2:+(n.climateEntityCount>0);return a===o?e.area.name.localeCompare(n.area.name):o-a}),e}_getFloorGroups(e){if(!this._groupByFloor||!this.hass.floors)return[{name:``,items:e}];let t=this.hass.floors,n=this.hass.language,r=new Map,i=[];for(let t of e){let e=t.area.floor_id??null;r.has(e)||(r.set(e,[]),i.push(e)),r.get(e).push(t)}return i.sort((e,n)=>{if(e===null)return 1;if(n===null)return-1;let r=t[e],i=t[n];return r?.level!=null&&i?.level!=null?i.level-r.level:r?.level==null?i?.level==null?(r?.name??``).localeCompare(i?.name??``):1:-1}),i.map(e=>({name:e===null?S(`panel.floor_other`,n):t[e]?.name??S(`panel.floor_other`,n),items:r.get(e)}))}_pollRooms(){document.hidden||this._loadRoomsInFlight||this._loadRooms()}async _loadRooms(){if(this.hass){this._loadRoomsInFlight=!0;try{let e=await this.hass.callWS({type:`roommind/rooms/list`});this._rooms=Er(this._rooms,e.rooms),this._compressorRelease=Tr(this._compressorRelease,e.compressor_release??{}),this._vacationActive=e.vacation_active??!1,this._vacationTemp=e.vacation_temp??null,this._vacationUntil=e.vacation_until??null,this._hiddenRooms=Tr(this._hiddenRooms,e.hidden_rooms??[]),this._roomOrder=Tr(this._roomOrder,e.room_order??[]),this._groupByFloor=e.group_by_floor??!1,this._controlMode=e.control_mode??`mpc`,this._climateControlActive=e.climate_control_active??!0,this._presenceEnabled=e.presence_enabled??!1,this._valveProtectionEnabled=e.valve_protection_enabled??!1,this._coilDryEnabled=e.coil_dry_enabled??!1,this._coilDryMinutes=e.coil_dry_minutes??20,this._coilDryMode=e.coil_dry_mode??`fan_only`,this._coilDryFanMode=e.coil_dry_fan_mode??`low`,this._anyoneHome=e.anyone_home??!0,this._presencePersons=Tr(this._presencePersons,e.presence_persons??[]),this._presenceAwayAction=e.presence_away_action??`eco`}catch(e){console.debug(`[RoomMind] loadRooms:`,e)}finally{this._loadRoomsInFlight=!1,this._roomsLoaded=!0}}}_onBackFromDetail(){this._selectedAreaId=null,this._navigate(``)}async _onDeleteRoom(){if(!this._selectedAreaId)return;let e=this.hass?.areas?.[this._selectedAreaId];if(e&&confirm(S(`room.confirm_delete`,this.hass.language,{name:e.name})))try{await this.hass.callWS({type:`roommind/rooms/delete`,area_id:this._selectedAreaId}),this._selectedAreaId=null,this._navigate(``),this._loadRooms()}catch(e){console.debug(`[RoomMind] deleteRoom:`,e)}}_onTabClicked(e){this._activeTab=e,this._selectedAreaId=null,e===`areas`?this._navigate(``):this._navigate(`/${e}`)}_onAreaSelected(e){this._selectedAreaId=e.detail.areaId,this._navigate(`/room/${e.detail.areaId}`)}async _onHideRoom(e){let t=[...new Set([...this._hiddenRooms,e.detail.areaId])];this._hiddenRooms=t;try{await this.hass.callWS({type:`roommind/settings/save`,hidden_rooms:t})}catch(e){console.debug(`[RoomMind] hideRoom:`,e)}}async _unhideRoom(e){let t=this._hiddenRooms.filter(t=>t!==e);this._hiddenRooms=t,t.length===0&&(this._showHiddenRooms=!1);try{await this.hass.callWS({type:`roommind/settings/save`,hidden_rooms:t})}catch(e){console.debug(`[RoomMind] unhideRoom:`,e)}}_onGoToAnalytics(){this._selectedAreaId&&(this._analyticsRoom=this._selectedAreaId,this._selectedAreaId=null,this._activeTab=`analytics`,this._navigate(`/analytics/${this._analyticsRoom}`))}_onGoToRoomFromAnalytics(){this._analyticsRoom&&(this._selectedAreaId=this._analyticsRoom,this._activeTab=`areas`,this._navigate(`/room/${this._analyticsRoom}`))}_onAnalyticsRoomSelected(e){this._analyticsRoom=e.detail.areaId,this._navigate(`/analytics/${e.detail.areaId}`)}async _onMoveRoomUp(e){this._moveRoom(e.detail.areaId,-1)}async _onMoveRoomDown(e){this._moveRoom(e.detail.areaId,1)}async _moveRoom(e,t){let n=this._areaInfosCache.filter(e=>!this._hiddenRooms.includes(e.area.area_id));if(this._groupByFloor&&this.hass.floors){let r=this._getFloorGroups(n);for(let n of r){let i=n.items.map(e=>e.area.area_id),a=i.indexOf(e);if(a===-1)continue;let o=a+t;if(o<0||o>=i.length)return;[i[a],i[o]]=[i[o],i[a]];let s=r.flatMap(e=>e===n?i:e.items.map(e=>e.area.area_id));await this._saveRoomOrder(s);return}}else{let r=n.map(e=>e.area.area_id),i=r.indexOf(e);if(i===-1)return;let a=i+t;if(a<0||a>=r.length)return;[r[i],r[a]]=[r[a],r[i]],await this._saveRoomOrder(r)}}async _saveRoomOrder(e){this._roomOrder=e,this._areaInfosCache=this._computeAreaInfos();try{await this.hass.callWS({type:`roommind/settings/save`,room_order:e})}catch(e){console.debug(`[RoomMind] saveRoomOrder:`,e)}}_onReorderDone(){this._reorderMode=!1}_onRoomUpdated(){this._loadRooms()}_renderSaveIndicator(){if(this._saveStatus===`idle`)return h;let e=this.hass.language,t=this._saveStatus===`saving`?`mdi:content-save-outline`:this._saveStatus===`saved`?`mdi:check`:`mdi:alert-circle-outline`,n=this._saveStatus===`saving`?S(`settings.saving`,e):this._saveStatus===`saved`?S(`settings.saved`,e):S(`settings.error`,e);return m`
      <span class="save-indicator ${this._saveStatus}">
        <ha-icon .icon=${t}></ha-icon>
        ${n}
      </span>
    `}willUpdate(e){if(e.has(`route`)&&this._routeApplied&&this._applyRoute(),e.has(`_rooms`)||e.has(`hass`)){let e=[this._rooms,this.hass?.areas,this.hass?.entities,this.hass?.devices,this.hass?Object.keys(this.hass.states).length:0];e.some((e,t)=>e!==this._areaInfosKey[t])&&(this._areaInfosKey=e,this._areaInfosCache=this._computeAreaInfos())}}updated(e){e.has(`hass`)&&this.hass&&!this._roomsLoaded&&this._loadRooms(),e.has(`hass`)&&this.hass?.connection&&!this._boundConnectionReady&&(this._boundConnectionReady=()=>{this._loadRooms(),this.requestUpdate()},this.hass.connection.addEventListener(`ready`,this._boundConnectionReady))}_navigate(e){history.replaceState(null,``,`/roommind${e}`),window.dispatchEvent(new Event(`location-changed`))}_applyRoute(){let e=this.route?.path??``;e.startsWith(`/room/`)?(this._activeTab=`areas`,this._selectedAreaId=decodeURIComponent(e.slice(6))):e.startsWith(`/analytics/`)?(this._activeTab=`analytics`,this._selectedAreaId=null,this._analyticsRoom=decodeURIComponent(e.slice(11))):e===`/analytics`?(this._activeTab=`analytics`,this._selectedAreaId=null,this._analyticsRoom=``):e===`/heating`?(this._activeTab=`heating`,this._selectedAreaId=null):e===`/settings`?(this._activeTab=`settings`,this._selectedAreaId=null):(this._activeTab=`areas`,this._selectedAreaId=null)}};A([y({attribute:!1})],$.prototype,`hass`,void 0),A([y({type:Boolean,reflect:!0})],$.prototype,`narrow`,void 0),A([y({type:Object})],$.prototype,`route`,void 0),A([y({type:Object})],$.prototype,`panel`,void 0),A([b()],$.prototype,`_activeTab`,void 0),A([b()],$.prototype,`_rooms`,void 0),A([b()],$.prototype,`_roomsLoaded`,void 0),A([b()],$.prototype,`_selectedAreaId`,void 0),A([b()],$.prototype,`_analyticsRoom`,void 0),A([b()],$.prototype,`_vacationActive`,void 0),A([b()],$.prototype,`_vacationTemp`,void 0),A([b()],$.prototype,`_vacationUntil`,void 0),A([b()],$.prototype,`_hiddenRooms`,void 0),A([b()],$.prototype,`_showHiddenRooms`,void 0),A([b()],$.prototype,`_controlMode`,void 0),A([b()],$.prototype,`_climateControlActive`,void 0),A([b()],$.prototype,`_presenceEnabled`,void 0),A([b()],$.prototype,`_valveProtectionEnabled`,void 0),A([b()],$.prototype,`_coilDryEnabled`,void 0),A([b()],$.prototype,`_coilDryMinutes`,void 0),A([b()],$.prototype,`_coilDryMode`,void 0),A([b()],$.prototype,`_coilDryFanMode`,void 0),A([b()],$.prototype,`_anyoneHome`,void 0),A([b()],$.prototype,`_presencePersons`,void 0),A([b()],$.prototype,`_presenceAwayAction`,void 0),A([b()],$.prototype,`_saveStatus`,void 0),A([b()],$.prototype,`_roomOrder`,void 0),A([b()],$.prototype,`_groupByFloor`,void 0),A([b()],$.prototype,`_reorderMode`,void 0),A([b()],$.prototype,`_elementsLoaded`,void 0),A([b()],$.prototype,`_compressorRelease`,void 0),$=A([v(`roommind-panel`)],$)})();