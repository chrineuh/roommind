"""Cover/blind manager for RoomMind smart home control."""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, replace

from homeassistant.core import HomeAssistant

from ..const import (
    COVER_HYSTERESIS,
    COVER_MAX_EFFECTIVENESS,
    COVER_MIN_HOLD_SECONDS,
    COVER_POS_DEADBAND,
    COVER_POS_SCALE,
    COVER_REOPEN_HOLD_SECONDS,
    COVER_REOPEN_STEP,
    COVER_SOLAR_MIN,
    COVER_TRANSITION_SETTLE_S,
    COVER_USER_CONFLICT_THRESHOLD,
    COVER_USER_OVERRIDE_MINUTES,
)

_LOGGER = logging.getLogger(__name__)

# HA cover supported_features bit for SET_POSITION
_SUPPORT_SET_POSITION = 4


def compute_shading_factor(
    positions: list[int],
    max_effectiveness: float = COVER_MAX_EFFECTIVENESS,
) -> float:
    """Compute solar shading factor [0..1] from cover positions.

    HA convention: position 0 = fully closed, 100 = fully open.
    Returns 1.0 when fully open (no shading), (1-max_effectiveness) when fully closed.
    """
    if not positions:
        return 1.0
    avg = sum(positions) / len(positions)
    return 1.0 - max_effectiveness * (1.0 - avg / 100.0)


@dataclass
class CoverDecision:
    """Result of CoverManager.evaluate() for a single room."""

    target_position: int  # 0-100 (HA: 0=closed, 100=open)
    changed: bool  # True if caller should call HA service
    reason: str  # For debug logging


@dataclass
class _RoomCoverState:
    """Per-room mutable state."""

    current_position: int = 100
    last_change_ts: float = 0.0  # 0 = never changed, allows first action immediately
    last_commanded_position: int | None = None  # None = never commanded yet
    user_override_until: float = 0.0  # Unix timestamp; 0 = no override
    last_was_forced: bool = False  # True after forced position (schedule/night close)
    last_command_ts: float = 0.0  # timestamp of last issued command (for transit settling)
    owned: bool = False  # current position was produced by RoomMind
    baseline_position: int | None = None  # position before first deploy of a shading episode
    travel_from: int | None = None  # real reading at command time (travel corridor anchor)
    last_reading: int | None = None  # last real reading; never overwritten by commands
    drift_latched: bool = False  # current drift episode already armed an override once


class CoverManager:
    """Manages automatic blind/cover control per room."""

    def __init__(self) -> None:
        self._states: dict[str, _RoomCoverState] = {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def update_position(self, area_id: str, position: int, override_minutes: int = COVER_USER_OVERRIDE_MINUTES) -> None:
        """Update the tracked position from HA state. Call before evaluate().

        Detects user manual moves by comparing readings against the last
        commanded position. Movement along the travel corridor toward the
        target is RoomMind's own motion. Anything else arms a user override
        for ``override_minutes``, releases RoomMind's ownership of the
        position and drops the shading baseline.
        """
        state = self._get_state(area_id)
        prev = state.last_reading
        state.last_reading = position
        state.current_position = position

        if override_minutes <= 0 or state.last_commanded_position is None:
            return

        now = time.time()
        target = state.last_commanded_position

        if abs(position - target) <= COVER_USER_CONFLICT_THRESHOLD:
            state.travel_from = None
            state.drift_latched = False
            return

        moved = prev is not None and position != prev

        if moved and state.travel_from is not None and prev is not None:
            lo = min(state.travel_from, target) - COVER_USER_CONFLICT_THRESHOLD
            hi = max(state.travel_from, target) + COVER_USER_CONFLICT_THRESHOLD
            if lo <= position <= hi and abs(position - target) < abs(prev - target):
                return

        if not moved and (now - state.last_command_ts) < COVER_TRANSITION_SETTLE_S:
            return

        state.owned = False
        state.baseline_position = None
        state.travel_from = None
        if state.user_override_until <= now:
            if moved or not state.drift_latched:
                state.user_override_until = now + override_minutes * 60
                state.drift_latched = True
                _LOGGER.info(
                    "Cover user override detected [%s]: position %d vs commanded %d → pausing %d min",
                    area_id,
                    position,
                    target,
                    override_minutes,
                )
        elif moved:
            state.user_override_until = now + override_minutes * 60
            state.drift_latched = True

    def get_current_position(self, area_id: str) -> int:
        """Return the last-known cover position for a room (100 if unknown)."""
        return self._get_state(area_id).current_position

    def is_user_override_active(self, area_id: str) -> bool:
        """Return True if user manual override is currently active."""
        return self._get_state(area_id).user_override_until > time.time()

    def get_user_override_until(self, area_id: str) -> float | None:
        """Return the unix timestamp until which a user override is active, or None."""
        until = self._get_state(area_id).user_override_until
        return until if until > time.time() else None

    def clear_user_override(self, area_id: str) -> None:
        """End a user override pause so automatic control resumes next cycle."""
        state = self._get_state(area_id)
        state.user_override_until = 0.0
        # Latch stays set: the still-present drift must not immediately re-arm the pause
        state.drift_latched = True

    def evaluate(
        self,
        area_id: str,
        *,
        covers_auto_enabled: bool,
        cover_entity_ids: list[str],
        covers_deploy_threshold: float,
        covers_min_position: int,
        covers_snap_deploy: bool = False,
        shade_by_need: bool = False,
        predicted_peak_temp: float | None,
        target_temp: float,
        q_solar: float,
        has_active_override: bool,
        forced_position: int | None = None,
        forced_reason: str = "",
        current_temp: float | None = None,
        solar_gated: bool = True,
    ) -> CoverDecision:
        """Evaluate whether to change cover positions this cycle.

        Does NOT call HA services — caller handles that.
        Returns CoverDecision(changed=False) to hold current state.
        """
        state = self._get_state(area_id)
        current = state.current_position

        # Gate 0: No covers configured — nothing to do
        if not cover_entity_ids:
            return CoverDecision(target_position=current, changed=False, reason="disabled")

        # Gate 1: Forced position (schedule or night close) — immediate, no rate limit.
        # Note: the orchestrator returns early when covers_auto_enabled=False, so this gate
        # is only reached when auto control is on (or when evaluate() is called directly).
        # Only user manual override (Gate 1b) can block a forced position.
        if forced_position is not None:
            if state.user_override_until > time.time():
                return CoverDecision(target_position=current, changed=False, reason="user_override_active")
            state.last_was_forced = True
            state.baseline_position = None
            if abs(forced_position - current) <= 2:
                return CoverDecision(
                    target_position=current, changed=False, reason=f"forced_at_target({forced_reason})"
                )
            return self._apply_change(state, forced_position, f"forced({forced_reason})")

        # Gate 2: Auto control disabled — no solar/thermal decisions
        if not covers_auto_enabled:
            return CoverDecision(target_position=current, changed=False, reason="disabled")

        # Gate 2.5: Schedule gate — a gate-mode schedule is off, suppress solar logic
        # Retract owned covers (open) when gate is inactive, subject to rate limit.
        if not solar_gated:
            state.last_was_forced = False
            return self._retract_decision(
                state,
                "gate_inactive",
                "gate_retract",
                hold_time_ok=(time.time() - state.last_change_ts) >= COVER_MIN_HOLD_SECONDS,
                rate_limited_reason="gate_inactive",
            )

        # Gate 3: Manual override — never fight the user
        if has_active_override:
            return CoverDecision(target_position=current, changed=False, reason="manual_override_active")

        # Gate 3b: User manually moved cover (e.g. opened for balcony)
        if state.user_override_until > time.time():
            return CoverDecision(target_position=current, changed=False, reason="user_override_active")

        # Gate 4: Safety check — predicted_peak_temp must be available
        if predicted_peak_temp is None:
            return CoverDecision(target_position=current, changed=False, reason="no_prediction")

        # After forced section: allow immediate transition back to normal control
        was_forced = state.last_was_forced
        state.last_was_forced = False

        # Gate 4: Low solar — only retract if prediction also says no solar threat ahead
        if q_solar < COVER_SOLAR_MIN:
            solar_threat = predicted_peak_temp > target_temp + covers_deploy_threshold and (
                current_temp is None or predicted_peak_temp > current_temp
            )
            if solar_threat:
                return CoverDecision(target_position=current, changed=False, reason="low_solar_but_peak_predicted")
            return self._retract_decision(
                state,
                "low_solar",
                "low_solar_retract",
                hold_time_ok=was_forced or (time.time() - state.last_change_ts) >= COVER_MIN_HOLD_SECONDS,
            )

        # Compute desired position
        excess = predicted_peak_temp - target_temp
        retract_threshold = covers_deploy_threshold - COVER_HYSTERESIS
        now = time.time()
        hold_time_ok = was_forced or (now - state.last_change_ts) >= COVER_MIN_HOLD_SECONDS

        if excess < retract_threshold:
            return self._retract_decision(state, "deadband", "retract", hold_time_ok=hold_time_ok)
        if excess <= covers_deploy_threshold:
            # Hysteresis band — hold
            return CoverDecision(target_position=current, changed=False, reason="hysteresis_hold")

        if covers_snap_deploy:
            desired_pos = covers_min_position
        elif shade_by_need:
            # Close just far enough that the solar overshoot left over is the
            # threshold: shading factor threshold/excess, cover effectiveness
            # COVER_MAX_EFFECTIVENESS. The unit cools what is left, the room keeps daylight.
            needed = (1.0 - covers_deploy_threshold / excess) / COVER_MAX_EFFECTIVENESS
            desired_pos = max(covers_min_position, 100 - int(min(1.0, needed) * 100))
        else:
            raw_close_pct = min(100, int((excess - covers_deploy_threshold) * COVER_POS_SCALE))
            desired_pos = max(covers_min_position, 100 - raw_close_pct)
        if state.baseline_position is not None:
            desired_pos = min(desired_pos, state.baseline_position)
        if desired_pos > current and not state.owned:
            return CoverDecision(target_position=current, changed=False, reason="user_position_hold")

        if not hold_time_ok:
            return CoverDecision(target_position=current, changed=False, reason="min_hold_time")

        # Reopening inside an episode follows the slowly falling afternoon excess;
        # in 20 % steps that was a move every 15 min. An excess just above the
        # threshold maps to fully open and counts as reopening too, otherwise the
        # cover would retract at the threshold instead of below the hysteresis
        # band. The retract below the band (deadband path above) is not affected.
        reopen_ceiling = state.baseline_position if state.baseline_position is not None else 100
        if (
            not was_forced
            and current < desired_pos <= reopen_ceiling
            and (desired_pos - current < COVER_REOPEN_STEP or now - state.last_change_ts < COVER_REOPEN_HOLD_SECONDS)
        ):
            return CoverDecision(target_position=current, changed=False, reason="reopen_hold")

        if abs(desired_pos - current) <= COVER_POS_DEADBAND:
            return CoverDecision(target_position=current, changed=False, reason="deadband")

        if not state.owned and state.baseline_position is None:
            state.baseline_position = current
        reason = f"deploy(excess={excess:.2f}°C→pos={desired_pos}%)" if desired_pos < 100 else "retract"
        return self._apply_change(state, desired_pos, reason)

    def snapshot(self, area_id: str) -> _RoomCoverState:
        """Return a copy of the room's state, to undo an evaluate() whose move is not sent."""
        return replace(self._get_state(area_id))

    def hold(self, area_id: str, snapshot: _RoomCoverState, reason: str) -> CoverDecision:
        """Undo the last evaluate() and keep the covers where they are.

        The next cycle decides afresh, so a held forced position (night close,
        schedule) goes out as soon as the hold ends.
        """
        self._states[area_id] = snapshot
        return CoverDecision(target_position=snapshot.current_position, changed=False, reason=reason)

    def remove_room(self, area_id: str) -> None:
        """Clean up state when a room is deleted."""
        self._states.pop(area_id, None)

    def set_commanded_position(self, area_id: str, position: int) -> None:
        """Correct last_commanded_position after per-cover clamping."""
        state = self._get_state(area_id)
        state.last_commanded_position = position

    @staticmethod
    async def async_apply(
        hass: HomeAssistant,
        cover_entity_ids: list[str],
        target_position: int,
        cover_min_positions: dict[str, int] | None = None,
    ) -> None:
        """Call HA cover service to set position on all configured cover entities."""
        position_eids: list[str] = []
        binary_open_eids: list[str] = []
        binary_close_eids: list[str] = []

        for eid in cover_entity_ids:
            state = hass.states.get(eid)
            if state is None:
                continue
            supported = state.attributes.get("supported_features", 0) or 0
            if supported & _SUPPORT_SET_POSITION:
                position_eids.append(eid)
            elif target_position >= 100:
                binary_open_eids.append(eid)
            else:
                binary_close_eids.append(eid)

        if position_eids:
            if cover_min_positions:
                pos_groups: dict[int, list[str]] = {}
                for eid in position_eids:
                    min_pos = cover_min_positions.get(eid, 0)
                    effective = max(min_pos, target_position)
                    pos_groups.setdefault(effective, []).append(eid)
                for pos, eids in pos_groups.items():
                    await hass.services.async_call(
                        "cover",
                        "set_cover_position",
                        {"entity_id": eids, "position": pos},
                        blocking=False,
                    )
            else:
                await hass.services.async_call(
                    "cover",
                    "set_cover_position",
                    {"entity_id": position_eids, "position": target_position},
                    blocking=False,
                )
        if binary_open_eids:
            await hass.services.async_call(
                "cover",
                "open_cover",
                {"entity_id": binary_open_eids},
                blocking=False,
            )
        if binary_close_eids:
            await hass.services.async_call(
                "cover",
                "close_cover",
                {"entity_id": binary_close_eids},
                blocking=False,
            )

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _get_state(self, area_id: str) -> _RoomCoverState:
        if area_id not in self._states:
            self._states[area_id] = _RoomCoverState()
        return self._states[area_id]

    def _apply_change(self, state: _RoomCoverState, position: int, reason: str) -> CoverDecision:
        state.travel_from = state.current_position
        state.current_position = position
        state.last_commanded_position = position
        state.last_change_ts = time.time()
        state.last_command_ts = time.time()
        state.owned = True
        state.drift_latched = False
        return CoverDecision(target_position=position, changed=True, reason=reason)

    def _retract_decision(
        self,
        state: _RoomCoverState,
        hold_reason: str,
        apply_reason: str,
        hold_time_ok: bool,
        rate_limited_reason: str = "min_hold_time",
    ) -> CoverDecision:
        current = state.current_position
        target = state.baseline_position if state.baseline_position is not None else 100
        # The deadband must not end an episode on RoomMind's own intermediate
        # position: it would be handed to the user and kept overnight.
        restore_pending = state.owned and state.last_commanded_position != target
        if current >= target or (abs(target - current) <= COVER_POS_DEADBAND and not restore_pending):
            if state.baseline_position is not None:
                # Episode ends at/near the user baseline without a command —
                # hand the position back like the command-restore path below.
                state.owned = False
            state.baseline_position = None
            return CoverDecision(target_position=current, changed=False, reason=hold_reason)
        if not state.owned:
            return CoverDecision(target_position=current, changed=False, reason="user_position_hold")
        if not hold_time_ok:
            return CoverDecision(target_position=current, changed=False, reason=rate_limited_reason)
        had_baseline = state.baseline_position is not None
        state.baseline_position = None
        decision = self._apply_change(state, target, apply_reason)
        if had_baseline:
            # Restoring a real user baseline hands the position back to the user —
            # relinquish ownership so the next retract doesn't auto-open it to 100.
            state.owned = False
        return decision
